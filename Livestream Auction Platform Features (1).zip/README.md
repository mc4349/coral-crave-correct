
  # Livestream Auction Platform Features

  This is a code bundle for Livestream Auction Platform Features. The original project is available at https://www.figma.com/design/2gQTceAActATIzn0DbAT5o/Livestream-Auction-Platform-Features.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  