/**
 * Network-aware API utility with fallback support for Coral Crave
 * Handles network failures gracefully in embedded environments
 */

import { projectId } from './supabase/info';
import { toast } from 'sonner@2.0.3';

interface ApiCallOptions {
  endpoint: string;
  method?: 'GET' | 'POST' | 'PUT' | 'DELETE';
  headers?: Record<string, string>;
  body?: any;
  maxRetries?: number;
  timeoutMs?: number;
}

interface FallbackOptions {
  shouldFallback?: boolean;
  fallbackMessage?: string;
  fallbackData?: any;
}

/**
 * Makes an API call with retry logic and fallback support
 */
export async function apiCallWithFallback<T = any>(
  options: ApiCallOptions,
  fallback: FallbackOptions = {}
): Promise<{ success: boolean; data?: T; fallbackUsed?: boolean }> {
  const {
    endpoint,
    method = 'GET',
    headers = {},
    body,
    maxRetries = 3,
    timeoutMs = 10000
  } = options;

  const {
    shouldFallback = true,
    fallbackMessage = 'API unavailable - using local fallback',
    fallbackData = null
  } = fallback;

  // Build full URL
  const url = `https://${projectId}.supabase.co/functions/v1/make-server-9f7745d8${endpoint}`;
  
  // Prepare request options
  const requestOptions: RequestInit = {
    method,
    headers: {
      'Content-Type': 'application/json',
      ...headers,
    },
    signal: AbortSignal.timeout(timeoutMs),
  };

  if (body && method !== 'GET') {
    requestOptions.body = JSON.stringify(body);
  }

  // Try API calls with retries
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      console.log(`🔄 API call attempt ${attempt}/${maxRetries} to ${endpoint}`);
      
      const response = await fetch(url, requestOptions);
      
      if (response.ok) {
        const data = await response.json();
        console.log(`✅ API call successful on attempt ${attempt}:`, endpoint);
        return { success: true, data, fallbackUsed: false };
      } else {
        const errorData = await response.json().catch(() => ({}));
        console.warn(`⚠️ API attempt ${attempt} failed:`, response.status, errorData);
        
        if (attempt === maxRetries) {
          throw new Error(errorData.error || errorData.message || `HTTP ${response.status}`);
        }
      }
    } catch (error) {
      console.warn(`🌐 Network error on attempt ${attempt}:`, error);
      
      if (attempt === maxRetries) {
        if (shouldFallback) {
          console.log(`🎭 ${fallbackMessage}`);
          return { 
            success: true, 
            data: fallbackData, 
            fallbackUsed: true 
          };
        } else {
          throw error;
        }
      }
      
      // Wait before retry with exponential backoff
      await new Promise(resolve => setTimeout(resolve, attempt * 1000));
    }
  }
  
  return { success: false, fallbackUsed: false };
}

/**
 * Specialized function for bid placement with proper fallback
 */
export async function placeBidWithFallback({
  itemId,
  amount,
  maxAmount,
  isProxyBid = false,
  accessToken,
  user
}: {
  itemId: string;
  amount: number;
  maxAmount?: number;
  isProxyBid?: boolean;
  accessToken: string;
  user: { id: string; name: string; email: string };
}): Promise<boolean> {
  try {
    const result = await apiCallWithFallback(
      {
        endpoint: '/bid/place',
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'X-Idempotency-Key': crypto.randomUUID(),
        },
        body: {
          itemId,
          amount,
          maxAmount,
          isProxyBid
        }
      },
      {
        shouldFallback: true,
        fallbackMessage: 'Bid API unavailable - using demo mode',
        fallbackData: {
          id: `fallback_bid_${Date.now()}`,
          itemId,
          amount,
          userId: user.id,
          userName: user.name,
          timestamp: new Date().toISOString(),
          status: 'placed_offline'
        }
      }
    );

    if (result.success) {
      if (result.fallbackUsed) {
        toast.success(
          isProxyBid 
            ? '🎭 Auto-bid placed (Demo Mode - Network Unavailable)' 
            : '🎭 Bid placed (Demo Mode - Network Unavailable)', 
          { 
            description: 'Your bid was processed locally since the server is unreachable.',
            duration: 4000 
          }
        );
      } else {
        toast.success(isProxyBid ? '🤖 Auto-bid placed' : `✅ Bid placed: $${amount}`);
      }
      
      return true;
    }
    
    return false;
  } catch (error) {
    console.error('Bid placement completely failed:', error);
    toast.error(`❌ Failed to place bid: ${error instanceof Error ? error.message : 'Unknown error'}`);
    return false;
  }
}

/**
 * Check network connectivity
 */
export async function checkNetworkConnectivity(): Promise<boolean> {
  try {
    // Try a simple health check
    const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-9f7745d8/ping`, {
      method: 'GET',
      signal: AbortSignal.timeout(5000),
    });
    
    return response.ok;
  } catch (error) {
    console.warn('Network connectivity check failed:', error);
    return false;
  }
}

/**
 * Show network status to user
 */
export function showNetworkStatus() {
  checkNetworkConnectivity().then(isOnline => {
    if (!isOnline) {
      toast.info('🌐 Network Unavailable', {
        description: 'Using demo mode - your actions are simulated locally.',
        duration: 3000
      });
    } else {
      toast.success('🌐 Connected to Coral Crave servers', {
        duration: 2000
      });
    }
  });
}

export default {
  apiCallWithFallback,
  placeBidWithFallback,
  checkNetworkConnectivity,
  showNetworkStatus
};