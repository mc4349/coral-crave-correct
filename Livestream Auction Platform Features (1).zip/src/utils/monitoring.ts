import { projectId, publicAnonKey } from './supabase/info';

class MonitoringService {
  private baseUrl: string;
  private headers: Record<string, string>;

  constructor() {
    this.baseUrl = `https://${projectId}.supabase.co/functions/v1/make-server-9f7745d8/monitoring`;
    this.headers = {
      'Authorization': `Bearer ${publicAnonKey}`,
      'Content-Type': 'application/json'
    };
  }

  // Log API requests automatically
  async logRequest(endpoint: string, method: string, responseTime: number, statusCode: number) {
    try {
      // Add timeout and error handling
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 3000); // Reduced from 5 to 3 seconds
      
      await fetch(`${this.baseUrl}/log-request`, {
        method: 'POST',
        headers: this.headers,
        body: JSON.stringify({
          endpoint,
          method,
          responseTime,
          statusCode,
          userAgent: typeof navigator !== 'undefined' ? navigator.userAgent : 'Unknown',
          ip: 'client-side' // Client-side can't get real IP
        }),
        signal: controller.signal
      });
      
      clearTimeout(timeoutId);
    } catch (error) {
      // Silently ignore monitoring errors to prevent error loops
      if (!(error instanceof Error && error.name === 'AbortError')) {
        console.debug('Monitoring log request failed (non-critical):', error instanceof Error ? error.message : error);
      }
    }
  }

  // Log errors
  async logError(error: string, endpoint: string, stack?: string, userId?: string) {
    try {
      // Add timeout and error handling
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 3000); // Reduced from 5 to 3 seconds
      
      await fetch(`${this.baseUrl}/log-error`, {
        method: 'POST',
        headers: this.headers,
        body: JSON.stringify({
          error,
          endpoint,
          stack,
          userId
        }),
        signal: controller.signal
      });
      
      clearTimeout(timeoutId);
    } catch (err) {
      // Silently ignore monitoring errors to prevent error loops
      if (!(err instanceof Error && err.name === 'AbortError')) {
        console.debug('Monitoring log error failed (non-critical):', err instanceof Error ? err.message : err);
      }
    }
  }

  // Log user activity
  async logActivity(userId: string, action: string, details: any = {}) {
    try {
      // Add timeout and error handling
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 3000); // Reduced from 5 to 3 seconds
      
      await fetch(`${this.baseUrl}/log-activity`, {
        method: 'POST',
        headers: this.headers,
        body: JSON.stringify({
          userId,
          action,
          details: {
            ...details,
            timestamp: Date.now(),
            userAgent: typeof navigator !== 'undefined' ? navigator.userAgent : 'Unknown',
            url: typeof window !== 'undefined' ? window.location.href : 'Unknown'
          }
        }),
        signal: controller.signal
      });
      
      clearTimeout(timeoutId);
    } catch (error) {
      // Silently ignore monitoring errors to prevent error loops
      if (!(error instanceof Error && error.name === 'AbortError')) {
        console.debug('Monitoring log activity failed (non-critical):', error instanceof Error ? error.message : error);
      }
    }
  }

  // Create system alert
  async createAlert(type: 'info' | 'warning' | 'error' | 'critical', title: string, message: string) {
    try {
      const response = await fetch(`${this.baseUrl}/create-alert`, {
        method: 'POST',
        headers: this.headers,
        body: JSON.stringify({
          type,
          title,
          message
        })
      });
      
      const result = await response.json();
      return result.alertId;
    } catch (error) {
      console.warn('Failed to create alert:', error);
      return null;
    }
  }

  // Resolve alert
  async resolveAlert(alertId: string) {
    try {
      await fetch(`${this.baseUrl}/resolve-alert/${alertId}`, {
        method: 'POST',
        headers: this.headers
      });
    } catch (error) {
      console.warn('Failed to resolve alert:', error);
    }
  }

  // Get monitoring dashboard data
  async getDashboardData() {
    try {
      const response = await fetch(`${this.baseUrl}/dashboard`, {
        headers: this.headers
      });
      
      if (response.ok) {
        return await response.json();
      } else {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
    } catch (error) {
      console.error('Failed to fetch dashboard data:', error);
      throw error;
    }
  }

  // Get detailed health metrics
  async getDetailedHealth() {
    try {
      const response = await fetch(`${this.baseUrl}/health-detailed`, {
        headers: this.headers
      });
      
      if (response.ok) {
        return await response.json();
      } else {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
    } catch (error) {
      console.error('Failed to fetch detailed health:', error);
      throw error;
    }
  }

  // Get monitoring statistics
  async getStats() {
    try {
      const response = await fetch(`${this.baseUrl}/stats`, {
        headers: this.headers
      });
      
      if (response.ok) {
        return await response.json();
      } else {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
    } catch (error) {
      console.error('Failed to fetch stats:', error);
      throw error;
    }
  }
}

// Create singleton instance
export const monitoring = new MonitoringService();

// Auto-monitor fetch requests (only in browser environment)
if (typeof window !== 'undefined' && window.fetch) {
  const originalFetch = window.fetch;
  
  // Add flag to prevent infinite loops
  let isMonitoringEnabled = true;
  
  window.fetch = async (...args) => {
    // Skip monitoring for monitoring endpoints to prevent loops
    const [resource] = args;
    const url = typeof resource === 'string' ? resource : resource.url;
    
    if (!isMonitoringEnabled || url.includes('/monitoring/')) {
      return originalFetch(...args);
    }
    
    const startTime = Date.now();
    const [originalResource, config] = args;
    const method = config?.method || 'GET';

    try {
      const response = await originalFetch(...args);
      const responseTime = Date.now() - startTime;
      
      // Only log API calls to our Supabase functions (but exclude monitoring endpoints)
      if (url.includes('supabase.co/functions/v1/make-server-9f7745d8')) {
        const endpoint = url.split('/make-server-9f7745d8')[1] || '/';
        // Use setTimeout to prevent blocking the main thread
        setTimeout(() => {
          monitoring.logRequest(endpoint, method, responseTime, response.status);
          
          // Log errors for non-2xx responses
          if (!response.ok) {
            monitoring.logError(
              `HTTP ${response.status}: ${response.statusText}`,
              endpoint,
              undefined,
              localStorage.getItem('currentUserId') || undefined
            );
          }
        }, 100);
      }
      
      return response;
    } catch (error) {
      const responseTime = Date.now() - startTime;
      
      // Log network errors (excluding monitoring endpoints)
      if (url.includes('supabase.co/functions/v1/make-server-9f7745d8')) {
        const endpoint = url.split('/make-server-9f7745d8')[1] || '/';
        // Use setTimeout to prevent blocking the main thread
        setTimeout(() => {
          monitoring.logRequest(endpoint, method, responseTime, 0);
          monitoring.logError(
            error instanceof Error ? error.message : 'Network error',
            endpoint,
            error instanceof Error ? error.stack : undefined,
            localStorage.getItem('currentUserId') || undefined
          );
        }, 100);
      }
      
      throw error;
    }
  };
  
  // Provide way to disable monitoring if needed
  (window as any).disableMonitoring = () => { isMonitoringEnabled = false; };
  (window as any).enableMonitoring = () => { isMonitoringEnabled = true; };
}

// Auto-monitor global errors (only in browser environment)
if (typeof window !== 'undefined') {
  window.addEventListener('error', (event) => {
    // Filter out common non-critical errors to prevent spam
    const errorMessage = event.error?.message || event.message || 'Global error';
    
    // Skip monitoring, oauth, and network-related errors
    if (errorMessage.includes('127.0.0.1') || 
        errorMessage.includes('localhost') ||
        errorMessage.includes('ERR_CONNECTION_REFUSED') ||
        errorMessage.includes('accounts.google.com') ||
        errorMessage.includes('X-Frame-Options') ||
        errorMessage.includes('heartbeat') ||
        errorMessage.includes('monitoring')) {
      return;
    }
    
    monitoring.logError(
      errorMessage,
      window.location.pathname,
      event.error?.stack,
      localStorage.getItem('currentUserId') || undefined
    );
  });

  // Auto-monitor unhandled promise rejections
  window.addEventListener('unhandledrejection', (event) => {
    const errorMessage = event.reason?.message || 'Unhandled promise rejection';
    
    // Filter out common non-critical errors
    if (errorMessage.includes('127.0.0.1') || 
        errorMessage.includes('localhost') ||
        errorMessage.includes('ERR_CONNECTION_REFUSED') ||
        errorMessage.includes('accounts.google.com') ||
        errorMessage.includes('X-Frame-Options') ||
        errorMessage.includes('heartbeat') ||
        errorMessage.includes('monitoring')) {
      return;
    }
    
    monitoring.logError(
      errorMessage,
      window.location.pathname,
      event.reason?.stack,
      localStorage.getItem('currentUserId') || undefined
    );
  });
}

// Helper functions for common monitoring tasks
export const trackUserAction = (userId: string, action: string, details?: any) => {
  monitoring.logActivity(userId, action, details);
};

export const createSystemAlert = (type: 'info' | 'warning' | 'error' | 'critical', title: string, message: string) => {
  return monitoring.createAlert(type, title, message);
};

export const trackPageView = (userId?: string) => {
  if (userId && typeof window !== 'undefined') {
    monitoring.logActivity(userId, 'page_view', {
      page: window.location.pathname,
      referrer: document.referrer,
      timestamp: Date.now()
    });
  }
};

export const trackUserSession = (userId: string, action: 'login' | 'logout') => {
  monitoring.logActivity(userId, action, {
    timestamp: Date.now(),
    sessionId: Date.now().toString()
  });
  
  // Store user ID for error tracking (only in browser environment)
  if (typeof window !== 'undefined' && localStorage) {
    if (action === 'login') {
      localStorage.setItem('currentUserId', userId);
    } else {
      localStorage.removeItem('currentUserId');
    }
  }
};

export default monitoring;