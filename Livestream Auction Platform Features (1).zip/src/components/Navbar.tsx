import React from 'react';
import { Search, Bell, User, ShoppingCart } from 'lucide-react';

interface NavbarProps {
  user?: any;
  onSearchClick?: () => void;
  onNotificationsClick?: () => void;
  onProfileClick?: () => void;
  onCartClick?: () => void;
}

export function Navbar({ user, onSearchClick, onNotificationsClick, onProfileClick, onCartClick }: NavbarProps) {
  return (
    <nav className="bg-gray-800 border-b border-gray-700 px-4 py-3">
      <div className="flex items-center justify-between">
        {/* Logo */}
        <div className="flex items-center gap-2">
          <span className="text-2xl">🪸</span>
          <h1 className="text-xl font-bold text-cyan-400">Coral Crave</h1>
        </div>

        {/* Actions */}
        <div className="flex items-center gap-3">
          <button
            onClick={onSearchClick}
            className="p-2 text-gray-400 hover:text-white rounded-lg hover:bg-gray-700 transition-colors"
          >
            <Search size={20} />
          </button>
          
          <button
            onClick={onNotificationsClick}
            className="p-2 text-gray-400 hover:text-white rounded-lg hover:bg-gray-700 transition-colors relative"
          >
            <Bell size={20} />
            {/* Notification badge */}
            <span className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full"></span>
          </button>
          
          <button
            onClick={onCartClick}
            className="p-2 text-gray-400 hover:text-white rounded-lg hover:bg-gray-700 transition-colors"
          >
            <ShoppingCart size={20} />
          </button>
          
          <button
            onClick={onProfileClick}
            className="flex items-center gap-2 p-2 text-gray-400 hover:text-white rounded-lg hover:bg-gray-700 transition-colors"
          >
            <User size={20} />
            {user && <span className="text-sm">{user.name}</span>}
          </button>
        </div>
      </div>
    </nav>
  );
}