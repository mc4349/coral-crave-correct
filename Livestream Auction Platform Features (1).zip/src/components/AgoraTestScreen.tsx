import React, { useState, useEffect } from 'react';
import { Play, Users, CheckCircle, XCircle, AlertCircle } from 'lucide-react';
import { AGORA_CONFIG, loadAgoraSDK, isAgoraSDKLoaded } from '../utils/agora-config';

interface User {
  id: string;
  email: string;
  name: string;
}

interface AgoraTestProps {
  user: User | null;
  onBack: () => void;
}

export function AgoraTestScreen({ user, onBack }: AgoraTestProps) {
  const [testResults, setTestResults] = useState({
    sdkLoaded: false,
    configValid: false,
    tokenGenerated: false,
    connectionTest: false
  });
  const [loading, setLoading] = useState(false);
  const [logs, setLogs] = useState<string[]>([]);

  const addLog = (message: string) => {
    const timestamp = new Date().toLocaleTimeString();
    setLogs(prev => [...prev, `[${timestamp}] ${message}`]);
    console.log(message);
  };

  useEffect(() => {
    // Check initial SDK status
    setTestResults(prev => ({
      ...prev,
      sdkLoaded: isAgoraSDKLoaded(),
      configValid: !!AGORA_CONFIG.APP_ID
    }));
  }, []);

  const runFullTest = async () => {
    setLoading(true);
    setLogs([]);
    setTestResults({
      sdkLoaded: false,
      configValid: false,
      tokenGenerated: false,
      connectionTest: false
    });

    try {
      // Test 1: SDK Loading
      addLog('🔄 Testing Agora SDK loading...');
      await loadAgoraSDK();
      setTestResults(prev => ({ ...prev, sdkLoaded: true }));
      addLog('✅ Agora SDK loaded successfully');

      // Test 2: Configuration Check  
      addLog('🔄 Checking Agora configuration...');
      if (AGORA_CONFIG.APP_ID) {
        setTestResults(prev => ({ ...prev, configValid: true }));
        addLog(`✅ App ID configured: ${AGORA_CONFIG.APP_ID}`);
      } else {
        addLog('❌ App ID not configured');
        return;
      }

      // Test 3: Token Generation
      addLog('🔄 Testing token generation...');
      try {
        const { api } = await import('../utils/api');
        const tokenResponse = await api.getAgoraToken({
          channelName: 'test_channel_' + Date.now(),
          role: 'publisher',
          uid: '12345'
        });
        
        setTestResults(prev => ({ ...prev, tokenGenerated: true }));
        addLog(`✅ Token generated: ${tokenResponse.tokenType || 'success'}`);
        addLog(`   App ID: ${tokenResponse.appId}`);
        addLog(`   UID: ${tokenResponse.uid}`);
        addLog(`   Has Token: ${!!tokenResponse.token}`);
        
      } catch (error) {
        addLog(`⚠️ Token generation failed: ${error.message}`);
        // This might be expected if certificate isn't configured
      }

      // Test 4: Basic Connection Test
      addLog('🔄 Testing basic Agora client creation...');
      try {
        const client = window.AgoraRTC.createClient({
          mode: 'live',
          codec: 'vp8'
        });
        
        if (client) {
          setTestResults(prev => ({ ...prev, connectionTest: true }));
          addLog('✅ Agora client created successfully');
        }
      } catch (error) {
        addLog(`❌ Client creation failed: ${error.message}`);
      }

    } catch (error) {
      addLog(`❌ Test failed: ${error.message}`);
    } finally {
      setLoading(false);
      addLog('🏁 Test completed');
    }
  };

  const TestResult = ({ title, status, description }: { title: string; status: boolean; description: string }) => (
    <div className="flex items-center justify-between p-4 bg-gray-700 rounded-lg">
      <div className="flex items-center gap-3">
        {status ? (
          <CheckCircle className="text-green-400" size={20} />
        ) : (
          <XCircle className="text-red-400" size={20} />
        )}
        <div>
          <h4 className="text-white font-medium">{title}</h4>
          <p className="text-gray-400 text-sm">{description}</p>
        </div>
      </div>
      <span className={`px-2 py-1 rounded text-xs font-medium ${
        status ? 'bg-green-500 text-white' : 'bg-red-500 text-white'
      }`}>
        {status ? 'PASS' : 'FAIL'}
      </span>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-900 text-white p-6">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <button
            onClick={onBack}
            className="text-cyan-400 hover:text-cyan-300 mb-4"
          >
            ← Back to Dashboard
          </button>
          <h1 className="text-3xl font-bold mb-2">🔧 Agora Integration Test</h1>
          <p className="text-gray-400">
            Test your Agora livestreaming setup for Coral Crave
          </p>
        </div>

        {/* Configuration Info */}
        <div className="bg-gray-800 rounded-xl p-6 mb-6">
          <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
            <AlertCircle className="text-yellow-400" size={20} />
            Current Configuration
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
            <div>
              <span className="text-gray-400">App ID:</span>
              <span className="text-white ml-2 font-mono">{AGORA_CONFIG.APP_ID}</span>
            </div>
            <div>
              <span className="text-gray-400">Mode:</span>
              <span className="text-white ml-2">{AGORA_CONFIG.MODE}</span>
            </div>
            <div>
              <span className="text-gray-400">Codec:</span>
              <span className="text-white ml-2">{AGORA_CONFIG.CODEC}</span>
            </div>
            <div>
              <span className="text-gray-400">SDK Version:</span>
              <span className="text-white ml-2">4.19.0</span>
            </div>
          </div>
        </div>

        {/* Test Controls */}
        <div className="bg-gray-800 rounded-xl p-6 mb-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold">Integration Tests</h2>
            <button
              onClick={runFullTest}
              disabled={loading}
              className="bg-cyan-500 text-white px-6 py-2 rounded-lg hover:bg-cyan-400 transition-colors disabled:opacity-50 flex items-center gap-2"
            >
              {loading ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                  Running Tests...
                </>
              ) : (
                <>
                  <Play size={16} />
                  Run All Tests
                </>
              )}
            </button>
          </div>

          <div className="space-y-3">
            <TestResult
              title="Agora SDK Loading"
              status={testResults.sdkLoaded}
              description="Checks if the Agora Web SDK can be loaded from CDN"
            />
            <TestResult
              title="Configuration Validation"
              status={testResults.configValid}
              description="Verifies that App ID and settings are properly configured"
            />
            <TestResult
              title="Token Generation"
              status={testResults.tokenGenerated}
              description="Tests server-side token generation (may use null token for development)"
            />
            <TestResult
              title="Client Creation"
              status={testResults.connectionTest}
              description="Verifies that Agora client can be created with current settings"
            />
          </div>
        </div>

        {/* Test Logs */}
        {logs.length > 0 && (
          <div className="bg-gray-800 rounded-xl p-6">
            <h2 className="text-xl font-bold mb-4">Test Logs</h2>
            <div className="bg-black rounded-lg p-4 max-h-64 overflow-y-auto">
              {logs.map((log, index) => (
                <div key={index} className="text-sm text-gray-300 font-mono mb-1">
                  {log}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Next Steps */}
        <div className="mt-6 bg-blue-500 bg-opacity-20 border border-blue-500 rounded-xl p-6">
          <h3 className="text-lg font-bold text-blue-400 mb-2">💡 Next Steps</h3>
          <ul className="text-blue-200 text-sm space-y-1">
            <li>• If all tests pass, your Agora integration is ready!</li>
            <li>• Token generation may use null tokens in development (this is normal)</li>
            <li>• For production, ensure AGORA_APP_CERTIFICATE is properly configured</li>
            <li>• Test livestreaming by going to "Go Live" and starting a stream</li>
          </ul>
        </div>
      </div>
    </div>
  );
}