import React, { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { 
  Bell, 
  MessageSquare, 
  Gavel, 
  DollarSign,
  Truck,
  Calendar,
  User,
  Check,
  X,
  MoreVertical,
  Archive,
  Trash,
  Eye,
  EyeOff
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { formatDistanceToNow } from 'date-fns';
import { projectId, publicAnonKey } from '../utils/supabase/info';

interface Notification {
  id: string;
  userId: string;
  type: 'message' | 'bid_outbid' | 'bid_won' | 'payment_received' | 'shipping_address_available' | 'show_reminder' | 'system';
  title: string;
  message: string;
  read: boolean;
  createdAt: string;
  metadata?: {
    senderId?: string;
    senderName?: string;
    conversationId?: string;
    orderId?: string;
    itemId?: string;
    itemName?: string;
    amount?: number;
    streamId?: string;
    showId?: string;
  };
}

interface EnhancedNotificationsProps {
  userId: string;
  userToken: string;
  onNotificationRead?: (notificationId: string) => void;
  onNewMessage?: (notification: Notification) => void;
}

export function EnhancedNotifications({
  userId,
  userToken,
  onNotificationRead,
  onNewMessage
}: EnhancedNotificationsProps) {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | 'unread' | 'messages' | 'auctions'>('all');
  const [showArchived, setShowArchived] = useState(false);

  useEffect(() => {
    loadNotifications();
    
    // Set up real-time notifications (in a real app, this would use WebSocket/SSE)
    const interval = setInterval(loadNotifications, 30000);
    return () => clearInterval(interval);
  }, [userId]);

  const loadNotifications = async () => {
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-9f7745d8/notifications`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${userToken}`,
          'Content-Type': 'application/json'
        }
      });

      if (response.ok) {
        const data = await response.json();
        setNotifications(data.notifications || []);
      } else {
        throw new Error(`HTTP ${response.status}`);
      }
    } catch (error) {
      console.error('Failed to load notifications:', error);
      toast.error('Failed to load notifications');
    } finally {
      setLoading(false);
    }
  };

  const markAsRead = async (notificationId: string) => {
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-9f7745d8/notifications/${notificationId}/read`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${userToken}`
        }
      });

      if (response.ok) {
        setNotifications(prev => prev.map(notif => 
          notif.id === notificationId ? { ...notif, read: true } : notif
        ));
        onNotificationRead?.(notificationId);
      }
    } catch (error) {
      console.error('Failed to mark notification as read:', error);
    }
  };

  const markAllAsRead = async () => {
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-9f7745d8/notifications/mark-all-read`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${userToken}`
        }
      });

      if (response.ok) {
        setNotifications(prev => prev.map(notif => ({ ...notif, read: true })));
        toast.success('All notifications marked as read');
      }
    } catch (error) {
      console.error('Failed to mark all notifications as read:', error);
      toast.error('Failed to mark all notifications as read');
    }
  };

  const deleteNotification = async (notificationId: string) => {
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-9f7745d8/notifications/${notificationId}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${userToken}`
        }
      });

      if (response.ok) {
        setNotifications(prev => prev.filter(notif => notif.id !== notificationId));
        toast.success('Notification deleted');
      }
    } catch (error) {
      console.error('Failed to delete notification:', error);
      toast.error('Failed to delete notification');
    }
  };

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'message': return <MessageSquare className="h-4 w-4" />;
      case 'bid_outbid': return <Gavel className="h-4 w-4" />;
      case 'bid_won': return <Gavel className="h-4 w-4" />;
      case 'payment_received': return <DollarSign className="h-4 w-4" />;
      case 'shipping_address_available': return <Truck className="h-4 w-4" />;
      case 'show_reminder': return <Calendar className="h-4 w-4" />;
      case 'system': return <Bell className="h-4 w-4" />;
      default: return <Bell className="h-4 w-4" />;
    }
  };

  const getNotificationColor = (type: string) => {
    switch (type) {
      case 'message': return 'text-blue-400';
      case 'bid_outbid': return 'text-red-400';
      case 'bid_won': return 'text-green-400';
      case 'payment_received': return 'text-green-400';
      case 'shipping_address_available': return 'text-orange-400';
      case 'show_reminder': return 'text-purple-400';
      case 'system': return 'text-gray-400';
      default: return 'text-gray-400';
    }
  };

  const filteredNotifications = notifications.filter(notif => {
    if (filter === 'unread' && notif.read) return false;
    if (filter === 'messages' && notif.type !== 'message') return false;
    if (filter === 'auctions' && !['bid_outbid', 'bid_won', 'payment_received'].includes(notif.type)) return false;
    return true;
  });

  const unreadCount = notifications.filter(notif => !notif.read).length;

  return (
    <Card className="bg-gray-800 border-gray-700">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <Bell className="h-6 w-6 text-cyan-400" />
            <div>
              <CardTitle className="text-white">Notifications</CardTitle>
              <CardDescription>
                Stay updated with messages, bids, and auction activity
              </CardDescription>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            {unreadCount > 0 && (
              <Badge className="bg-red-500 text-white">
                {unreadCount}
              </Badge>
            )}
            {unreadCount > 0 && (
              <Button
                onClick={markAllAsRead}
                size="sm"
                variant="outline"
              >
                Mark All Read
              </Button>
            )}
          </div>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Filter Tabs */}
        <div className="flex space-x-1 bg-gray-700 rounded-lg p-1">
          {[
            { key: 'all', label: 'All' },
            { key: 'unread', label: 'Unread' },
            { key: 'messages', label: 'Messages' },
            { key: 'auctions', label: 'Auctions' }
          ].map((tab) => (
            <button
              key={tab.key}
              onClick={() => setFilter(tab.key as any)}
              className={`flex-1 px-3 py-2 text-sm rounded-md transition-colors ${
                filter === tab.key
                  ? 'bg-cyan-500 text-white'
                  : 'text-gray-300 hover:text-white hover:bg-gray-600'
              }`}
            >
              {tab.label}
              {tab.key === 'unread' && unreadCount > 0 && (
                <span className="ml-1 bg-red-500 text-white text-xs px-1 rounded-full">
                  {unreadCount}
                </span>
              )}
            </button>
          ))}
        </div>

        {/* Notifications List */}
        {loading ? (
          <div className="flex items-center justify-center py-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-cyan-400"></div>
            <span className="ml-2 text-gray-400">Loading notifications...</span>
          </div>
        ) : filteredNotifications.length === 0 ? (
          <div className="text-center py-8">
            <Bell className="mx-auto h-12 w-12 text-gray-400 mb-4" />
            <h3 className="text-lg font-medium text-gray-300 mb-2">
              {filter === 'unread' ? 'No unread notifications' : 'No notifications'}
            </h3>
            <p className="text-gray-400">
              {filter === 'messages' 
                ? 'No messages yet. Start a conversation!'
                : filter === 'auctions'
                ? 'No auction notifications. Place some bids!'
                : 'You\'ll see notifications here when you have activity'
              }
            </p>
          </div>
        ) : (
          <div className="space-y-3 max-h-96 overflow-y-auto">
            {filteredNotifications.map((notification) => (
              <Card 
                key={notification.id}
                className={`bg-gray-700 border-gray-600 cursor-pointer transition-all hover:bg-gray-600 ${
                  !notification.read ? 'ring-2 ring-cyan-400 ring-opacity-50' : ''
                }`}
                onClick={() => !notification.read && markAsRead(notification.id)}
              >
                <CardContent className="p-4">
                  <div className="flex items-start justify-between">
                    <div className="flex items-start space-x-3 flex-1">
                      <div className={`${getNotificationColor(notification.type)} mt-1`}>
                        {getNotificationIcon(notification.type)}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center space-x-2 mb-1">
                          <h4 className="font-medium text-white truncate">
                            {notification.title}
                          </h4>
                          {!notification.read && (
                            <div className="w-2 h-2 bg-cyan-400 rounded-full flex-shrink-0"></div>
                          )}
                        </div>
                        <p className="text-gray-300 text-sm mb-2">
                          {notification.message}
                        </p>
                        
                        {/* Metadata Display */}
                        {notification.metadata && (
                          <div className="flex flex-wrap gap-2 mb-2">
                            {notification.metadata.senderName && (
                              <Badge variant="outline" className="text-xs">
                                <User className="h-3 w-3 mr-1" />
                                {notification.metadata.senderName}
                              </Badge>
                            )}
                            {notification.metadata.itemName && (
                              <Badge variant="outline" className="text-xs">
                                {notification.metadata.itemName}
                              </Badge>
                            )}
                            {notification.metadata.amount && (
                              <Badge variant="outline" className="text-xs text-green-400">
                                ${notification.metadata.amount}
                              </Badge>
                            )}
                          </div>
                        )}
                        
                        <div className="flex items-center justify-between">
                          <span className="text-xs text-gray-400">
                            {formatDistanceToNow(new Date(notification.createdAt), { addSuffix: true })}
                          </span>
                          
                          {/* Action buttons based on notification type */}
                          {notification.type === 'message' && notification.metadata?.conversationId && (
                            <Button
                              size="sm"
                              variant="outline"
                              className="text-xs"
                              onClick={(e) => {
                                e.stopPropagation();
                                // Navigate to conversation
                                toast.info('Opening conversation...');
                              }}
                            >
                              Reply
                            </Button>
                          )}
                          
                          {notification.type === 'shipping_address_available' && notification.metadata?.orderId && (
                            <Button
                              size="sm"
                              variant="outline"
                              className="text-xs"
                              onClick={(e) => {
                                e.stopPropagation();
                                // Navigate to shipping info
                                toast.info('Opening shipping details...');
                              }}
                            >
                              View Address
                            </Button>
                          )}
                          
                          {notification.type === 'bid_won' && notification.metadata?.orderId && (
                            <Button
                              size="sm"
                              variant="outline"
                              className="text-xs text-green-400 border-green-400"
                              onClick={(e) => {
                                e.stopPropagation();
                                // Navigate to payment
                                toast.info('Opening payment page...');
                              }}
                            >
                              Pay Now
                            </Button>
                          )}
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-2 ml-2">
                      {!notification.read && (
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={(e) => {
                            e.stopPropagation();
                            markAsRead(notification.id);
                          }}
                          className="text-cyan-400 hover:bg-cyan-400 hover:text-black"
                        >
                          <Check className="h-4 w-4" />
                        </Button>
                      )}
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={(e) => {
                          e.stopPropagation();
                          deleteNotification(notification.id);
                        }}
                        className="text-red-400 hover:bg-red-400 hover:text-white"
                      >
                        <Trash className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}