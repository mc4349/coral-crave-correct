import React from 'react';
import { Video, Plus } from 'lucide-react';

interface GoLiveButtonProps {
  onClick: () => void;
  isLive?: boolean;
  disabled?: boolean;
  variant?: 'primary' | 'secondary' | 'floating';
  className?: string;
}

export function GoLiveButton({ 
  onClick, 
  isLive = false, 
  disabled = false, 
  variant = 'primary',
  className = ''
}: GoLiveButtonProps) {
  const getButtonStyles = () => {
    const baseStyles = "flex items-center gap-2 font-medium transition-colors rounded-lg";
    
    switch (variant) {
      case 'floating':
        return `${baseStyles} fixed bottom-24 right-4 w-14 h-14 bg-red-500 hover:bg-red-600 text-white rounded-full shadow-lg justify-center md:hidden ${className}`;
      case 'secondary':
        return `${baseStyles} bg-gray-700 hover:bg-gray-600 text-white px-4 py-2 ${className}`;
      default:
        return `${baseStyles} bg-red-500 hover:bg-red-600 text-white px-6 py-3 ${className}`;
    }
  };

  const getContent = () => {
    if (variant === 'floating') {
      return isLive ? <Video size={24} /> : <Plus size={24} />;
    }
    
    return (
      <>
        <Video size={20} />
        {isLive ? 'You\'re Live' : 'Go Live'}
      </>
    );
  };

  return (
    <button
      onClick={onClick}
      disabled={disabled || isLive}
      className={`${getButtonStyles()} ${disabled ? 'opacity-50 cursor-not-allowed' : ''} ${isLive ? 'bg-green-500 hover:bg-green-600' : ''}`}
    >
      {getContent()}
    </button>
  );
}