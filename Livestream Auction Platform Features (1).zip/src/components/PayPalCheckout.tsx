import React, { useEffect, useState } from 'react';
import { CreditCard, Loader2, CheckCircle, XCircle, AlertTriangle } from 'lucide-react';
import { Button } from './ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Alert, AlertDescription } from './ui/alert';
import { projectId, publicAnonKey } from '../utils/supabase/info';
import { supabase } from '../utils/supabase/client';

// PayPal SDK script loader
declare global {
  interface Window {
    paypal?: {
      Buttons: (options: any) => {
        render: (container: string) => Promise<void>;
      };
    };
  }
}

interface PayPalCheckoutProps {
  isOpen: boolean;
  onClose: () => void;
  amount: number;
  currency?: string;
  description: string;
  auctionId: string;
  itemId: string;
  itemTitle: string;
  sellerMerchantId?: string;
  onSuccess: (purchaseId: string) => void;
  onError: (error: string) => void;
}

interface PayPalOrder {
  orderId: string;
  approvalUrl: string;
}

export function PayPalCheckout({
  isOpen,
  onClose,
  amount,
  currency = 'USD',
  description,
  auctionId,
  itemId,
  itemTitle,
  sellerMerchantId,
  onSuccess,
  onError
}: PayPalCheckoutProps) {
  const [loading, setLoading] = useState(false);
  const [scriptLoaded, setScriptLoaded] = useState(false);
  const [currentOrder, setCurrentOrder] = useState<PayPalOrder | null>(null);
  const [status, setStatus] = useState<'idle' | 'creating' | 'approving' | 'capturing' | 'success' | 'error'>('idle');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [purchaseId, setPurchaseId] = useState<string | null>(null);

  // Load PayPal SDK
  useEffect(() => {
    if (isOpen && !scriptLoaded) {
      // Get production PayPal client ID from server
      const loadPayPalSDK = async () => {
        try {
          // Get the PayPal client ID from the server
          const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-9f7745d8/config/paypal-client-id`, {
            headers: {
              'Authorization': `Bearer ${publicAnonKey}`
            }
          });
          
          let clientId = 'AbaLVJ8ORlm5lRkHufYnUW8AyGRXc8iDN1tD-j0iGDa3RFts4Mqklnu4SsuiMIY_HDvk_ZufEOuzKGdz'; // Fallback
          
          if (response.ok) {
            const data = await response.json();
            clientId = data.clientId || clientId;
            console.log('💳 Using PayPal Client ID from server');
          } else {
            console.warn('⚠️ Could not get PayPal client ID from server, using fallback');
          }

          const script = document.createElement('script');
          script.src = `https://www.paypal.com/sdk/js?client-id=${clientId}&currency=${currency}&intent=capture`;
          script.addEventListener('load', () => {
            console.log('💳 PayPal SDK loaded (Production Mode)');
            setScriptLoaded(true);
          });
          script.addEventListener('error', () => {
            console.error('❌ Failed to load PayPal SDK');
            setErrorMessage('Failed to load PayPal SDK');
            setStatus('error');
          });
          document.body.appendChild(script);

          return () => {
            // Clean up script if component unmounts
            if (document.body.contains(script)) {
              document.body.removeChild(script);
            }
          };
        } catch (error) {
          console.error('Failed to load PayPal configuration:', error);
          // Use fallback if server request fails
          const script = document.createElement('script');
          script.src = `https://www.paypal.com/sdk/js?client-id=AbaLVJ8ORlm5lRkHufYnUW8AyGRXc8iDN1tD-j0iGDa3RFts4Mqklnu4SsuiMIY_HDvk_ZufEOuzKGdz&currency=${currency}&intent=capture`;
          script.addEventListener('load', () => {
            console.log('💳 PayPal SDK loaded (Fallback Client ID)');
            setScriptLoaded(true);
          });
          script.addEventListener('error', () => {
            console.error('❌ Failed to load PayPal SDK');
            setErrorMessage('Failed to load PayPal SDK');
            setStatus('error');
          });
          document.body.appendChild(script);
        }
      };

      loadPayPalSDK();
    }
  }, [isOpen, scriptLoaded, currency]);

  // Initialize PayPal buttons when SDK is loaded
  useEffect(() => {
    if (scriptLoaded && window.paypal && isOpen && status === 'idle') {
      initializePayPalButtons();
    }
  }, [scriptLoaded, isOpen, status]);

  const createPayPalOrder = async (): Promise<string> => {
    try {
      setStatus('creating');
      console.log('🔄 Creating PayPal order...');

      // Get access token from Supabase session
      const { data: { session } } = await supabase.auth.getSession();
      
      if (!session?.access_token) {
        throw new Error('Please log in to make a purchase');
      }
      
      const accessToken = session.access_token;

      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-9f7745d8/paypal/create-order`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`,
        },
        body: JSON.stringify({
          amount: amount.toFixed(2),
          currency,
          description,
          auctionId,
          itemId,
          sellerMerchantId
        })
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to create PayPal order');
      }

      const data = await response.json();
      console.log('✅ PayPal order created:', data.orderId);

      setCurrentOrder({
        orderId: data.orderId,
        approvalUrl: data.approvalUrl
      });

      return data.orderId;
    } catch (error) {
      console.error('❌ PayPal order creation failed:', error);
      const message = error instanceof Error ? error.message : 'Failed to create PayPal order';
      setErrorMessage(message);
      setStatus('error');
      onError(message);
      throw error;
    }
  };

  const capturePayPalOrder = async (orderId: string): Promise<void> => {
    try {
      setStatus('capturing');
      console.log('💰 Capturing PayPal order:', orderId);

      // Get access token from Supabase session
      const { data: { session } } = await supabase.auth.getSession();
      const accessToken = session?.access_token;

      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-9f7745d8/paypal/capture-order`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`,
        },
        body: JSON.stringify({ orderId })
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to capture PayPal order');
      }

      const data = await response.json();
      console.log('✅ PayPal order captured:', data.purchaseId);

      setPurchaseId(data.purchaseId);
      setStatus('success');
      onSuccess(data.purchaseId);
    } catch (error) {
      console.error('❌ PayPal order capture failed:', error);
      const message = error instanceof Error ? error.message : 'Failed to capture payment';
      setErrorMessage(message);
      setStatus('error');
      onError(message);
    }
  };

  const initializePayPalButtons = () => {
    if (!window.paypal) return;

    const paypalButtonsComponent = window.paypal.Buttons({
      style: {
        layout: 'vertical',
        color: 'blue',
        shape: 'rect',
        label: 'paypal'
      },
      
      createOrder: async () => {
        try {
          return await createPayPalOrder();
        } catch (error) {
          console.error('PayPal createOrder error:', error);
          throw error;
        }
      },

      onApprove: async (data: any) => {
        try {
          setStatus('approving');
          console.log('✅ PayPal payment approved:', data.orderID);
          await capturePayPalOrder(data.orderID);
        } catch (error) {
          console.error('PayPal onApprove error:', error);
        }
      },

      onError: (err: any) => {
        console.error('PayPal error:', err);
        setErrorMessage('PayPal payment error occurred');
        setStatus('error');
        onError('PayPal payment error occurred');
      },

      onCancel: () => {
        console.log('PayPal payment cancelled by user');
        setStatus('idle');
      }
    });

    // Clear previous buttons and render new ones
    const container = document.getElementById('paypal-button-container');
    if (container) {
      container.innerHTML = '';
      paypalButtonsComponent.render('#paypal-button-container').catch((error: any) => {
        console.error('PayPal button render error:', error);
        setErrorMessage('Failed to load PayPal buttons');
        setStatus('error');
      });
    }
  };

  const handleClose = () => {
    setStatus('idle');
    setErrorMessage(null);
    setCurrentOrder(null);
    setPurchaseId(null);
    onClose();
  };

  const getStatusIcon = () => {
    switch (status) {
      case 'creating':
      case 'approving':
      case 'capturing':
        return <Loader2 className="w-5 h-5 animate-spin text-cyan-400" />;
      case 'success':
        return <CheckCircle className="w-5 h-5 text-green-400" />;
      case 'error':
        return <XCircle className="w-5 h-5 text-red-400" />;
      default:
        return <CreditCard className="w-5 h-5 text-cyan-400" />;
    }
  };

  const getStatusMessage = () => {
    switch (status) {
      case 'creating':
        return 'Creating payment order...';
      case 'approving':
        return 'Processing your approval...';
      case 'capturing':
        return 'Completing your purchase...';
      case 'success':
        return 'Payment successful! Your purchase is complete.';
      case 'error':
        return errorMessage || 'An error occurred';
      default:
        return 'Complete your purchase with PayPal';
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md bg-gray-800 border-gray-700">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-white">
            {getStatusIcon()}
            Complete Purchase
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {/* Purchase Details */}
          <div className="bg-gray-700 p-4 rounded-lg">
            <h3 className="font-medium text-white mb-2">{itemTitle}</h3>
            <p className="text-sm text-gray-300 mb-3">{description}</p>
            <div className="flex justify-between items-center">
              <span className="text-gray-300">Total:</span>
              <span className="text-xl font-bold text-cyan-400">
                ${amount.toFixed(2)} {currency}
              </span>
            </div>
          </div>

          {/* Status Message */}
          <Alert className="bg-gray-700 border-gray-600">
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription className="text-gray-300">
              {getStatusMessage()}
            </AlertDescription>
          </Alert>

          {/* PayPal Buttons Container */}
          {scriptLoaded && status !== 'success' && status !== 'error' && (
            <div id="paypal-button-container" className="mt-4"></div>
          )}

          {/* Success State */}
          {status === 'success' && purchaseId && (
            <div className="text-center py-4">
              <CheckCircle className="w-12 h-12 text-green-400 mx-auto mb-3" />
              <h3 className="text-lg font-medium text-white mb-2">Payment Successful!</h3>
              <p className="text-sm text-gray-300 mb-4">
                Your purchase has been completed successfully.
              </p>
              <p className="text-xs text-gray-400">
                Purchase ID: {purchaseId}
              </p>
              <Button onClick={handleClose} className="mt-4">
                Continue
              </Button>
            </div>
          )}

          {/* Error State */}
          {status === 'error' && (
            <div className="text-center py-4">
              <XCircle className="w-12 h-12 text-red-400 mx-auto mb-3" />
              <h3 className="text-lg font-medium text-white mb-2">Payment Failed</h3>
              <p className="text-sm text-gray-300 mb-4">
                {errorMessage || 'An error occurred during payment processing.'}
              </p>
              <div className="flex gap-2 justify-center">
                <Button variant="outline" onClick={() => setStatus('idle')}>
                  Try Again
                </Button>
                <Button variant="secondary" onClick={handleClose}>
                  Cancel
                </Button>
              </div>
            </div>
          )}

          {/* Loading State */}
          {!scriptLoaded && status === 'idle' && (
            <div className="text-center py-8">
              <Loader2 className="w-8 h-8 animate-spin text-cyan-400 mx-auto mb-3" />
              <p className="text-sm text-gray-300">Loading PayPal...</p>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}