import React, { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Users, UserPlus, Shield, Crown, Trash2, Volume2, VolumeX, Ban, MessageSquare, Clock, Settings } from 'lucide-react';
import { createClient } from '@supabase/supabase-js';
import { projectId, publicAnonKey } from '../utils/supabase/info';

const supabase = createClient(
  `https://${projectId}.supabase.co`,
  publicAnonKey
);

interface StreamRole {
  id: string;
  userId: string;
  username: string;
  role: 'host' | 'co-host' | 'moderator';
  permissions: string[];
  addedAt: number;
  addedBy: string;
}

interface StreamRoleManagerProps {
  streamId: string;
  currentUserId: string;
  userRole: 'host' | 'co-host' | 'moderator' | 'viewer';
  onRoleChange?: (roles: StreamRole[]) => void;
  className?: string;
}

interface ModerationAction {
  id: string;
  type: 'mute' | 'ban' | 'delete_message' | 'slow_mode';
  targetUserId?: string;
  targetUsername?: string;
  moderatorId: string;
  moderatorUsername: string;
  duration?: number;
  reason?: string;
  timestamp: number;
}

export function StreamRoleManager({ 
  streamId, 
  currentUserId, 
  userRole, 
  onRoleChange,
  className = "" 
}: StreamRoleManagerProps) {
  const [roles, setRoles] = useState<StreamRole[]>([]);
  const [moderationActions, setModerationActions] = useState<ModerationAction[]>([]);
  const [inviteUsername, setInviteUsername] = useState('');
  const [inviteRole, setInviteRole] = useState<'co-host' | 'moderator'>('moderator');
  const [slowModeEnabled, setSlowModeEnabled] = useState(false);
  const [slowModeInterval, setSlowModeInterval] = useState(3);
  const [isInviting, setIsInviting] = useState(false);
  const [showModerationLog, setShowModerationLog] = useState(false);

  // Load roles and moderation state
  useEffect(() => {
    loadStreamRoles();
    loadModerationState();
  }, [streamId]);

  const loadStreamRoles = async () => {
    try {
      // In a real implementation, this would fetch from your database
      // For now, we'll simulate with mock data
      const mockRoles: StreamRole[] = [
        {
          id: '1',
          userId: currentUserId,
          username: 'Stream Host',
          role: 'host',
          permissions: ['all'],
          addedAt: Date.now() - 3600000,
          addedBy: 'system'
        }
      ];
      
      setRoles(mockRoles);
      onRoleChange?.(mockRoles);
    } catch (error) {
      console.error('Failed to load stream roles:', error);
    }
  };

  const loadModerationState = async () => {
    try {
      // Load slow mode and other moderation settings
      setSlowModeEnabled(false);
      setSlowModeInterval(3);
      setModerationActions([]);
    } catch (error) {
      console.error('Failed to load moderation state:', error);
    }
  };

  const handleInviteUser = async () => {
    if (!inviteUsername.trim() || !canManageRoles()) return;

    try {
      setIsInviting(true);
      
      // In a real implementation, this would:
      // 1. Validate the username exists
      // 2. Check they're not already invited
      // 3. Send the invitation
      // 4. Add to the roles list once accepted

      const newRole: StreamRole = {
        id: Date.now().toString(),
        userId: `user_${Date.now()}`,
        username: inviteUsername.trim(),
        role: inviteRole,
        permissions: getPermissionsForRole(inviteRole),
        addedAt: Date.now(),
        addedBy: currentUserId
      };

      const updatedRoles = [...roles, newRole];
      setRoles(updatedRoles);
      onRoleChange?.(updatedRoles);
      
      setInviteUsername('');
      console.log(`Invited ${inviteUsername} as ${inviteRole}`);
    } catch (error) {
      console.error('Failed to invite user:', error);
    } finally {
      setIsInviting(false);
    }
  };

  const handleRemoveRole = async (roleId: string) => {
    if (!canManageRoles()) return;

    try {
      const updatedRoles = roles.filter(role => role.id !== roleId);
      setRoles(updatedRoles);
      onRoleChange?.(updatedRoles);
      
      console.log(`Removed role ${roleId}`);
    } catch (error) {
      console.error('Failed to remove role:', error);
    }
  };

  const handleMuteUser = async (username: string, duration: number) => {
    if (!canModerate()) return;

    try {
      const action: ModerationAction = {
        id: Date.now().toString(),
        type: 'mute',
        targetUsername: username,
        moderatorId: currentUserId,
        moderatorUsername: getCurrentUserRole()?.username || 'Unknown',
        duration,
        timestamp: Date.now()
      };

      setModerationActions(prev => [action, ...prev]);
      console.log(`Muted ${username} for ${duration} minutes`);
      
      // In real implementation, this would update the chat system
    } catch (error) {
      console.error('Failed to mute user:', error);
    }
  };

  const handleBanUser = async (username: string, reason?: string) => {
    if (!canModerate()) return;

    try {
      const action: ModerationAction = {
        id: Date.now().toString(),
        type: 'ban',
        targetUsername: username,
        moderatorId: currentUserId,
        moderatorUsername: getCurrentUserRole()?.username || 'Unknown',
        reason,
        timestamp: Date.now()
      };

      setModerationActions(prev => [action, ...prev]);
      console.log(`Banned ${username}${reason ? ` for: ${reason}` : ''}`);
      
      // In real implementation, this would update the chat system
    } catch (error) {
      console.error('Failed to ban user:', error);
    }
  };

  const handleToggleSlowMode = async () => {
    if (!canModerate()) return;

    try {
      const newSlowModeState = !slowModeEnabled;
      setSlowModeEnabled(newSlowModeState);
      
      const action: ModerationAction = {
        id: Date.now().toString(),
        type: 'slow_mode',
        moderatorId: currentUserId,
        moderatorUsername: getCurrentUserRole()?.username || 'Unknown',
        duration: newSlowModeState ? slowModeInterval : 0,
        timestamp: Date.now()
      };

      setModerationActions(prev => [action, ...prev]);
      console.log(`${newSlowModeState ? 'Enabled' : 'Disabled'} slow mode`);
    } catch (error) {
      console.error('Failed to toggle slow mode:', error);
    }
  };

  const getPermissionsForRole = (role: 'co-host' | 'moderator'): string[] => {
    switch (role) {
      case 'co-host':
        return ['start_items', 'end_items', 'adjust_timer', 'pin_items', 'moderate_chat'];
      case 'moderator':
        return ['moderate_chat', 'delete_messages', 'mute_users', 'ban_users', 'slow_mode'];
      default:
        return [];
    }
  };

  const getCurrentUserRole = () => {
    return roles.find(role => role.userId === currentUserId);
  };

  const canManageRoles = () => {
    return userRole === 'host';
  };

  const canModerate = () => {
    return ['host', 'co-host', 'moderator'].includes(userRole);
  };

  const getRoleIcon = (role: string) => {
    switch (role) {
      case 'host':
        return <Crown className="text-yellow-400" size={16} />;
      case 'co-host':
        return <Shield className="text-purple-400" size={16} />;
      case 'moderator':
        return <Shield className="text-blue-400" size={16} />;
      default:
        return null;
    }
  };

  const getRoleBadge = (role: string) => {
    const colors = {
      host: 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30',
      'co-host': 'bg-purple-500/20 text-purple-400 border-purple-500/30',
      moderator: 'bg-blue-500/20 text-blue-400 border-blue-500/30'
    };

    return (
      <Badge variant="outline" className={colors[role as keyof typeof colors]}>
        {getRoleIcon(role)}
        <span className="ml-1 capitalize">{role.replace('-', ' ')}</span>
      </Badge>
    );
  };

  const formatDuration = (minutes: number) => {
    if (minutes < 60) return `${minutes}m`;
    const hours = Math.floor(minutes / 60);
    const remainingMinutes = minutes % 60;
    return `${hours}h${remainingMinutes > 0 ? ` ${remainingMinutes}m` : ''}`;
  };

  return (
    <div className={`space-y-4 ${className}`}>
      {/* Role Management - Host Only */}
      {canManageRoles() && (
        <div className="bg-gray-800 rounded-lg p-4">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-medium text-white flex items-center gap-2">
              <Users size={18} />
              Stream Roles
            </h3>
            <Dialog>
              <DialogTrigger asChild>
                <Button size="sm" className="bg-cyan-600 hover:bg-cyan-500">
                  <UserPlus size={14} className="mr-1" />
                  Invite
                </Button>
              </DialogTrigger>
              <DialogContent className="bg-gray-900 border-gray-700">
                <DialogHeader>
                  <DialogTitle className="text-white">Invite User</DialogTitle>
                  <DialogDescription className="text-gray-400">
                    Add a co-host or moderator to help manage your stream
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4 mt-4">
                  <div>
                    <label className="block text-sm text-gray-300 mb-2">Username</label>
                    <Input
                      value={inviteUsername}
                      onChange={(e) => setInviteUsername(e.target.value)}
                      placeholder="Enter username"
                      className="bg-gray-800 border-gray-600 text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-sm text-gray-300 mb-2">Role</label>
                    <Select value={inviteRole} onValueChange={(value: 'co-host' | 'moderator') => setInviteRole(value)}>
                      <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-gray-800 border-gray-700">
                        <SelectItem value="moderator">Moderator - Chat moderation only</SelectItem>
                        <SelectItem value="co-host">Co-Host - Full auction controls</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <Button
                    onClick={handleInviteUser}
                    disabled={isInviting || !inviteUsername.trim()}
                    className="w-full bg-cyan-600 hover:bg-cyan-500"
                  >
                    {isInviting ? 'Inviting...' : 'Send Invitation'}
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>

          {/* Current Roles */}
          <div className="space-y-2">
            {roles.map((role) => (
              <div key={role.id} className="flex items-center justify-between p-3 bg-gray-700 rounded-lg">
                <div className="flex items-center gap-3">
                  <span className="text-white font-medium">{role.username}</span>
                  {getRoleBadge(role.role)}
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-gray-400">
                    Added {new Date(role.addedAt).toLocaleDateString()}
                  </span>
                  {role.role !== 'host' && (
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleRemoveRole(role.id)}
                      className="text-red-400 border-red-400 hover:bg-red-400 hover:text-white"
                    >
                      <Trash2 size={14} />
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Moderation Controls */}
      {canModerate() && (
        <div className="bg-gray-800 rounded-lg p-4">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-medium text-white flex items-center gap-2">
              <Shield size={18} />
              Moderation Tools
            </h3>
            <Button
              size="sm"
              variant="outline"
              onClick={() => setShowModerationLog(!showModerationLog)}
              className="text-gray-400 border-gray-600"
            >
              <MessageSquare size={14} className="mr-1" />
              {showModerationLog ? 'Hide' : 'Show'} Log
            </Button>
          </div>

          {/* Quick Actions */}
          <div className="grid grid-cols-2 gap-3">
            <Button
              onClick={handleToggleSlowMode}
              variant={slowModeEnabled ? "default" : "outline"}
              className={slowModeEnabled ? "bg-orange-600 hover:bg-orange-500" : "border-gray-600 text-gray-300"}
            >
              <Clock size={14} className="mr-1" />
              Slow Mode {slowModeEnabled ? 'ON' : 'OFF'}
            </Button>
            
            <Dialog>
              <DialogTrigger asChild>
                <Button variant="outline" className="border-gray-600 text-gray-300">
                  <Settings size={14} className="mr-1" />
                  Settings
                </Button>
              </DialogTrigger>
              <DialogContent className="bg-gray-900 border-gray-700">
                <DialogHeader>
                  <DialogTitle className="text-white">Moderation Settings</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 mt-4">
                  <div>
                    <label className="block text-sm text-gray-300 mb-2">Slow Mode Interval</label>
                    <Select 
                      value={slowModeInterval.toString()} 
                      onValueChange={(value) => setSlowModeInterval(parseInt(value))}
                    >
                      <SelectTrigger className="bg-gray-800 border-gray-600 text-white">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent className="bg-gray-800 border-gray-700">
                        <SelectItem value="3">3 seconds</SelectItem>
                        <SelectItem value="5">5 seconds</SelectItem>
                        <SelectItem value="10">10 seconds</SelectItem>
                        <SelectItem value="30">30 seconds</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          </div>

          {/* Quick Moderation Actions */}
          <div className="mt-4 p-3 bg-gray-700/50 rounded-lg">
            <div className="text-sm text-gray-400 mb-2">Quick Actions</div>
            <div className="grid grid-cols-3 gap-2">
              <Button
                size="sm"
                variant="outline"
                onClick={() => handleMuteUser('example_user', 5)}
                className="text-orange-400 border-orange-400 hover:bg-orange-400 hover:text-white"
              >
                <VolumeX size={12} className="mr-1" />
                Mute 5m
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={() => handleMuteUser('example_user', 60)}
                className="text-red-400 border-red-400 hover:bg-red-400 hover:text-white"
              >
                <VolumeX size={12} className="mr-1" />
                Mute 1h
              </Button>
              <Button
                size="sm"
                variant="outline"
                onClick={() => handleBanUser('example_user', 'Spam')}
                className="text-red-500 border-red-500 hover:bg-red-500 hover:text-white"
              >
                <Ban size={12} className="mr-1" />
                Ban
              </Button>
            </div>
          </div>

          {/* Moderation Log */}
          {showModerationLog && (
            <div className="mt-4 space-y-2">
              <div className="text-sm text-gray-400">Recent Actions</div>
              <div className="max-h-32 overflow-y-auto space-y-1">
                {moderationActions.length > 0 ? (
                  moderationActions.map((action) => (
                    <div key={action.id} className="text-xs p-2 bg-gray-700/50 rounded">
                      <span className="text-blue-400">{action.moderatorUsername}</span>
                      <span className="text-gray-300 ml-1">
                        {action.type === 'mute' && `muted ${action.targetUsername} for ${formatDuration(action.duration!)}`}
                        {action.type === 'ban' && `banned ${action.targetUsername}`}
                        {action.type === 'slow_mode' && `${action.duration! > 0 ? 'enabled' : 'disabled'} slow mode`}
                      </span>
                      <span className="text-gray-500 ml-2">
                        {new Date(action.timestamp).toLocaleTimeString()}
                      </span>
                    </div>
                  ))
                ) : (
                  <div className="text-xs text-gray-500 p-2">No recent moderation actions</div>
                )}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Role Display for Non-Managers */}
      {!canManageRoles() && !canModerate() && (
        <div className="bg-gray-800 rounded-lg p-4">
          <h3 className="font-medium text-white mb-3">Stream Team</h3>
          <div className="space-y-2">
            {roles.map((role) => (
              <div key={role.id} className="flex items-center justify-between">
                <span className="text-gray-300">{role.username}</span>
                {getRoleBadge(role.role)}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}