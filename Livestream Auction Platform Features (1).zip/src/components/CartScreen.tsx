import React, { useState, useEffect } from 'react';
import { ShoppingCart, Package, CreditCard, CheckCircle, Plus, Minus, Truck } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { Checkbox } from './ui/checkbox';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { PayPalCheckout } from './PayPalCheckout';

interface CartItem {
  id: string;
  auctionItemId: string;
  title: string;
  image: string;
  winningBid: number;
  sellerId: string;
  sellerName: string;
  weight: number; // in lbs for shipping calculation
  dimensions: {
    length: number;
    width: number;
    height: number;
  };
  itemPaidStatus: 'paid' | 'pending';
  shippingStatus: 'pending' | 'calculated' | 'paid' | 'shipped';
  shippingCost?: number;
  canCombineShipping: boolean;
}

interface ShippingGroup {
  sellerId: string;
  sellerName: string;
  items: CartItem[];
  totalWeight: number;
  combinedShipping: boolean;
  shippingCost: number;
}

interface CartScreenProps {
  userId: string;
  onPaymentSuccess: () => void;
}

export function CartScreen({ userId, onPaymentSuccess }: CartScreenProps) {
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [shippingGroups, setShippingGroups] = useState<ShippingGroup[]>([]);
  const [loading, setLoading] = useState(true);
  const [calculatingShipping, setCalculatingShipping] = useState(false);
  const [paymentStep, setPaymentStep] = useState<'cart' | 'payment' | 'success'>('cart');
  const [totalShippingCost, setTotalShippingCost] = useState(0);

  useEffect(() => {
    fetchCartItems();
  }, [userId]);

  useEffect(() => {
    if (cartItems.length > 0) {
      organizeShippingGroups();
    }
  }, [cartItems]);

  const fetchCartItems = async () => {
    try {
      const response = await fetch(
        `https://${window.supabase?.supabaseUrl?.split('//')[1]}/functions/v1/make-server-9f7745d8/cart-items?userId=${userId}`,
        {
          headers: {
            'Authorization': `Bearer ${window.supabase?.supabaseKey}`
          }
        }
      );

      if (response.ok) {
        const data = await response.json();
        setCartItems(data.items || []);
      }
    } catch (error) {
      console.error('Failed to fetch cart items:', error);
    } finally {
      setLoading(false);
    }
  };

  const organizeShippingGroups = () => {
    const groupedBySeller: { [sellerId: string]: CartItem[] } = {};
    
    cartItems.forEach(item => {
      if (!groupedBySeller[item.sellerId]) {
        groupedBySeller[item.sellerId] = [];
      }
      groupedBySeller[item.sellerId].push(item);
    });

    const groups: ShippingGroup[] = Object.entries(groupedBySeller).map(([sellerId, items]) => {
      const totalWeight = items.reduce((sum, item) => sum + item.weight, 0);
      const canCombine = items.every(item => item.canCombineShipping);
      
      return {
        sellerId,
        sellerName: items[0].sellerName,
        items,
        totalWeight,
        combinedShipping: canCombine && items.length > 1,
        shippingCost: 0
      };
    });

    setShippingGroups(groups);
    calculateShippingCosts(groups);
  };

  const calculateShippingCosts = async (groups: ShippingGroup[]) => {
    setCalculatingShipping(true);
    
    try {
      const response = await fetch(
        `https://${window.supabase?.supabaseUrl?.split('//')[1]}/functions/v1/make-server-9f7745d8/calculate-shipping`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${window.supabase?.supabaseKey}`
          },
          body: JSON.stringify({
            shippingGroups: groups,
            buyerId: userId
          })
        }
      );

      if (response.ok) {
        const data = await response.json();
        const updatedGroups = groups.map((group, index) => ({
          ...group,
          shippingCost: data.shippingCosts[index] || 0
        }));
        
        setShippingGroups(updatedGroups);
        
        const total = updatedGroups.reduce((sum, group) => sum + group.shippingCost, 0);
        setTotalShippingCost(total);
      }
    } catch (error) {
      console.error('Failed to calculate shipping:', error);
      // Use default shipping calculation based on weight
      const updatedGroups = groups.map(group => ({
        ...group,
        shippingCost: calculateDefaultShipping(group.totalWeight, group.combinedShipping)
      }));
      
      setShippingGroups(updatedGroups);
      const total = updatedGroups.reduce((sum, group) => sum + group.shippingCost, 0);
      setTotalShippingCost(total);
    } finally {
      setCalculatingShipping(false);
    }
  };

  const calculateDefaultShipping = (weight: number, combined: boolean): number => {
    const baseRate = 8.99;
    const perPoundRate = 1.50;
    const combinedDiscount = 0.8; // 20% discount for combined shipping
    
    let cost = baseRate + (weight * perPoundRate);
    if (combined) {
      cost *= combinedDiscount;
    }
    
    return Math.max(cost, 5.99); // Minimum shipping cost
  };

  const toggleCombinedShipping = (sellerId: string) => {
    setShippingGroups(prev => prev.map(group => {
      if (group.sellerId === sellerId && group.items.every(item => item.canCombineShipping)) {
        const newCombined = !group.combinedShipping;
        return {
          ...group,
          combinedShipping: newCombined,
          shippingCost: calculateDefaultShipping(group.totalWeight, newCombined)
        };
      }
      return group;
    }));
    
    // Recalculate total
    const total = shippingGroups.reduce((sum, group) => sum + group.shippingCost, 0);
    setTotalShippingCost(total);
  };

  const handlePayShipping = () => {
    setPaymentStep('payment');
  };

  const handlePaymentSuccess = async (paymentId: string) => {
    try {
      const response = await fetch(
        `https://${window.supabase?.supabaseUrl?.split('//')[1]}/functions/v1/make-server-9f7745d8/process-shipping-payment`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${window.supabase?.supabaseKey}`
          },
          body: JSON.stringify({
            userId,
            paymentId,
            shippingGroups,
            totalAmount: totalShippingCost
          })
        }
      );

      if (response.ok) {
        setPaymentStep('success');
        setTimeout(() => {
          onPaymentSuccess();
        }, 3000);
      }
    } catch (error) {
      console.error('Failed to process shipping payment:', error);
    }
  };

  if (loading) {
    return (
      <div className="p-6">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-gray-700 rounded w-1/4"></div>
          <div className="space-y-3">
            {[1, 2, 3].map(i => (
              <div key={i} className="h-32 bg-gray-700 rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  if (paymentStep === 'success') {
    return (
      <div className="p-6 flex items-center justify-center min-h-96">
        <Card className="w-full max-w-md bg-gray-800 border-gray-700">
          <CardContent className="p-8 text-center">
            <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
            <h2 className="text-2xl font-semibold text-white mb-2">Shipping Paid!</h2>
            <p className="text-gray-300 mb-4">
              Your shipping fees have been processed successfully.
            </p>
            <p className="text-sm text-cyan-400">
              Your items will ship once sellers receive your payment confirmation.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (paymentStep === 'payment') {
    return (
      <div className="p-6">
        <Card className="max-w-2xl mx-auto bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle className="text-xl text-white flex items-center">
              <CreditCard className="w-5 h-5 mr-2" />
              Pay Shipping Fees
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            {/* Order Summary */}
            <div className="mb-6">
              <h3 className="font-semibold text-white mb-4">Shipping Summary</h3>
              <div className="space-y-3">
                {shippingGroups.map((group) => (
                  <div key={group.sellerId} className="flex justify-between items-center p-3 bg-gray-700 rounded-lg">
                    <div>
                      <p className="text-white font-medium">{group.sellerName}</p>
                      <p className="text-sm text-gray-400">
                        {group.items.length} item{group.items.length > 1 ? 's' : ''} • {group.totalWeight} lbs
                        {group.combinedShipping && ' • Combined shipping'}
                      </p>
                    </div>
                    <span className="text-white font-semibold">${group.shippingCost.toFixed(2)}</span>
                  </div>
                ))}
              </div>
              
              <Separator className="my-4 bg-gray-600" />
              
              <div className="flex justify-between items-center">
                <span className="text-lg font-semibold text-white">Total Shipping</span>
                <span className="text-xl font-bold text-white">${totalShippingCost.toFixed(2)}</span>
              </div>
            </div>

            {/* Payment Method */}
            <div className="mb-6">
              <PayPalCheckout
                amount={totalShippingCost}
                onSuccess={handlePaymentSuccess}
                onError={(error) => console.error('Payment error:', error)}
                label={`Pay $${totalShippingCost.toFixed(2)} Shipping`}
              />
            </div>

            <Button
              onClick={() => setPaymentStep('cart')}
              variant="outline"
              className="w-full border-gray-600 text-gray-300 hover:bg-gray-700"
            >
              Back to Cart
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-white flex items-center">
          <ShoppingCart className="w-6 h-6 mr-2" />
          Shipping Cart
        </h1>
        <Badge variant="secondary" className="bg-cyan-500/20 text-cyan-400">
          {cartItems.length} items
        </Badge>
      </div>

      {cartItems.length === 0 ? (
        <Card className="bg-gray-800 border-gray-700">
          <CardContent className="p-8 text-center">
            <Package className="w-12 h-12 text-gray-500 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-400">Your cart is empty</h3>
            <p className="text-gray-500">
              Items you win at auctions will appear here for shipping payment.
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-6">
          {/* Shipping Groups */}
          {shippingGroups.map((group) => (
            <Card key={group.sellerId} className="bg-gray-800 border-gray-700">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-lg text-white flex items-center">
                    <Truck className="w-5 h-5 mr-2" />
                    {group.sellerName}
                  </CardTitle>
                  {group.items.length > 1 && group.items.every(item => item.canCombineShipping) && (
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id={`combine-${group.sellerId}`}
                        checked={group.combinedShipping}
                        onCheckedChange={() => toggleCombinedShipping(group.sellerId)}
                      />
                      <label 
                        htmlFor={`combine-${group.sellerId}`} 
                        className="text-sm text-gray-300 cursor-pointer"
                      >
                        Combine shipping
                      </label>
                    </div>
                  )}
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {group.items.map((item) => (
                    <div key={item.id} className="flex items-center space-x-4 p-4 bg-gray-700 rounded-lg">
                      <ImageWithFallback
                        src={item.image}
                        alt={item.title}
                        className="w-16 h-16 object-cover rounded-lg"
                      />
                      <div className="flex-1">
                        <h4 className="font-medium text-white">{item.title}</h4>
                        <div className="flex items-center space-x-2 mt-1">
                          <Badge variant="default" className="bg-green-500/20 text-green-400">
                            {item.itemPaidStatus === 'paid' ? 'Paid for item' : 'Payment pending'}
                          </Badge>
                          <span className="text-sm text-gray-400">
                            {item.weight} lbs
                          </span>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="font-semibold text-white">${item.winningBid.toFixed(2)}</p>
                        <p className="text-sm text-gray-400">Item cost</p>
                      </div>
                    </div>
                  ))}
                  
                  <Separator className="bg-gray-600" />
                  
                  <div className="flex justify-between items-center">
                    <div>
                      <p className="text-white font-medium">Shipping Cost</p>
                      <p className="text-sm text-gray-400">
                        {group.totalWeight} lbs total
                        {group.combinedShipping && ' • 20% combined discount applied'}
                      </p>
                    </div>
                    <div className="text-right">
                      {calculatingShipping ? (
                        <div className="w-4 h-4 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin" />
                      ) : (
                        <span className="text-xl font-bold text-white">
                          ${group.shippingCost.toFixed(2)}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}

          {/* Cart Summary */}
          <Card className="bg-gray-800 border-gray-700">
            <CardContent className="p-6">
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-gray-300">Items ({cartItems.length})</span>
                  <span className="text-gray-300">Paid separately</span>
                </div>
                
                <div className="flex justify-between items-center">
                  <span className="text-gray-300">Total Shipping</span>
                  <span className="text-white font-semibold">
                    {calculatingShipping ? 'Calculating...' : `$${totalShippingCost.toFixed(2)}`}
                  </span>
                </div>
                
                <Separator className="bg-gray-600" />
                
                <div className="flex justify-between items-center">
                  <span className="text-xl font-bold text-white">Total Due</span>
                  <span className="text-2xl font-bold text-cyan-400">
                    ${totalShippingCost.toFixed(2)}
                  </span>
                </div>

                <Button
                  onClick={handlePayShipping}
                  disabled={calculatingShipping || totalShippingCost === 0}
                  className="w-full bg-cyan-600 hover:bg-cyan-700 text-white py-3"
                >
                  <CreditCard className="w-5 h-5 mr-2" />
                  Pay Shipping Fees
                </Button>

                <p className="text-sm text-gray-400 text-center">
                  💡 Items ship after shipping is paid. Sellers will provide tracking numbers.
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}