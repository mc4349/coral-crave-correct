import React, { useState } from 'react';
import { X, LogIn, UserPlus } from 'lucide-react';
import { supabase } from '../utils/supabase/client';

interface SimpleAuthModalProps {
  onClose: () => void;
  onSuccess: () => void;
}

export function SimpleAuthModal({ onClose, onSuccess }: SimpleAuthModalProps) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const handleDemoLogin = async () => {
    setLoading(true);
    setError('');
    setSuccess('');

    try {
      console.log('🟦 Starting demo login process...');
      
      // Try to sign in with demo account first
      console.log('🔍 Attempting to sign in with existing demo account...');
      const { data: signInData, error: signInError } = await supabase.auth.signInWithPassword({
        email: 'demo@coralcrave.com',
        password: 'demo123456'
      });

      if (signInError) {
        console.log('⚠️ Demo account does not exist, creating new one...');
        console.log('Sign in error:', signInError.message);
        
        // If demo account doesn't exist, create it using Supabase Admin API
        console.log('🔧 Creating demo account...');
        
        // Use the client to create the user (this will work if auth is properly configured)
        const { data: signUpData, error: signUpError } = await supabase.auth.signUp({
          email: 'demo@coralcrave.com',
          password: 'demo123456',
          options: {
            data: {
              name: 'Demo User'
            }
          }
        });

        if (signUpError) {
          console.error('❌ Failed to create demo account:', signUpError);
          throw new Error(`Failed to create demo account: ${signUpError.message}`);
        }

        console.log('✅ Demo account created successfully');
        setSuccess('Demo account created and logged in successfully!');
      } else {
        console.log('✅ Successfully signed in with existing demo account');
        setSuccess('Successfully signed in with demo account!');
      }

      // Close modal and notify parent
      setTimeout(() => {
        onSuccess();
        onClose();
      }, 1000);

    } catch (err: any) {
      console.error('💥 Demo login error:', err);
      setError(err.message || 'Failed to sign in with demo account');
    } finally {
      setLoading(false);
    }
  };

  const handleQuickSignUp = async () => {
    setLoading(true);
    setError('');
    setSuccess('');

    try {
      console.log('🔵 Creating quick test account...');
      
      const randomId = Math.random().toString(36).substring(7);
      const testEmail = `test${randomId}@coralcrave.com`;
      const testPassword = 'testpass123';

      const { data, error } = await supabase.auth.signUp({
        email: testEmail,
        password: testPassword,
        options: {
          data: {
            name: `Test User ${randomId}`
          }
        }
      });

      if (error) {
        console.error('❌ Quick signup error:', error);
        throw error;
      }

      console.log('✅ Quick test account created successfully');
      setSuccess(`Test account created! Email: ${testEmail}`);
      
      setTimeout(() => {
        onSuccess();
        onClose();
      }, 1500);

    } catch (err: any) {
      console.error('💥 Quick signup error:', err);
      setError(err.message || 'Failed to create test account');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl max-w-md w-full p-8 shadow-2xl">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-gray-900">
            🪸 Welcome to Coral Crave
          </h2>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600 transition-colors"
          >
            <X size={24} />
          </button>
        </div>

        <div className="space-y-4">
          {/* Demo Login Button */}
          <button
            onClick={handleDemoLogin}
            disabled={loading}
            className="w-full bg-gradient-to-r from-cyan-500 to-blue-500 text-white py-4 rounded-lg hover:from-cyan-600 hover:to-blue-600 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-3"
          >
            <LogIn size={20} />
            {loading ? 'Signing in...' : 'Try Demo Account'}
          </button>

          {/* Quick Test Account Button */}
          <button
            onClick={handleQuickSignUp}
            disabled={loading}
            className="w-full bg-gradient-to-r from-green-500 to-emerald-500 text-white py-4 rounded-lg hover:from-green-600 hover:to-emerald-600 transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-3"
          >
            <UserPlus size={20} />
            {loading ? 'Creating...' : 'Create Test Account'}
          </button>
        </div>

        {/* Status Messages */}
        {error && (
          <div className="mt-4 p-4 bg-red-50 border border-red-200 rounded-lg">
            <p className="text-red-700 text-sm">{error}</p>
          </div>
        )}

        {success && (
          <div className="mt-4 p-4 bg-green-50 border border-green-200 rounded-lg">
            <p className="text-green-700 text-sm">{success}</p>
          </div>
        )}

        {/* Info */}
        <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
          <p className="text-blue-700 text-sm">
            <strong>Demo Account:</strong> Use the demo account to explore all features without creating an account.
          </p>
          <p className="text-blue-700 text-sm mt-2">
            <strong>Test Account:</strong> Creates a unique test account for your session.
          </p>
        </div>

        {/* Debug Info */}
        <div className="mt-4 p-3 bg-gray-50 rounded-lg">
          <p className="text-xs text-gray-500">
            Environment: {window.location.href.includes('figma') ? 'Figma Preview' : 'Web'}
          </p>
          <p className="text-xs text-gray-500">
            Supabase: ✓ Connected (using shared client)
          </p>
        </div>
      </div>
    </div>
  );
}