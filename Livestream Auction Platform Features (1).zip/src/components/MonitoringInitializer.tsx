import { useEffect } from 'react';
import { trackUserAction } from '../utils/monitoring';

interface MonitoringInitializerProps {
  user?: { id: string; email: string; name: string } | null;
}

export function MonitoringInitializer({ user }: MonitoringInitializerProps) {
  useEffect(() => {
    // Initialize monitoring system
    console.log('🔍 Monitoring system initialized');
    
    // Track app start
    if (user) {
      trackUserAction(user.id, 'app_start', {
        timestamp: Date.now(),
        userAgent: navigator.userAgent
      });
    }
  }, [user]);

  // This component doesn't render anything
  return null;
}