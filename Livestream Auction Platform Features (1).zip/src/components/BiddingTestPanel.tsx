import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Gavel, DollarSign, Clock, Users } from 'lucide-react';
import { projectId } from '../utils/supabase/info';
import { supabase } from '../utils/supabase/client';

interface User {
  id: string;
  email: string;
  name: string;
  avatar?: string;
}

interface BiddingTestPanelProps {
  user: User | null;
  onAuthRequired: () => void;
}

export function BiddingTestPanel({ user, onAuthRequired }: BiddingTestPanelProps) {
  const [bidAmount, setBidAmount] = useState('');
  const [isPlacingBid, setIsPlacingBid] = useState(false);
  const [bidHistory, setBidHistory] = useState<any[]>([]);
  const [currentHighBid, setCurrentHighBid] = useState(25);

  // Mock auction item for testing
  const mockAuctionItem = {
    id: 'test_item_' + Date.now(),
    title: 'Rainbow Acropora Colony - TEST ITEM',
    description: 'Beautiful test coral for bidding system testing',
    currentBid: currentHighBid,
    minIncrement: 5,
    endTime: new Date(Date.now() + 300000), // 5 minutes from now
    imageUrl: 'https://images.unsplash.com/photo-1583212292454-1fe6229603b7?w=300&h=200&fit=crop'
  };

  const handlePlaceBid = async () => {
    if (!user) {
      onAuthRequired();
      return;
    }

    const amount = parseFloat(bidAmount);
    if (!amount || amount <= currentHighBid) {
      alert(`Bid must be higher than current bid of $${currentHighBid}`);
      return;
    }

    setIsPlacingBid(true);

    try {
      console.log('🔨 Placing test bid:', { amount, itemId: mockAuctionItem.id });

      // Get user session for API call
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.access_token) {
        alert('Please sign in to place bids');
        return;
      }

      // Call the bidding API endpoint
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-9f7745d8/bid/place`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${session.access_token}`
        },
        body: JSON.stringify({
          itemId: mockAuctionItem.id,
          amount: amount,
          streamId: 'test_stream_123'
        })
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error('❌ Bidding API error:', response.status, errorText);
        throw new Error(`Server error ${response.status}: ${errorText}`);
      }

      const result = await response.json();
      console.log('✅ Bid response:', result);

      if (result.success) {
        // Update local state
        setCurrentHighBid(amount);
        setBidHistory(prev => [{
          id: result.bid.id,
          amount: amount,
          bidder: user.name,
          timestamp: new Date().toLocaleTimeString()
        }, ...prev]);
        setBidAmount('');
        
        console.log('🎉 Bid placed successfully!');
        alert(`✅ Bid of $${amount} placed successfully!`);
      } else {
        throw new Error(result.error || 'Failed to place bid');
      }

    } catch (error) {
      console.error('💥 Bidding error:', error);
      alert(`Failed to place bid: ${error.message}`);
    } finally {
      setIsPlacingBid(false);
    }
  };

  const timeRemaining = () => {
    const now = new Date();
    const end = mockAuctionItem.endTime;
    const diff = end.getTime() - now.getTime();
    
    if (diff <= 0) return 'Auction Ended';
    
    const minutes = Math.floor(diff / 60000);
    const seconds = Math.floor((diff % 60000) / 1000);
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  return (
    <Card className="bg-gray-800 border-gray-700">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Gavel className="text-orange-400" size={20} />
          <span>🧪 Bidding System Test</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Mock Auction Item */}
        <div className="flex space-x-4">
          <img
            src={mockAuctionItem.imageUrl}
            alt={mockAuctionItem.title}
            className="w-24 h-24 object-cover rounded-lg"
          />
          <div className="flex-1">
            <h3 className="font-medium text-white mb-1">{mockAuctionItem.title}</h3>
            <p className="text-sm text-gray-400 mb-2">{mockAuctionItem.description}</p>
            <div className="flex items-center space-x-4">
              <Badge variant="outline" className="text-green-400 border-green-400">
                <DollarSign size={12} className="mr-1" />
                Current: ${currentHighBid}
              </Badge>
              <Badge variant="outline" className="text-orange-400 border-orange-400">
                <Clock size={12} className="mr-1" />
                {timeRemaining()}
              </Badge>
            </div>
          </div>
        </div>

        {/* Bidding Controls */}
        <div className="space-y-3">
          <div className="flex space-x-2">
            <Input
              type="number"
              placeholder={`Min: $${currentHighBid + mockAuctionItem.minIncrement}`}
              value={bidAmount}
              onChange={(e) => setBidAmount(e.target.value)}
              className="bg-gray-700 border-gray-600 text-white"
              min={currentHighBid + mockAuctionItem.minIncrement}
              step="1"
            />
            <Button
              onClick={handlePlaceBid}
              disabled={isPlacingBid || !user}
              className="bg-green-500 hover:bg-green-600 text-white min-w-[120px]"
            >
              {isPlacingBid ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                  Bidding...
                </>
              ) : (
                <>
                  <Gavel size={16} className="mr-2" />
                  Place Bid
                </>
              )}
            </Button>
          </div>

          {!user && (
            <div className="text-center p-4 bg-yellow-500/20 border border-yellow-500/30 rounded-lg">
              <p className="text-yellow-300 text-sm">
                Please sign in to test the bidding system
              </p>
            </div>
          )}
        </div>

        {/* Bid History */}
        {bidHistory.length > 0 && (
          <div className="space-y-2">
            <h4 className="text-sm font-medium text-gray-300 flex items-center">
              <Users size={14} className="mr-1" />
              Bid History
            </h4>
            <div className="space-y-1 max-h-32 overflow-y-auto">
              {bidHistory.map((bid) => (
                <div key={bid.id} className="flex justify-between items-center text-xs p-2 bg-gray-700/50 rounded">
                  <span className="text-gray-300">{bid.bidder}</span>
                  <span className="text-green-400 font-medium">${bid.amount}</span>
                  <span className="text-gray-500">{bid.timestamp}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Test Info */}
        <div className="bg-blue-500/20 border border-blue-500/30 rounded-lg p-3">
          <p className="text-blue-300 text-xs">
            <strong>Test Mode:</strong> This is a mock auction item for testing the bidding system. 
            Bids are processed through the server but not saved permanently.
          </p>
        </div>
      </CardContent>
    </Card>
  );
}