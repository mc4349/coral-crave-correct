import React, { useState, useEffect } from 'react';
import { Bell, Check, X, Gavel, Heart, User, Clock, DollarSign, MessageCircle, Star, TrendingUp, Package, Settings } from 'lucide-react';
import { NotificationCenter } from './NotificationCenter';
import { Button } from './ui/button';

interface User {
  id: string;
  email: string;
  name: string;
  avatar?: string;
}

interface AlertsScreenProps {
  user: User | null;
  onAuthRequired: () => void;
}

interface Alert {
  id: string;
  type: 'outbid' | 'winning' | 'message' | 'sale' | 'rating';
  title: string;
  message: string;
  timestamp: Date;
  read: boolean;
  data?: {
    itemName?: string;
    amount?: number;
    buyerName?: string;
    ratingScore?: number;
    messageText?: string;
    saleTotal?: number;
  };
}

export function AlertsScreen({ user, onAuthRequired }: AlertsScreenProps) {
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [filter, setFilter] = useState<'all' | 'unread' | 'outbid' | 'winning' | 'messages' | 'sales' | 'ratings'>('all');
  const [loading, setLoading] = useState(true);
  const [showNotificationCenter, setShowNotificationCenter] = useState(false);

  // Stats for dashboard
  const [stats, setStats] = useState({
    totalSales: 2340.50,
    averageRating: 4.8,
    totalRatings: 156,
    pendingWins: 3
  });

  useEffect(() => {
    if (!user) {
      setLoading(false);
      return;
    }

    // Mock alerts data
    const mockAlerts: Alert[] = [
      {
        id: '1',
        type: 'outbid',
        title: 'You were outbid!',
        message: 'Someone placed a higher bid on Rainbow Acropora Colony. Current bid: $142',
        timestamp: new Date(Date.now() - 300000),
        read: false,
        data: {
          itemName: 'Rainbow Acropora Colony',
          amount: 142
        }
      },
      {
        id: '2',
        type: 'winning',
        title: 'You\'re winning!',
        message: 'You have the highest bid on Orange Torch Coral',
        timestamp: new Date(Date.now() - 600000),
        read: false,
        data: {
          itemName: 'Orange Torch Coral',
          amount: 67
        }
      },
      {
        id: '3',
        type: 'message',
        title: 'New message from AquaReef Co.',
        message: 'Thanks for your purchase! Your coral has been carefully packaged...',
        timestamp: new Date(Date.now() - 1800000),
        read: false,
        data: {
          buyerName: 'AquaReef Co.',
          messageText: 'Thanks for your purchase! Your coral has been carefully packaged and will ship tomorrow.'
        }
      },
      {
        id: '4',
        type: 'sale',
        title: 'Item sold!',
        message: 'Your Green Star Polyps sold for $45',
        timestamp: new Date(Date.now() - 3600000),
        read: true,
        data: {
          itemName: 'Green Star Polyps',
          amount: 45,
          buyerName: 'ReefMaster'
        }
      },
      {
        id: '5',
        type: 'rating',
        title: 'New rating received',
        message: 'ReefMaster gave you 5 stars: "Excellent coral quality and fast shipping!"',
        timestamp: new Date(Date.now() - 7200000),
        read: true,
        data: {
          buyerName: 'ReefMaster',
          ratingScore: 5,
          messageText: 'Excellent coral quality and fast shipping!'
        }
      },
      {
        id: '6',
        type: 'winning',
        title: 'You\'re winning!',
        message: 'You have the highest bid on Purple Hammer Coral',
        timestamp: new Date(Date.now() - 10800000),
        read: true,
        data: {
          itemName: 'Purple Hammer Coral',
          amount: 89
        }
      },
      {
        id: '7',
        type: 'sale',
        title: 'Item sold!',
        message: 'Your Red Montipora sold for $32',
        timestamp: new Date(Date.now() - 86400000),
        read: true,
        data: {
          itemName: 'Red Montipora',
          amount: 32,
          buyerName: 'CoralCollector'
        }
      }
    ];

    setAlerts(mockAlerts);
    setLoading(false);
  }, [user]);

  const markAsRead = (alertId: string) => {
    setAlerts(prev => 
      prev.map(alert => 
        alert.id === alertId ? { ...alert, read: true } : alert
      )
    );
  };

  const markAllAsRead = () => {
    setAlerts(prev => 
      prev.map(alert => ({ ...alert, read: true }))
    );
  };

  const deleteAlert = (alertId: string) => {
    setAlerts(prev => prev.filter(alert => alert.id !== alertId));
  };

  const getAlertIcon = (type: string) => {
    switch (type) {
      case 'outbid':
        return <Gavel className="text-red-400" size={20} />;
      case 'winning':
        return <Gavel className="text-green-400" size={20} />;
      case 'message':
        return <MessageCircle className="text-blue-400" size={20} />;
      case 'sale':
        return <DollarSign className="text-green-400" size={20} />;
      case 'rating':
        return <Star className="text-yellow-400" size={20} />;
      default:
        return <Bell className="text-gray-400" size={20} />;
    }
  };

  const filteredAlerts = alerts.filter(alert => {
    if (filter === 'all') return true;
    if (filter === 'unread') return !alert.read;
    return alert.type === filter;
  });

  const unreadCount = alerts.filter(alert => !alert.read).length;

  if (!user) {
    return (
      <div className="p-4">
        <div className="text-center py-12">
          <Bell className="mx-auto text-gray-400 mb-4" size={64} />
          <h2 className="text-2xl font-bold text-gray-300 mb-2">Stay Updated</h2>
          <p className="text-gray-500 mb-6">Sign in to receive alerts about your bids, auctions, sales, and messages</p>
          <button
            onClick={onAuthRequired}
            className="bg-cyan-500 text-white px-6 py-3 rounded-lg hover:bg-cyan-400 transition-colors"
          >
            Sign In
          </button>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="p-4">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-gray-700 rounded w-48"></div>
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="h-16 bg-gray-700 rounded"></div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="p-4">
      {/* Stats Dashboard */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
        <div className="bg-gray-800 rounded-xl p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-red-500 bg-opacity-20 rounded-lg flex items-center justify-center">
              <Gavel className="text-red-400" size={20} />
            </div>
            <div>
              <p className="text-sm text-gray-400">Outbid Alerts</p>
              <p className="text-xl font-bold text-white">
                {alerts.filter(a => a.type === 'outbid' && !a.read).length}
              </p>
            </div>
          </div>
        </div>

        <div className="bg-gray-800 rounded-xl p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-green-500 bg-opacity-20 rounded-lg flex items-center justify-center">
              <Package className="text-green-400" size={20} />
            </div>
            <div>
              <p className="text-sm text-gray-400">Winning Items</p>
              <p className="text-xl font-bold text-white">{stats.pendingWins}</p>
            </div>
          </div>
        </div>

        <div className="bg-gray-800 rounded-xl p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-500 bg-opacity-20 rounded-lg flex items-center justify-center">
              <MessageCircle className="text-blue-400" size={20} />
            </div>
            <div>
              <p className="text-sm text-gray-400">New Messages</p>
              <p className="text-xl font-bold text-white">
                {alerts.filter(a => a.type === 'message' && !a.read).length}
              </p>
            </div>
          </div>
        </div>

        <div className="bg-gray-800 rounded-xl p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-cyan-500 bg-opacity-20 rounded-lg flex items-center justify-center">
              <TrendingUp className="text-cyan-400" size={20} />
            </div>
            <div>
              <p className="text-sm text-gray-400">Total Sales</p>
              <p className="text-xl font-bold text-white">${stats.totalSales.toLocaleString()}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Ratings Summary */}
      <div className="bg-gray-800 rounded-xl p-6 mb-8">
        <h3 className="text-lg font-bold text-white mb-4">Your Seller Rating</h3>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1">
            {[1, 2, 3, 4, 5].map((star) => (
              <Star
                key={star}
                size={20}
                className={star <= Math.floor(stats.averageRating) ? 'text-yellow-400 fill-current' : 'text-gray-600'}
              />
            ))}
          </div>
          <span className="text-xl font-bold text-white">{stats.averageRating}</span>
          <span className="text-gray-400">({stats.totalRatings} ratings)</span>
        </div>
      </div>

      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-3xl font-bold mb-2">Alerts & Notifications</h1>
          <p className="text-gray-400">
            {unreadCount > 0 ? `${unreadCount} unread alert${unreadCount !== 1 ? 's' : ''}` : 'All caught up!'}
          </p>
        </div>
        
        <div className="flex items-center gap-2">
          <Button
            onClick={() => setShowNotificationCenter(true)}
            variant="outline"
            className="border-gray-600 text-gray-300"
          >
            <Settings className="w-4 h-4 mr-2" />
            Notification Settings
          </Button>
          
          {unreadCount > 0 && (
            <button
              onClick={markAllAsRead}
              className="text-cyan-400 hover:text-cyan-300 transition-colors text-sm"
            >
              Mark all as read
            </button>
          )}
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex gap-2 mb-6 overflow-x-auto">
        {[
          { key: 'all', label: `All (${alerts.length})` },
          { key: 'unread', label: `Unread (${unreadCount})` },
          { key: 'outbid', label: 'Outbid' },
          { key: 'winning', label: 'Winning' },
          { key: 'messages', label: 'Messages' },
          { key: 'sales', label: 'Sales' },
          { key: 'ratings', label: 'Ratings' }
        ].map((tab) => (
          <button
            key={tab.key}
            onClick={() => setFilter(tab.key as any)}
            className={`px-4 py-2 rounded-lg transition-colors whitespace-nowrap ${
              filter === tab.key ? 'bg-cyan-500 text-white' : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Alerts List */}
      {filteredAlerts.length === 0 ? (
        <div className="text-center py-12">
          <div className="text-6xl mb-4">📬</div>
          <h3 className="text-xl font-medium text-gray-300 mb-2">
            {filter === 'unread' ? 'No unread alerts' : `No ${filter} alerts`}
          </h3>
          <p className="text-gray-500">
            {filter === 'unread' 
              ? 'All your alerts have been read'
              : 'Start bidding and selling to get alerts'
            }
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {filteredAlerts.map((alert) => (
            <div
              key={alert.id}
              className={`bg-gray-800 rounded-xl p-4 border-l-4 transition-all hover:bg-gray-750 ${
                alert.read ? 'border-gray-600' : 'border-cyan-400'
              }`}
            >
              <div className="flex items-start gap-3">
                <div className="flex-shrink-0 mt-1">
                  {getAlertIcon(alert.type)}
                </div>
                
                <div className="flex-1">
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="font-medium text-white mb-1">{alert.title}</h3>
                      <p className="text-gray-300 text-sm mb-2">{alert.message}</p>
                      
                      {/* Alert Data */}
                      {alert.data && (
                        <div className="flex flex-wrap gap-2 mb-2">
                          {alert.data.itemName && (
                            <span className="bg-gray-700 text-gray-300 px-2 py-1 rounded text-xs">
                              {alert.data.itemName}
                            </span>
                          )}
                          {alert.data.amount && (
                            <span className="bg-green-500 bg-opacity-20 text-green-400 px-2 py-1 rounded text-xs flex items-center gap-1">
                              <DollarSign size={12} />
                              {alert.data.amount}
                            </span>
                          )}
                          {alert.data.buyerName && (
                            <span className="bg-blue-500 bg-opacity-20 text-blue-400 px-2 py-1 rounded text-xs">
                              {alert.data.buyerName}
                            </span>
                          )}
                          {alert.data.ratingScore && (
                            <span className="bg-yellow-500 bg-opacity-20 text-yellow-400 px-2 py-1 rounded text-xs flex items-center gap-1">
                              <Star size={12} />
                              {alert.data.ratingScore}/5
                            </span>
                          )}
                        </div>
                      )}
                      
                      <p className="text-xs text-gray-500">
                        {alert.timestamp.toLocaleString()}
                      </p>
                    </div>
                    
                    <div className="flex items-center gap-2 ml-4">
                      {!alert.read && (
                        <button
                          onClick={() => markAsRead(alert.id)}
                          className="text-gray-400 hover:text-green-400 transition-colors"
                          title="Mark as read"
                        >
                          <Check size={16} />
                        </button>
                      )}
                      <button
                        onClick={() => deleteAlert(alert.id)}
                        className="text-gray-400 hover:text-red-400 transition-colors"
                        title="Delete alert"
                      >
                        <X size={16} />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Notification Center */}
      <NotificationCenter
        user={user}
        isOpen={showNotificationCenter}
        onClose={() => setShowNotificationCenter(false)}
      />
    </div>
  );
}