import React, { useState, useEffect } from 'react';
import { Package, Calendar, DollarSign, Truck, CheckCircle, Clock, AlertCircle, Receipt } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Skeleton } from './ui/skeleton';
import { projectId, publicAnonKey } from '../utils/supabase/info';

interface Purchase {
  id: string;
  userId: string;
  auctionId: string;
  itemId: string;
  amount: number;
  currency: string;
  paypalOrderId: string;
  status: 'completed' | 'pending' | 'failed';
  purchasedAt: string;
  itemTitle?: string;
  itemDescription?: string;
  sellerName?: string;
  shippingStatus?: 'pending' | 'shipped' | 'in_transit' | 'delivered';
  trackingNumber?: string;
}

interface PurchaseHistoryProps {
  user: any;
}

export function PurchaseHistory({ user }: PurchaseHistoryProps) {
  const [purchases, setPurchases] = useState<Purchase[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (user) {
      fetchPurchaseHistory();
    }
  }, [user]);

  const fetchPurchaseHistory = async () => {
    try {
      setLoading(true);
      setError(null);

      const accessToken = localStorage.getItem('access_token');
      if (!accessToken) {
        throw new Error('Please log in to view purchase history');
      }

      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-9f7745d8/purchases`, {
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`,
        }
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to fetch purchase history');
      }

      const data = await response.json();
      console.log('📦 Purchase history loaded:', data.purchases.length, 'items');
      
      // Enhance purchases with mock item details for demo
      const enhancedPurchases = data.purchases.map((purchase: Purchase) => ({
        ...purchase,
        itemTitle: getItemTitle(purchase.auctionId),
        itemDescription: getItemDescription(purchase.auctionId),
        sellerName: getSellerName(purchase.auctionId),
        shippingStatus: getShippingStatus(purchase.purchasedAt)
      }));

      setPurchases(enhancedPurchases);
    } catch (error) {
      console.error('❌ Failed to fetch purchase history:', error);
      setError(error instanceof Error ? error.message : 'Failed to load purchase history');
    } finally {
      setLoading(false);
    }
  };

  // Mock data helpers for demo purposes
  const getItemTitle = (auctionId: string): string => {
    const items = [
      'Premium Rainbow Acropora Colony',
      'Ultra Chalice Coral Fragment',
      'Rare Blue Tang Fish',
      'LED Reef Light System',
      'Protein Skimmer Pro',
      'Live Rock Collection'
    ];
    return items[Math.abs(auctionId.length) % items.length];
  };

  const getItemDescription = (auctionId: string): string => {
    const descriptions = [
      'Beautiful rainbow acropora with vibrant colors',
      'Stunning chalice coral with unique patterns',
      'Healthy blue tang, perfect for reef tanks',
      'Professional LED lighting system',
      'High-performance protein skimmer',
      'Premium live rock for aquascaping'
    ];
    return descriptions[Math.abs(auctionId.length) % descriptions.length];
  };

  const getSellerName = (auctionId: string): string => {
    const sellers = [
      'AquaReef Co.',
      'Coral Paradise',
      'Marine Depot',
      'Reef Central',
      'Ocean Treasures',
      'Aquatic Gardens'
    ];
    return sellers[Math.abs(auctionId.length) % sellers.length];
  };

  const getShippingStatus = (purchasedAt: string): Purchase['shippingStatus'] => {
    const daysSincePurchase = Math.floor((Date.now() - new Date(purchasedAt).getTime()) / (1000 * 60 * 60 * 24));
    
    if (daysSincePurchase < 1) return 'pending';
    if (daysSincePurchase < 3) return 'shipped';
    if (daysSincePurchase < 7) return 'in_transit';
    return 'delivered';
  };

  const getStatusIcon = (status: Purchase['status']) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="w-4 h-4 text-green-400" />;
      case 'pending':
        return <Clock className="w-4 h-4 text-yellow-400" />;
      case 'failed':
        return <AlertCircle className="w-4 h-4 text-red-400" />;
      default:
        return <Package className="w-4 h-4 text-gray-400" />;
    }
  };

  const getShippingIcon = (status: Purchase['shippingStatus']) => {
    switch (status) {
      case 'delivered':
        return <CheckCircle className="w-4 h-4 text-green-400" />;
      case 'in_transit':
        return <Truck className="w-4 h-4 text-blue-400" />;
      case 'shipped':
        return <Package className="w-4 h-4 text-cyan-400" />;
      default:
        return <Clock className="w-4 h-4 text-gray-400" />;
    }
  };

  const getStatusBadgeVariant = (status: Purchase['status']) => {
    switch (status) {
      case 'completed':
        return 'default';
      case 'pending':
        return 'secondary';
      case 'failed':
        return 'destructive';
      default:
        return 'outline';
    }
  };

  const getShippingBadgeVariant = (status: Purchase['shippingStatus']) => {
    switch (status) {
      case 'delivered':
        return 'default';
      case 'in_transit':
        return 'secondary';
      case 'shipped':
        return 'outline';
      default:
        return 'secondary';
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (loading) {
    return (
      <div className="space-y-4">
        <h2 className="text-xl font-semibold text-white mb-4">Purchase History</h2>
        {[...Array(3)].map((_, i) => (
          <Card key={i} className="bg-gray-800 border-gray-700">
            <CardContent className="p-4">
              <div className="flex items-start gap-4">
                <Skeleton className="w-16 h-16 rounded-lg bg-gray-700" />
                <div className="flex-1 space-y-2">
                  <Skeleton className="h-4 w-3/4 bg-gray-700" />
                  <Skeleton className="h-3 w-1/2 bg-gray-700" />
                  <Skeleton className="h-3 w-1/4 bg-gray-700" />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-8">
        <AlertCircle className="w-12 h-12 text-red-400 mx-auto mb-4" />
        <h3 className="text-lg font-medium text-white mb-2">Error Loading Purchase History</h3>
        <p className="text-gray-400 mb-4">{error}</p>
        <Button onClick={fetchPurchaseHistory} variant="outline">
          Try Again
        </Button>
      </div>
    );
  }

  if (purchases.length === 0) {
    return (
      <div className="text-center py-12">
        <Package className="w-16 h-16 text-gray-600 mx-auto mb-4" />
        <h3 className="text-lg font-medium text-white mb-2">No Purchases Yet</h3>
        <p className="text-gray-400 mb-6">
          Start bidding on live auctions to see your purchase history here.
        </p>
        <Button className="bg-cyan-500 hover:bg-cyan-600">
          Browse Live Auctions
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-semibold text-white">Purchase History</h2>
        <Badge variant="secondary" className="bg-cyan-500/20 text-cyan-400">
          {purchases.length} {purchases.length === 1 ? 'Purchase' : 'Purchases'}
        </Badge>
      </div>

      <div className="space-y-4">
        {purchases.map((purchase) => (
          <Card key={purchase.id} className="bg-gray-800 border-gray-700 hover:bg-gray-750 transition-colors">
            <CardContent className="p-4">
              <div className="flex items-start gap-4">
                {/* Item Image Placeholder */}
                <div className="w-16 h-16 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-lg flex items-center justify-center">
                  <Package className="w-8 h-8 text-white" />
                </div>

                <div className="flex-1 min-w-0">
                  {/* Item Title and Seller */}
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <h3 className="font-medium text-white mb-1">{purchase.itemTitle}</h3>
                      <p className="text-sm text-gray-400">Sold by {purchase.sellerName}</p>
                    </div>
                    <div className="text-right">
                      <div className="text-lg font-bold text-cyan-400">
                        ${purchase.amount.toFixed(2)}
                      </div>
                      <div className="text-xs text-gray-400">
                        {purchase.currency}
                      </div>
                    </div>
                  </div>

                  {/* Status Badges */}
                  <div className="flex items-center gap-2 mb-2">
                    <Badge 
                      variant={getStatusBadgeVariant(purchase.status)}
                      className="flex items-center gap-1"
                    >
                      {getStatusIcon(purchase.status)}
                      {purchase.status.charAt(0).toUpperCase() + purchase.status.slice(1)}
                    </Badge>
                    
                    {purchase.shippingStatus && (
                      <Badge 
                        variant={getShippingBadgeVariant(purchase.shippingStatus)}
                        className="flex items-center gap-1"
                      >
                        {getShippingIcon(purchase.shippingStatus)}
                        {purchase.shippingStatus.replace('_', ' ').charAt(0).toUpperCase() + 
                         purchase.shippingStatus.replace('_', ' ').slice(1)}
                      </Badge>
                    )}
                  </div>

                  {/* Purchase Details */}
                  <div className="flex items-center gap-4 text-sm text-gray-400">
                    <div className="flex items-center gap-1">
                      <Calendar className="w-4 h-4" />
                      {formatDate(purchase.purchasedAt)}
                    </div>
                    <div className="flex items-center gap-1">
                      <Receipt className="w-4 h-4" />
                      Order #{purchase.id.slice(-8)}
                    </div>
                  </div>

                  {/* Description */}
                  {purchase.itemDescription && (
                    <p className="text-sm text-gray-500 mt-2 line-clamp-2">
                      {purchase.itemDescription}
                    </p>
                  )}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-between mt-4 pt-4 border-t border-gray-700">
                <div className="flex gap-2">
                  {purchase.trackingNumber && (
                    <Button variant="outline" size="sm">
                      <Truck className="w-4 h-4 mr-2" />
                      Track Package
                    </Button>
                  )}
                  <Button variant="outline" size="sm">
                    <Receipt className="w-4 h-4 mr-2" />
                    View Receipt
                  </Button>
                </div>
                
                {purchase.status === 'completed' && purchase.shippingStatus === 'delivered' && (
                  <Button variant="outline" size="sm">
                    Leave Review
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}