import React from 'react';

interface User {
  id: string;
  email: string;
  name: string;
  avatar?: string;
}

interface UserProfileScreenProps {
  userId: string;
  currentUser: User | null;
  onBack: () => void;
  onFollow: (userId: string) => void;
  onMessage: (userId: string) => void;
  onReport: (userId: string) => void;
}

export function UserProfileScreen({ userId, currentUser, onBack, onFollow, onMessage, onReport }: UserProfileScreenProps) {
  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold text-white mb-4">User Profile</h1>
      <p className="text-gray-400">User profile for {userId} coming soon...</p>
      <button 
        onClick={onBack}
        className="mt-4 px-4 py-2 bg-cyan-500 rounded-lg hover:bg-cyan-600 text-white"
      >
        Back
      </button>
    </div>
  );
}

export default UserProfileScreen;