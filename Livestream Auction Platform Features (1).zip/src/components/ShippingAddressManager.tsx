import React, { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Separator } from './ui/separator';
import { Badge } from './ui/badge';
import { 
  Truck, 
  MapPin, 
  Edit, 
  Save, 
  X, 
  Plus,
  Check,
  AlertCircle,
  Lock,
  Eye,
  EyeOff
} from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { projectId, publicAnonKey } from '../utils/supabase/info';

interface ShippingAddress {
  id: string;
  name: string;
  streetAddress: string;
  city: string;
  state: string;
  zipCode: string;
  country: string;
  phoneNumber?: string;
  specialInstructions?: string;
  isDefault: boolean;
  createdAt: string;
}

interface ShippingAddressManagerProps {
  userId: string;
  userToken: string;
  onAddressUpdated?: () => void;
  viewMode?: 'buyer' | 'seller';
  orderId?: string; // For sellers viewing buyer's address after purchase
}

export function ShippingAddressManager({
  userId,
  userToken,
  onAddressUpdated,
  viewMode = 'buyer',
  orderId
}: ShippingAddressManagerProps) {
  const [addresses, setAddresses] = useState<ShippingAddress[]>([]);
  const [isEditing, setIsEditing] = useState(false);
  const [isAdding, setIsAdding] = useState(false);
  const [editingAddress, setEditingAddress] = useState<ShippingAddress | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [showAddresses, setShowAddresses] = useState(viewMode === 'buyer');

  const [formData, setFormData] = useState({
    name: '',
    streetAddress: '',
    city: '',
    state: '',
    zipCode: '',
    country: 'United States',
    phoneNumber: '',
    specialInstructions: '',
    isDefault: false
  });

  useEffect(() => {
    if (viewMode === 'buyer') {
      loadUserAddresses();
    } else if (viewMode === 'seller' && orderId) {
      loadBuyerAddressForOrder();
    }
  }, [userId, viewMode, orderId]);

  const loadUserAddresses = async () => {
    try {
      setLoading(true);
      
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-9f7745d8/shipping/addresses`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${userToken}`,
          'Content-Type': 'application/json'
        }
      });

      if (response.ok) {
        const data = await response.json();
        setAddresses(data.addresses || []);
      } else {
        throw new Error(`HTTP ${response.status}`);
      }
    } catch (error) {
      console.error('Failed to load addresses:', error);
      toast.error('Failed to load shipping addresses');
    } finally {
      setLoading(false);
    }
  };

  const loadBuyerAddressForOrder = async () => {
    try {
      setLoading(true);
      
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-9f7745d8/shipping/order-address/${orderId}`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${userToken}`,
          'Content-Type': 'application/json'
        }
      });

      if (response.ok) {
        const data = await response.json();
        if (data.address) {
          setAddresses([data.address]);
        }
      } else {
        throw new Error(`HTTP ${response.status}`);
      }
    } catch (error) {
      console.error('Failed to load buyer address:', error);
      toast.error('Failed to load buyer shipping address');
    } finally {
      setLoading(false);
    }
  };

  const handleSaveAddress = async () => {
    try {
      setSaving(true);

      // Validate required fields
      if (!formData.name || !formData.streetAddress || !formData.city || !formData.state || !formData.zipCode) {
        toast.error('Please fill in all required fields');
        return;
      }

      const addressData = {
        ...formData,
        id: editingAddress?.id || undefined
      };

      const url = editingAddress 
        ? `https://${projectId}.supabase.co/functions/v1/make-server-9f7745d8/shipping/addresses/${editingAddress.id}`
        : `https://${projectId}.supabase.co/functions/v1/make-server-9f7745d8/shipping/addresses`;

      const response = await fetch(url, {
        method: editingAddress ? 'PUT' : 'POST',
        headers: {
          'Authorization': `Bearer ${userToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(addressData)
      });

      if (response.ok) {
        const data = await response.json();
        
        if (editingAddress) {
          setAddresses(prev => prev.map(addr => 
            addr.id === editingAddress.id ? data.address : addr
          ));
          toast.success('Address updated successfully');
        } else {
          setAddresses(prev => [...prev, data.address]);
          toast.success('Address added successfully');
        }

        // Reset form
        setFormData({
          name: '',
          streetAddress: '',
          city: '',
          state: '',
          zipCode: '',
          country: 'United States',
          phoneNumber: '',
          specialInstructions: '',
          isDefault: false
        });
        setIsEditing(false);
        setIsAdding(false);
        setEditingAddress(null);

        onAddressUpdated?.();
      } else {
        throw new Error(`HTTP ${response.status}`);
      }
    } catch (error) {
      console.error('Failed to save address:', error);
      toast.error('Failed to save address');
    } finally {
      setSaving(false);
    }
  };

  const handleEditAddress = (address: ShippingAddress) => {
    setFormData({
      name: address.name,
      streetAddress: address.streetAddress,
      city: address.city,
      state: address.state,
      zipCode: address.zipCode,
      country: address.country,
      phoneNumber: address.phoneNumber || '',
      specialInstructions: address.specialInstructions || '',
      isDefault: address.isDefault
    });
    setEditingAddress(address);
    setIsEditing(true);
  };

  const handleDeleteAddress = async (addressId: string) => {
    if (!confirm('Are you sure you want to delete this address?')) {
      return;
    }

    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-9f7745d8/shipping/addresses/${addressId}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${userToken}`
        }
      });

      if (response.ok) {
        setAddresses(prev => prev.filter(addr => addr.id !== addressId));
        toast.success('Address deleted successfully');
        onAddressUpdated?.();
      } else {
        throw new Error(`HTTP ${response.status}`);
      }
    } catch (error) {
      console.error('Failed to delete address:', error);
      toast.error('Failed to delete address');
    }
  };

  const handleSetDefault = async (addressId: string) => {
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-9f7745d8/shipping/addresses/${addressId}/default`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${userToken}`
        }
      });

      if (response.ok) {
        setAddresses(prev => prev.map(addr => ({
          ...addr,
          isDefault: addr.id === addressId
        })));
        toast.success('Default address updated');
        onAddressUpdated?.();
      } else {
        throw new Error(`HTTP ${response.status}`);
      }
    } catch (error) {
      console.error('Failed to set default address:', error);
      toast.error('Failed to set default address');
    }
  };

  const handleCancel = () => {
    setFormData({
      name: '',
      streetAddress: '',
      city: '',
      state: '',
      zipCode: '',
      country: 'United States',
      phoneNumber: '',
      specialInstructions: '',
      isDefault: false
    });
    setIsEditing(false);
    setIsAdding(false);
    setEditingAddress(null);
  };

  if (loading) {
    return (
      <Card className="bg-gray-800 border-gray-700">
        <CardContent className="p-6">
          <div className="flex items-center justify-center py-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-cyan-400"></div>
            <span className="ml-2 text-gray-400">Loading addresses...</span>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <Card className="bg-gray-800 border-gray-700">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Truck className="h-6 w-6 text-cyan-400" />
              <div>
                <CardTitle className="text-white">
                  {viewMode === 'buyer' ? 'Shipping Addresses' : 'Buyer Shipping Information'}
                </CardTitle>
                <CardDescription>
                  {viewMode === 'buyer' 
                    ? 'Manage your shipping addresses for auction purchases'
                    : 'Shipping address for this order - only visible after purchase'
                  }
                </CardDescription>
              </div>
            </div>
            
            {viewMode === 'buyer' && (
              <div className="flex items-center space-x-2">
                {!isEditing && !isAdding && (
                  <Button
                    onClick={() => setIsAdding(true)}
                    className="bg-cyan-500 hover:bg-cyan-600"
                    size="sm"
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Add Address
                  </Button>
                )}
              </div>
            )}
            
            {viewMode === 'seller' && (
              <Button
                onClick={() => setShowAddresses(!showAddresses)}
                variant="outline"
                size="sm"
              >
                {showAddresses ? <EyeOff className="h-4 w-4 mr-2" /> : <Eye className="h-4 w-4 mr-2" />}
                {showAddresses ? 'Hide Address' : 'Show Address'}
              </Button>
            )}
          </div>
        </CardHeader>

        <CardContent className="space-y-6">
          {/* Privacy Notice for Sellers */}
          {viewMode === 'seller' && (
            <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-4">
              <div className="flex items-start space-x-3">
                <Lock className="h-5 w-5 text-blue-400 mt-0.5" />
                <div>
                  <h4 className="text-blue-400 font-medium mb-2">Privacy Protection</h4>
                  <p className="text-gray-300 text-sm">
                    Buyer shipping addresses are only shared with sellers after a successful purchase. 
                    This ensures buyer privacy while allowing sellers to ship items to winning bidders.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Add/Edit Address Form */}
          {(isAdding || isEditing) && viewMode === 'buyer' && (
            <Card className="bg-gray-700 border-gray-600">
              <CardHeader>
                <CardTitle className="text-white">
                  {isEditing ? 'Edit Address' : 'Add New Address'}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="name" className="text-white">Full Name *</Label>
                    <Input
                      id="name"
                      value={formData.name}
                      onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                      className="bg-gray-600 border-gray-500 text-white"
                      placeholder="John Doe"
                    />
                  </div>
                  <div>
                    <Label htmlFor="phone" className="text-white">Phone Number</Label>
                    <Input
                      id="phone"
                      value={formData.phoneNumber}
                      onChange={(e) => setFormData(prev => ({ ...prev, phoneNumber: e.target.value }))}
                      className="bg-gray-600 border-gray-500 text-white"
                      placeholder="(555) 123-4567"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="street" className="text-white">Street Address *</Label>
                  <Input
                    id="street"
                    value={formData.streetAddress}
                    onChange={(e) => setFormData(prev => ({ ...prev, streetAddress: e.target.value }))}
                    className="bg-gray-600 border-gray-500 text-white"
                    placeholder="123 Main St, Apt 4B"
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <Label htmlFor="city" className="text-white">City *</Label>
                    <Input
                      id="city"
                      value={formData.city}
                      onChange={(e) => setFormData(prev => ({ ...prev, city: e.target.value }))}
                      className="bg-gray-600 border-gray-500 text-white"
                      placeholder="San Francisco"
                    />
                  </div>
                  <div>
                    <Label htmlFor="state" className="text-white">State *</Label>
                    <Input
                      id="state"
                      value={formData.state}
                      onChange={(e) => setFormData(prev => ({ ...prev, state: e.target.value }))}
                      className="bg-gray-600 border-gray-500 text-white"
                      placeholder="CA"
                    />
                  </div>
                  <div>
                    <Label htmlFor="zip" className="text-white">ZIP Code *</Label>
                    <Input
                      id="zip"
                      value={formData.zipCode}
                      onChange={(e) => setFormData(prev => ({ ...prev, zipCode: e.target.value }))}
                      className="bg-gray-600 border-gray-500 text-white"
                      placeholder="94105"
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="country" className="text-white">Country *</Label>
                  <Input
                    id="country"
                    value={formData.country}
                    onChange={(e) => setFormData(prev => ({ ...prev, country: e.target.value }))}
                    className="bg-gray-600 border-gray-500 text-white"
                  />
                </div>

                <div>
                  <Label htmlFor="instructions" className="text-white">Special Delivery Instructions</Label>
                  <Textarea
                    id="instructions"
                    value={formData.specialInstructions}
                    onChange={(e) => setFormData(prev => ({ ...prev, specialInstructions: e.target.value }))}
                    className="bg-gray-600 border-gray-500 text-white"
                    placeholder="Leave at front door, ring doorbell, etc."
                    rows={3}
                  />
                </div>

                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id="default"
                    checked={formData.isDefault}
                    onChange={(e) => setFormData(prev => ({ ...prev, isDefault: e.target.checked }))}
                    className="rounded border-gray-500"
                  />
                  <Label htmlFor="default" className="text-white">Set as default address</Label>
                </div>

                <div className="flex items-center space-x-3 pt-4">
                  <Button
                    onClick={handleSaveAddress}
                    disabled={saving}
                    className="bg-green-500 hover:bg-green-600"
                  >
                    {saving ? (
                      <>
                        <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                        Saving...
                      </>
                    ) : (
                      <>
                        <Save className="h-4 w-4 mr-2" />
                        Save Address
                      </>
                    )}
                  </Button>
                  <Button
                    onClick={handleCancel}
                    variant="outline"
                    disabled={saving}
                  >
                    <X className="h-4 w-4 mr-2" />
                    Cancel
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Address List */}
          {showAddresses && (
            <div className="space-y-4">
              {addresses.length === 0 ? (
                <div className="text-center py-8">
                  <MapPin className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                  <h3 className="text-lg font-medium text-gray-300 mb-2">
                    {viewMode === 'buyer' ? 'No addresses yet' : 'No shipping address available'}
                  </h3>
                  <p className="text-gray-400 mb-4">
                    {viewMode === 'buyer' 
                      ? 'Add your first shipping address to start bidding on auctions'
                      : 'Buyer shipping address will appear here after purchase'
                    }
                  </p>
                  {viewMode === 'buyer' && (
                    <Button
                      onClick={() => setIsAdding(true)}
                      className="bg-cyan-500 hover:bg-cyan-600"
                    >
                      <Plus className="h-4 w-4 mr-2" />
                      Add First Address
                    </Button>
                  )}
                </div>
              ) : (
                addresses.map((address) => (
                  <Card key={address.id} className={`bg-gray-700 border-gray-600 ${address.isDefault ? 'ring-2 ring-cyan-400' : ''}`}>
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center space-x-2 mb-3">
                            <h4 className="font-medium text-white">{address.name}</h4>
                            {address.isDefault && (
                              <Badge className="bg-cyan-500 text-white">Default</Badge>
                            )}
                            {viewMode === 'seller' && (
                              <Badge variant="outline" className="text-blue-400 border-blue-400">Buyer Address</Badge>
                            )}
                          </div>
                          
                          <div className="text-gray-300 space-y-1">
                            <p>{address.streetAddress}</p>
                            <p>{address.city}, {address.state} {address.zipCode}</p>
                            <p>{address.country}</p>
                            {address.phoneNumber && (
                              <p className="text-sm">📞 {address.phoneNumber}</p>
                            )}
                            {address.specialInstructions && (
                              <p className="text-sm text-gray-400 italic">
                                Note: {address.specialInstructions}
                              </p>
                            )}
                          </div>
                        </div>
                        
                        {viewMode === 'buyer' && (
                          <div className="flex items-center space-x-2 ml-4">
                            <Button
                              onClick={() => handleEditAddress(address)}
                              variant="outline"
                              size="sm"
                            >
                              <Edit className="h-4 w-4" />
                            </Button>
                            {!address.isDefault && (
                              <Button
                                onClick={() => handleSetDefault(address.id)}
                                variant="outline"
                                size="sm"
                                className="text-cyan-400 border-cyan-400 hover:bg-cyan-400 hover:text-black"
                              >
                                <Check className="h-4 w-4" />
                              </Button>
                            )}
                            <Button
                              onClick={() => handleDeleteAddress(address.id)}
                              variant="outline"
                              size="sm"
                              className="text-red-400 border-red-400 hover:bg-red-400 hover:text-white"
                            >
                              <X className="h-4 w-4" />
                            </Button>
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}