import React, { useState, useEffect } from 'react';
import { 
  Plus, 
  Play, 
  Pause, 
  Trash2, 
  Edit3, 
  Clock, 
  DollarSign, 
  Eye, 
  Users, 
  TrendingUp,
  Package,
  AlertCircle,
  CheckCircle,
  Timer,
  Settings
} from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Switch } from './ui/switch';
import { Skeleton } from './ui/skeleton';
import { toast } from 'sonner@2.0.3';
import { projectId, publicAnonKey } from '../utils/supabase/info';
import { supabase } from '../utils/supabase/client';

interface QueuedItem {
  id: string;
  sellerId: string;
  sellerName: string;
  title: string;
  description: string;
  category: string;
  startingBid: number;
  reservePrice?: number;
  buyItNowPrice?: number;
  duration: number;
  images: string[];
  status: 'queued' | 'active' | 'completed' | 'cancelled';
  queuedAt: string;
  startedAt?: string;
  endedAt?: string;
  currentBid: number;
  bidCount: number;
  highestBidder?: string;
  autoExtend: boolean;
  incrementType: 'fixed' | 'percentage';
  minimumIncrement: number;
}

interface AuctionQueueProps {
  user: any;
  onStartAuction?: (item: QueuedItem) => void;
}

export function AuctionQueue({ user, onStartAuction }: AuctionQueueProps) {
  const [queueItems, setQueueItems] = useState<QueuedItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [editingItem, setEditingItem] = useState<QueuedItem | null>(null);
  const [starting, setStarting] = useState<string | null>(null);

  // Form state for adding/editing items
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    category: 'Coral',
    startingBid: '',
    reservePrice: '',
    buyItNowPrice: '',
    duration: '30',
    autoExtend: true,
    incrementType: 'fixed' as 'fixed' | 'percentage',
    minimumIncrement: '5'
  });

  useEffect(() => {
    if (user) {
      fetchQueue();
    }
  }, [user]);

  const fetchQueue = async () => {
    try {
      setLoading(true);
      
      // Get current session for proper authentication  
      const { data: { session } } = await supabase.auth.getSession();
      const accessToken = session?.access_token;
      
      if (!accessToken) {
        throw new Error('No valid access token found. Please sign in again.');
      }

      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-9f7745d8/queue/${user.id}`, {
        headers: {
          'Authorization': `Bearer ${accessToken}`,
        }
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to fetch queue');
      }

      const data = await response.json();
      setQueueItems(data.items || []);
    } catch (error) {
      console.error('❌ Failed to fetch queue:', error);
      toast.error(error instanceof Error ? error.message : 'Failed to load queue');
    } finally {
      setLoading(false);
    }
  };

  const handleAddItem = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      // Get current session for proper authentication  
      const { data: { session } } = await supabase.auth.getSession();
      const accessToken = session?.access_token;
      
      if (!accessToken) {
        throw new Error('No valid access token found. Please sign in again.');
      }

      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-9f7745d8/queue/add`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`,
        },
        body: JSON.stringify({
          ...formData,
          startingBid: parseFloat(formData.startingBid),
          reservePrice: formData.reservePrice ? parseFloat(formData.reservePrice) : undefined,
          buyItNowPrice: formData.buyItNowPrice ? parseFloat(formData.buyItNowPrice) : undefined,
          duration: parseInt(formData.duration),
          minimumIncrement: parseFloat(formData.minimumIncrement)
        })
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to add item to queue');
      }

      const data = await response.json();
      toast.success('✅ Item added to auction queue!');
      
      setShowAddDialog(false);
      resetForm();
      fetchQueue();
    } catch (error) {
      console.error('❌ Failed to add item:', error);
      toast.error(error instanceof Error ? error.message : 'Failed to add item');
    }
  };

  const handleStartAuction = async (item: QueuedItem) => {
    try {
      setStarting(item.id);
      
      // Get current session for proper authentication  
      const { data: { session } } = await supabase.auth.getSession();
      const accessToken = session?.access_token;
      
      if (!accessToken) {
        throw new Error('No valid access token found. Please sign in again.');
      }

      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-9f7745d8/queue/start/${item.id}`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
        }
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to start auction');
      }

      const data = await response.json();
      toast.success('🎯 Auction started successfully!');
      
      fetchQueue();
      
      if (onStartAuction) {
        onStartAuction(data.auction);
      }
    } catch (error) {
      console.error('❌ Failed to start auction:', error);
      toast.error(error instanceof Error ? error.message : 'Failed to start auction');
    } finally {
      setStarting(null);
    }
  };

  const handleRemoveItem = async (itemId: string) => {
    try {
      // Get current session for proper authentication  
      const { data: { session } } = await supabase.auth.getSession();
      const accessToken = session?.access_token;
      
      if (!accessToken) {
        throw new Error('No valid access token found. Please sign in again.');
      }

      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-9f7745d8/queue/${itemId}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
        }
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to remove item');
      }

      toast.success('🗑️ Item removed from queue');
      fetchQueue();
    } catch (error) {
      console.error('❌ Failed to remove item:', error);
      toast.error(error instanceof Error ? error.message : 'Failed to remove item');
    }
  };

  const resetForm = () => {
    setFormData({
      title: '',
      description: '',
      category: 'Coral',
      startingBid: '',
      reservePrice: '',
      buyItNowPrice: '',
      duration: '30',
      autoExtend: true,
      incrementType: 'fixed',
      minimumIncrement: '5'
    });
    setEditingItem(null);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'queued':
        return <Clock className="w-4 h-4 text-yellow-400" />;
      case 'active':
        return <Play className="w-4 h-4 text-green-400" />;
      case 'completed':
        return <CheckCircle className="w-4 h-4 text-blue-400" />;
      case 'cancelled':
        return <AlertCircle className="w-4 h-4 text-red-400" />;
      default:
        return <Package className="w-4 h-4 text-gray-400" />;
    }
  };

  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case 'active':
        return 'default';
      case 'completed':
        return 'secondary';
      case 'cancelled':
        return 'destructive';
      default:
        return 'outline';
    }
  };

  const formatDuration = (minutes: number) => {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    if (hours > 0) {
      return `${hours}h ${mins}m`;
    }
    return `${mins}m`;
  };

  if (loading) {
    return (
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <Skeleton className="h-8 w-48 bg-gray-700" />
          <Skeleton className="h-10 w-32 bg-gray-700" />
        </div>
        {[...Array(3)].map((_, i) => (
          <Card key={i} className="bg-gray-800 border-gray-700">
            <CardContent className="p-4">
              <div className="flex items-start gap-4">
                <Skeleton className="w-16 h-16 rounded-lg bg-gray-700" />
                <div className="flex-1 space-y-2">
                  <Skeleton className="h-4 w-3/4 bg-gray-700" />
                  <Skeleton className="h-3 w-1/2 bg-gray-700" />
                  <Skeleton className="h-3 w-1/4 bg-gray-700" />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white">Auction Queue</h2>
          <p className="text-gray-400">Manage your upcoming auctions</p>
        </div>
        
        <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
          <DialogTrigger asChild>
            <Button className="bg-cyan-500 hover:bg-cyan-600">
              <Plus className="w-4 h-4 mr-2" />
              Add Item
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md bg-gray-800 border-gray-700 max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="text-white">Add Item to Queue</DialogTitle>
            </DialogHeader>
            
            <form onSubmit={handleAddItem} className="space-y-4">
              <div>
                <label className="block text-sm text-gray-300 mb-2">Item Title</label>
                <Input
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  placeholder="e.g., Rainbow Acropora Colony"
                  className="bg-gray-700 border-gray-600 text-white"
                  required
                />
              </div>

              <div>
                <label className="block text-sm text-gray-300 mb-2">Description</label>
                <Textarea
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Describe your item..."
                  className="bg-gray-700 border-gray-600 text-white"
                  rows={3}
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm text-gray-300 mb-2">Category</label>
                  <Select value={formData.category} onValueChange={(value) => setFormData({ ...formData, category: value })}>
                    <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Coral">Coral</SelectItem>
                      <SelectItem value="Fish">Fish</SelectItem>
                      <SelectItem value="Equipment">Equipment</SelectItem>
                      <SelectItem value="Live Rock">Live Rock</SelectItem>
                      <SelectItem value="Other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="block text-sm text-gray-300 mb-2">Duration (minutes)</label>
                  <Select value={formData.duration} onValueChange={(value) => setFormData({ ...formData, duration: value })}>
                    <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="15">15 minutes</SelectItem>
                      <SelectItem value="30">30 minutes</SelectItem>
                      <SelectItem value="60">1 hour</SelectItem>
                      <SelectItem value="120">2 hours</SelectItem>
                      <SelectItem value="180">3 hours</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm text-gray-300 mb-2">Starting Bid ($)</label>
                  <Input
                    type="number"
                    step="0.01"
                    min="0.01"
                    value={formData.startingBid}
                    onChange={(e) => setFormData({ ...formData, startingBid: e.target.value })}
                    placeholder="10.00"
                    className="bg-gray-700 border-gray-600 text-white"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm text-gray-300 mb-2">Reserve Price ($)</label>
                  <Input
                    type="number"
                    step="0.01"
                    min="0.01"
                    value={formData.reservePrice}
                    onChange={(e) => setFormData({ ...formData, reservePrice: e.target.value })}
                    placeholder="Optional"
                    className="bg-gray-700 border-gray-600 text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm text-gray-300 mb-2">Buy It Now ($)</label>
                  <Input
                    type="number"
                    step="0.01"
                    min="0.01"
                    value={formData.buyItNowPrice}
                    onChange={(e) => setFormData({ ...formData, buyItNowPrice: e.target.value })}
                    placeholder="Optional"
                    className="bg-gray-700 border-gray-600 text-white"
                  />
                </div>

                <div>
                  <label className="block text-sm text-gray-300 mb-2">Min Increment ($)</label>
                  <Input
                    type="number"
                    step="0.01"
                    min="0.01"
                    value={formData.minimumIncrement}
                    onChange={(e) => setFormData({ ...formData, minimumIncrement: e.target.value })}
                    placeholder="5.00"
                    className="bg-gray-700 border-gray-600 text-white"
                    required
                  />
                </div>
              </div>

              <div className="flex items-center justify-between">
                <label className="text-sm text-gray-300">Auto-extend auction</label>
                <Switch
                  checked={formData.autoExtend}
                  onCheckedChange={(checked) => setFormData({ ...formData, autoExtend: checked })}
                />
              </div>

              <div className="flex gap-2 pt-4">
                <Button type="submit" className="flex-1 bg-cyan-500 hover:bg-cyan-600">
                  Add to Queue
                </Button>
                <Button 
                  type="button" 
                  variant="outline" 
                  onClick={() => setShowAddDialog(false)}
                  className="border-gray-600 text-gray-300"
                >
                  Cancel
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Queue Items */}
      {queueItems.length === 0 ? (
        <Card className="bg-gray-800 border-gray-700">
          <CardContent className="p-8 text-center">
            <Package className="w-16 h-16 text-gray-600 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-white mb-2">No Items in Queue</h3>
            <p className="text-gray-400 mb-6">Add items to your auction queue to get started selling.</p>
            <Button onClick={() => setShowAddDialog(true)} className="bg-cyan-500 hover:bg-cyan-600">
              <Plus className="w-4 h-4 mr-2" />
              Add First Item
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {queueItems.map((item) => (
            <Card key={item.id} className="bg-gray-800 border-gray-700 hover:bg-gray-750 transition-colors">
              <CardContent className="p-4">
                <div className="flex items-start gap-4">
                  {/* Item Image Placeholder */}
                  <div className="w-16 h-16 bg-gradient-to-br from-cyan-500 to-blue-600 rounded-lg flex items-center justify-center">
                    <Package className="w-8 h-8 text-white" />
                  </div>

                  <div className="flex-1 min-w-0">
                    {/* Item Header */}
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <h3 className="font-medium text-white mb-1">{item.title}</h3>
                        <p className="text-sm text-gray-400 line-clamp-2">{item.description}</p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant={getStatusBadgeVariant(item.status)} className="flex items-center gap-1">
                          {getStatusIcon(item.status)}
                          {item.status.charAt(0).toUpperCase() + item.status.slice(1)}
                        </Badge>
                      </div>
                    </div>

                    {/* Item Details */}
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-3">
                      <div>
                        <p className="text-xs text-gray-500">Starting Bid</p>
                        <p className="text-sm font-medium text-cyan-400">${item.startingBid}</p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-500">Duration</p>
                        <p className="text-sm font-medium text-white">{formatDuration(item.duration)}</p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-500">Category</p>
                        <p className="text-sm font-medium text-white">{item.category}</p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-500">Min Increment</p>
                        <p className="text-sm font-medium text-white">
                          {item.incrementType === 'percentage' ? `${item.minimumIncrement}%` : `$${item.minimumIncrement}`}
                        </p>
                      </div>
                    </div>

                    {/* Additional Info */}
                    <div className="flex items-center gap-4 text-xs text-gray-500 mb-3">
                      <span>Queued: {new Date(item.queuedAt).toLocaleDateString()}</span>
                      {item.reservePrice && <span>Reserve: ${item.reservePrice}</span>}
                      {item.buyItNowPrice && <span>Buy Now: ${item.buyItNowPrice}</span>}
                      {item.autoExtend && <span>Auto-extend enabled</span>}
                    </div>

                    {/* Action Buttons */}
                    <div className="flex items-center gap-2">
                      {item.status === 'queued' && (
                        <>
                          <Button
                            onClick={() => handleStartAuction(item)}
                            disabled={starting === item.id}
                            size="sm"
                            className="bg-green-500 hover:bg-green-600"
                          >
                            {starting === item.id ? (
                              <>
                                <Timer className="w-4 h-4 mr-2 animate-spin" />
                                Starting...
                              </>
                            ) : (
                              <>
                                <Play className="w-4 h-4 mr-2" />
                                Start Auction
                              </>
                            )}
                          </Button>
                          <Button
                            onClick={() => setEditingItem(item)}
                            size="sm"
                            variant="outline"
                            className="border-gray-600 text-gray-300"
                          >
                            <Edit3 className="w-4 h-4 mr-2" />
                            Edit
                          </Button>
                          <Button
                            onClick={() => handleRemoveItem(item.id)}
                            size="sm"
                            variant="outline"
                            className="border-red-600 text-red-400 hover:bg-red-600"
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </>
                      )}
                      
                      {item.status === 'active' && (
                        <div className="flex items-center gap-2 text-sm text-green-400">
                          <TrendingUp className="w-4 h-4" />
                          Live Auction - Current Bid: ${item.currentBid}
                          <span className="text-gray-400">({item.bidCount} bids)</span>
                        </div>
                      )}

                      {item.status === 'completed' && (
                        <div className="flex items-center gap-2 text-sm text-blue-400">
                          <CheckCircle className="w-4 h-4" />
                          Sold for ${item.currentBid}
                          {item.highestBidder && <span className="text-gray-400">to {item.highestBidder}</span>}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}