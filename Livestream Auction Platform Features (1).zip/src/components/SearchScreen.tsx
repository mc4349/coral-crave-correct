import React from 'react';

interface User {
  id: string;
  email: string;
  name: string;
  avatar?: string;
}

interface SearchScreenProps {
  user: User | null;
  onJoinLive: (streamId: string) => void;
  onAuthRequired: () => void;
}

export function SearchScreen({ user, onJoinLive, onAuthRequired }: SearchScreenProps) {
  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold text-white mb-4">Search</h1>
      <p className="text-gray-400">Search functionality coming soon...</p>
    </div>
  );
}

export default SearchScreen;