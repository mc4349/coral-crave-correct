import React, { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle, SheetTrigger } from './ui/sheet';
import { Clock, DollarSign, Gavel, ChevronUp, Package, Truck, AlertCircle, Zap } from 'lucide-react';

interface AuctionItem {
  id: string;
  title: string;
  description: string;
  startingPrice: number;
  currentPrice: number;
  timeLeft: number;
  endTime: number;
  image: string;
  gallery?: string[];
  shippingNote?: string;
  bids: Array<{
    id: string;
    amount: number;
    bidder: string;
    timestamp: number;
  }>;
}

interface QueueItem {
  id: string;
  title: string;
  image: string;
  position: number;
}

interface PinnedLotCardProps {
  currentItem: AuctionItem | null;
  nextItem: QueueItem | null;
  onPlaceBid: (amount: number) => Promise<void>;
  isHost?: boolean;
  className?: string;
}

export function PinnedLotCard({ 
  currentItem, 
  nextItem, 
  onPlaceBid, 
  isHost = false,
  className = "" 
}: PinnedLotCardProps) {
  const [currentTimeLeft, setCurrentTimeLeft] = useState(0);
  const [isPlacingBid, setIsPlacingBid] = useState(false);

  // Update timer
  useEffect(() => {
    if (!currentItem) return;
    
    const updateTimer = () => {
      const now = Date.now();
      const timeRemaining = Math.max(0, currentItem.endTime - now);
      setCurrentTimeLeft(timeRemaining);
    };

    updateTimer();
    const interval = setInterval(updateTimer, 1000);

    return () => clearInterval(interval);
  }, [currentItem?.endTime]);

  const formatTime = (ms: number) => {
    if (ms <= 0) return '00:00';
    
    const minutes = Math.floor(ms / 60000);
    const seconds = Math.floor((ms % 60000) / 1000);
    
    return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  };

  const handlePresetBid = async (increment: number) => {
    if (isHost || !currentItem || currentTimeLeft <= 0) return;
    
    try {
      setIsPlacingBid(true);
      const newBidAmount = currentItem.currentPrice + increment;
      await onPlaceBid(newBidAmount);
    } catch (error) {
      console.error('Failed to place bid:', error);
    } finally {
      setIsPlacingBid(false);
    }
  };

  const getMinimumBid = () => {
    if (!currentItem) return 0;
    return currentItem.currentPrice + 1;
  };

  // If no current item and no next item, don't show the card
  if (!currentItem && !nextItem) {
    return null;
  }

  const isTimeRunningOut = currentTimeLeft <= 30000 && currentTimeLeft > 0;
  const isTimeCritical = currentTimeLeft <= 10000 && currentTimeLeft > 0;

  return (
    <div className={`w-80 max-w-[90vw] bg-gray-900/95 backdrop-blur-sm border border-gray-700 rounded-lg shadow-2xl ${className}`}>
      {/* Current Auction Item */}
      {currentItem && currentTimeLeft > 0 && (
        <div className="p-3">
          <Sheet>
            <SheetTrigger asChild>
              <div className="bg-gray-800 rounded-lg p-3 cursor-pointer hover:bg-gray-750 transition-colors">
                <div className="flex items-center gap-3">
                  {/* Item Image */}
                  <div className="relative flex-shrink-0">
                    <img 
                      src={currentItem.image} 
                      alt={currentItem.title}
                      className="w-12 h-12 object-cover rounded-lg"
                    />
                    <div className="absolute -top-1 -right-1 bg-red-500 text-white text-xs px-1.5 py-0.5 rounded-full">
                      LIVE
                    </div>
                  </div>

                  {/* Item Info */}
                  <div className="flex-1 min-w-0">
                    <h3 className="font-bold text-white text-sm truncate">{currentItem.title}</h3>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-green-400 font-bold text-base">
                        ${currentItem.currentPrice.toLocaleString()}
                      </span>
                      <div className="flex items-center gap-1">
                        <Clock 
                          className={`${
                            isTimeCritical ? 'text-red-400' : 
                            isTimeRunningOut ? 'text-yellow-400' : 
                            'text-cyan-400'
                          }`} 
                          size={12} 
                        />
                        <span className={`font-mono text-xs font-bold ${
                          isTimeCritical ? 'text-red-400' : 
                          isTimeRunningOut ? 'text-yellow-400' : 
                          'text-white'
                        }`}>
                          {formatTime(currentTimeLeft)}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Expand Indicator */}
                  <ChevronUp className="text-gray-400" size={16} />
                </div>

                {/* Quick Bid Buttons - Only for non-hosts */}
                {!isHost && (
                  <div className="grid grid-cols-3 gap-2 mt-2">
                    <Button
                      onClick={(e) => {
                        e.stopPropagation();
                        handlePresetBid(1);
                      }}
                      disabled={isPlacingBid}
                      className="bg-cyan-600 hover:bg-cyan-500 text-white h-7 text-xs"
                      size="sm"
                    >
                      +$1
                    </Button>
                    <Button
                      onClick={(e) => {
                        e.stopPropagation();
                        handlePresetBid(5);
                      }}
                      disabled={isPlacingBid}
                      className="bg-cyan-600 hover:bg-cyan-500 text-white h-7 text-xs"
                      size="sm"
                    >
                      +$5
                    </Button>
                    <Button
                      onClick={(e) => {
                        e.stopPropagation();
                        handlePresetBid(10);
                      }}
                      disabled={isPlacingBid}
                      className="bg-cyan-600 hover:bg-cyan-500 text-white h-7 text-xs"
                      size="sm"
                    >
                      +$10
                    </Button>
                  </div>
                )}

                {/* Host Notice */}
                {isHost && (
                  <div className="mt-2 p-2 bg-yellow-500/10 rounded-lg border border-yellow-500/20">
                    <div className="flex items-center gap-2 text-yellow-400 text-xs">
                      <AlertCircle size={12} />
                      <span>Tap for details - Can't bid on own auction</span>
                    </div>
                  </div>
                )}
              </div>
            </SheetTrigger>

            {/* Full Item Sheet */}
            <SheetContent side="bottom" className="h-[80vh] bg-gray-900 border-gray-700">
              <SheetHeader>
                <SheetTitle className="text-white text-xl">{currentItem.title}</SheetTitle>
                <SheetDescription className="text-gray-400">
                  {currentItem.description}
                </SheetDescription>
              </SheetHeader>

              <div className="mt-6 space-y-6 overflow-y-auto h-full pb-20">
                {/* Image Gallery */}
                <div className="space-y-4">
                  <h3 className="font-medium text-white">Gallery</h3>
                  <div className="grid grid-cols-2 gap-3">
                    <img 
                      src={currentItem.image} 
                      alt={currentItem.title}
                      className="w-full h-40 object-cover rounded-lg"
                    />
                    {currentItem.gallery?.map((image, index) => (
                      <img 
                        key={index}
                        src={image} 
                        alt={`${currentItem.title} ${index + 2}`}
                        className="w-full h-40 object-cover rounded-lg"
                      />
                    ))}
                  </div>
                </div>

                {/* Current Bid Info */}
                <div className="bg-gray-800 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-gray-400">Current Bid</span>
                    <div className="flex items-center gap-2">
                      <Clock className={isTimeCritical ? 'text-red-400' : 'text-cyan-400'} size={16} />
                      <span className={`font-mono font-bold ${isTimeCritical ? 'text-red-400' : 'text-white'}`}>
                        {formatTime(currentTimeLeft)}
                      </span>
                    </div>
                  </div>
                  <div className="text-2xl font-bold text-green-400 mb-2">
                    ${currentItem.currentPrice.toLocaleString()}
                  </div>
                  <div className="text-sm text-gray-400">
                    Starting bid: ${currentItem.startingPrice.toLocaleString()} • {currentItem.bids.length} bids
                  </div>
                </div>

                {/* Shipping Information */}
                {currentItem.shippingNote && (
                  <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-4">
                    <div className="flex items-center gap-2 mb-2">
                      <Truck className="text-blue-400" size={16} />
                      <span className="font-medium text-blue-400">Shipping Info</span>
                    </div>
                    <p className="text-gray-300 text-sm">{currentItem.shippingNote}</p>
                  </div>
                )}

                {/* Bidding Actions - Full Interface */}
                {!isHost && (
                  <div className="space-y-4">
                    <h3 className="font-medium text-white">Place Your Bid</h3>
                    
                    {/* Quick Bids */}
                    <div>
                      <div className="text-sm text-gray-400 mb-2">Quick Bid</div>
                      <div className="grid grid-cols-3 gap-2">
                        <Button
                          onClick={() => handlePresetBid(1)}
                          disabled={isPlacingBid}
                          className="bg-cyan-600 hover:bg-cyan-500 text-white"
                        >
                          +$1
                        </Button>
                        <Button
                          onClick={() => handlePresetBid(5)}
                          disabled={isPlacingBid}
                          className="bg-cyan-600 hover:bg-cyan-500 text-white"
                        >
                          +$5
                        </Button>
                        <Button
                          onClick={() => handlePresetBid(10)}
                          disabled={isPlacingBid}
                          className="bg-cyan-600 hover:bg-cyan-500 text-white"
                        >
                          +$10
                        </Button>
                      </div>
                    </div>

                    {/* Minimum Bid Notice */}
                    <div className="flex items-center gap-2 text-sm text-gray-400">
                      <AlertCircle size={14} />
                      <span>Minimum bid: ${getMinimumBid().toLocaleString()}</span>
                    </div>

                    {/* Soft Close Warning */}
                    {isTimeRunningOut && (
                      <div className="flex items-center gap-2 text-yellow-400 text-sm bg-yellow-500/10 p-3 rounded-lg">
                        <Zap size={14} />
                        <span>Bidding with ≤10 seconds remaining extends auction by 10 seconds</span>
                      </div>
                    )}
                  </div>
                )}

                {/* Recent Bids */}
                {currentItem.bids.length > 0 && (
                  <div>
                    <h3 className="font-medium text-white mb-3">Recent Bids</h3>
                    <div className="space-y-2">
                      {currentItem.bids.slice(-5).reverse().map((bid) => (
                        <div key={bid.id} className="flex items-center justify-between p-3 bg-gray-800 rounded-lg">
                          <span className="text-gray-300">{bid.bidder}</span>
                          <span className="text-green-400 font-medium">${bid.amount.toLocaleString()}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </SheetContent>
          </Sheet>
        </div>
      )}

      {/* Next Item Teaser */}
      {!currentItem && nextItem && (
        <div className="p-3">
          <div className="bg-gray-800 rounded-lg p-3">
            <div className="flex items-center gap-3">
              <div className="relative flex-shrink-0">
                <img 
                  src={nextItem.image} 
                  alt={nextItem.title}
                  className="w-16 h-16 object-cover rounded-lg opacity-75"
                />
                <div className="absolute -top-1 -right-1 bg-orange-500 text-white text-xs px-1.5 py-0.5 rounded-full">
                  NEXT
                </div>
              </div>

              <div className="flex-1">
                <h3 className="font-bold text-white text-sm">{nextItem.title}</h3>
                <div className="flex items-center gap-2 mt-1">
                  <Badge variant="outline" className="text-orange-400 border-orange-400">
                    <Package size={12} className="mr-1" />
                    Position #{nextItem.position}
                  </Badge>
                  <span className="text-gray-400 text-sm">Coming up next...</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Auction Ended State */}
      {currentItem && currentTimeLeft <= 0 && (
        <div className="p-3">
          <div className="bg-red-500/10 border border-red-500/20 rounded-lg p-3">
            <div className="flex items-center gap-3">
              <img 
                src={currentItem.image} 
                alt={currentItem.title}
                className="w-16 h-16 object-cover rounded-lg opacity-75"
              />
              <div className="flex-1">
                <h3 className="font-bold text-white text-sm">{currentItem.title}</h3>
                <div className="flex items-center gap-2 mt-1">
                  <span className="text-red-400 font-bold">ENDED</span>
                  <span className="text-green-400 font-bold">
                    ${currentItem.currentPrice.toLocaleString()}
                  </span>
                </div>
                {currentItem.bids.length > 0 && (
                  <div className="text-sm text-gray-400 mt-1">
                    Winner: {currentItem.bids[currentItem.bids.length - 1]?.bidder}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}