import React, { useState, useEffect } from 'react';
import { 
  DollarSign, 
  TrendingUp, 
  Package, 
  CreditCard, 
  Settings, 
  AlertCircle, 
  CheckCircle,
  ExternalLink,
  Calendar,
  BarChart3,
  Users
} from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Progress } from './ui/progress';
import { Separator } from './ui/separator';
import { PayPalConnect } from './PayPalConnect';

interface SellerStats {
  totalEarings: number;
  pendingPayouts: number;
  totalSales: number;
  averageItemValue: number;
  monthlyEarnings: number;
  payoutStatus: 'connected' | 'not_connected' | 'pending';
  paypalAccount?: string;
}

interface Sale {
  id: string;
  itemTitle: string;
  winningBid: number;
  buyerName: string;
  dateCompleted: string;
  commissionFee: number;
  processingFee: number;
  netPayout: number;
  status: 'completed' | 'pending' | 'shipped';
  trackingNumber?: string;
}

interface SellerDashboardProps {
  userId: string;
}

export function SellerDashboard({ userId }: SellerDashboardProps) {
  const [stats, setStats] = useState<SellerStats | null>(null);
  const [sales, setSales] = useState<Sale[]>([]);
  const [loading, setLoading] = useState(true);
  const [paypalConnected, setPaypalConnected] = useState(false);
  const [sellerMerchantId, setSellerMerchantId] = useState<string | undefined>();

  useEffect(() => {
    fetchSellerData();
  }, [userId]);

  const fetchSellerData = async () => {
    try {
      const [statsResponse, salesResponse] = await Promise.all([
        fetch(`https://${window.supabase?.supabaseUrl?.split('//')[1]}/functions/v1/make-server-9f7745d8/seller-stats?userId=${userId}`, {
          headers: { 'Authorization': `Bearer ${window.supabase?.supabaseKey}` }
        }),
        fetch(`https://${window.supabase?.supabaseUrl?.split('//')[1]}/functions/v1/make-server-9f7745d8/seller-sales?userId=${userId}`, {
          headers: { 'Authorization': `Bearer ${window.supabase?.supabaseKey}` }
        })
      ]);

      if (statsResponse.ok) {
        const statsData = await statsResponse.json();
        setStats(statsData);
      }

      if (salesResponse.ok) {
        const salesData = await salesResponse.json();
        setSales(salesData.sales || []);
      }
    } catch (error) {
      console.error('Failed to fetch seller data:', error);
    } finally {
      setLoading(false);
    }
  };

  // Handle PayPal connection status change
  const handlePayPalConnectionChange = (isConnected: boolean, merchantId?: string) => {
    setPaypalConnected(isConnected);
    setSellerMerchantId(merchantId);
  };

  if (loading) {
    return (
      <div className="p-6">
        <div className="animate-pulse space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[1, 2, 3, 4].map(i => (
              <div key={i} className="h-32 bg-gray-700 rounded-lg"></div>
            ))}
          </div>
          <div className="h-96 bg-gray-700 rounded-lg"></div>
        </div>
      </div>
    );
  }

  const PaymentSetupSection = () => (
    <Card className="bg-gray-800 border-gray-700">
      <CardHeader>
        <CardTitle className="text-xl text-white flex items-center">
          <CreditCard className="w-5 h-5 mr-2" />
          Payment Setup
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {stats?.payoutStatus === 'connected' ? (
            <div className="flex items-center justify-between p-4 bg-green-500/20 border border-green-500/30 rounded-lg">
              <div className="flex items-center space-x-3">
                <CheckCircle className="w-5 h-5 text-green-400" />
                <div>
                  <p className="text-green-400 font-medium">PayPal Connected</p>
                  <p className="text-sm text-gray-300">****{stats.paypalAccount}</p>
                </div>
              </div>
              <Badge variant="outline" className="border-green-500 text-green-400">
                Active
              </Badge>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="flex items-center space-x-3 p-4 bg-yellow-500/20 border border-yellow-500/30 rounded-lg">
                <AlertCircle className="w-5 h-5 text-yellow-400" />
                <div>
                  <p className="text-yellow-400 font-medium">PayPal Not Connected</p>
                  <p className="text-sm text-gray-300">Connect your PayPal account to receive payouts</p>
                </div>
              </div>
              
              <Button
                onClick={handleConnectPayPal}
                disabled={connectingPayPal}
                className="w-full bg-cyan-600 hover:bg-cyan-700 text-white"
              >
                {connectingPayPal ? (
                  <div className="flex items-center space-x-2">
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    <span>Connecting...</span>
                  </div>
                ) : (
                  <>
                    <ExternalLink className="w-4 h-4 mr-2" />
                    Connect PayPal Account
                  </>
                )}
              </Button>
            </div>
          )}
          
          <div className="p-4 bg-gray-700 rounded-lg">
            <h4 className="font-medium text-white mb-2">Fee Structure</h4>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-300">Coral Crave Commission</span>
                <span className="text-red-400">8%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-300">Payment Processing</span>
                <span className="text-red-400">2.9% + $0.30</span>
              </div>
              <Separator className="bg-gray-600" />
              <p className="text-cyan-400 text-xs">
                Funds go directly to your PayPal account after fees are deducted per transaction.
              </p>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );

  const SalesTable = () => (
    <Card className="bg-gray-800 border-gray-700">
      <CardHeader>
        <CardTitle className="text-xl text-white">Recent Sales</CardTitle>
      </CardHeader>
      <CardContent>
        {sales.length === 0 ? (
          <div className="text-center py-8">
            <BarChart3 className="w-12 h-12 text-gray-500 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-400">No Sales Yet</h3>
            <p className="text-gray-500">Your completed sales will appear here.</p>
          </div>
        ) : (
          <div className="space-y-4">
            {sales.map((sale) => (
              <div key={sale.id} className="p-4 bg-gray-700 rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-medium text-white">{sale.itemTitle}</h4>
                  <Badge variant={sale.status === 'completed' ? 'default' : 'secondary'}>
                    {sale.status}
                  </Badge>
                </div>
                
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm mb-3">
                  <div>
                    <p className="text-gray-400">Buyer</p>
                    <p className="text-white">{sale.buyerName}</p>
                  </div>
                  <div>
                    <p className="text-gray-400">Sale Date</p>
                    <p className="text-white">{new Date(sale.dateCompleted).toLocaleDateString()}</p>
                  </div>
                  <div>
                    <p className="text-gray-400">Winning Bid</p>
                    <p className="text-white">${sale.winningBid.toFixed(2)}</p>
                  </div>
                  <div>
                    <p className="text-gray-400">Your Payout</p>
                    <p className="text-green-400 font-semibold">${sale.netPayout.toFixed(2)}</p>
                  </div>
                </div>

                <div className="text-xs text-gray-400">
                  <span>Fees: Commission ${sale.commissionFee.toFixed(2)} + Processing ${sale.processingFee.toFixed(2)}</span>
                  {sale.trackingNumber && (
                    <span className="ml-4">Tracking: {sale.trackingNumber}</span>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-white">Seller Dashboard</h1>
        <Button variant="outline" className="border-gray-600 text-gray-300 hover:bg-gray-700">
          <Settings className="w-4 h-4 mr-2" />
          Settings
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Card className="bg-gray-800 border-gray-700">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-400">Total Earnings</p>
                <p className="text-2xl font-bold text-white">
                  ${stats?.totalEarings?.toFixed(2) || '0.00'}
                </p>
              </div>
              <DollarSign className="w-8 h-8 text-green-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gray-800 border-gray-700">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-400">Pending Payouts</p>
                <p className="text-2xl font-bold text-white">
                  ${stats?.pendingPayouts?.toFixed(2) || '0.00'}
                </p>
              </div>
              <TrendingUp className="w-8 h-8 text-yellow-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gray-800 border-gray-700">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-400">Total Sales</p>
                <p className="text-2xl font-bold text-white">
                  {stats?.totalSales || 0}
                </p>
              </div>
              <Package className="w-8 h-8 text-cyan-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gray-800 border-gray-700">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-400">Avg. Item Value</p>
                <p className="text-2xl font-bold text-white">
                  ${stats?.averageItemValue?.toFixed(2) || '0.00'}
                </p>
              </div>
              <BarChart3 className="w-8 h-8 text-purple-400" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content Tabs */}
      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3 bg-gray-800">
          <TabsTrigger value="overview" className="data-[state=active]:bg-gray-700">
            Overview
          </TabsTrigger>
          <TabsTrigger value="sales" className="data-[state=active]:bg-gray-700">
            Sales History
          </TabsTrigger>
          <TabsTrigger value="payouts" className="data-[state=active]:bg-gray-700">
            Payouts
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <PayPalConnect 
              onConnectionChange={handlePayPalConnectionChange}
              className="bg-gray-800 border-gray-700"
            />
            
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="text-xl text-white">Monthly Performance</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-gray-300">This Month's Earnings</span>
                    <span className="text-xl font-bold text-green-400">
                      ${stats?.monthlyEarnings?.toFixed(2) || '0.00'}
                    </span>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-400">Progress to last month</span>
                      <span className="text-gray-400">75%</span>
                    </div>
                    <Progress value={75} className="h-2" />
                  </div>

                  <Separator className="bg-gray-600" />
                  
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="text-gray-400">Items Sold</p>
                      <p className="text-white font-semibold">{sales.length}</p>
                    </div>
                    <div>
                      <p className="text-gray-400">Avg. Sale</p>
                      <p className="text-white font-semibold">${stats?.averageItemValue?.toFixed(2) || '0.00'}</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="sales">
          <SalesTable />
        </TabsContent>

        <TabsContent value="payouts">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <PayPalConnect 
              onConnectionChange={handlePayPalConnectionChange}
              className="bg-gray-800 border-gray-700"
            />
            
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle className="text-xl text-white">Payout History</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center py-8">
                  <Calendar className="w-12 h-12 text-gray-500 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-400">No Payouts Yet</h3>
                  <p className="text-gray-500">Your payout history will appear here after sales are completed.</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}