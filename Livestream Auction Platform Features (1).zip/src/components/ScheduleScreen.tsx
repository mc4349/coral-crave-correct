import React from 'react';

interface User {
  id: string;
  email: string;
  name: string;
  avatar?: string;
}

interface ScheduleScreenProps {
  user: User | null;
  onStartAuction: (auctionId: string) => void;
  onEditAuction: (auctionId: string) => void;
}

export function ScheduleScreen({ user, onStartAuction, onEditAuction }: ScheduleScreenProps) {
  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold text-white mb-4">Schedule</h1>
      <p className="text-gray-400">Auction scheduling coming soon...</p>
    </div>
  );
}

export default ScheduleScreen;