import React, { useState, useEffect } from 'react';
import { Play, Users, Shield, Zap, TrendingUp, MessageCircle, Gavel, Timer, LogIn, UserPlus, ExternalLink, ChevronLeft, ChevronRight } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { RecommendationsEngine } from './RecommendationsEngine';
import { BiddingTestPanel } from './BiddingTestPanel';
import { ServerStatusChecker } from './ServerStatusChecker';
import { NetworkDiagnostic } from './NetworkDiagnostic';
import { ImportTestDiagnostic } from './ImportTestDiagnostic';

interface User {
  id: string;
  email: string;
  name: string;
  avatar?: string;
}

interface HomeScreenProps {
  user: User | null;
  onJoinLive: (streamId: string) => void;
  onAuthRequired: () => void;
  onNavigate?: (tab: string) => void;
}

// Ocean facts data
const oceanFacts = [
  {
    title: "New Deep-Sea Coral Species Discovered",
    description: "Scientists discover vibrant new coral species in the Mariana Trench that could revolutionize aquaculture.",
    link: "https://www.nationalgeographic.com/animals/article/new-coral-species-discovered",
    image: "https://images.unsplash.com/photo-1567448242786-2407728f469f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkZWVwJTIwc2VhJTIwY29yYWx8ZW58MXx8fHwxNTc3NzgzODYzfDA&ixlib=rb-4.1.0&q=80&w=1080"
  },
  {
    title: "Mandarin Fish Breeding Breakthrough",
    description: "Researchers achieve sustainable captive breeding of the elusive Mandarin fish using innovative techniques.",
    link: "https://www.marinebio.org/news/mandarin-fish-breeding",
    image: "https://images.unsplash.com/photo-1688826672253-72901b65222d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYW5kYXJpbiUyMGZpc2h8ZW58MXx8fHwxNzU3NzgzODY2fDA&ixlib=rb-4.1.0&q=80&w=1080"
  },
  {
    title: "Great Barrier Reef Recovery",
    description: "New coral restoration techniques show promising results in healing damaged reef ecosystems.",
    link: "https://www.gbrmpa.gov.au/news/coral-restoration",
    image: "https://images.unsplash.com/photo-1659609288520-acc88e9bd913?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb3JhbCUyMHJlc3RvcmF0aW9ufGVufDF8fHx8MTc1Nzc4Mzg2OXww&ixlib=rb-4.1.0&q=80&w=1080"
  },
  {
    title: "Rare Peppermint Angelfish Spotted",
    description: "Marine biologists capture rare footage of the $30,000 Peppermint Angelfish in its natural habitat.",
    link: "https://www.reefbuilders.com/peppermint-angelfish-discovery",
    image: "https://images.unsplash.com/photo-1510020904390-f245a6de84f5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhbmdlbGZpc2h8ZW58MXx8fHwxNzU3NzgzODcyfDA&ixlib=rb-4.1.0&q=80&w=1080"
  },
  {
    title: "Coral Symbiosis Research",
    description: "New study reveals how coral-algae partnerships could help reefs survive climate change.",
    link: "https://www.nature.com/articles/coral-symbiosis",
    image: "https://images.unsplash.com/photo-1711469402904-0cff5dda925a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb3JhbCUyMGNsb3NlJTIwdXB8ZW58MXx8fHwxNzU3NzgzODc0fDA&ixlib=rb-4.1.0&q=80&w=1080"
  }
];

export function HomeScreen({ user, onJoinLive, onAuthRequired, onNavigate }: HomeScreenProps) {
  const [currentFactIndex, setCurrentFactIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentFactIndex((prev) => (prev + 1) % oceanFacts.length);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const nextFact = () => {
    setCurrentFactIndex((prev) => (prev + 1) % oceanFacts.length);
  };

  const prevFact = () => {
    setCurrentFactIndex((prev) => (prev - 1 + oceanFacts.length) % oceanFacts.length);
  };

  const handleWatchItem = (itemId: string) => {
    if (!user) {
      onAuthRequired();
      return;
    }
    console.log('Watching item:', itemId);
  };

  const handleItemClick = (itemId: string) => {
    onJoinLive(itemId);
  };

  return (
    <div className="min-h-screen bg-gray-900">
      {/* Hero Section */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-cyan-900 via-teal-900 to-blue-900 opacity-90"></div>
        <div className="relative px-4 py-16 md:py-24">
          <div className="max-w-6xl mx-auto text-center">
            <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
              Welcome to <span className="text-cyan-400">Coral Crave</span>
            </h1>
            <p className="text-xl md:text-2xl text-gray-200 mb-8 max-w-3xl mx-auto">
              The premier livestream auction platform for the aquarium and reef community. 
              Discover rare corals, exotic fish, and premium equipment from trusted sellers worldwide.
            </p>
            
            {/* Auth buttons for non-logged in users */}
            {!user && (
              <div className="flex flex-col sm:flex-row gap-4 justify-center mb-8">
                <button 
                  onClick={onAuthRequired}
                  className="bg-cyan-500 text-white px-8 py-4 rounded-lg hover:bg-cyan-400 transition-colors flex items-center justify-center gap-2"
                >
                  <LogIn size={20} />
                  Sign In
                </button>
                <button 
                  onClick={onAuthRequired}
                  className="bg-transparent border-2 border-cyan-400 text-cyan-400 px-8 py-4 rounded-lg hover:bg-cyan-400 hover:text-white transition-colors flex items-center justify-center gap-2"
                >
                  <UserPlus size={20} />
                  Create Account
                </button>
              </div>
            )}
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button 
                onClick={() => onNavigate ? onNavigate('explore') : window.location.hash = '#explore'}
                className="bg-cyan-500 text-white px-8 py-4 rounded-lg hover:bg-cyan-400 transition-colors flex items-center justify-center gap-2"
              >
                <Play size={20} />
                Explore Live Auctions
              </button>
              <button 
                onClick={onAuthRequired}
                className="bg-transparent border-2 border-cyan-400 text-cyan-400 px-8 py-4 rounded-lg hover:bg-cyan-400 hover:text-white transition-colors"
              >
                Start Selling
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Ocean Facts Carousel */}
      <section className="py-16 px-4 bg-gradient-to-r from-teal-800 to-cyan-800">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center text-white mb-12">
            Latest Ocean & Reef Discoveries
          </h2>
          
          <div className="relative bg-gray-800 rounded-xl overflow-hidden">
            <div className="flex items-center">
              <button 
                onClick={prevFact}
                className="absolute left-4 z-10 p-2 bg-black bg-opacity-50 text-white rounded-full hover:bg-opacity-75 transition-colors"
              >
                <ChevronLeft size={24} />
              </button>
              
              <div className="w-full p-8">
                <div className="flex flex-col md:flex-row gap-6 items-center">
                  <div className="md:w-1/3">
                    <ImageWithFallback 
                      src={oceanFacts[currentFactIndex].image}
                      alt={oceanFacts[currentFactIndex].title}
                      className="w-full h-48 object-cover rounded-lg"
                    />
                  </div>
                  <div className="md:w-2/3">
                    <h3 className="text-2xl font-bold text-white mb-4">
                      {oceanFacts[currentFactIndex].title}
                    </h3>
                    <p className="text-gray-300 mb-4 text-lg">
                      {oceanFacts[currentFactIndex].description}
                    </p>
                    <a 
                      href={oceanFacts[currentFactIndex].link}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 text-cyan-400 hover:text-cyan-300 transition-colors"
                    >
                      Read Full Article <ExternalLink size={16} />
                    </a>
                  </div>
                </div>
              </div>
              
              <button 
                onClick={nextFact}
                className="absolute right-4 z-10 p-2 bg-black bg-opacity-50 text-white rounded-full hover:bg-opacity-75 transition-colors"
              >
                <ChevronRight size={24} />
              </button>
            </div>
            
            {/* Indicators */}
            <div className="flex justify-center pb-4">
              {oceanFacts.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentFactIndex(index)}
                  className={`w-3 h-3 mx-1 rounded-full transition-colors ${
                    index === currentFactIndex ? 'bg-cyan-400' : 'bg-gray-600'
                  }`}
                />
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center text-white mb-12">
            Why Choose Coral Crave?
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-gray-800 rounded-xl p-6 text-center">
              <div className="w-16 h-16 bg-cyan-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <Zap className="text-white" size={32} />
              </div>
              <h3 className="text-xl font-bold text-white mb-3">Live Bidding</h3>
              <p className="text-gray-400">
                Real-time auctions with instant bidding. Watch the action unfold and place bids as sellers showcase their premium specimens.
              </p>
            </div>

            <div className="bg-gray-800 rounded-xl p-6 text-center">
              <div className="w-16 h-16 bg-teal-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <Shield className="text-white" size={32} />
              </div>
              <h3 className="text-xl font-bold text-white mb-3">Trusted Sellers</h3>
              <p className="text-gray-400">
                Verified sellers with reputation ratings. Shop with confidence knowing you're buying from experienced aquarists.
              </p>
            </div>

            <div className="bg-gray-800 rounded-xl p-6 text-center">
              <div className="w-16 h-16 bg-blue-500 rounded-full flex items-center justify-center mx-auto mb-4">
                <MessageCircle className="text-white" size={32} />
              </div>
              <h3 className="text-xl font-bold text-white mb-3">Community Chat</h3>
              <p className="text-gray-400">
                Engage with fellow reef enthusiasts during live streams. Ask questions and share your knowledge with the community.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-16 px-4 bg-gray-800">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center text-white mb-12">
            How It Works
          </h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="w-12 h-12 bg-cyan-500 rounded-full flex items-center justify-center mx-auto mb-4 text-white font-bold text-xl">
                1
              </div>
              <h3 className="font-bold text-white mb-2">Browse Live Streams</h3>
              <p className="text-gray-400 text-sm">Discover active auctions in the Explore tab</p>
            </div>

            <div className="text-center">
              <div className="w-12 h-12 bg-teal-500 rounded-full flex items-center justify-center mx-auto mb-4 text-white font-bold text-xl">
                2
              </div>
              <h3 className="font-bold text-white mb-2">Join & Watch</h3>
              <p className="text-gray-400 text-sm">Enter live streams and see items in real-time</p>
            </div>

            <div className="text-center">
              <div className="w-12 h-12 bg-blue-500 rounded-full flex items-center justify-center mx-auto mb-4 text-white font-bold text-xl">
                3
              </div>
              <h3 className="font-bold text-white mb-2">Place Bids</h3>
              <p className="text-gray-400 text-sm">Bid on items you love with our instant bidding system</p>
            </div>

            <div className="text-center">
              <div className="w-12 h-12 bg-purple-500 rounded-full flex items-center justify-center mx-auto mb-4 text-white font-bold text-xl">
                4
              </div>
              <h3 className="font-bold text-white mb-2">Win & Enjoy</h3>
              <p className="text-gray-400 text-sm">Complete secure checkout and receive your items</p>
            </div>
          </div>
        </div>
      </section>

      {/* Categories Preview */}
      <section className="py-16 px-4">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center text-white mb-12">
            Popular Categories
          </h2>
          
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            {['Coral', 'Fish', 'Equipment', 'Inverts', 'Supplies'].map((category) => (
              <div key={category} className="bg-gray-800 rounded-xl p-6 text-center hover:bg-gray-700 transition-colors cursor-pointer">
                <div className="text-3xl mb-3">
                  {category === 'Coral' && '🪸'}
                  {category === 'Fish' && '🐠'}
                  {category === 'Equipment' && '⚙️'}
                  {category === 'Inverts' && '🦐'}
                  {category === 'Supplies' && '🧪'}
                </div>
                <h3 className="font-medium text-white">{category}</h3>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Stats Banner */}
      <section className="py-16 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="bg-gradient-to-r from-cyan-500 via-teal-500 to-blue-500 rounded-xl p-8 text-center text-white">
            <h3 className="text-2xl md:text-3xl font-bold mb-2">Join Our Growing Community</h3>
            <p className="text-cyan-100 mb-8">Connect with reef enthusiasts from around the world</p>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div>
                <div className="text-3xl md:text-4xl font-bold">2,400+</div>
                <div className="text-cyan-100">Active Sellers</div>
              </div>
              <div>
                <div className="text-3xl md:text-4xl font-bold">15,000+</div>
                <div className="text-cyan-100">Community Members</div>
              </div>
              <div>
                <div className="text-3xl md:text-4xl font-bold">$1.2M+</div>
                <div className="text-cyan-100">Monthly Sales</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Personalized Recommendations */}
      {user && (
        <section className="py-16 px-4">
          <div className="max-w-6xl mx-auto">
            <RecommendationsEngine
              userId={user.id}
              onItemClick={handleItemClick}
              onWatch={handleWatchItem}
              compact={true}
            />
          </div>
        </section>
      )}

      {/* CTA Section */}
      <section className="py-16 px-4 bg-gray-800">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
            Ready to Start Your Reef Journey?
          </h2>
          <p className="text-xl text-gray-300 mb-8">
            Whether you're buying or selling, Coral Crave is your gateway to the aquarium community.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button 
              onClick={() => onNavigate ? onNavigate('explore') : window.location.hash = '#explore'}
              className="bg-cyan-500 text-white px-8 py-4 rounded-lg hover:bg-cyan-400 transition-colors flex items-center justify-center gap-2"
            >
              <Users size={20} />
              Explore Auctions
            </button>
            <button 
              onClick={onAuthRequired}
              className="bg-teal-500 text-white px-8 py-4 rounded-lg hover:bg-teal-400 transition-colors flex items-center justify-center gap-2"
            >
              <Gavel size={20} />
              Start Selling
            </button>
          </div>
        </div>
      </section>

      {/* Bidding Test Panel */}
      <section className="py-16 px-4">
        <div className="max-w-4xl mx-auto">
          <BiddingTestPanel user={user} onAuthRequired={onAuthRequired} />
        </div>
      </section>

      {/* Server Diagnostics */}
      <section className="py-16 px-4 bg-gray-800">
        <div className="max-w-4xl mx-auto">
          <ServerStatusChecker user={user} />
        </div>
      </section>

      {/* Network Diagnostics */}
      <section className="py-16 px-4 bg-gray-800">
        <div className="max-w-4xl mx-auto">
          <NetworkDiagnostic />
        </div>
      </section>

      {/* Import Test Diagnostics */}
      <section className="py-16 px-4 bg-gray-800">
        <div className="max-w-4xl mx-auto">
          <ImportTestDiagnostic />
        </div>
      </section>
    </div>
  );
}