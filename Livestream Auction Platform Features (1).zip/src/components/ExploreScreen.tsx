import React, { useState, useEffect } from 'react';
import { Search, Bell, User, Eye, Users, Heart, Play, Filter, ChevronRight, Clock, DollarSign } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Card, CardContent } from './ui/card';
import { Avatar, AvatarFallback, AvatarImage } from './ui/avatar';
import { Skeleton } from './ui/skeleton';
import { projectId, publicAnonKey } from '../utils/supabase/info';

interface User {
  id: string;
  email: string;
  name: string;
  avatar?: string;
}

interface LiveStream {
  id: string;
  title: string;
  description: string;
  seller: {
    id: string;
    name: string;
    avatar: string;
    verified: boolean;
    rating: number;
  };
  thumbnail: string;
  viewerCount: number;
  isLive: boolean;
  category: string;
  currentItem?: {
    title: string;
    currentBid: number;
    timeLeft: string;
  };
  tags: string[];
  startedAt: string;
}

interface ExploreScreenProps {
  user: User | null;
  onJoinLive: (streamId: string) => void;
  onAuthRequired: () => void;
}

const categories = [
  { id: 'all', label: 'All', emoji: '🌊' },
  { id: 'corals', label: 'Corals', emoji: '🪸' },
  { id: 'fish', label: 'Fish', emoji: '🐠' },
  { id: 'equipment', label: 'Equipment', emoji: '⚙️' },
  { id: 'trending', label: 'Trending', emoji: '🔥' },
];

export function ExploreScreen({ user, onJoinLive, onAuthRequired }: ExploreScreenProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [liveStreams, setLiveStreams] = useState<LiveStream[]>([]);
  const [featuredStream, setFeaturedStream] = useState<LiveStream | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    loadLiveStreams();
    
    // Auto-refresh every 30 seconds to keep viewer counts and bids current
    const interval = setInterval(() => {
      refreshLiveStreams();
    }, 30000);

    return () => clearInterval(interval);
  }, [selectedCategory]);

  const loadLiveStreams = async () => {
    setLoading(true);
    try {
      // Fetch live streams from backend
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-9f7745d8/live-streams/search?q=${encodeURIComponent(searchQuery)}&category=${selectedCategory}`, {
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`
        }
      });

      if (response.ok) {
        const data = await response.json();
        if (data.success) {
          setLiveStreams(data.streams);
          
          // Set featured stream (highest viewer count)
          if (data.streams.length > 0) {
            setFeaturedStream(data.streams.reduce((prev: LiveStream, current: LiveStream) => 
              prev.viewerCount > current.viewerCount ? prev : current
            ));
          }
          setLoading(false);
          return;
        }
      }
      
      // Fallback to mock data if API fails
      console.log('Using fallback mock data for live streams');
      
      const mockStreams: LiveStream[] = [
        {
          id: 'stream_1',
          title: 'Rare Acropora Collection Auction',
          description: 'Amazing collection of colorful acropora corals',
          seller: {
            id: 'seller_1',
            name: 'CoralKing_Reef',
            avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face',
            verified: true,
            rating: 4.8
          },
          thumbnail: 'https://images.unsplash.com/photo-1583212292454-1fe6229603b7?w=400&h=225&fit=crop',
          viewerCount: 247,
          isLive: true,
          category: 'corals',
          currentItem: {
            title: 'Rainbow Acropora Colony',
            currentBid: 125,
            timeLeft: '5m 23s'
          },
          tags: ['rare', 'acropora', 'sps'],
          startedAt: new Date(Date.now() - 45 * 60 * 1000).toISOString()
        },
        {
          id: 'stream_2',
          title: 'Premium Fish Collection',
          description: 'Healthy marine fish from our quarantine system',
          seller: {
            id: 'seller_2',
            name: 'AquaLife_Pro',
            avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face',
            verified: true,
            rating: 4.9
          },
          thumbnail: 'https://images.unsplash.com/photo-1559827260-dc66d52bef19?w=400&h=225&fit=crop',
          viewerCount: 183,
          isLive: true,
          category: 'fish',
          currentItem: {
            title: 'Mandarin Dragonet Pair',
            currentBid: 89,
            timeLeft: '12m 45s'
          },
          tags: ['fish', 'pair', 'healthy'],
          startedAt: new Date(Date.now() - 20 * 60 * 1000).toISOString()
        },
        {
          id: 'stream_3',
          title: 'Equipment & Lighting Sale',
          description: 'High-end aquarium equipment at great prices',
          seller: {
            id: 'seller_3',
            name: 'ReefTech_Supply',
            avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=100&h=100&fit=crop&crop=face',
            verified: false,
            rating: 4.6
          },
          thumbnail: 'https://images.unsplash.com/photo-1544551763-46a013bb70d5?w=400&h=225&fit=crop',
          viewerCount: 92,
          isLive: true,
          category: 'equipment',
          currentItem: {
            title: 'AI Prime 16HD LED',
            currentBid: 245,
            timeLeft: '3m 12s'
          },
          tags: ['equipment', 'lighting', 'ai'],
          startedAt: new Date(Date.now() - 15 * 60 * 1000).toISOString()
        },
        {
          id: 'stream_4',
          title: 'Soft Coral Garden',
          description: 'Beautiful soft corals and zoanthids',
          seller: {
            id: 'seller_4',
            name: 'SoftCoral_Paradise',
            avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face',
            verified: true,
            rating: 4.7
          },
          thumbnail: 'https://images.unsplash.com/photo-1583212292454-1fe6229603b7?w=400&h=225&fit=crop',
          viewerCount: 156,
          isLive: true,
          category: 'corals',
          currentItem: {
            title: 'Zoanthid Garden Rock',
            currentBid: 67,
            timeLeft: '8m 30s'
          },
          tags: ['soft-coral', 'zoanthids', 'colorful'],
          startedAt: new Date(Date.now() - 35 * 60 * 1000).toISOString()
        }
      ];

      // Filter by category
      let filteredStreams = mockStreams;
      if (selectedCategory !== 'all') {
        if (selectedCategory === 'trending') {
          filteredStreams = mockStreams.sort((a, b) => b.viewerCount - a.viewerCount);
        } else {
          filteredStreams = mockStreams.filter(stream => stream.category === selectedCategory);
        }
      }

      // Apply search filter
      if (searchQuery) {
        filteredStreams = filteredStreams.filter(stream =>
          stream.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          stream.seller.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          stream.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()))
        );
      }

      setLiveStreams(filteredStreams);
      
      // Set featured stream (highest viewer count)
      if (filteredStreams.length > 0) {
        setFeaturedStream(filteredStreams.reduce((prev, current) => 
          prev.viewerCount > current.viewerCount ? prev : current
        ));
      }

    } catch (error) {
      console.error('Failed to load live streams:', error);
    } finally {
      setLoading(false);
    }
  };

  const refreshLiveStreams = async () => {
    setRefreshing(true);
    try {
      // Simulate viewer count updates
      setLiveStreams(prev => prev.map(stream => ({
        ...stream,
        viewerCount: stream.viewerCount + Math.floor(Math.random() * 20) - 10,
        currentItem: stream.currentItem ? {
          ...stream.currentItem,
          currentBid: stream.currentItem.currentBid + Math.floor(Math.random() * 10),
          timeLeft: updateTimeLeft(stream.currentItem.timeLeft)
        } : undefined
      })));
    } catch (error) {
      console.error('Failed to refresh streams:', error);
    } finally {
      setRefreshing(false);
    }
  };

  const updateTimeLeft = (timeLeft: string): string => {
    // Simple time update simulation
    const [minutes, seconds] = timeLeft.split('m ').map(s => parseInt(s.replace('s', '')));
    let newSeconds = seconds - 30;
    let newMinutes = minutes;
    
    if (newSeconds < 0) {
      newSeconds = 30;
      newMinutes = Math.max(0, newMinutes - 1);
    }
    
    return `${newMinutes}m ${newSeconds}s`;
  };

  const handleJoinLive = (streamId: string) => {
    if (!user) {
      onAuthRequired();
      return;
    }
    onJoinLive(streamId);
  };

  const formatViewerCount = (count: number): string => {
    if (count >= 1000) {
      return `${(count / 1000).toFixed(1)}k`;
    }
    return count.toString();
  };

  const getTimeAgo = (timestamp: string): string => {
    const now = new Date();
    const started = new Date(timestamp);
    const diffInMinutes = Math.floor((now.getTime() - started.getTime()) / 60000);
    
    if (diffInMinutes < 60) {
      return `${diffInMinutes}m ago`;
    } else {
      const hours = Math.floor(diffInMinutes / 60);
      return `${hours}h ago`;
    }
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      {/* Top Navigation Bar */}
      <div className="sticky top-0 z-50 bg-gray-800/95 backdrop-blur border-b border-gray-700">
        <div className="flex items-center justify-between p-4">
          {/* Logo */}
          <div className="flex items-center space-x-2">
            <span className="text-2xl">🪸</span>
            <span className="text-lg font-bold text-cyan-400">Coral Crave</span>
          </div>

          {/* Search Bar */}
          <div className="flex-1 max-w-md mx-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={16} />
              <Input
                placeholder="Search Coral Crave"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 bg-gray-700 border-gray-600 text-white placeholder-gray-400"
              />
            </div>
          </div>

          {/* Right Icons */}
          <div className="flex items-center space-x-3">
            <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white">
              <Bell size={20} />
            </Button>
            <Button variant="ghost" size="sm" className="text-gray-400 hover:text-white">
              {user ? (
                <Avatar className="w-6 h-6">
                  <AvatarImage src={user.avatar} />
                  <AvatarFallback>{user.name[0]}</AvatarFallback>
                </Avatar>
              ) : (
                <User size={20} />
              )}
            </Button>
          </div>
        </div>
      </div>

      {/* Categories Carousel */}
      <div className="border-b border-gray-700 bg-gray-800">
        <div className="flex items-center space-x-4 p-4 overflow-x-auto scrollbar-hide">
          {categories.map((category) => (
            <Button
              key={category.id}
              variant={selectedCategory === category.id ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedCategory(category.id)}
              className={`flex items-center space-x-2 whitespace-nowrap ${
                selectedCategory === category.id
                  ? 'bg-cyan-500 text-white border-cyan-500'
                  : 'bg-transparent text-gray-300 border-gray-600 hover:bg-gray-700'
              }`}
            >
              <span>{category.emoji}</span>
              <span>{category.label}</span>
            </Button>
          ))}
        </div>
      </div>

      {/* Main Content */}
      <div className="p-4 space-y-6">
        {/* Featured Stream Banner */}
        {featuredStream && !loading && (
          <Card className="bg-gray-800 border-gray-700 overflow-hidden">
            <div className="relative">
              <img
                src={featuredStream.thumbnail}
                alt={featuredStream.title}
                className="w-full h-48 md:h-64 object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
              
              {/* Live Badge */}
              <Badge className="absolute top-4 left-4 bg-red-500 text-white animate-pulse">
                🔴 Live
              </Badge>

              {/* Viewer Count */}
              <div className="absolute top-4 right-4 bg-black/50 rounded-full px-3 py-1 flex items-center space-x-1">
                <Eye size={14} />
                <span className="text-sm">{formatViewerCount(featuredStream.viewerCount)}</span>
              </div>

              {/* Stream Info Overlay */}
              <div className="absolute bottom-0 left-0 right-0 p-4">
                {/* Seller Info */}
                <div className="flex items-center space-x-3 mb-3">
                  <Avatar className="w-10 h-10 border-2 border-white">
                    <AvatarImage src={featuredStream.seller.avatar} />
                    <AvatarFallback>{featuredStream.seller.name[0]}</AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="flex items-center space-x-2">
                      <span className="font-medium">{featuredStream.seller.name}</span>
                      {featuredStream.seller.verified && (
                        <Badge variant="secondary" className="text-xs bg-blue-500">
                          ✓
                        </Badge>
                      )}
                    </div>
                    <div className="text-sm text-gray-300">
                      ⭐ {featuredStream.seller.rating} • Started {getTimeAgo(featuredStream.startedAt)}
                    </div>
                  </div>
                </div>

                <h3 className="text-xl font-bold mb-2">{featuredStream.title}</h3>
                
                {/* Current Item Info */}
                {featuredStream.currentItem && (
                  <div className="bg-black/30 rounded-lg p-3 mb-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <p className="font-medium">{featuredStream.currentItem.title}</p>
                        <p className="text-cyan-400 font-bold">${featuredStream.currentItem.currentBid}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm text-gray-300">Ends in</p>
                        <p className="text-red-400 font-bold">{featuredStream.currentItem.timeLeft}</p>
                      </div>
                    </div>
                  </div>
                )}

                <Button 
                  onClick={() => handleJoinLive(featuredStream.id)}
                  className="w-full bg-cyan-500 hover:bg-cyan-600 text-white font-medium"
                >
                  <Play className="w-4 h-4 mr-2" />
                  Join Live
                </Button>
              </div>
            </div>
          </Card>
        )}

        {/* Live Stream Grid */}
        <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold">Live Now</h2>
            {refreshing && (
              <div className="flex items-center space-x-2 text-gray-400">
                <div className="w-4 h-4 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin" />
                <span className="text-sm">Updating...</span>
              </div>
            )}
          </div>

          {loading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {[...Array(6)].map((_, i) => (
                <Card key={i} className="bg-gray-800 border-gray-700">
                  <CardContent className="p-0">
                    <Skeleton className="w-full h-48 bg-gray-700" />
                    <div className="p-4 space-y-3">
                      <Skeleton className="h-4 bg-gray-700" />
                      <div className="flex items-center space-x-2">
                        <Skeleton className="w-8 h-8 rounded-full bg-gray-700" />
                        <Skeleton className="h-4 w-24 bg-gray-700" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {liveStreams.map((stream) => (
                <Card key={stream.id} className="bg-gray-800 border-gray-700 hover:border-gray-600 transition-colors cursor-pointer group">
                  <CardContent className="p-0">
                    <div className="relative">
                      <img
                        src={stream.thumbnail}
                        alt={stream.title}
                        className="w-full h-48 object-cover rounded-t-lg"
                      />
                      <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors rounded-t-lg" />
                      
                      {/* Live Badge */}
                      <Badge className="absolute top-2 left-2 bg-red-500 text-white animate-pulse">
                        🔴 Live
                      </Badge>

                      {/* Viewer Count */}
                      <div className="absolute top-2 right-2 bg-black/70 rounded-full px-2 py-1 flex items-center space-x-1">
                        <Eye size={12} />
                        <span className="text-xs">{formatViewerCount(stream.viewerCount)}</span>
                      </div>

                      {/* Play Button Overlay */}
                      <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                        <Button
                          size="sm"
                          className="bg-cyan-500 hover:bg-cyan-600 text-white"
                          onClick={() => handleJoinLive(stream.id)}
                        >
                          <Play className="w-4 h-4 mr-2" />
                          Join Live
                        </Button>
                      </div>
                    </div>

                    <div className="p-4">
                      {/* Seller Info */}
                      <div className="flex items-center space-x-2 mb-2">
                        <Avatar className="w-6 h-6">
                          <AvatarImage src={stream.seller.avatar} />
                          <AvatarFallback>{stream.seller.name[0]}</AvatarFallback>
                        </Avatar>
                        <span className="text-sm text-gray-300">{stream.seller.name}</span>
                        {stream.seller.verified && (
                          <Badge variant="secondary" className="text-xs bg-blue-500">
                            ✓
                          </Badge>
                        )}
                      </div>

                      {/* Stream Title */}
                      <h3 className="font-medium text-white mb-2 line-clamp-2">{stream.title}</h3>

                      {/* Current Item */}
                      {stream.currentItem && (
                        <div className="bg-gray-700 rounded-lg p-2 mb-3">
                          <div className="flex items-center justify-between text-sm">
                            <div>
                              <p className="text-gray-300 truncate">{stream.currentItem.title}</p>
                              <p className="text-green-400 font-medium">${stream.currentItem.currentBid}</p>
                            </div>
                            <div className="text-right">
                              <p className="text-red-400 font-medium">{stream.currentItem.timeLeft}</p>
                            </div>
                          </div>
                        </div>
                      )}

                      {/* Tags */}
                      <div className="flex flex-wrap gap-1 mb-3">
                        {stream.tags.slice(0, 3).map((tag) => (
                          <Badge key={tag} variant="outline" className="text-xs text-gray-400 border-gray-600">
                            #{tag}
                          </Badge>
                        ))}
                      </div>

                      {/* Join Button */}
                      <Button
                        onClick={() => handleJoinLive(stream.id)}
                        className="w-full bg-cyan-500 hover:bg-cyan-600 text-white"
                        size="sm"
                      >
                        Join Live
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}

          {/* Empty State */}
          {!loading && liveStreams.length === 0 && (
            <div className="text-center py-12">
              <div className="text-6xl mb-4">🌊</div>
              <h3 className="text-xl font-medium text-gray-300 mb-2">No Live Streams</h3>
              <p className="text-gray-500 mb-6">
                {searchQuery 
                  ? `No streams found for "${searchQuery}"`
                  : selectedCategory === 'all' 
                    ? 'Be the first to go live!' 
                    : `No ${selectedCategory} streams currently live`
                }
              </p>
              {!user && (
                <Button onClick={onAuthRequired} className="bg-cyan-500 hover:bg-cyan-600">
                  Sign In to Go Live
                </Button>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}