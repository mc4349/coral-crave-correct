import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { CheckCircle, XCircle, Loader, RefreshCw } from 'lucide-react';
import { projectId } from '../utils/supabase/info';
import { supabase } from '../utils/supabase/client';

interface User {
  id: string;
  email: string;
  name: string;
  avatar?: string;
}

interface ServerStatusCheckerProps {
  user: User | null;
}

export function ServerStatusChecker({ user }: ServerStatusCheckerProps) {
  const [healthStatus, setHealthStatus] = useState<'loading' | 'success' | 'error'>('loading');
  const [authStatus, setAuthStatus] = useState<'loading' | 'success' | 'error'>('loading');
  const [bidStatus, setBidStatus] = useState<'loading' | 'success' | 'error' | 'idle'>('idle');
  const [streamStatus, setStreamStatus] = useState<'loading' | 'success' | 'error' | 'idle'>('idle');
  const [lastCheck, setLastCheck] = useState<Date>(new Date());
  const [logs, setLogs] = useState<string[]>([]);

  const addLog = (message: string) => {
    const timestamp = new Date().toLocaleTimeString();
    setLogs(prev => [`[${timestamp}] ${message}`, ...prev.slice(0, 4)]);
  };

  const checkHealth = async () => {
    setHealthStatus('loading');
    try {
      addLog('🔍 Checking server health...');
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-9f7745d8/health`);
      
      console.log('📊 Health check response:', { status: response.status, statusText: response.statusText });
      
      if (!response.ok) {
        const errorText = await response.text();
        console.error('❌ Health check HTTP error:', response.status, errorText);
        throw new Error(`Health check failed: ${response.status} - ${errorText}`);
      }
      
      const result = await response.json();
      console.log('✅ Health check result:', result);
      addLog(`✅ Server health: ${result.status} (${result.server})`);
      setHealthStatus('success');
    } catch (error) {
      console.error('💥 Health check error:', error);
      addLog(`❌ Health check failed: ${error.message}`);
      setHealthStatus('error');
    }
  };

  const checkAuth = async () => {
    setAuthStatus('loading');
    try {
      addLog('🔑 Checking authentication...');
      const { data: { session } } = await supabase.auth.getSession();
      
      if (session?.access_token) {
        addLog(`✅ Auth token available for user: ${session.user.email}`);
        setAuthStatus('success');
      } else {
        addLog('❌ No auth token available');
        setAuthStatus('error');
      }
    } catch (error) {
      addLog(`❌ Auth check failed: ${error.message}`);
      setAuthStatus('error');
    }
  };

  const testBidding = async () => {
    if (!user) {
      addLog('❌ Cannot test bidding: no user');
      return;
    }

    setBidStatus('loading');
    try {
      addLog('🔨 Testing bidding endpoint...');
      const { data: { session } } = await supabase.auth.getSession();
      
      if (!session?.access_token) {
        throw new Error('No auth token');
      }

      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-9f7745d8/bid/place`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${session.access_token}`
        },
        body: JSON.stringify({
          itemId: 'test_item_diagnostic',
          amount: 100,
          streamId: 'test_stream_diagnostic'
        })
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`${response.status}: ${errorText}`);
      }

      const result = await response.json();
      addLog(`✅ Bidding test successful: ${result.message}`);
      setBidStatus('success');
    } catch (error) {
      addLog(`❌ Bidding test failed: ${error.message}`);
      setBidStatus('error');
    }
  };

  const testStreaming = async () => {
    if (!user) {
      addLog('❌ Cannot test streaming: no user');
      return;
    }

    setStreamStatus('loading');
    try {
      addLog('📹 Testing streaming endpoint...');
      const { data: { session } } = await supabase.auth.getSession();
      
      if (!session?.access_token) {
        throw new Error('No auth token');
      }

      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-9f7745d8/streams/start`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${session.access_token}`
        },
        body: JSON.stringify({
          title: 'Diagnostic Test Stream',
          description: 'Testing stream creation',
          category: 'Test'
        })
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`${response.status}: ${errorText}`);
      }

      const result = await response.json();
      addLog(`✅ Streaming test successful: ${result.channelName}`);
      setStreamStatus('success');
    } catch (error) {
      addLog(`❌ Streaming test failed: ${error.message}`);
      setStreamStatus('error');
    }
  };

  const runAllTests = async () => {
    setLastCheck(new Date());
    await checkHealth();
    await checkAuth();
    if (user) {
      await testBidding();
      await testStreaming();
    }
  };

  useEffect(() => {
    // Only run tests once when component mounts or when user changes significantly
    // Add debouncing to prevent constant requests
    const timeoutId = setTimeout(() => {
      runAllTests();
    }, 1000); // Wait 1 second before running tests

    return () => clearTimeout(timeoutId);
  }, [user?.id]); // Only trigger when user ID changes, not on every user object change

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'loading':
        return <Loader className="animate-spin" size={16} />;
      case 'success':
        return <CheckCircle className="text-green-400" size={16} />;
      case 'error':
        return <XCircle className="text-red-400" size={16} />;
      default:
        return <div className="w-4 h-4 bg-gray-600 rounded-full" />;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'success':
        return <Badge className="bg-green-500/20 text-green-400 border-green-400">Online</Badge>;
      case 'error':
        return <Badge className="bg-red-500/20 text-red-400 border-red-400">Error</Badge>;
      case 'loading':
        return <Badge className="bg-yellow-500/20 text-yellow-400 border-yellow-400">Testing...</Badge>;
      default:
        return <Badge className="bg-gray-500/20 text-gray-400 border-gray-400">Not Tested</Badge>;
    }
  };

  return (
    <Card className="bg-gray-800 border-gray-700">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center space-x-2">
            <span>🔧 Server Diagnostics</span>
          </CardTitle>
          <Button 
            onClick={runAllTests}
            size="sm"
            variant="outline"
            className="border-gray-600 text-gray-300 hover:bg-gray-700"
          >
            <RefreshCw size={14} className="mr-2" />
            Refresh
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Server Status */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="flex items-center justify-between p-3 bg-gray-700/50 rounded-lg">
            <div className="flex items-center space-x-2">
              {getStatusIcon(healthStatus)}
              <span className="text-sm">Server Health</span>
            </div>
            {getStatusBadge(healthStatus)}
          </div>

          <div className="flex items-center justify-between p-3 bg-gray-700/50 rounded-lg">
            <div className="flex items-center space-x-2">
              {getStatusIcon(authStatus)}
              <span className="text-sm">Authentication</span>
            </div>
            {getStatusBadge(authStatus)}
          </div>

          <div className="flex items-center justify-between p-3 bg-gray-700/50 rounded-lg">
            <div className="flex items-center space-x-2">
              {getStatusIcon(bidStatus)}
              <span className="text-sm">Bidding API</span>
            </div>
            {getStatusBadge(bidStatus)}
          </div>

          <div className="flex items-center justify-between p-3 bg-gray-700/50 rounded-lg">
            <div className="flex items-center space-x-2">
              {getStatusIcon(streamStatus)}
              <span className="text-sm">Streaming API</span>
            </div>
            {getStatusBadge(streamStatus)}
          </div>
        </div>

        {/* Test Actions */}
        {user && (
          <div className="flex space-x-2">
            <Button onClick={testBidding} size="sm" disabled={bidStatus === 'loading'}>
              Test Bidding
            </Button>
            <Button onClick={testStreaming} size="sm" disabled={streamStatus === 'loading'}>
              Test Streaming
            </Button>
          </div>
        )}

        {!user && (
          <div className="text-center p-3 bg-yellow-500/20 border border-yellow-500/30 rounded-lg">
            <p className="text-yellow-300 text-sm">
              Sign in to test bidding and streaming endpoints
            </p>
          </div>
        )}

        {/* Logs */}
        <div className="space-y-2">
          <h4 className="text-sm font-medium text-gray-300">Recent Tests</h4>
          <div className="bg-gray-900/50 rounded-lg p-3 text-xs text-gray-400 max-h-32 overflow-y-auto">
            {logs.length === 0 ? (
              <p>No tests run yet...</p>
            ) : (
              logs.map((log, index) => (
                <div key={index} className="font-mono">{log}</div>
              ))
            )}
          </div>
        </div>

        {/* Info */}
        <div className="text-xs text-gray-500">
          <p>Last check: {lastCheck.toLocaleTimeString()}</p>
          <p>Project ID: {projectId}</p>
          <p>User: {user ? user.email : 'Not signed in'}</p>
        </div>
      </CardContent>
    </Card>
  );
}