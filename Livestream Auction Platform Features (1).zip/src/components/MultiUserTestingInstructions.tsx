import React, { useState } from 'react';
import { X, Copy, CheckCircle, Users, Settings, CreditCard } from 'lucide-react';

interface MultiUserTestingInstructionsProps {
  onClose: () => void;
  onCreateBuyerAccount: () => void;
}

export function MultiUserTestingInstructions({ onClose, onCreateBuyerAccount }: MultiUserTestingInstructionsProps) {
  const [copied, setCopied] = useState(false);
  
  const currentUrl = window.location.href;
  const buyerUrl = `${window.location.origin}?testMode=buyer`;

  const copyUrl = async () => {
    try {
      await navigator.clipboard.writeText(buyerUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (error) {
      console.error('Failed to copy URL:', error);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/75 flex items-center justify-center z-50">
      <div className="bg-gray-800 rounded-xl max-w-4xl mx-4 max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-700">
          <div className="flex items-center gap-3">
            <Users className="text-cyan-400" size={24} />
            <h2 className="text-xl font-bold text-white">Multi-User Testing Guide</h2>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-white"
          >
            <X size={24} />
          </button>
        </div>

        <div className="p-6 space-y-6">
          {/* Quick Test Option */}
          <div className="bg-blue-500/10 border border-blue-500/30 rounded-lg p-4">
            <h3 className="text-lg font-bold text-blue-400 mb-3">🚀 Quick Test (Recommended)</h3>
            <p className="text-gray-300 mb-4">
              Test the complete seller → buyer → payment flow in the same browser using different accounts:
            </p>
            <div className="space-y-2">
              <button
                onClick={onCreateBuyerAccount}
                className="w-full bg-blue-500 hover:bg-blue-600 text-white px-4 py-3 rounded-lg transition-colors flex items-center justify-center gap-2"
              >
                <Settings size={18} />
                Create Buyer Test Account & Instructions
              </button>
              <p className="text-xs text-gray-400 text-center">
                This will set up a buyer account and show step-by-step testing instructions
              </p>
            </div>
          </div>

          {/* Manual Multi-Tab Testing */}
          <div className="bg-gray-700/50 rounded-lg p-4">
            <h3 className="text-lg font-bold text-white mb-4">🔄 Manual Multi-Tab Testing</h3>
            
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <div className="bg-cyan-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold">1</div>
                <div>
                  <h4 className="text-cyan-400 font-medium">Set Up Seller (Current Tab)</h4>
                  <p className="text-gray-300 text-sm">
                    Stay signed in as <code className="bg-gray-600 px-1 rounded">demo@coralcrave.com</code> (seller account)
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="bg-cyan-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold">2</div>
                <div>
                  <h4 className="text-cyan-400 font-medium">Open New Tab for Buyer</h4>
                  <div className="flex items-center gap-2 mt-2">
                    <input
                      type="text"
                      value={buyerUrl}
                      readOnly
                      className="flex-1 bg-gray-700 text-gray-300 px-3 py-2 rounded border border-gray-600 text-sm"
                    />
                    <button
                      onClick={copyUrl}
                      className="bg-gray-600 hover:bg-gray-500 text-white px-3 py-2 rounded transition-colors flex items-center gap-1"
                    >
                      {copied ? <CheckCircle size={16} /> : <Copy size={16} />}
                      {copied ? 'Copied!' : 'Copy'}
                    </button>
                  </div>
                  <p className="text-gray-400 text-xs mt-1">
                    This will open buyer mode - sign in as a different user
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="bg-cyan-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold">3</div>
                <div>
                  <h4 className="text-cyan-400 font-medium">Start Seller Flow</h4>
                  <ul className="text-gray-300 text-sm mt-1 space-y-1">
                    <li>• Go to "Go Live" tab</li>
                    <li>• Click "🔴 Start Live Stream"</li>
                    <li>• Fill in stream details and start</li>
                    <li>• Use auction controls to manage items</li>
                  </ul>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="bg-cyan-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold">4</div>
                <div>
                  <h4 className="text-cyan-400 font-medium">Join as Buyer (New Tab)</h4>
                  <ul className="text-gray-300 text-sm mt-1 space-y-1">
                    <li>• Sign in with different email (or create new account)</li>
                    <li>• Go to "Explore" tab</li>
                    <li>• Click "Join Live" on the seller's stream</li>
                    <li>• Place bids on auction items</li>
                  </ul>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="bg-green-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold">5</div>
                <div>
                  <h4 className="text-green-400 font-medium">Test Payment Flow</h4>
                  <ul className="text-gray-300 text-sm mt-1 space-y-1">
                    <li>• Win an auction by having the highest bid when timer expires</li>
                    <li>• Payment modal should appear automatically</li>
                    <li>• Complete PayPal payment flow</li>
                    <li>• Verify payment success in console</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>

          {/* Testing Accounts */}
          <div className="bg-gray-700/50 rounded-lg p-4">
            <h3 className="text-lg font-bold text-white mb-3">👥 Pre-configured Test Accounts</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-cyan-500/10 border border-cyan-500/30 rounded-lg p-3">
                <h4 className="text-cyan-400 font-medium mb-2">🐠 Seller Account</h4>
                <p className="text-sm text-gray-300 mb-2">Email: <code className="bg-gray-600 px-1 rounded">demo@coralcrave.com</code></p>
                <p className="text-sm text-gray-300">Password: <code className="bg-gray-600 px-1 rounded">demo123</code></p>
                <p className="text-xs text-gray-400 mt-1">Can create streams and host auctions</p>
              </div>
              
              <div className="bg-green-500/10 border border-green-500/30 rounded-lg p-3">
                <h4 className="text-green-400 font-medium mb-2">🛒 Buyer Account</h4>
                <p className="text-sm text-gray-300 mb-2">Email: <code className="bg-gray-600 px-1 rounded">buyer@coralcrave.com</code></p>
                <p className="text-sm text-gray-300">Password: <code className="bg-gray-600 px-1 rounded">demo123</code></p>
                <p className="text-xs text-gray-400 mt-1">Can bid on auctions and make payments</p>
              </div>
            </div>
          </div>

          {/* Payment Testing */}
          <div className="bg-yellow-500/10 border border-yellow-500/30 rounded-lg p-4">
            <h3 className="text-lg font-bold text-yellow-400 mb-3 flex items-center gap-2">
              <CreditCard size={20} />
              PayPal Payment Testing
            </h3>
            <div className="text-sm text-gray-300 space-y-2">
              <p>✅ <strong>Real PayPal Integration:</strong> Your app now uses the live PayPal API</p>
              <p>🔒 <strong>Sandbox Mode:</strong> All payments are in sandbox/test mode - no real money</p>
              <p>💳 <strong>Test Payment:</strong> Use the PayPal sandbox account or create a test account</p>
              <div className="bg-gray-700 rounded p-2 mt-2">
                <p className="text-xs text-gray-400">
                  <strong>Note:</strong> PayPal payments are processed through the sandbox environment. 
                  All transactions are simulated and no real money is charged.
                </p>
              </div>
            </div>
          </div>

          {/* Close Button */}
          <div className="flex justify-end pt-4 border-t border-gray-700">
            <button
              onClick={onClose}
              className="bg-gray-600 hover:bg-gray-500 text-white px-6 py-2 rounded-lg transition-colors"
            >
              Got it, let's test!
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}