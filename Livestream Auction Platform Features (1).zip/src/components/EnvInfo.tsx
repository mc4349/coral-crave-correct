import React from 'react';
import { Info, Database, Video, CreditCard, Globe } from 'lucide-react';

export function EnvInfo() {
  const getEnvStatus = (envVar: string) => {
    // Check if environment variable exists (this would be replaced with actual env checks in production)
    const hasVar = typeof window !== 'undefined' && window.location.hostname !== 'localhost';
    return hasVar ? '✓ Connected' : '⚠ Not configured';
  };

  const envVars = [
    {
      name: 'Supabase',
      icon: <Database size={16} />,
      status: getEnvStatus('SUPABASE_URL'),
      description: 'Database & Authentication'
    },
    {
      name: 'Agora',
      icon: <Video size={16} />,
      status: getEnvStatus('AGORA_APP_ID'),
      description: 'Live Streaming'
    },
    {
      name: 'PayPal',
      icon: <CreditCard size={16} />,
      status: getEnvStatus('PAYPAL_CLIENT_ID'),
      description: 'Payment Processing'
    },
    {
      name: 'Production',
      icon: <Globe size={16} />,
      status: process.env.NODE_ENV === 'production' ? '✓ Production' : '⚠ Development',
      description: 'Environment Mode'
    }
  ];

  return (
    <div className="bg-gray-800 rounded-lg border border-gray-700 p-4">
      <div className="flex items-center gap-2 mb-4">
        <Info className="text-cyan-400" size={20} />
        <h3 className="font-medium text-white">Environment Status</h3>
      </div>

      <div className="space-y-3">
        {envVars.map((env) => (
          <div key={env.name} className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="text-gray-400">{env.icon}</div>
              <div>
                <div className="text-sm font-medium text-white">{env.name}</div>
                <div className="text-xs text-gray-400">{env.description}</div>
              </div>
            </div>
            <div className={`text-xs px-2 py-1 rounded ${
              env.status.includes('✓') 
                ? 'bg-green-600/20 text-green-400' 
                : 'bg-yellow-600/20 text-yellow-400'
            }`}>
              {env.status}
            </div>
          </div>
        ))}
      </div>

      {/* Additional Info */}
      <div className="mt-4 pt-3 border-t border-gray-700">
        <div className="text-xs text-gray-500">
          <div className="flex justify-between mb-1">
            <span>Build Version:</span>
            <span>1.0.0</span>
          </div>
          <div className="flex justify-between">
            <span>Last Updated:</span>
            <span>{new Date().toLocaleDateString()}</span>
          </div>
        </div>
      </div>
    </div>
  );
}