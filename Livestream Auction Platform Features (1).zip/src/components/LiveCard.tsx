import React from 'react';
import { Eye, User } from 'lucide-react';
import { RealtimeBadge } from './RealtimeBadge';

interface LiveCardProps {
  streamId: string;
  thumbnail: string;
  title: string;
  sellerName: string;
  sellerAvatar?: string;
  viewerCount: number;
  currentBid: number;
  isLive: boolean;
  onJoin: (streamId: string) => void;
}

export function LiveCard({ 
  streamId, 
  thumbnail, 
  title, 
  sellerName, 
  sellerAvatar, 
  viewerCount, 
  currentBid, 
  isLive, 
  onJoin 
}: LiveCardProps) {
  return (
    <div className="bg-gray-800 rounded-lg overflow-hidden hover:bg-gray-750 transition-colors cursor-pointer">
      {/* Thumbnail */}
      <div className="relative aspect-video">
        <img 
          src={thumbnail} 
          alt={title}
          className="w-full h-full object-cover"
        />
        
        {/* Live Badge */}
        {isLive && (
          <div className="absolute top-2 left-2">
            <RealtimeBadge />
          </div>
        )}
        
        {/* Viewer Count */}
        <div className="absolute top-2 right-2 bg-black bg-opacity-60 text-white px-2 py-1 rounded text-xs flex items-center gap-1">
          <Eye size={12} />
          {viewerCount}
        </div>
      </div>
      
      {/* Content */}
      <div className="p-4">
        {/* Seller Info */}
        <div className="flex items-center gap-2 mb-2">
          <div className="w-6 h-6 rounded-full bg-gradient-to-r from-cyan-400 to-teal-500 flex items-center justify-center">
            {sellerAvatar ? (
              <img src={sellerAvatar} alt={sellerName} className="w-full h-full rounded-full object-cover" />
            ) : (
              <User size={12} className="text-white" />
            )}
          </div>
          <span className="text-sm text-gray-400">{sellerName}</span>
        </div>
        
        {/* Title */}
        <h3 className="text-white font-medium mb-2 line-clamp-2">{title}</h3>
        
        {/* Current Bid */}
        <div className="flex items-center justify-between">
          <div className="text-green-400 font-bold">
            ${currentBid}
          </div>
          
          {/* Join Button */}
          <button
            onClick={() => onJoin(streamId)}
            className="bg-cyan-500 text-white px-4 py-1 rounded text-sm hover:bg-cyan-600 transition-colors"
          >
            Join
          </button>
        </div>
      </div>
    </div>
  );
}