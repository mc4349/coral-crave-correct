import React from 'react';
import { Play, Eye, Users, Heart } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface LiveStream {
  id: string;
  title: string;
  seller: {
    name: string;
    avatar: string;
    verified: boolean;
  };
  thumbnail: string;
  viewerCount: number;
  category: string;
  isLive: boolean;
  currentItem?: {
    title: string;
    currentBid: number;
    timeLeft: number;
  };
}

interface LiveStreamCardProps {
  stream: LiveStream;
  onJoinLive: (streamId: string) => void;
}

export function LiveStreamCard({ stream, onJoinLive }: LiveStreamCardProps) {
  return (
    <div className="bg-gray-800 rounded-xl overflow-hidden shadow-lg hover:shadow-xl transition-all hover:scale-105 group cursor-pointer">
      <div className="relative">
        <ImageWithFallback 
          src={stream.thumbnail}
          alt={stream.title}
          className="w-full h-48 object-cover"
        />
        
        {/* Live indicator */}
        <div className="absolute top-3 left-3 bg-red-500 text-white px-2 py-1 rounded-full text-xs flex items-center gap-1">
          <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
          LIVE
        </div>

        {/* Viewer count */}
        <div className="absolute top-3 right-3 bg-black bg-opacity-60 text-white px-2 py-1 rounded-full text-xs flex items-center gap-1">
          <Eye size={12} />
          {stream.viewerCount}
        </div>

        {/* Play overlay */}
        <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-30 transition-all flex items-center justify-center">
          <div className="transform scale-0 group-hover:scale-100 transition-transform">
            <div className="bg-cyan-400 text-white p-3 rounded-full">
              <Play size={24} fill="currentColor" />
            </div>
          </div>
        </div>
      </div>

      <div className="p-4">
        <div className="flex items-start justify-between mb-2">
          <h3 className="font-medium text-white line-clamp-2 flex-1">{stream.title}</h3>
          <span className="bg-gray-700 text-gray-300 px-2 py-1 rounded text-xs ml-2 shrink-0">
            {stream.category}
          </span>
        </div>

        <div className="flex items-center gap-2 mb-3">
          <div className="w-6 h-6 bg-gray-600 rounded-full"></div>
          <span className="text-gray-400 text-sm">{stream.seller.name}</span>
          {stream.seller.verified && (
            <div className="w-3 h-3 bg-blue-500 rounded-full flex items-center justify-center">
              <span className="text-white text-xs">✓</span>
            </div>
          )}
        </div>

        {stream.currentItem && (
          <div className="bg-gray-700 rounded-lg p-3 mb-3">
            <p className="text-sm text-gray-300 mb-1">{stream.currentItem.title}</p>
            <div className="flex items-center justify-between">
              <span className="text-teal-400 font-medium text-sm">
                ${stream.currentItem.currentBid}
              </span>
              <span className="text-orange-400 text-xs">
                {stream.currentItem.timeLeft}s
              </span>
            </div>
          </div>
        )}

        <button
          onClick={() => onJoinLive(stream.id)}
          className="w-full bg-cyan-500 text-white py-2 rounded-lg hover:bg-cyan-400 transition-colors flex items-center justify-center gap-2 text-sm"
        >
          <Play size={16} fill="currentColor" />
          Join Live
        </button>
      </div>
    </div>
  );
}