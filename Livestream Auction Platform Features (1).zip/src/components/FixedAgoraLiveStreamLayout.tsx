import React, { useEffect, useRef, useState } from 'react';
import { Mic, MicOff, Video, VideoOff, Users, MessageCircle, X, Settings, Gavel, Clock, DollarSign, ChevronRight, Grid } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent } from './ui/card';
import { Badge } from './ui/badge';
import { AuctionQueue } from './AuctionQueue';
import { DemoBiddingPanel } from './DemoBiddingPanel';
import { PinnedLotCard } from './PinnedLotCard';
import { StreamRoleManager } from './StreamRoleManager';

interface FixedAgoraLiveStreamLayoutProps {
  channelName: string;
  isHost: boolean;
  onLeave: () => void;
  userToken?: string;
  forceRealCamera?: boolean;
}

export function FixedAgoraLiveStreamLayout({ 
  channelName, 
  isHost, 
  onLeave, 
  userToken, 
  forceRealCamera = true 
}: FixedAgoraLiveStreamLayoutProps) {
  const [micEnabled, setMicEnabled] = useState(true);
  const [cameraEnabled, setCameraEnabled] = useState(true);
  const [viewerCount, setViewerCount] = useState(0);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  // Chat state
  const [chatMessages, setChatMessages] = useState<any[]>([]);
  const [currentMessage, setCurrentMessage] = useState('');
  
  // Auction state
  const [currentAuctionItem, setCurrentAuctionItem] = useState<any>(null);
  const [upcomingItems, setUpcomingItems] = useState<any[]>([]);
  const [showAuctionQueue, setShowAuctionQueue] = useState(false);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [winningItem, setWinningItem] = useState<any>(null);

  const localVideoRef = useRef<HTMLDivElement>(null);
  const chatContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Initialize demo data
    initializeDemoData();
    setViewerCount(Math.floor(Math.random() * 100) + 10);
  }, []);

  const initializeDemoData = () => {
    // Initialize chat messages
    setChatMessages([
      {
        id: '1',
        user: { name: 'ReefExplorer', color: '#10B981' },
        message: 'Amazing coral collection!',
        timestamp: new Date().toISOString(),
        type: 'message'
      },
      {
        id: '2',
        user: { name: 'CoralFan123', color: '#3B82F6' },
        message: 'Beautiful colors on that one!',
        timestamp: new Date().toISOString(),
        type: 'message'
      }
    ]);

    // Initialize auction items
    setCurrentAuctionItem({
      id: 'auction_1',
      title: 'Premium Rainbow Acropora Colony',
      description: 'Beautiful rainbow acropora with amazing colors. Fully established and healthy.',
      startingBid: 25,
      currentBid: 45,
      bidCount: 8,
      timeLeft: 180, // 3 minutes
      endTime: new Date(Date.now() + 180000).toISOString(),
      image: 'https://images.unsplash.com/photo-1522802451138-8afd417be4bf?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb2xvcmZ1bCUyMGNvcmFsJTIwcmVlZiUyMGFxdWFyaXVtfGVufDF8fHx8MTc1ODA0ODMwNHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
      isActive: true,
      reservePrice: 40,
      buyItNowPrice: 85,
      autoExtend: true,
      incrementType: 'fixed',
      minimumIncrement: 5,
      highestBidder: 'CoralFan123',
      sellerId: userToken || 'demo-seller',
      sellerName: 'Demo Seller'
    });

    setUpcomingItems([
      {
        id: 'upcoming_1',
        title: 'Orange Torch Coral',
        description: 'Vibrant orange torch coral',
        startingBid: 30,
        currentBid: 30,
        bidCount: 0,
        image: 'https://images.unsplash.com/photo-1638286269600-8f6f5d44cd84?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxvcmFuZ2UlMjB0b3JjaCUyMGNvcmFsfGVufDF8fHx8MTc1ODA0ODMwOHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
      },
      {
        id: 'upcoming_2',
        title: 'Blue Chalice Coral',
        description: 'Stunning blue chalice coral',
        startingBid: 20,
        currentBid: 20,
        bidCount: 0,
        image: 'https://images.unsplash.com/photo-1674801664581-b431ab58fe83?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxibHVlJTIwY2hhbGljZSUyMGNvcmFsfGVufDF8fHx8MTc1ODA0ODMxM3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral'
      }
    ]);
  };

  const handleSendMessage = () => {
    if (!currentMessage.trim()) return;

    const newMessage = {
      id: Date.now().toString(),
      user: { name: 'You', color: '#FBBF24' },
      message: currentMessage,
      timestamp: new Date().toISOString(),
      type: 'message'
    };

    setChatMessages(prev => [...prev, newMessage]);
    setCurrentMessage('');

    // Scroll to bottom
    if (chatContainerRef.current) {
      setTimeout(() => {
        chatContainerRef.current?.scrollTo({ top: chatContainerRef.current.scrollHeight, behavior: 'smooth' });
      }, 100);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleBid = (amount: number) => {
    console.log('🎯 Bid placed:', amount);
    if (currentAuctionItem) {
      setCurrentAuctionItem(prev => ({
        ...prev,
        currentBid: amount,
        bidCount: prev.bidCount + 1,
        highestBidder: 'You'
      }));
      
      // Add a chat message about the bid
      const bidMessage = {
        id: Date.now().toString(),
        user: { name: 'System', color: '#10B981' },
        message: `💰 New bid placed: $${amount} by You`,
        timestamp: new Date().toISOString(),
        type: 'bid'
      };
      setChatMessages(prev => [...prev, bidMessage]);
      
      // Auto-scroll chat to show the new bid
      if (chatContainerRef.current) {
        setTimeout(() => {
          chatContainerRef.current?.scrollTo({ top: chatContainerRef.current.scrollHeight, behavior: 'smooth' });
        }, 100);
      }
    }
  };

  const handleAuthRequired = () => {
    console.log('🔐 Authentication required for bidding');
  };

  const handleStartAuction = (item: any) => {
    console.log('🎯 Starting auction for:', item);
    setCurrentAuctionItem(item);
    setShowAuctionQueue(false);
  };

  const queueNextItem = () => {
    if (upcomingItems.length > 0) {
      const nextItem = upcomingItems[0];
      setCurrentAuctionItem(nextItem);
      setUpcomingItems(prev => prev.slice(1));
      console.log('📋 Queued next item:', nextItem.title);
    } else {
      console.log('📋 No more items in queue');
    }
  };

  const getDummyUser = () => ({
    id: userToken || 'demo-user',
    email: 'demo@coralcrave.com',
    name: 'Demo User'
  });

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full bg-gray-900">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-cyan-400 mx-auto mb-4"></div>
          <p className="text-white">Initializing livestream...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center h-full bg-gray-900">
        <div className="text-center max-w-md mx-auto p-6">
          <div className="bg-red-500/10 border border-red-500 rounded-lg p-4 mb-4">
            <h3 className="text-red-400 font-medium mb-2">Livestream Error</h3>
            <p className="text-red-300 text-sm">{error}</p>
          </div>
          <Button onClick={onLeave} className="bg-gray-600 hover:bg-gray-700">
            Return to Dashboard
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col bg-gray-900">
      {/* Top Bar */}
      <div className="flex items-center justify-between p-4 bg-gray-800 border-b border-gray-700">
        <div className="flex items-center space-x-4">
          <Badge className="bg-red-500 text-white">
            {isHost ? 'HOSTING' : 'LIVE'}
          </Badge>
          <div className="flex items-center space-x-2 text-gray-300">
            <Users className="h-4 w-4" />
            <span>{viewerCount} viewers</span>
          </div>
          <div className="text-gray-300 text-sm">
            Channel: {channelName}
          </div>
        </div>
        
        <div className="flex items-center space-x-2">
          <Button
            onClick={() => setShowAuctionQueue(!showAuctionQueue)}
            variant="outline"
            size="sm"
          >
            <Grid className="h-4 w-4 mr-2" />
            Queue
          </Button>
          <Button onClick={onLeave} variant="outline" size="sm">
            <X className="h-4 w-4 mr-2" />
            Leave
          </Button>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 flex">
        {/* Video Area */}
        <div className="flex-1 flex flex-col">
          {/* Video Player */}
          <div className="flex-1 relative bg-black">
            <div 
              ref={localVideoRef}
              className="w-full h-full flex items-center justify-center bg-gradient-to-br from-gray-800 to-gray-900"
            >
              <div className="text-center">
                <div className="w-24 h-24 bg-cyan-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Video className="h-12 w-12 text-white" />
                </div>
                <h3 className="text-xl font-bold text-white mb-2">Live Stream Active</h3>
                <p className="text-gray-400">
                  {isHost ? 'You are broadcasting live' : 'Watching live stream'}
                </p>
              </div>
            </div>

            {/* Stream Info Overlay */}
            <div className="absolute top-4 left-4 right-4 flex justify-between items-start pointer-events-none">
              <Card className="bg-black/50 border-gray-600 backdrop-blur-sm pointer-events-auto">
                <CardContent className="p-3">
                  <div className="flex items-center space-x-2 text-white">
                    <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
                    <span className="text-sm font-medium">LIVE</span>
                    <span className="text-sm text-gray-300">• {viewerCount} watching</span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>

          {/* Fixed Bottom Controls - This is the main fix! */}
          <div className="bg-gray-800 border-t border-gray-700">
            {/* Host Controls Row */}
            {isHost && (
              <div className="flex items-center justify-between p-4 border-b border-gray-700">
                {/* Stream Controls */}
                <div className="flex items-center space-x-3">
                  <Button
                    onClick={() => setMicEnabled(!micEnabled)}
                    variant={micEnabled ? "default" : "destructive"}
                    size="sm"
                    className="flex items-center space-x-2"
                  >
                    {micEnabled ? <Mic className="h-4 w-4" /> : <MicOff className="h-4 w-4" />}
                    <span className="hidden sm:inline">
                      {micEnabled ? 'Mute' : 'Unmute'}
                    </span>
                  </Button>
                  
                  <Button
                    onClick={() => setCameraEnabled(!cameraEnabled)}
                    variant={cameraEnabled ? "default" : "destructive"}
                    size="sm"
                    className="flex items-center space-x-2"
                  >
                    {cameraEnabled ? <Video className="h-4 w-4" /> : <VideoOff className="h-4 w-4" />}
                    <span className="hidden sm:inline">
                      {cameraEnabled ? 'Stop Video' : 'Start Video'}
                    </span>
                  </Button>

                  <Button
                    variant="outline"
                    size="sm"
                    className="flex items-center space-x-2"
                  >
                    <Settings className="h-4 w-4" />
                    <span className="hidden sm:inline">Settings</span>
                  </Button>
                </div>

                {/* Auction Controls */}
                <div className="flex items-center space-x-3">
                  <Button
                    onClick={queueNextItem}
                    disabled={upcomingItems.length === 0}
                    className="bg-green-600 hover:bg-green-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center space-x-2"
                    size="sm"
                  >
                    <ChevronRight className="h-4 w-4" />
                    <span>Queue Next Item</span>
                    {upcomingItems.length > 0 && (
                      <Badge className="bg-green-500 text-white ml-2">
                        {upcomingItems.length}
                      </Badge>
                    )}
                  </Button>
                  
                  <Button
                    onClick={() => setShowAuctionQueue(!showAuctionQueue)}
                    variant="outline"
                    size="sm"
                    className="flex items-center space-x-2"
                  >
                    <Grid className="h-4 w-4" />
                    <span>Manage Queue</span>
                  </Button>
                </div>
              </div>
            )}

            {/* Stream Role Manager */}
            {isHost && (
              <div className="px-4 pb-2">
                <StreamRoleManager
                  streamId={channelName}
                  currentUser={getDummyUser()}
                  onRoleChange={(userId, role) => {
                    console.log('Role changed:', userId, role);
                  }}
                />
              </div>
            )}
          </div>
        </div>

        {/* Chat Panel */}
        <div className="w-80 bg-gray-800 border-l border-gray-700 flex flex-col">
          <div className="p-4 border-b border-gray-700">
            <div className="flex items-center space-x-2">
              <MessageCircle className="h-5 w-5 text-cyan-400" />
              <h3 className="font-medium text-white">Live Chat</h3>
            </div>
          </div>
          
          <div 
            ref={chatContainerRef}
            className="flex-1 overflow-y-auto p-4 space-y-3"
          >
            {chatMessages.map((message) => (
              <div key={message.id} className="flex flex-col space-y-1">
                <div className="flex items-center space-x-2">
                  <span 
                    className="font-medium text-sm"
                    style={{ color: message.user.color }}
                  >
                    {message.user.name}
                  </span>
                  {message.type === 'bid' && (
                    <Badge className="bg-green-500 text-white text-xs">
                      BID
                    </Badge>
                  )}
                </div>
                <p className="text-gray-300 text-sm">{message.message}</p>
              </div>
            ))}
          </div>
          
          <div className="p-4 border-t border-gray-700">
            <div className="flex space-x-2">
              <input
                type="text"
                value={currentMessage}
                onChange={(e) => setCurrentMessage(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Type a message..."
                className="flex-1 bg-gray-700 text-white px-3 py-2 rounded-lg border border-gray-600 focus:border-cyan-400 focus:outline-none text-sm"
              />
              <Button 
                onClick={handleSendMessage}
                size="sm"
                className="bg-cyan-500 hover:bg-cyan-600"
              >
                Send
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Pinned Lot Card - Always at bottom */}
      {currentAuctionItem && (
        <div className="p-4 bg-gray-900 border-t border-gray-700">
          <PinnedLotCard
            item={currentAuctionItem}
            onBid={handleBid}
            onAuthRequired={handleAuthRequired}
            user={getDummyUser()}
          />
        </div>
      )}

      {/* Auction Queue Modal */}
      {showAuctionQueue && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-gray-800 rounded-lg max-w-4xl w-full mx-4 max-h-[80vh] overflow-hidden">
            <div className="flex items-center justify-between p-6 border-b border-gray-700">
              <h2 className="text-xl font-bold text-white">Auction Queue</h2>
              <Button
                onClick={() => setShowAuctionQueue(false)}
                variant="ghost"
                size="sm"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
            <div className="p-6 overflow-y-auto">
              <AuctionQueue
                items={upcomingItems}
                onStartAuction={handleStartAuction}
                onReorderItems={(reorderedItems) => setUpcomingItems(reorderedItems)}
                currentItem={currentAuctionItem}
                isHost={isHost}
              />
            </div>
          </div>
        </div>
      )}

      {/* Bidding Panel (if not host) */}
      {!isHost && currentAuctionItem && (
        <div className="fixed bottom-24 right-4 w-80 z-40">
          <DemoBiddingPanel
            item={currentAuctionItem}
            onBid={handleBid}
            onAuthRequired={handleAuthRequired}
            user={getDummyUser()}
          />
        </div>
      )}
    </div>
  );
}