import React, { useState, useEffect, useRef } from 'react';
import { ArrowLeft, Heart, Share, MoreVertical, Users, Gavel, Clock, DollarSign } from 'lucide-react';
import { LiveChat } from './LiveChat';
import { EnhancedBiddingPanel } from './EnhancedBiddingPanel';
import { AgoraLiveStream } from './AgoraLiveStream';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface User {
  id: string;
  email: string;
  name: string;
  avatar?: string;
}

interface LiveStreamScreenProps {
  user: User | null;
  streamId: string | null;
  onLeaveLive: () => void;
  onAuthRequired: () => void;
}

interface AuctionItem {
  id: string;
  title: string;
  description: string;
  startingBid: number;
  currentBid: number;
  bidCount: number;
  timeLeft: number;
  endTime: string;
  image: string;
  isActive: boolean;
  reservePrice?: number;
  buyItNowPrice?: number;
  autoExtend: boolean;
  incrementType: 'fixed' | 'percentage';
  minimumIncrement: number;
  highestBidder?: string;
  sellerId: string;
  sellerName: string;
}

interface StreamData {
  id: string;
  title: string;
  seller: {
    id: string;
    name: string;
    avatar: string;
    verified: boolean;
    followers: number;
  };
  viewerCount: number;
  category: string;
  thumbnail: string;
  isLive: boolean;
  currentItem?: AuctionItem;
  upcomingItems: AuctionItem[];
}

export function LiveStreamScreen({ user, streamId, onLeaveLive, onAuthRequired }: LiveStreamScreenProps) {
  const [streamData, setStreamData] = useState<StreamData | null>(null);
  const [isFollowing, setIsFollowing] = useState(false);
  const [liked, setLiked] = useState(false);
  const [showBidding, setShowBidding] = useState(true);
  const [loading, setLoading] = useState(true);
  const [isHost, setIsHost] = useState(false);
  const [forceRealCamera, setForceRealCamera] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    if (!streamId) {
      onLeaveLive();
      return;
    }

    // Determine if user is the host (streamId format: stream_${userId}_${timestamp})
    const isUserHost = user && streamId.startsWith(`stream_${user.id}_`);
    setIsHost(!!isUserHost);
    
    // Check for forceRealCamera URL parameter
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('realCamera') === 'true') {
      setForceRealCamera(true);
      console.log('🎥 Real camera mode forced via URL parameter');
    }
    
    console.log('🎬 LiveStream Setup:', {
      streamId,
      userId: user?.id,
      isHost: !!isUserHost,
      userEmail: user?.email
    });

    // Mock stream data
    const mockStreamData: StreamData = {
      id: streamId,
      title: 'Premium Coral Collection - Live Auction',
      seller: {
        id: 'seller1',
        name: 'AquaReef Co.',
        avatar: '/placeholder-avatar.jpg',
        verified: true,
        followers: 12400
      },
      viewerCount: 847,
      category: 'Coral',
      thumbnail: 'https://images.unsplash.com/photo-1544551763-46a013bb70d5?w=800',
      isLive: true,
      currentItem: {
        id: streamId || 'test_item_1', // Use streamId as item ID for test auctions
        title: 'Rainbow Acropora Colony',
        description: 'Beautiful rainbow acropora colony, approximately 3 inches. Healthy and vibrant colors under LED lighting.',
        startingBid: 50,
        currentBid: 125,
        bidCount: 23,
        timeLeft: 47,
        endTime: new Date(Date.now() + 47 * 1000).toISOString(), // 47 seconds from now
        image: 'https://images.unsplash.com/photo-1544551763-46a013bb70d5?w=400',
        isActive: true,
        reservePrice: 100,
        buyItNowPrice: 250,
        autoExtend: true,
        incrementType: 'fixed',
        minimumIncrement: 5,
        highestBidder: undefined,
        sellerId: 'seller1',
        sellerName: 'AquaReef Co.'
      },
      upcomingItems: [
        {
          id: `${streamId}_item2` || 'test_item_2',
          title: 'Orange Torch Coral',
          description: 'Stunning orange torch coral with flowing tentacles.',
          startingBid: 40,
          currentBid: 40,
          bidCount: 0,
          timeLeft: 0,
          endTime: new Date().toISOString(),
          image: 'https://images.unsplash.com/photo-1583212292454-1fe6229603b7?w=400',
          isActive: false,
          autoExtend: false,
          incrementType: 'fixed',
          minimumIncrement: 5,
          sellerId: 'seller1',
          sellerName: 'AquaReef Co.'
        },
        {
          id: `${streamId}_item3` || 'test_item_3',
          title: 'Green Star Polyps',
          description: 'Fast growing GSP colony perfect for beginners.',
          startingBid: 25,
          currentBid: 25,
          bidCount: 0,
          timeLeft: 0,
          endTime: new Date().toISOString(),
          image: 'https://images.unsplash.com/photo-1559827260-dc66d52bef19?w=400',
          isActive: false,
          autoExtend: false,
          incrementType: 'fixed',
          minimumIncrement: 3,
          sellerId: 'seller1',
          sellerName: 'AquaReef Co.'
        }
      ]
    };

    setStreamData(mockStreamData);
    setLoading(false);

    // Timer countdown simulation
    const interval = setInterval(() => {
      setStreamData(prev => {
        if (!prev?.currentItem || prev.currentItem.timeLeft <= 0) return prev;
        
        return {
          ...prev,
          currentItem: {
            ...prev.currentItem,
            timeLeft: Math.max(0, prev.currentItem.timeLeft - 1)
          }
        };
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [streamId, onLeaveLive]);

  const handleBid = (amount: number) => {
    if (!user) {
      onAuthRequired();
      return;
    }

    setStreamData(prev => {
      if (!prev?.currentItem) return prev;
      
      return {
        ...prev,
        currentItem: {
          ...prev.currentItem,
          currentBid: amount,
          bidCount: prev.currentItem.bidCount + 1
        }
      };
    });
  };

  const handleFollow = () => {
    if (!user) {
      onAuthRequired();
      return;
    }
    setIsFollowing(!isFollowing);
  };

  const handleLike = () => {
    if (!user) {
      onAuthRequired();
      return;
    }
    setLiked(!liked);
  };

  if (loading || !streamData) {
    return (
      <div className="h-screen bg-gray-900 flex items-center justify-center">
        <div className="animate-pulse text-white">Loading stream...</div>
      </div>
    );
  }

  return (
    <div className="h-screen bg-gray-900 text-white flex flex-col md:flex-row">
      {/* Mobile Header */}
      <div className="md:hidden bg-gray-800 p-4 flex items-center justify-between">
        <button
          onClick={onLeaveLive}
          className="text-gray-300 hover:text-white transition-colors"
        >
          <ArrowLeft size={24} />
        </button>
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
          <span className="text-sm">LIVE</span>
          <span className="text-sm text-gray-400">•</span>
          <span className="text-sm">{streamData.viewerCount.toLocaleString()}</span>
        </div>
        <button
          onClick={() => {
            const newMode = !forceRealCamera;
            setForceRealCamera(newMode);
            console.log(`🎬 Camera mode changed to: ${newMode ? 'Real Camera' : 'Demo Mode'}`);
            if (newMode) {
              console.log('🔄 Refresh the page to apply real camera mode');
            }
          }}
          className={`px-2 py-1 rounded text-xs transition-colors ${
            forceRealCamera 
              ? 'bg-green-500 text-white' 
              : 'bg-gray-600 text-gray-300 hover:bg-gray-500'
          }`}
          title={forceRealCamera ? 'Real camera mode enabled' : 'Enable real camera mode'}
        >
          {forceRealCamera ? '📹 Real' : '📱 Demo'}
        </button>
      </div>

      {/* Video Area - with Stream Info Overlay */}
      <div className="flex-1 relative bg-black">
        <AgoraLiveStream
          channelName={streamId || 'default-channel'}
          isHost={isHost}
          onLeave={onLeaveLive}
          userToken={user?.id}
          forceRealCamera={forceRealCamera}
        />

        {/* Stream Info Overlay */}
        <div className="absolute bottom-4 left-4 right-4 z-10">
          <div className="bg-black/80 rounded-lg p-4">
            <h2 className="text-xl font-bold mb-2">{streamData.title}</h2>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gradient-to-r from-cyan-400 to-teal-500 rounded-full flex items-center justify-center">
                  <span className="text-white font-medium">
                    {streamData.seller.name.charAt(0).toUpperCase()}
                  </span>
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-medium">{streamData.seller.name}</span>
                    {streamData.seller.verified && (
                      <div className="w-4 h-4 bg-blue-500 rounded-full flex items-center justify-center">
                        <span className="text-white text-xs">✓</span>
                      </div>
                    )}
                  </div>
                  <span className="text-sm text-gray-400">
                    {streamData.seller.followers.toLocaleString()} followers
                  </span>
                </div>
              </div>
              
              <div className="flex items-center gap-2">
                <button
                  onClick={handleLike}
                  className={`p-2 rounded-lg transition-colors ${
                    liked ? 'bg-red-500 text-white' : 'bg-black/60 text-gray-300 hover:text-white'
                  }`}
                >
                  <Heart size={20} fill={liked ? 'currentColor' : 'none'} />
                </button>
                
                <button
                  onClick={handleFollow}
                  className={`px-4 py-2 rounded-lg transition-colors ${
                    isFollowing 
                      ? 'bg-gray-600 text-white' 
                      : 'bg-cyan-500 text-white hover:bg-cyan-400'
                  }`}
                >
                  {isFollowing ? 'Following' : 'Follow'}
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Right Panel - Chat & Bidding */}
      <div className="md:w-96 bg-gray-800 flex flex-col">
        {/* Panel Tabs */}
        <div className="flex border-b border-gray-700">
          <button
            onClick={() => setShowBidding(false)}
            className={`flex-1 py-3 px-4 text-sm transition-colors ${
              !showBidding ? 'bg-gray-700 text-white' : 'text-gray-400 hover:text-white'
            }`}
          >
            Chat
          </button>
          <button
            onClick={() => setShowBidding(true)}
            className={`flex-1 py-3 px-4 text-sm transition-colors ${
              showBidding ? 'bg-gray-700 text-white' : 'text-gray-400 hover:text-white'
            }`}
          >
            Auction
          </button>
        </div>

        {/* Panel Content */}
        <div className="flex-1 flex flex-col">
          {showBidding ? (
            <EnhancedBiddingPanel
              currentItem={streamData.currentItem}
              upcomingItems={streamData.upcomingItems}
              user={user}
              onBid={handleBid}
              onAuthRequired={onAuthRequired}
            />
          ) : (
            <LiveChat
              streamId={streamId!}
              user={user}
              onAuthRequired={onAuthRequired}
            />
          )}
        </div>
      </div>
    </div>
  );
}