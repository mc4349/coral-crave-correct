import React, { useState, useEffect } from 'react';
import { Heart, Eye, Clock, Star, TrendingUp, Sparkles, ArrowRight, RefreshCw } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface RecommendationItem {
  id: string;
  title: string;
  description: string;
  image: string;
  currentBid: number;
  timeLeft: string;
  category: string;
  seller: {
    name: string;
    rating: number;
    verified: boolean;
  };
  reason: string;
  confidence: number;
  status: 'live' | 'scheduled';
  views: number;
  watchers: number;
  isWatched: boolean;
}

interface RecommendationSection {
  title: string;
  subtitle: string;
  icon: React.ReactNode;
  items: RecommendationItem[];
  algorithm: string;
}

interface RecommendationsEngineProps {
  userId: string;
  onItemClick: (itemId: string) => void;
  onWatch: (itemId: string) => void;
  compact?: boolean;
}

export function RecommendationsEngine({ 
  userId, 
  onItemClick, 
  onWatch, 
  compact = false 
}: RecommendationsEngineProps) {
  const [recommendations, setRecommendations] = useState<RecommendationSection[]>([]);
  const [loading, setLoading] = useState(true);
  const [lastUpdated, setLastUpdated] = useState<Date>(new Date());

  // Mock recommendation data
  const mockRecommendations: RecommendationSection[] = [
    {
      title: "Because you bought SPS Corals",
      subtitle: "Similar corals from trusted sellers",
      icon: <Sparkles className="w-5 h-5 text-purple-500" />,
      algorithm: "collaborative-filtering",
      items: [
        {
          id: 'r1',
          title: 'Ultra Rainbow Acropora Colony',
          description: 'Stunning rainbow acropora with amazing polyp extension',
          image: 'https://images.unsplash.com/photo-1583212292454-1fe6229603b7?w=300&h=200&fit=crop',
          currentBid: 95,
          timeLeft: '3h 45m',
          category: 'SPS Corals',
          seller: {
            name: 'CoralMaster_Pro',
            rating: 4.9,
            verified: true
          },
          reason: 'Similar to your previous SPS purchases',
          confidence: 0.92,
          status: 'live',
          views: 156,
          watchers: 9,
          isWatched: false
        },
        {
          id: 'r2',
          title: 'Blue Staghorn Acropora',
          description: 'Healthy blue staghorn with excellent growth',
          image: 'https://images.unsplash.com/photo-1583212292454-1fe6229603b7?w=300&h=200&fit=crop',
          currentBid: 65,
          timeLeft: '1h 20m',
          category: 'SPS Corals',
          seller: {
            name: 'ReefLife_Expert',
            rating: 4.7,
            verified: true
          },
          reason: 'High rating from SPS specialist',
          confidence: 0.88,
          status: 'live',
          views: 89,
          watchers: 6,
          isWatched: true
        }
      ]
    },
    {
      title: "Trending Now",
      subtitle: "Popular auctions in your categories",
      icon: <TrendingUp className="w-5 h-5 text-green-500" />,
      algorithm: "trending-popularity",
      items: [
        {
          id: 'r3',
          title: 'Rare Torch Coral Garden',
          description: 'Collection of rare torch corals in multiple colors',
          image: 'https://images.unsplash.com/photo-1583212292454-1fe6229603b7?w=300&h=200&fit=crop',
          currentBid: 145,
          timeLeft: '4h 10m',
          category: 'LPS Corals',
          seller: {
            name: 'TorchSpecialist',
            rating: 4.8,
            verified: false
          },
          reason: 'Trending in LPS corals this week',
          confidence: 0.85,
          status: 'live',
          views: 342,
          watchers: 18,
          isWatched: false
        }
      ]
    },
    {
      title: "From Sellers You Follow",
      subtitle: "New listings from your followed sellers",
      icon: <Heart className="w-5 h-5 text-red-500" />,
      algorithm: "social-following",
      items: [
        {
          id: 'r4',
          title: 'Premium Clownfish Pair',
          description: 'Mated pair of premium clownfish, captive bred',
          image: 'https://images.unsplash.com/photo-1559827260-dc66d52bef19?w=300&h=200&fit=crop',
          currentBid: 75,
          timeLeft: 'Starting in 1h',
          category: 'Fish',
          seller: {
            name: 'CoralKing_Reef',
            rating: 4.8,
            verified: true
          },
          reason: 'New listing from seller you follow',
          confidence: 0.95,
          status: 'scheduled',
          views: 23,
          watchers: 5,
          isWatched: false
        }
      ]
    },
    {
      title: "Price Drops",
      subtitle: "Items on your watchlist with lower bids",
      icon: <Clock className="w-5 h-5 text-blue-500" />,
      algorithm: "price-drop-alerts",
      items: [
        {
          id: 'r5',
          title: 'Green Hammer Coral',
          description: 'Large green hammer coral with multiple heads',
          image: 'https://images.unsplash.com/photo-1583212292454-1fe6229603b7?w=300&h=200&fit=crop',
          currentBid: 55,
          timeLeft: '6h 30m',
          category: 'LPS Corals',
          seller: {
            name: 'HammerTime_Corals',
            rating: 4.6,
            verified: false
          },
          reason: 'Price dropped $15 since you watched',
          confidence: 1.0,
          status: 'live',
          views: 98,
          watchers: 12,
          isWatched: true
        }
      ]
    }
  ];

  useEffect(() => {
    // Simulate API call to get personalized recommendations
    const fetchRecommendations = async () => {
      setLoading(true);
      
      // Mock API delay
      setTimeout(() => {
        setRecommendations(mockRecommendations);
        setLastUpdated(new Date());
        setLoading(false);
      }, 1000);
    };

    fetchRecommendations();
  }, [userId]);

  const refreshRecommendations = () => {
    setLoading(true);
    // Simulate refresh with slight delay
    setTimeout(() => {
      // Shuffle recommendations to simulate new data
      const shuffled = [...mockRecommendations].map(section => ({
        ...section,
        items: [...section.items].sort(() => Math.random() - 0.5)
      }));
      setRecommendations(shuffled);
      setLastUpdated(new Date());
      setLoading(false);
    }, 800);
  };

  const handleWatch = (itemId: string) => {
    setRecommendations(prev => 
      prev.map(section => ({
        ...section,
        items: section.items.map(item =>
          item.id === itemId 
            ? { ...item, isWatched: !item.isWatched }
            : item
        )
      }))
    );
    onWatch(itemId);
  };

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 0.9) return 'text-green-600';
    if (confidence >= 0.8) return 'text-yellow-600';
    return 'text-gray-600';
  };

  const RecommendationCard = ({ item }: { item: RecommendationItem }) => (
    <Card 
      className={`overflow-hidden hover:shadow-lg transition-all cursor-pointer group ${
        compact ? 'w-64 shrink-0' : ''
      }`}
      onClick={() => onItemClick(item.id)}
    >
      <div className="relative">
        <div className={`${compact ? 'aspect-[4/3]' : 'aspect-video'}`}>
          <ImageWithFallback
            src={item.image}
            alt={item.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform"
          />
        </div>
        
        {/* Status Badge */}
        <div className="absolute top-2 left-2">
          {item.status === 'live' && (
            <Badge variant="destructive" className="text-xs">
              <span className="w-1.5 h-1.5 bg-white rounded-full mr-1"></span>
              LIVE
            </Badge>
          )}
          {item.status === 'scheduled' && (
            <Badge variant="secondary" className="text-xs">
              <Clock className="w-3 h-3 mr-1" />
              SCHEDULED
            </Badge>
          )}
        </div>

        {/* Watch Button */}
        <Button
          variant="ghost"
          size="sm"
          className="absolute top-2 right-2 h-8 w-8 p-0 bg-black/50 hover:bg-black/70"
          onClick={(e) => {
            e.stopPropagation();
            handleWatch(item.id);
          }}
        >
          <Heart className={`w-4 h-4 ${item.isWatched ? 'fill-red-500 text-red-500' : 'text-white'}`} />
        </Button>

        {/* Stats */}
        <div className="absolute bottom-2 right-2 flex gap-2 text-xs text-white">
          <div className="flex items-center gap-1 bg-black/50 rounded px-2 py-1">
            <Eye className="w-3 h-3" />
            {item.views}
          </div>
          <div className="flex items-center gap-1 bg-black/50 rounded px-2 py-1">
            <Heart className="w-3 h-3" />
            {item.watchers}
          </div>
        </div>
      </div>

      <CardContent className="p-4">
        <h3 className={`font-semibold mb-1 line-clamp-1 ${compact ? 'text-sm' : ''}`}>
          {item.title}
        </h3>
        <p className={`text-muted-foreground mb-3 line-clamp-2 ${compact ? 'text-xs' : 'text-sm'}`}>
          {item.description}
        </p>
        
        {/* Seller Info */}
        <div className="flex items-center gap-2 mb-3">
          <div className="flex items-center gap-1">
            <div className="w-4 h-4 bg-gradient-to-br from-cyan-400 to-blue-600 rounded-full flex items-center justify-center text-xs text-white font-bold">
              {item.seller.name[0]}
            </div>
            <span className="text-xs font-medium">{item.seller.name}</span>
            {item.seller.verified && (
              <div className="w-3 h-3 bg-blue-500 rounded-full flex items-center justify-center">
                <span className="text-white text-[8px]">✓</span>
              </div>
            )}
          </div>
          <div className="flex items-center gap-1 ml-auto">
            <Star className="w-3 h-3 fill-yellow-400 text-yellow-400" />
            <span className="text-xs">{item.seller.rating}</span>
          </div>
        </div>

        {/* Recommendation Reason */}
        <div className="mb-3">
          <p className="text-xs text-muted-foreground">{item.reason}</p>
          <div className="flex items-center gap-1 mt-1">
            <span className="text-xs text-muted-foreground">Confidence:</span>
            <span className={`text-xs font-medium ${getConfidenceColor(item.confidence)}`}>
              {(item.confidence * 100).toFixed(0)}%
            </span>
          </div>
        </div>

        {/* Price and Time */}
        <div className="flex items-center justify-between">
          <div>
            <p className="text-xs text-muted-foreground">Current Bid</p>
            <p className="font-bold text-green-600">${item.currentBid}</p>
          </div>
          <div className="text-right">
            <p className="text-xs text-muted-foreground">
              {item.status === 'scheduled' ? 'Starts' : 'Ends'}
            </p>
            <p className="text-xs font-medium">{item.timeLeft}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );

  if (loading) {
    return (
      <div className="space-y-6">
        {[...Array(3)].map((_, i) => (
          <div key={i} className="space-y-4">
            <div className="h-6 bg-muted rounded w-1/3 animate-pulse" />
            <div className={`grid gap-4 ${compact ? 'grid-cols-1' : 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3'}`}>
              {[...Array(compact ? 1 : 3)].map((_, j) => (
                <div key={j} className="animate-pulse">
                  <div className="aspect-video bg-muted rounded-lg mb-4" />
                  <div className="space-y-2">
                    <div className="h-4 bg-muted rounded" />
                    <div className="h-3 bg-muted rounded w-3/4" />
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      {!compact && (
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl font-bold">Recommended for You</h2>
            <p className="text-sm text-muted-foreground">
              Last updated {lastUpdated.toLocaleTimeString()}
            </p>
          </div>
          <Button variant="outline" size="sm" onClick={refreshRecommendations} disabled={loading}>
            <RefreshCw className={`w-4 h-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
        </div>
      )}

      {/* Recommendation Sections */}
      {recommendations.map((section, index) => (
        <div key={index} className="space-y-4">
          <div className="flex items-center gap-3">
            {section.icon}
            <div>
              <h3 className={`font-semibold ${compact ? 'text-base' : 'text-lg'}`}>
                {section.title}
              </h3>
              <p className={`text-muted-foreground ${compact ? 'text-xs' : 'text-sm'}`}>
                {section.subtitle}
              </p>
            </div>
          </div>

          {compact ? (
            <div className="flex gap-4 overflow-x-auto pb-2 scrollbar-hide">
              {section.items.map((item) => (
                <RecommendationCard key={item.id} item={item} />
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {section.items.map((item) => (
                <RecommendationCard key={item.id} item={item} />
              ))}
            </div>
          )}

          {!compact && index < recommendations.length - 1 && (
            <Separator className="my-6" />
          )}
        </div>
      ))}

      {/* Algorithm Info */}
      {!compact && (
        <Card className="bg-muted/50">
          <CardContent className="p-4">
            <div className="flex items-center gap-2 mb-2">
              <Sparkles className="w-4 h-4 text-purple-500" />
              <span className="text-sm font-medium">How we recommend</span>
            </div>
            <p className="text-xs text-muted-foreground">
              Our AI analyzes your purchase history, viewing patterns, followed sellers, 
              and community trends to suggest items you're most likely to be interested in.
              Recommendations update in real-time based on your activity.
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}