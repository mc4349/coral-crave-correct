import React, { useState } from 'react';
import { X, Key, Shield, CheckCircle, AlertCircle } from 'lucide-react';
import { projectId, publicAnonKey } from '../utils/supabase/info';

interface AgoraCredentialsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCredentialsSet: () => void;
}

export function AgoraCredentialsModal({ isOpen, onClose, onCredentialsSet }: AgoraCredentialsModalProps) {
  const [appId, setAppId] = useState('');
  const [certificate, setCertificate] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!appId.trim() || !certificate.trim()) {
      setError('Both App ID and Certificate are required');
      return;
    }

    setIsSubmitting(true);
    setError(null);

    try {
      console.log('🔑 Setting Agora credentials...');
      
      // Call server endpoint to set credentials
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-9f7745d8/agora/set-credentials`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`
        },
        body: JSON.stringify({
          appId: appId.trim(),
          certificate: certificate.trim()
        })
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Failed to set credentials: ${errorText}`);
      }

      const result = await response.json();
      console.log('✅ Agora credentials set successfully:', result);
      
      setSuccess(true);
      
      // Close modal after short delay
      setTimeout(() => {
        setSuccess(false);
        onCredentialsSet();
        onClose();
      }, 2000);

    } catch (err) {
      console.error('❌ Failed to set Agora credentials:', err);
      setError(err instanceof Error ? err.message : 'Failed to set credentials');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-gray-800 rounded-xl max-w-md w-full p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <Key className="text-cyan-400" size={24} />
            <h2 className="text-xl font-bold text-white">Agora Credentials</h2>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-white transition-colors"
          >
            <X size={24} />
          </button>
        </div>

        {success ? (
          <div className="text-center">
            <CheckCircle className="mx-auto text-green-400 mb-4" size={48} />
            <h3 className="text-lg font-medium text-white mb-2">Credentials Set!</h3>
            <p className="text-gray-300">Your Agora credentials have been configured successfully.</p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="bg-blue-500/20 border border-blue-500/30 rounded-lg p-4 mb-4">
              <div className="flex items-start gap-3">
                <Shield className="text-blue-400 mt-0.5" size={20} />
                <div>
                  <h3 className="text-blue-300 font-medium mb-1">Your Agora Credentials</h3>
                  <p className="text-blue-200/80 text-sm">
                    Enter your actual Agora App ID and Certificate to enable real camera streaming.
                  </p>
                </div>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-white mb-2">
                App ID
              </label>
              <input
                type="text"
                value={appId}
                onChange={(e) => setAppId(e.target.value)}
                placeholder="ec04bb440a664616b3aa04e10ca2ea41"
                className="w-full bg-gray-700 text-white px-3 py-2 rounded-lg border border-gray-600 focus:border-cyan-400 focus:outline-none"
                disabled={isSubmitting}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-white mb-2">
                App Certificate
              </label>
              <input
                type="text"
                value={certificate}
                onChange={(e) => setCertificate(e.target.value)}
                placeholder="73a5f7a53db7469aa15a08a79696bc02"
                className="w-full bg-gray-700 text-white px-3 py-2 rounded-lg border border-gray-600 focus:border-cyan-400 focus:outline-none"
                disabled={isSubmitting}
              />
            </div>

            {error && (
              <div className="bg-red-500/20 border border-red-500/30 rounded-lg p-3">
                <div className="flex items-center gap-2">
                  <AlertCircle className="text-red-400" size={16} />
                  <p className="text-red-300 text-sm">{error}</p>
                </div>
              </div>
            )}

            <div className="flex gap-3 pt-2">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 bg-gray-600 text-white px-4 py-2 rounded-lg hover:bg-gray-500 transition-colors"
                disabled={isSubmitting}
              >
                Cancel
              </button>
              <button
                type="submit"
                className="flex-1 bg-cyan-500 text-white px-4 py-2 rounded-lg hover:bg-cyan-400 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                disabled={isSubmitting || !appId.trim() || !certificate.trim()}
              >
                {isSubmitting ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                    Setting...
                  </>
                ) : (
                  'Set Credentials'
                )}
              </button>
            </div>

            <div className="bg-gray-700/50 rounded-lg p-3 mt-4">
              <h4 className="text-white font-medium mb-2">📋 Your Credentials:</h4>
              <div className="text-sm text-gray-300 space-y-1">
                <p><strong>App ID:</strong> ec04bb440a664616b3aa04e10ca2ea41</p>
                <p><strong>Certificate:</strong> 73a5f7a53db7469aa15a08a79696bc02</p>
              </div>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}