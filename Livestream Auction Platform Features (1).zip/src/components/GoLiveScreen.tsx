import React, { useState, useEffect, useRef } from 'react';
import { ArrowLeft, Upload, Clock, Play, X, Image as ImageIcon, Plus, Settings, Users, Eye, AlertTriangle } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Alert, AlertDescription } from './ui/alert';
import { PayPalConnect } from './PayPalConnect';
import { projectId, publicAnonKey } from '../utils/supabase/info';
import { supabase } from '../utils/supabase/client';

interface User {
  id: string;
  email: string;
  name: string;
  avatar?: string;
}

interface Product {
  id: string;
  title: string;
  description: string;
  category: string;
  startingBid: number;
  images: string[];
}

interface GoLiveScreenProps {
  user: User | null;
  onAuthRequired: () => void;
  onGoLive: (streamData: { title: string; description: string; channelName: string }) => void;
  onCancel: () => void;
}

const timerOptions = [
  { value: '30', label: '30 seconds' },
  { value: '60', label: '1 minute' },
  { value: '120', label: '2 minutes' },
  { value: '300', label: '5 minutes' },
];

const categories = [
  'SPS Corals',
  'LPS Corals', 
  'Soft Corals',
  'Fish',
  'Equipment',
  'Invertebrates',
  'Live Rock',
  'Other'
];

export function GoLiveScreen({ user, onAuthRequired, onGoLive, onCancel }: GoLiveScreenProps) {
  const [showGoLiveModal, setShowGoLiveModal] = useState(false);
  const [streamTitle, setStreamTitle] = useState('');
  const [streamDescription, setStreamDescription] = useState('');
  const [selectedProduct, setSelectedProduct] = useState<string>('none');
  const [timer, setTimer] = useState('30');
  const [thumbnail, setThumbnail] = useState<string>('');
  const [isStarting, setIsStarting] = useState(false);
  const [liveStreams, setLiveStreams] = useState<any[]>([]);
  const [queuedProducts, setQueuedProducts] = useState<Product[]>([]);
  const [showAddProduct, setShowAddProduct] = useState(false);
  const [newProduct, setNewProduct] = useState({
    title: '',
    description: '',
    category: '',
    startingBid: 0,
    images: [] as string[]
  });
  const [isAddingProduct, setIsAddingProduct] = useState(false);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [paypalConnected, setPaypalConnected] = useState(false);
  const [sellerMerchantId, setSellerMerchantId] = useState<string | undefined>();
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!user) {
      // Don't call onAuthRequired immediately, let the component render first
      console.log('GoLiveScreen: No user, component will show auth required UI');
      return;
    }
    
    loadSellerData();
    
    // Update current time every second
    const timeInterval = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => clearInterval(timeInterval);
  }, [user]);

  const loadSellerData = async () => {
    if (!user) return;

    try {
      // Load seller's products and active streams
      // Mock data for now since we don't have database tables set up
      setQueuedProducts([
        {
          id: '1',
          title: 'Rainbow Acropora Colony',
          description: 'Beautiful rainbow acropora with amazing polyp extension',
          category: 'SPS Corals',
          startingBid: 50,
          images: ['https://images.unsplash.com/photo-1583212292454-1fe6229603b7?w=300&h=200&fit=crop']
        },
        {
          id: '2', 
          title: 'Torch Coral Frags',
          description: 'Healthy torch coral fragments in various colors',
          category: 'LPS Corals',
          startingBid: 25,
          images: ['https://images.unsplash.com/photo-1583212292454-1fe6229603b7?w=300&h=200&fit=crop']
        }
      ]);

      setLiveStreams([]);
    } catch (error) {
      console.error('Failed to load seller data:', error);
    }
  };

  const handleGoLive = () => {
    if (!user) {
      onAuthRequired();
      return;
    }
    
    // Check PayPal connection requirement
    if (!paypalConnected) {
      alert('Please connect your PayPal account before going live to receive payments.');
      return;
    }
    
    setShowGoLiveModal(true);
  };

  // Handle PayPal connection status change
  const handlePayPalConnectionChange = (isConnected: boolean, merchantId?: string) => {
    setPaypalConnected(isConnected);
    setSellerMerchantId(merchantId);
  };

  const handleStartStream = async () => {
    if (!streamTitle.trim()) {
      alert('Please enter a stream title');
      return;
    }

    setIsStarting(true);

    try {
      // Generate channel name
      const channelName = `${user.id}_${Date.now()}`;
      
      // Get user session for API call
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.access_token) {
        alert('Please sign in to start streaming');
        return;
      }

      console.log('🎥 Starting stream with data:', {
        title: streamTitle,
        description: streamDescription,
        channelName
      });

      // Call backend API to start stream - FIXED ENDPOINT
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-9f7745d8/streams/start`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${session.access_token}`
        },
        body: JSON.stringify({
          title: streamTitle,
          description: streamDescription,
          category: 'Corals' // Default category
        })
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error('❌ Server response error:', response.status, errorText);
        throw new Error(`Server error ${response.status}: ${errorText}`);
      }

      const result = await response.json();
      console.log('✅ Server response:', result);
      
      if (result.success) {
        // Create stream data for local state
        const streamData = {
          title: streamTitle,
          description: streamDescription,
          channelName: result.channelName || channelName
        };

        console.log('🚀 Starting stream with data:', streamData);

        // Start the stream
        onGoLive(streamData);
        
        setShowGoLiveModal(false);
        resetForm();
      } else {
        throw new Error(result.error || 'Failed to start stream');
      }

    } catch (error) {
      console.error('💥 Failed to start stream:', error);
      alert(`Failed to start stream: ${error.message}`);
    } finally {
      setIsStarting(false);
    }
  };

  const resetForm = () => {
    setStreamTitle('');
    setStreamDescription('');
    setSelectedProduct('none');
    setTimer('30');
    setThumbnail('');
  };

  const handleThumbnailUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setThumbnail(e.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const generateAutoThumbnail = async () => {
    try {
      // Use a placeholder coral/aquarium image
      const imageUrl = 'https://images.unsplash.com/photo-1583212292454-1fe6229603b7?w=400&h=225&fit=crop';
      setThumbnail(imageUrl);
    } catch (error) {
      console.error('Failed to generate thumbnail:', error);
    }
  };

  const handleAddProduct = async () => {
    if (!newProduct.title.trim() || !newProduct.category || newProduct.startingBid <= 0) {
      alert('Please fill in all required fields');
      return;
    }

    setIsAddingProduct(true);

    try {
      // Generate product images if none provided
      if (newProduct.images.length === 0) {
        const imageUrl = 'https://images.unsplash.com/photo-1583212292454-1fe6229603b7?w=300&h=200&fit=crop';
        newProduct.images = [imageUrl];
      }

      const product: Product = {
        id: Date.now().toString(),
        ...newProduct
      };

      setQueuedProducts(prev => [...prev, product]);
      setShowAddProduct(false);
      setNewProduct({
        title: '',
        description: '',
        category: '',
        startingBid: 0,
        images: []
      });

    } catch (error) {
      console.error('Failed to add product:', error);
      alert('Failed to add product. Please try again.');
    } finally {
      setIsAddingProduct(false);
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-900 text-white flex items-center justify-center">
        <div className="text-center">
          <div className="text-6xl mb-4">🔐</div>
          <h2 className="text-2xl font-bold mb-4">Authentication Required</h2>
          <p className="text-gray-400 mb-6">Please sign in to start streaming</p>
          <Button onClick={onAuthRequired} className="bg-cyan-500 hover:bg-cyan-600">
            Sign In
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      {/* Header */}
      <div className="bg-gray-800 border-b border-gray-700 p-4">
        <div className="flex items-center space-x-4">
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={onCancel}
            className="text-gray-400 hover:text-white"
          >
            <ArrowLeft size={20} />
          </Button>
          <div>
            <h1 className="text-xl font-bold">Seller Dashboard</h1>
            <p className="text-sm text-gray-400">Manage your live streams and products</p>
          </div>
        </div>
      </div>

      <div className="p-4 space-y-6">
        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card className="bg-gray-800 border-gray-700">
            <CardContent className="p-4">
              <div className="flex items-center space-x-3">
                <div className="bg-green-500/20 p-2 rounded-full">
                  <Play size={20} className="text-green-400" />
                </div>
                <div>
                  <p className="text-sm text-gray-400">Active Streams</p>
                  <p className="text-2xl font-bold">{liveStreams.length}</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gray-800 border-gray-700">
            <CardContent className="p-4">
              <div className="flex items-center space-x-3">
                <div className="bg-cyan-500/20 p-2 rounded-full">
                  <Eye size={20} className="text-cyan-400" />
                </div>
                <div>
                  <p className="text-sm text-gray-400">Total Viewers</p>
                  <p className="text-2xl font-bold">0</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gray-800 border-gray-700">
            <CardContent className="p-4">
              <div className="flex items-center space-x-3">
                <div className="bg-orange-500/20 p-2 rounded-full">
                  <Users size={20} className="text-orange-400" />
                </div>
                <div>
                  <p className="text-sm text-gray-400">Products Ready</p>
                  <p className="text-2xl font-bold">{queuedProducts.length}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Go Live Section */}
        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Play className="text-cyan-400" size={20} />
              <span>Go Live</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-gray-400">
              Start a live stream to showcase and auction your products to buyers worldwide.
            </p>
            
            {/* PayPal Connection Alert */}
            {!paypalConnected && (
              <Alert className="bg-yellow-500/20 border-yellow-500/30">
                <AlertTriangle className="h-4 w-4 text-yellow-400" />
                <AlertDescription className="text-yellow-300">
                  Connect your PayPal account to receive payments before going live.
                </AlertDescription>
              </Alert>
            )}
            
            <div className="flex items-center space-x-4">
              <Button 
                onClick={handleGoLive}
                disabled={!paypalConnected}
                className={`px-8 py-2 ${paypalConnected 
                  ? 'bg-red-500 hover:bg-red-600 text-white' 
                  : 'bg-gray-600 text-gray-400 cursor-not-allowed'
                }`}
                size="lg"
              >
                <Play className="mr-2" size={16} />
                Go Live
              </Button>
              
              <div className="text-sm text-gray-400">
                <Clock size={16} className="inline mr-1" />
                {currentTime.toLocaleTimeString()}
              </div>
            </div>

            {liveStreams.length === 0 && (
              <div className="bg-gray-700/50 rounded-lg p-4 border border-gray-600">
                <h3 className="font-medium mb-2">Ready to go live?</h3>
                <ul className="text-sm text-gray-400 space-y-1">
                  <li>• Connect your PayPal account to receive payments</li>
                  <li>• Make sure your products are ready</li>
                  <li>• Check your internet connection</li>
                  <li>• Prepare your streaming setup</li>
                  <li>• Have good lighting for your products</li>
                </ul>
              </div>
            )}
          </CardContent>
        </Card>

        {/* PayPal Connection Section */}
        <PayPalConnect 
          onConnectionChange={handlePayPalConnectionChange}
          className="bg-gray-800 border-gray-700"
        />

        {/* Product Queue */}
        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Product Queue</CardTitle>
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => setShowAddProduct(true)}
                className="border-gray-600 text-gray-300 hover:bg-gray-700"
              >
                <Plus size={16} className="mr-2" />
                Add Product
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {queuedProducts.length === 0 ? (
              <div className="text-center py-8">
                <div className="text-4xl mb-4">📦</div>
                <h3 className="text-lg font-medium text-gray-300 mb-2">No Products Ready</h3>
                <p className="text-gray-500 mb-4">Add products to your queue to auction during live streams</p>
                <Button 
                  onClick={() => setShowAddProduct(true)}
                  className="bg-cyan-500 hover:bg-cyan-600"
                >
                  Add Your First Product
                </Button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {queuedProducts.map((product) => (
                  <Card key={product.id} className="bg-gray-700 border-gray-600">
                    <CardContent className="p-4">
                      <img
                        src={product.images[0]}
                        alt={product.title}
                        className="w-full h-32 object-cover rounded-lg mb-3"
                      />
                      <h4 className="font-medium mb-1">{product.title}</h4>
                      <p className="text-sm text-gray-400 mb-2 line-clamp-2">{product.description}</p>
                      <div className="flex items-center justify-between">
                        <Badge variant="outline" className="text-xs text-gray-400 border-gray-600">
                          {product.category}
                        </Badge>
                        <span className="text-green-400 font-medium">${product.startingBid}</span>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Go Live Modal */}
      <Dialog open={showGoLiveModal} onOpenChange={setShowGoLiveModal}>
        <DialogContent className="bg-gray-800 border-gray-700 text-white max-w-md">
          <DialogHeader>
            <DialogTitle>Go Live</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            {/* Stream Title */}
            <div>
              <label className="block text-sm font-medium mb-2">Stream Title</label>
              <Input
                placeholder="Enter your stream title..."
                value={streamTitle}
                onChange={(e) => setStreamTitle(e.target.value)}
                className="bg-gray-700 border-gray-600 text-white"
              />
            </div>

            {/* Stream Description */}
            <div>
              <label className="block text-sm font-medium mb-2">Description (Optional)</label>
              <Textarea
                placeholder="Describe what you'll be showing..."
                value={streamDescription}
                onChange={(e) => setStreamDescription(e.target.value)}
                className="bg-gray-700 border-gray-600 text-white"
                rows={3}
              />
            </div>

            {/* Product Selection */}
            <div>
              <label className="block text-sm font-medium mb-2">Select Product (Optional)</label>
              <Select value={selectedProduct} onValueChange={setSelectedProduct}>
                <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                  <SelectValue placeholder="Choose a product to start with" />
                </SelectTrigger>
                <SelectContent className="bg-gray-700 border-gray-600">
                  <SelectItem value="none">Start stream without product</SelectItem>
                  {queuedProducts.map((product) => (
                    <SelectItem key={product.id} value={product.id}>
                      {product.title} - ${product.startingBid}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Thumbnail */}
            <div>
              <label className="block text-sm font-medium mb-2">Stream Thumbnail</label>
              <div className="space-y-2">
                {thumbnail && (
                  <img 
                    src={thumbnail} 
                    alt="Stream thumbnail" 
                    className="w-full h-32 object-cover rounded-lg"
                  />
                )}
                <div className="flex space-x-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => fileInputRef.current?.click()}
                    className="border-gray-600 text-gray-300 hover:bg-gray-700"
                  >
                    <Upload size={16} className="mr-2" />
                    Upload
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={generateAutoThumbnail}
                    className="border-gray-600 text-gray-300 hover:bg-gray-700"
                  >
                    <ImageIcon size={16} className="mr-2" />
                    Auto Generate
                  </Button>
                </div>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handleThumbnailUpload}
                  className="hidden"
                />
              </div>
            </div>

            {/* Timer */}
            <div>
              <label className="block text-sm font-medium mb-2">Start Timer</label>
              <Select value={timer} onValueChange={setTimer}>
                <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-gray-700 border-gray-600">
                  {timerOptions.map((option) => (
                    <SelectItem key={option.value} value={option.value}>
                      {option.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <Separator className="bg-gray-600" />

            {/* Action Buttons */}
            <div className="flex space-x-3">
              <Button
                variant="outline"
                onClick={() => setShowGoLiveModal(false)}
                className="flex-1 border-gray-600 text-gray-300 hover:bg-gray-700"
              >
                Cancel
              </Button>
              <Button
                onClick={handleStartStream}
                disabled={isStarting}
                className="flex-1 bg-red-500 hover:bg-red-600 text-white"
              >
                {isStarting ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                    Starting...
                  </>
                ) : (
                  <>
                    <Play className="mr-2" size={16} />
                    Start Streaming
                  </>
                )}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Add Product Modal */}
      <Dialog open={showAddProduct} onOpenChange={setShowAddProduct}>
        <DialogContent className="bg-gray-800 border-gray-700 text-white max-w-md">
          <DialogHeader>
            <DialogTitle>Add Product</DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2">Product Title</label>
              <Input
                placeholder="Enter product title..."
                value={newProduct.title}
                onChange={(e) => setNewProduct(prev => ({ ...prev, title: e.target.value }))}
                className="bg-gray-700 border-gray-600 text-white"
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Description</label>
              <Textarea
                placeholder="Describe your product..."
                value={newProduct.description}
                onChange={(e) => setNewProduct(prev => ({ ...prev, description: e.target.value }))}
                className="bg-gray-700 border-gray-600 text-white"
                rows={3}
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Category</label>
              <Select 
                value={newProduct.category} 
                onValueChange={(value) => setNewProduct(prev => ({ ...prev, category: value }))}
              >
                <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent className="bg-gray-700 border-gray-600">
                  {categories.map((category) => (
                    <SelectItem key={category} value={category}>
                      {category}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Starting Bid ($)</label>
              <Input
                type="number"
                placeholder="0"
                value={newProduct.startingBid || ''}
                onChange={(e) => setNewProduct(prev => ({ 
                  ...prev, 
                  startingBid: parseFloat(e.target.value) || 0 
                }))}
                className="bg-gray-700 border-gray-600 text-white"
              />
            </div>

            <div className="flex space-x-3">
              <Button
                variant="outline"
                onClick={() => setShowAddProduct(false)}
                className="flex-1 border-gray-600 text-gray-300 hover:bg-gray-700"
              >
                Cancel
              </Button>
              <Button
                onClick={handleAddProduct}
                disabled={isAddingProduct}
                className="flex-1 bg-cyan-500 hover:bg-cyan-600 text-white"
              >
                {isAddingProduct ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2" />
                    Adding...
                  </>
                ) : (
                  'Add Product'
                )}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}