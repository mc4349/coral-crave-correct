import React, { useState, useEffect, useRef } from 'react';
import { Send, Heart, Smile, Gift, Star } from 'lucide-react';

interface User {
  id: string;
  email: string;
  name: string;
  avatar?: string;
}

interface LiveChatProps {
  streamId: string;
  user: User | null;
  onAuthRequired: () => void;
}

interface ChatMessage {
  id: string;
  user: {
    id: string;
    name: string;
    avatar?: string;
    verified?: boolean;
    color: string;
  };
  message: string;
  timestamp: Date;
  type: 'message' | 'system' | 'bid' | 'emoji';
  emoji?: string;
}

const quickEmojis = ['❤️', '🔥', '👏', '😍', '🌊', '🐠', '🪸', '✨'];

export function LiveChat({ streamId, user, onAuthRequired }: LiveChatProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const chatContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Mock initial messages
    const initialMessages: ChatMessage[] = [
      {
        id: '1',
        user: {
          id: 'user1',
          name: 'ReefExplorer',
          color: '#10B981'
        },
        message: 'Wow, that acropora is stunning! 🪸',
        timestamp: new Date(Date.now() - 120000),
        type: 'message'
      },
      {
        id: '2',
        user: {
          id: 'user2',
          name: 'CoralCollector',
          verified: true,
          color: '#3B82F6'
        },
        message: 'First time watching this seller, very impressed!',
        timestamp: new Date(Date.now() - 90000),
        type: 'message'
      },
      {
        id: '3',
        user: {
          id: 'system',
          name: 'System',
          color: '#F59E0B'
        },
        message: 'ReefMaster placed a bid of $125 on Rainbow Acropora Colony',
        timestamp: new Date(Date.now() - 60000),
        type: 'bid'
      },
      {
        id: '4',
        user: {
          id: 'user3',
          name: 'AquaEnthusiast',
          color: '#EF4444'
        },
        message: 'What are the water parameters for this coral?',
        timestamp: new Date(Date.now() - 30000),
        type: 'message'
      }
    ];

    setMessages(initialMessages);

    // Simulate live messages
    const interval = setInterval(() => {
      if (Math.random() < 0.3) {
        const randomMessages = [
          'Great colors on that coral!',
          'Shipping to California?',
          'How long have you been in the hobby?',
          'Beautiful tank setup!',
          'Next item looks amazing',
          'What lighting do you use?',
          'Tank tour soon?',
          'Love this seller! 🔥',
          'Bidding war! 😍',
          'Healthy looking specimens'
        ];

        const randomUsers = [
          { name: 'TankMaster', color: '#8B5CF6' },
          { name: 'ReefNinja', color: '#06B6D4' },
          { name: 'CoralWhisperer', color: '#F97316' },
          { name: 'SaltWaterPro', color: '#84CC16' },
          { name: 'AquaGuru', color: '#EC4899' }
        ];

        const randomUser = randomUsers[Math.floor(Math.random() * randomUsers.length)];
        const randomMessage = randomMessages[Math.floor(Math.random() * randomMessages.length)];

        const newMsg: ChatMessage = {
          id: Date.now().toString(),
          user: {
            id: `user_${Date.now()}`,
            ...randomUser
          },
          message: randomMessage,
          timestamp: new Date(),
          type: 'message'
        };

        setMessages(prev => [...prev, newMsg]);
      }
    }, 5000 + Math.random() * 10000);

    return () => clearInterval(interval);
  }, [streamId]);

  useEffect(() => {
    // Auto-scroll to bottom
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!user) {
      onAuthRequired();
      return;
    }

    if (!newMessage.trim()) return;

    const message: ChatMessage = {
      id: Date.now().toString(),
      user: {
        id: user.id,
        name: user.name,
        color: '#10B981'
      },
      message: newMessage.trim(),
      timestamp: new Date(),
      type: 'message'
    };

    setMessages(prev => [...prev, message]);
    setNewMessage('');
  };

  const handleEmojiClick = (emoji: string) => {
    if (!user) {
      onAuthRequired();
      return;
    }

    const emojiMessage: ChatMessage = {
      id: Date.now().toString(),
      user: {
        id: user.id,
        name: user.name,
        color: '#10B981'
      },
      message: emoji,
      timestamp: new Date(),
      type: 'emoji',
      emoji
    };

    setMessages(prev => [...prev, emojiMessage]);
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <div className="flex flex-col h-full">
      {/* Chat Header */}
      <div className="p-4 border-b border-gray-700">
        <h3 className="font-medium text-white">Live Chat</h3>
        <p className="text-sm text-gray-400">{messages.length} messages</p>
      </div>

      {/* Messages */}
      <div 
        ref={chatContainerRef}
        className="flex-1 overflow-y-auto p-4 space-y-3"
      >
        {messages.map((msg) => (
          <div key={msg.id} className="group">
            {msg.type === 'system' || msg.type === 'bid' ? (
              <div className="bg-gray-700 rounded-lg p-2 text-center">
                <p className="text-sm text-yellow-400">{msg.message}</p>
                <span className="text-xs text-gray-500">{formatTime(msg.timestamp)}</span>
              </div>
            ) : (
              <div className="flex items-start gap-2">
                <div 
                  className="w-6 h-6 rounded-full flex-shrink-0 flex items-center justify-center text-xs font-bold text-white"
                  style={{ backgroundColor: msg.user.color }}
                >
                  {msg.user.name[0].toUpperCase()}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <span 
                      className="text-sm font-medium"
                      style={{ color: msg.user.color }}
                    >
                      {msg.user.name}
                    </span>
                    {msg.user.verified && (
                      <div className="w-3 h-3 bg-blue-500 rounded-full flex items-center justify-center">
                        <span className="text-white text-xs">✓</span>
                      </div>
                    )}
                    <span className="text-xs text-gray-500">
                      {formatTime(msg.timestamp)}
                    </span>
                  </div>
                  <p className="text-sm text-white break-words">
                    {msg.type === 'emoji' ? (
                      <span className="text-2xl">{msg.emoji}</span>
                    ) : (
                      msg.message
                    )}
                  </p>
                </div>
              </div>
            )}
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>

      {/* Quick Emojis */}
      <div className="px-4 py-2 border-t border-gray-700">
        <div className="flex gap-2 overflow-x-auto">
          {quickEmojis.map((emoji) => (
            <button
              key={emoji}
              onClick={() => handleEmojiClick(emoji)}
              className="text-lg hover:scale-110 transition-transform flex-shrink-0 p-1 rounded hover:bg-gray-700"
            >
              {emoji}
            </button>
          ))}
        </div>
      </div>

      {/* Message Input */}
      <div className="p-4 border-t border-gray-700">
        <form onSubmit={handleSendMessage} className="flex gap-2">
          <input
            type="text"
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            placeholder={user ? "Type a message..." : "Sign in to chat"}
            disabled={!user}
            className="flex-1 bg-gray-700 text-white px-3 py-2 rounded-lg border border-gray-600 focus:border-yellow-400 focus:outline-none transition-colors disabled:opacity-50"
            maxLength={200}
          />
          <button
            type="submit"
            disabled={!user || !newMessage.trim()}
            className="bg-yellow-400 text-gray-900 p-2 rounded-lg hover:bg-yellow-300 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Send size={20} />
          </button>
        </form>
        
        {!user && (
          <p className="text-xs text-gray-500 mt-2 text-center">
            <button 
              onClick={onAuthRequired}
              className="text-yellow-400 hover:text-yellow-300 transition-colors"
            >
              Sign in
            </button>
            {' '}to join the conversation
          </p>
        )}
      </div>
    </div>
  );
}