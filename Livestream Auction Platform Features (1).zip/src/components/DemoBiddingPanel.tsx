import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { 
  Gavel, 
  Clock, 
  DollarSign, 
  TrendingUp, 
  Plus, 
  Timer, 
  CreditCard, 
  Trophy,
  Users,
  Zap,
  Target,
  Shield,
  AlertCircle,
  CheckCircle,
  Bot,
  Play,
  Pause
} from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Switch } from './ui/switch';
import { Progress } from './ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { toast } from 'sonner@2.0.3';

interface User {
  id: string;
  email: string;
  name: string;
  avatar?: string;
}

interface AuctionItem {
  id: string;
  title: string;
  description: string;
  startingBid: number;
  currentBid: number;
  bidCount: number;
  timeLeft: number;
  endTime: string;
  image: string;
  isActive: boolean;
  reservePrice?: number;
  buyItNowPrice?: number;
  autoExtend: boolean;
  incrementType: 'fixed' | 'percentage';
  minimumIncrement: number;
  highestBidder?: string;
  sellerId: string;
  sellerName: string;
}

interface Bid {
  id: string;
  userId: string;
  userName: string;
  amount: number;
  maxAmount?: number;
  isProxyBid: boolean;
  timestamp: string;
  status: 'active' | 'outbid' | 'winning';
}

interface DemoBiddingPanelProps {
  currentItem?: AuctionItem;
  upcomingItems: AuctionItem[];
  user: User | null;
  onBid: (amount: number) => void;
  onAuthRequired: () => void;
  demoMode?: boolean; // New prop to enable demo mode
  hostUserId?: string; // Add host user ID to check if user is the host
}

export function DemoBiddingPanel({ 
  currentItem, 
  upcomingItems, 
  user, 
  onBid, 
  onAuthRequired,
  demoMode = true, // Default to demo mode for safety
  hostUserId // Add host user ID to check if user is the host
}: DemoBiddingPanelProps) {
  const [customBid, setCustomBid] = useState<string>('');
  const [maxBid, setMaxBid] = useState<string>('');
  const [bidHistory, setBidHistory] = useState<Bid[]>([]);
  const [showPayment, setShowPayment] = useState(false);
  const [isWinning, setIsWinning] = useState(false);
  const [auctionEnded, setAuctionEnded] = useState(false);
  const [myHighestBid, setMyHighestBid] = useState<number | null>(null);
  const [autoBidEnabled, setAutoBidEnabled] = useState(false);
  const [autoBidActive, setAutoBidActive] = useState(false);
  const [timeLeftSeconds, setTimeLeftSeconds] = useState(0);
  const [activeBidders, setActiveBidders] = useState(0);
  const [reserveMet, setReserveMet] = useState(false);
  const [isPlacingBid, setIsPlacingBid] = useState(false);

  // Check if current user is the host/seller
  const isUserHost = user && hostUserId && user.id === hostUserId;

  // Initialize demo bid history
  useEffect(() => {
    if (demoMode && currentItem) {
      setBidHistory([
        {
          id: '1',
          userId: 'user1',
          userName: 'CoralFan123',
          amount: currentItem.currentBid,
          isProxyBid: false,
          timestamp: new Date().toISOString(),
          status: 'winning'
        },
        {
          id: '2',
          userId: 'user2',
          userName: 'ReefExplorer',
          amount: currentItem.currentBid - 5,
          isProxyBid: false,
          timestamp: new Date(Date.now() - 300000).toISOString(),
          status: 'outbid'
        },
        {
          id: '3',
          userId: 'user3',
          userName: 'AquariumPro',
          amount: currentItem.currentBid - 10,
          isProxyBid: true,
          timestamp: new Date(Date.now() - 600000).toISOString(),
          status: 'outbid'
        }
      ]);
      setActiveBidders(3);
    }
  }, [demoMode, currentItem]);

  // Memoize quick bid amounts to prevent recalculation on every render
  const quickBidAmounts = useMemo(() => {
    if (!currentItem) return [5, 10, 25, 50];
    
    const current = currentItem.currentBid;
    const increment = currentItem.minimumIncrement;
    
    if (current < 50) {
      return [increment, increment * 2, increment * 3, increment * 5];
    } else if (current < 200) {
      return [10, 20, 50, 100];
    } else {
      return [25, 50, 100, 250];
    }
  }, [currentItem?.currentBid, currentItem?.minimumIncrement]);

  // Memoize minimum bid calculation
  const minBid = useMemo(() => {
    if (!currentItem) return 0;
    
    if (currentItem.incrementType === 'percentage') {
      return currentItem.currentBid * (1 + currentItem.minimumIncrement / 100);
    } else {
      return currentItem.currentBid + currentItem.minimumIncrement;
    }
  }, [currentItem?.currentBid, currentItem?.incrementType, currentItem?.minimumIncrement]);

  // Demo-safe place bid function
  const placeBid = useCallback(async (amount: number, isProxyBid: boolean = false) => {
    if (isPlacingBid || !currentItem?.id) return;

    console.log('🎯 Demo bid placement:', { auctionId: currentItem.id, amount, user: user?.id });
    
    if (!user) {
      toast.error('Please sign in to place bids');
      onAuthRequired();
      return;
    }

    try {
      setIsPlacingBid(true);
      
      if (demoMode) {
        // Demo mode - simulate successful bid placement
        console.log('🎭 Demo mode bid simulation');
        
        // Simulate a delay
        await new Promise(resolve => setTimeout(resolve, 500));
        
        // Create new bid entry
        const newBid: Bid = {
          id: Date.now().toString(),
          userId: user.id,
          userName: user.name,
          amount,
          maxAmount: isProxyBid ? parseFloat(maxBid) : undefined,
          isProxyBid,
          timestamp: new Date().toISOString(),
          status: 'winning'
        };
        
        // Update bid history
        setBidHistory(prev => {
          const updated = prev.map(bid => ({ ...bid, status: 'outbid' as const }));
          return [newBid, ...updated];
        });
        
        setActiveBidders(prev => prev + 1);
        
        // Success message
        const successMessage = isProxyBid ? '🤖 Auto-bid placed successfully!' : `✅ Bid placed: $${amount}`;
        toast.success(successMessage);
        
        // Update parent component
        onBid(amount);
        
      } else {
        // Real mode - would make actual API calls here
        // This is kept as a fallback but should not be reached in demo environment
        toast.error('Real bidding not available in demo environment');
      }
      
    } catch (error) {
      console.error('💥 Demo bid placement error:', error);
      toast.error('Demo bid failed - this is unusual!');
    } finally {
      setIsPlacingBid(false);
    }
  }, [currentItem?.id, maxBid, isPlacingBid, onBid, onAuthRequired, user, demoMode]);

  // Stable handler functions
  const handleQuickBid = useCallback(async (amount: number) => {
    if (!user) {
      onAuthRequired();
      return;
    }

    if (!currentItem || auctionEnded) return;

    const newBidAmount = currentItem.currentBid + amount;
    await placeBid(newBidAmount, false);
  }, [user, currentItem, auctionEnded, placeBid, onAuthRequired]);

  const handleCustomBid = useCallback(async () => {
    if (!user) {
      onAuthRequired();
      return;
    }

    const bidAmount = parseFloat(customBid);
    if (!bidAmount || !currentItem || bidAmount <= currentItem.currentBid || auctionEnded) {
      return;
    }

    await placeBid(bidAmount, false);
    setCustomBid('');
  }, [user, customBid, currentItem, auctionEnded, placeBid, onAuthRequired]);

  const handleBuyItNow = useCallback(async () => {
    if (!user || !currentItem?.buyItNowPrice) return;
    
    await placeBid(currentItem.buyItNowPrice, false);
    setAuctionEnded(true);
    toast.success('🎯 You bought this item instantly!');
  }, [user, currentItem?.buyItNowPrice, placeBid]);

  const setupAutoBid = useCallback(async () => {
    if (!user || !currentItem) return;

    const maxAmount = parseFloat(maxBid);
    if (!maxAmount || maxAmount <= currentItem.currentBid) {
      toast.error('Max bid must be higher than current bid');
      return;
    }

    // Demo mode auto-bid setup
    setAutoBidEnabled(true);
    setAutoBidActive(true);
    toast.success(`🤖 Auto-bidding enabled up to $${maxAmount} (Demo)`);
  }, [user, currentItem, maxBid]);

  // Timer and initial setup effect
  useEffect(() => {
    if (!currentItem) return;

    setTimeLeftSeconds(currentItem.timeLeft);
    setReserveMet(!currentItem.reservePrice || currentItem.currentBid >= currentItem.reservePrice);
    
    // Set up timer
    const timer = setInterval(() => {
      setTimeLeftSeconds(prev => {
        if (prev <= 0) {
          setAuctionEnded(true);
          clearInterval(timer);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [currentItem?.id, currentItem?.timeLeft, currentItem?.currentBid, currentItem?.reservePrice]);

  // User winning status effect
  useEffect(() => {
    if (!user?.id || bidHistory.length === 0) {
      setMyHighestBid(null);
      setIsWinning(false);
      return;
    }

    const userBids = bidHistory.filter(bid => bid.userId === user.id);
    const userHighest = userBids.length > 0 ? Math.max(...userBids.map(bid => bid.amount)) : 0;
    
    const newHighestBid = userHighest > 0 ? userHighest : null;
    const newIsWinning = currentItem?.highestBidder === user.name || (userBids.length > 0 && userBids[0].status === 'winning');
    
    setMyHighestBid(newHighestBid);
    setIsWinning(newIsWinning);
  }, [user?.id, user?.name, bidHistory, currentItem?.highestBidder]);

  // Memoized time formatting function
  const formatTime = useCallback((seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  }, []);

  // Memoized time percentage calculation
  const timeLeftPercentage = useMemo(() => {
    if (!currentItem) return 100;
    const totalTime = new Date(currentItem.endTime).getTime() - new Date().getTime() + timeLeftSeconds * 1000;
    const elapsed = totalTime - timeLeftSeconds * 1000;
    return Math.max(0, ((totalTime - elapsed) / totalTime) * 100);
  }, [currentItem?.endTime, timeLeftSeconds]);
  
  if (!currentItem) {
    return (
      <div className="flex flex-col h-full p-4">
        <div className="text-center py-8">
          <Gavel className="mx-auto text-gray-400 mb-4" size={48} />
          <h3 className="text-lg font-medium text-gray-300 mb-2">No Active Auction</h3>
          <p className="text-gray-500">Check back soon for the next item</p>
        </div>
        
        {/* Upcoming Items */}
        {upcomingItems.length > 0 && (
          <div className="flex-1">
            <h4 className="font-medium text-white mb-3">Coming Up Next</h4>
            <div className="space-y-3">
              {upcomingItems.slice(0, 3).map((item, index) => (
                <div key={item.id} className="bg-gray-700 rounded-lg p-3">
                  <div className="flex items-center gap-3">
                    <ImageWithFallback 
                      src={item.image}
                      alt={item.title}
                      className="w-12 h-12 object-cover rounded"
                    />
                    <div className="flex-1">
                      <h5 className="text-sm font-medium text-white">{item.title}</h5>
                      <p className="text-xs text-gray-400">Starting at ${item.startingBid}</p>
                    </div>
                    <span className="text-xs text-gray-500">#{index + 1}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      {/* Demo Mode Indicator */}
      {demoMode && (
        <div className="p-2 bg-yellow-500/20 border-b border-yellow-500/30">
          <p className="text-xs text-yellow-300 text-center">
            📱 Demo Bidding Mode - No real money involved
          </p>
        </div>
      )}

      {/* Current Item Header */}
      <div className="p-4 border-b border-gray-700">
        <div className="relative mb-4">
          <ImageWithFallback 
            src={currentItem.image}
            alt={currentItem.title}
            className="w-full h-32 object-cover rounded-lg"
          />
          
          {/* Time and Status Overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent rounded-lg" />
          <div className="absolute bottom-2 left-2 right-2">
            <div className="flex items-center justify-between text-white text-sm">
              <div className="flex items-center gap-2">
                <Timer size={12} />
                <span className={timeLeftSeconds <= 60 ? 'animate-pulse text-red-400' : ''}>
                  {formatTime(timeLeftSeconds)}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <Users size={12} />
                <span>{activeBidders} bidders</span>
              </div>
            </div>
            
            {/* Time Progress Bar */}
            <Progress 
              value={timeLeftPercentage} 
              className="h-1 mt-1"
            />
          </div>
        </div>
        
        <h3 className="font-medium text-white mb-1">{currentItem.title}</h3>
        <p className="text-sm text-gray-400 mb-3 line-clamp-2">{currentItem.description}</p>
        
        {/* Current Status */}
        <div className="grid grid-cols-2 gap-4 mb-4">
          <div className="bg-gray-700 rounded-lg p-3 text-center">
            <p className="text-xs text-gray-400 mb-1">Current Bid</p>
            <p className="text-lg font-bold text-green-400">${currentItem.currentBid}</p>
          </div>
          <div className="bg-gray-700 rounded-lg p-3 text-center">
            <p className="text-xs text-gray-400 mb-1">Total Bids</p>
            <p className="text-lg font-bold text-blue-400">{currentItem.bidCount}</p>
          </div>
        </div>

        {/* Reserve & Buy It Now */}
        <div className="flex items-center gap-2 mb-4">
          {currentItem.reservePrice && (
            <Badge variant={reserveMet ? "default" : "secondary"} className="flex items-center gap-1">
              <Shield className="w-3 h-3" />
              Reserve {reserveMet ? 'Met' : `$${currentItem.reservePrice}`}
            </Badge>
          )}
          
          {currentItem.buyItNowPrice && (
            <Badge variant="outline" className="flex items-center gap-1 border-yellow-500 text-yellow-400">
              <Zap className="w-3 h-3" />
              Buy Now: ${currentItem.buyItNowPrice}
            </Badge>
          )}
        </div>

        {/* Winning Status */}
        {user && myHighestBid && (
          <div className={`mb-4 p-3 rounded-lg border ${
            isWinning 
              ? 'bg-green-500/20 border-green-500 text-green-400' 
              : 'bg-yellow-500/20 border-yellow-500 text-yellow-400'
          }`}>
            <div className="flex items-center gap-2 mb-1">
              {isWinning ? <Trophy className="w-4 h-4" /> : <TrendingUp className="w-4 h-4" />}
              <span className="text-sm font-medium">
                {isWinning ? 'You\'re winning!' : 'You\'ve been outbid'}
              </span>
            </div>
            <p className="text-xs opacity-90">
              Your highest bid: ${myHighestBid}
            </p>
          </div>
        )}
      </div>

      {/* Bidding Interface */}
      {!auctionEnded && (
        <div className="p-4 border-b border-gray-700">
          {/* Show host restriction message if user is the host */}
          {isUserHost ? (
            <div className="bg-orange-500/20 border border-orange-500 rounded-lg p-4 text-center">
              <div className="flex items-center justify-center gap-2 mb-2">
                <AlertCircle className="w-5 h-5 text-orange-400" />
                <span className="font-medium text-orange-400">Host Bidding Disabled</span>
              </div>
              <p className="text-sm text-orange-300 mb-2">
                You cannot bid on your own auction items
              </p>
              <p className="text-xs text-orange-400">
                This ensures fair and transparent auctions for all buyers
              </p>
            </div>
          ) : (
            /* Regular bidding interface for non-hosts */
            <Tabs defaultValue="quick" className="w-full">
              <TabsList className="grid w-full grid-cols-3 bg-gray-700">
                <TabsTrigger value="quick">Quick Bid</TabsTrigger>
                <TabsTrigger value="custom">Custom</TabsTrigger>
                <TabsTrigger value="auto">Auto-Bid</TabsTrigger>
              </TabsList>
              
              <TabsContent value="quick" className="space-y-3 mt-4">
                <h4 className="font-medium text-white">Quick Bid</h4>
                <div className="grid grid-cols-2 gap-2">
                  {quickBidAmounts.map((amount) => (
                    <Button
                      key={amount}
                      onClick={() => handleQuickBid(amount)}
                      disabled={!user || isPlacingBid}
                      className="bg-yellow-400 text-gray-900 hover:bg-yellow-300 transition-colors disabled:opacity-50"
                    >
                      <Plus size={14} className="mr-1" />
                      ${amount}
                    </Button>
                  ))}
                </div>
                
                {currentItem.buyItNowPrice && (
                  <Button
                    onClick={handleBuyItNow}
                    disabled={!user || isPlacingBid}
                    className="w-full bg-orange-500 hover:bg-orange-600 text-white"
                  >
                    <Zap className="w-4 h-4 mr-2" />
                    Buy It Now - ${currentItem.buyItNowPrice}
                  </Button>
                )}
              </TabsContent>
              
              <TabsContent value="custom" className="space-y-3 mt-4">
                <h4 className="font-medium text-white">Custom Bid</h4>
                <div className="flex gap-2">
                  <div className="flex-1 relative">
                    <DollarSign className="absolute left-2 top-2 text-gray-400" size={16} />
                    <Input
                      type="number"
                      value={customBid}
                      onChange={(e) => setCustomBid(e.target.value)}
                      placeholder={`Min: ${minBid.toFixed(2)}`}
                      min={minBid}
                      step="0.01"
                      disabled={!user || isPlacingBid}
                      className="w-full bg-gray-700 text-white pl-8 pr-3 py-2 border-gray-600"
                    />
                  </div>
                  <Button
                    onClick={handleCustomBid}
                    disabled={!user || !customBid || parseFloat(customBid) < minBid || isPlacingBid}
                    className="bg-green-500 text-white hover:bg-green-400"
                  >
                    {isPlacingBid ? 'Bidding...' : 'Bid'}
                  </Button>
                </div>
              </TabsContent>
              
              <TabsContent value="auto" className="space-y-3 mt-4">
                <div className="flex items-center justify-between">
                  <h4 className="font-medium text-white">Auto-Bidding</h4>
                  {autoBidActive && (
                    <Badge className="bg-blue-500 text-white flex items-center gap-1">
                      <Bot className="w-3 h-3" />
                      Active
                    </Badge>
                  )}
                </div>
                
                {!autoBidEnabled ? (
                  <>
                    <div className="relative">
                      <DollarSign className="absolute left-2 top-2 text-gray-400" size={16} />
                      <Input
                        type="number"
                        value={maxBid}
                        onChange={(e) => setMaxBid(e.target.value)}
                        placeholder="Maximum bid amount"
                        min={minBid}
                        step="0.01"
                        disabled={!user}
                        className="w-full bg-gray-700 text-white pl-8 pr-3 py-2 border-gray-600"
                      />
                    </div>
                    <Button
                      onClick={setupAutoBid}
                      disabled={!user || !maxBid || parseFloat(maxBid) < minBid}
                      className="w-full bg-blue-500 hover:bg-blue-600 text-white"
                    >
                      <Bot className="w-4 h-4 mr-2" />
                      Enable Auto-Bidding
                    </Button>
                  </>
                ) : (
                  <div className="bg-blue-500/20 border border-blue-500 rounded-lg p-3">
                    <div className="flex items-center gap-2 mb-2">
                      <Bot className="w-4 h-4 text-blue-400" />
                      <span className="text-sm font-medium text-blue-400">Auto-bidding enabled</span>
                    </div>
                    <p className="text-xs text-blue-300">
                      Will automatically bid up to ${maxBid} to keep you winning
                    </p>
                    <div className="flex items-center justify-between mt-2">
                      <span className="text-xs text-blue-300">Active</span>
                      <Switch
                        checked={autoBidActive}
                        onCheckedChange={setAutoBidActive}
                      />
                    </div>
                  </div>
                )}
              </TabsContent>
            </Tabs>
          )}
          
          {!user && !isUserHost && (
            <p className="text-xs text-gray-500 mt-3 text-center">
              <button 
                onClick={onAuthRequired}
                className="text-yellow-400 hover:text-yellow-300 transition-colors"
              >
                Sign in
              </button>
              {' '}to place bids
            </p>
          )}
        </div>
      )}

      {/* Bid History */}
      <div className="flex-1 p-4">
        <h4 className="font-medium text-white mb-3">Recent Bids</h4>
        <div className="space-y-2 max-h-48 overflow-y-auto">
          {bidHistory.length === 0 ? (
            <p className="text-gray-500 text-sm text-center py-4">No bids yet</p>
          ) : (
            bidHistory.slice(0, 10).map((bid, index) => (
              <div key={bid.id} className="flex items-center justify-between bg-gray-700 rounded-lg p-2">
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 bg-gray-600 rounded-full flex items-center justify-center">
                    <span className="text-xs text-white">{bid.userName[0]}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <span className="text-sm text-white">{bid.userName}</span>
                    {bid.isProxyBid && <Bot className="w-3 h-3 text-blue-400" />}
                    {bid.status === 'winning' && <Trophy className="w-3 h-3 text-green-400" />}
                  </div>
                </div>
                <div className="text-right">
                  <div className={`text-sm font-medium ${
                    bid.status === 'winning' ? 'text-green-400' : 
                    bid.status === 'outbid' ? 'text-gray-400' : 'text-yellow-400'
                  }`}>
                    ${bid.amount}
                  </div>
                  <div className="text-xs text-gray-400">
                    {new Date(bid.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Upcoming Items Preview */}
      {upcomingItems.length > 0 && (
        <div className="p-4 border-t border-gray-700">
          <h4 className="font-medium text-white mb-3">Next Up</h4>
          <div className="flex gap-2 overflow-x-auto">
            {upcomingItems.slice(0, 3).map((item, index) => (
              <div key={item.id} className="flex-shrink-0 bg-gray-700 rounded-lg p-2" style={{ minWidth: '120px' }}>
                <ImageWithFallback 
                  src={item.image}
                  alt={item.title}
                  className="w-full h-16 object-cover rounded mb-2"
                />
                <h5 className="text-xs font-medium text-white mb-1 line-clamp-2">{item.title}</h5>
                <p className="text-xs text-gray-400">Start: ${item.startingBid}</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}