import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { CheckCircle, AlertCircle, Loader2 } from 'lucide-react';
import { projectId, publicAnonKey } from '../utils/supabase/info';
import { QuickSystemCheck } from './QuickSystemCheck';

interface SetupStep {
  id: string;
  title: string;
  description: string;
  endpoint: string;
  method: 'GET' | 'POST';
  status: 'pending' | 'running' | 'success' | 'error';
  result?: any;
  error?: string;
}

interface ProductionSetupProps {
  user?: { id: string; email: string; name: string } | null;
}

export function ProductionSetup({ user }: ProductionSetupProps) {
  const [steps, setSteps] = useState<SetupStep[]>([
    {
      id: 'init-database',
      title: 'Initialize Database Schema',
      description: 'Create production tables and indexes',
      endpoint: '/init-database',
      method: 'POST',
      status: 'pending'
    },
    {
      id: 'seed-data',
      title: 'Seed Production Data',
      description: 'Add demo users and initial data',
      endpoint: '/seed-production-data',
      method: 'POST',
      status: 'pending'
    },
    {
      id: 'health-check',
      title: 'System Health Check',
      description: 'Verify all systems are operational',
      endpoint: '/system-health',
      method: 'GET',
      status: 'pending'
    },
    {
      id: 'load-test',
      title: 'Load Test (100 Users)',
      description: 'Test performance with 100 concurrent users',
      endpoint: '/load-test',
      method: 'POST',
      status: 'pending'
    },
    {
      id: 'stress-test',
      title: 'Stress Test (500 Users)',
      description: 'Test system limits with high load',
      endpoint: '/stress-test',
      method: 'POST',
      status: 'pending'
    },
    {
      id: 'performance-metrics',
      title: 'Performance Metrics',
      description: 'Get detailed system performance data',
      endpoint: '/performance-metrics',
      method: 'GET',
      status: 'pending'
    },
    {
      id: 'monitoring-test',
      title: 'Monitoring System Test',
      description: 'Test real-time monitoring and alerting',
      endpoint: '/monitoring/health-detailed',
      method: 'GET',
      status: 'pending'
    }
  ]);

  const updateStep = (id: string, updates: Partial<SetupStep>) => {
    setSteps(prev => prev.map(step => 
      step.id === id ? { ...step, ...updates } : step
    ));
  };

  const runStep = async (step: SetupStep) => {
    updateStep(step.id, { status: 'running' });

    try {
      // Prepare request body for POST requests
      let body = undefined;
      if (step.method === 'POST' && step.id === 'load-test') {
        body = JSON.stringify({
          users: 100,
          duration: 60,
          scenarios: ['browse', 'bid', 'chat']
        });
      } else if (step.method === 'POST' && step.id === 'stress-test') {
        body = JSON.stringify({
          users: 500,
          duration: 120,
          scenarios: ['browse', 'bid', 'chat', 'live_stream']
        });
      }

      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-9f7745d8${step.endpoint}`,
        {
          method: step.method,
          headers: {
            'Authorization': `Bearer ${publicAnonKey}`,
            'Content-Type': 'application/json'
          },
          ...(body && { body })
        }
      );

      const data = await response.json();

      if (response.ok) {
        updateStep(step.id, { 
          status: 'success', 
          result: data 
        });
      } else {
        updateStep(step.id, { 
          status: 'error', 
          error: data.error || 'Unknown error' 
        });
      }
    } catch (error) {
      updateStep(step.id, { 
        status: 'error', 
        error: error instanceof Error ? error.message : 'Network error' 
      });
    }
  };

  const runAllSteps = async () => {
    for (const step of steps) {
      await runStep(step);
      // Small delay between steps
      await new Promise(resolve => setTimeout(resolve, 1000));
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'running':
        return <Loader2 className="h-5 w-5 animate-spin text-blue-500" />;
      case 'success':
        return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'error':
        return <AlertCircle className="h-5 w-5 text-red-500" />;
      default:
        return <div className="h-5 w-5 rounded-full border-2 border-gray-300" />;
    }
  };

  const allCompleted = steps.every(step => step.status === 'success');
  const anyRunning = steps.some(step => step.status === 'running');

  return (
    <div className="min-h-screen bg-gray-900 text-white p-6">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-cyan-400 mb-2">
            🚀 Coral Crave Production Setup
          </h1>
          <p className="text-gray-300">
            Initialize your production database and verify system readiness for 1000+ users
          </p>
        </div>

        {/* Quick System Check */}
        <div className="mb-6">
          <QuickSystemCheck 
            user={user}
            onNavigateToFullTest={() => {
              // Navigate to system testing - you can implement this
              console.log('Navigate to full system testing');
            }} 
          />
        </div>

        {/* Progress Overview */}
        <Card className="bg-gray-800 border-gray-700 mb-6">
          <CardHeader>
            <CardTitle className="text-white">Setup Progress</CardTitle>
            <CardDescription>
              Complete these steps to prepare for production launch
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <Button
                  onClick={runAllSteps}
                  disabled={anyRunning}
                  className="bg-cyan-600 hover:bg-cyan-700"
                >
                  {anyRunning ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Running Setup...
                    </>
                  ) : (
                    '▶️ Run All Steps'
                  )}
                </Button>
              </div>
              
              {allCompleted && (
                <div className="flex items-center text-green-400">
                  <CheckCircle className="mr-2 h-5 w-5" />
                  Ready for Production! 🎉
                </div>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Setup Steps */}
        <div className="space-y-4">
          {steps.map((step, index) => (
            <Card key={step.id} className="bg-gray-800 border-gray-700">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="flex items-center justify-center w-8 h-8 rounded-full bg-gray-700 text-white text-sm">
                      {index + 1}
                    </div>
                    <div>
                      <CardTitle className="text-white text-lg">{step.title}</CardTitle>
                      <CardDescription>{step.description}</CardDescription>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-3">
                    {getStatusIcon(step.status)}
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => runStep(step)}
                      disabled={step.status === 'running'}
                      className="border-gray-600 text-gray-300 hover:bg-gray-700"
                    >
                      {step.status === 'running' ? 'Running...' : 'Run Step'}
                    </Button>
                  </div>
                </div>
              </CardHeader>
              
              {(step.result || step.error) && (
                <CardContent>
                  <div className="bg-gray-900 rounded-lg p-4">
                    <div className="text-sm">
                      <div className="text-gray-400 mb-1">
                        {step.method} {step.endpoint}
                      </div>
                      
                      {step.result && (
                        <div>
                          <div className="text-green-400 mb-2">✅ Success:</div>
                          <pre className="text-gray-300 text-xs overflow-x-auto">
                            {JSON.stringify(step.result, null, 2)}
                          </pre>
                        </div>
                      )}
                      
                      {step.error && (
                        <div>
                          <div className="text-red-400 mb-2">❌ Error:</div>
                          <div className="text-red-300 text-xs">{step.error}</div>
                        </div>
                      )}
                    </div>
                  </div>
                </CardContent>
              )}
            </Card>
          ))}
        </div>

        {/* Next Steps */}
        {allCompleted && (
          <Card className="bg-green-900/20 border-green-700 mt-8">
            <CardHeader>
              <CardTitle className="text-green-400">🎯 Next Steps</CardTitle>
            </CardHeader>
            <CardContent className="text-gray-300">
              <div className="space-y-2">
                <p>✅ Database schema initialized successfully</p>
                <p>✅ Production data seeded</p>
                <p>✅ System health verified</p>
                <div className="mt-4 p-4 bg-cyan-900/20 rounded-lg border border-cyan-700">
                  <h4 className="font-semibold text-cyan-400 mb-2">Ready for Step 2: Load Testing</h4>
                  <p className="text-sm">Your system is now ready for load testing with multiple concurrent users.</p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Configuration Info */}
        <Card className="bg-gray-800 border-gray-700 mt-6">
          <CardHeader>
            <CardTitle className="text-white">Configuration Info</CardTitle>
          </CardHeader>
          <CardContent className="text-gray-300 text-sm">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <span className="text-gray-400">Project ID:</span>
                <div className="font-mono bg-gray-900 rounded px-2 py-1 mt-1">{projectId}</div>
              </div>
              <div>
                <span className="text-gray-400">Supabase URL:</span>
                <div className="font-mono bg-gray-900 rounded px-2 py-1 mt-1 text-xs">
                  https://{projectId}.supabase.co
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}