import { Hono } from 'npm:hono';
import { cors } from 'npm:hono/cors';
import { createClient } from 'npm:@supabase/supabase-js@2';
import * as kv from './kv_store.tsx';

const app = new Hono();

app.use('*', cors({
  origin: '*',
  allowMethods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowHeaders: ['Content-Type', 'Authorization'],
}));

const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
);

// Advanced search with filters
app.post('/make-server-9f7745d8/search', async (c) => {
  try {
    const { query, filters, page = 1, limit = 20, sortBy = 'relevance' } = await c.req.json();
    
    console.log('Search request:', { query, filters, page, limit, sortBy });

    // Get all auction items from KV store
    const auctionItems = await kv.getByPrefix('auction_item_');
    
    let results = auctionItems.map(item => item.value).filter(item => item && typeof item === 'object');

    // Apply search query filter
    if (query) {
      const searchTerm = query.toLowerCase();
      results = results.filter(item =>
        item.title?.toLowerCase().includes(searchTerm) ||
        item.description?.toLowerCase().includes(searchTerm) ||
        item.category?.toLowerCase().includes(searchTerm) ||
        item.tags?.some((tag: string) => tag.toLowerCase().includes(searchTerm))
      );
    }

    // Apply filters
    if (filters) {
      if (filters.category && filters.category !== 'All Categories') {
        results = results.filter(item => item.category === filters.category);
      }
      
      if (filters.priceRange && filters.priceRange.length === 2) {
        results = results.filter(item => 
          item.currentBid >= filters.priceRange[0] && 
          item.currentBid <= filters.priceRange[1]
        );
      }
      
      if (filters.location && filters.location !== 'All Locations') {
        results = results.filter(item => 
          item.seller?.location?.includes(filters.location) ||
          (filters.location === 'Local Only' && item.seller?.localDelivery)
        );
      }
      
      if (filters.sellerRating && filters.sellerRating > 0) {
        results = results.filter(item => 
          item.seller?.rating >= filters.sellerRating
        );
      }
      
      if (filters.showLiveOnly) {
        results = results.filter(item => item.status === 'live');
      }
      
      if (!filters.showScheduled) {
        results = results.filter(item => item.status !== 'scheduled');
      }
    }

    // Apply sorting
    switch (sortBy) {
      case 'price-low':
        results.sort((a, b) => (a.currentBid || 0) - (b.currentBid || 0));
        break;
      case 'price-high':
        results.sort((a, b) => (b.currentBid || 0) - (a.currentBid || 0));
        break;
      case 'ending-soon':
        results.sort((a, b) => new Date(a.endTime || 0).getTime() - new Date(b.endTime || 0).getTime());
        break;
      case 'newest':
        results.sort((a, b) => new Date(b.createdAt || 0).getTime() - new Date(a.createdAt || 0).getTime());
        break;
      case 'popular':
        results.sort((a, b) => (b.views || 0) - (a.views || 0));
        break;
      case 'rating':
        results.sort((a, b) => (b.seller?.rating || 0) - (a.seller?.rating || 0));
        break;
      default: // relevance
        // Keep current order for relevance
        break;
    }

    // Paginate results
    const startIndex = (page - 1) * limit;
    const paginatedResults = results.slice(startIndex, startIndex + limit);

    return c.json({
      results: paginatedResults,
      totalCount: results.length,
      page,
      limit,
      totalPages: Math.ceil(results.length / limit)
    });

  } catch (error) {
    console.error('Search error:', error);
    return c.json({ error: 'Search failed' }, 500);
  }
});

// Get personalized recommendations
app.get('/make-server-9f7745d8/recommendations/:userId', async (c) => {
  try {
    const userId = c.req.param('userId');
    console.log('Getting recommendations for user:', userId);

    // Get user's purchase/view history
    const userHistory = await kv.get(`user_history_${userId}`);
    const userPreferences = await kv.get(`user_preferences_${userId}`);
    const followedSellers = await kv.get(`user_following_${userId}`);

    // Get all auction items
    const auctionItems = await kv.getByPrefix('auction_item_');
    const allItems = auctionItems.map(item => item.value).filter(item => item && typeof item === 'object');

    // Generate recommendations based on different algorithms
    const recommendations = {
      collaborative: generateCollaborativeRecommendations(userId, userHistory?.value, allItems),
      trending: generateTrendingRecommendations(allItems),
      following: generateFollowingRecommendations(followedSellers?.value, allItems),
      priceDrops: generatePriceDropRecommendations(userId, userHistory?.value, allItems)
    };

    return c.json(recommendations);

  } catch (error) {
    console.error('Recommendations error:', error);
    return c.json({ error: 'Failed to get recommendations' }, 500);
  }
});

// Update user preferences based on interactions
app.post('/make-server-9f7745d8/user-interaction', async (c) => {
  try {
    const { userId, itemId, action, category, seller } = await c.req.json();
    
    console.log('User interaction:', { userId, itemId, action, category, seller });

    // Get current user history
    const userHistory = await kv.get(`user_history_${userId}`);
    const history = userHistory?.value || { views: [], purchases: [], searches: [], categories: {} };

    // Update history based on action
    switch (action) {
      case 'view':
        history.views = [...(history.views || []), { itemId, timestamp: new Date().toISOString(), category }];
        // Keep only last 100 views
        if (history.views.length > 100) {
          history.views = history.views.slice(-100);
        }
        break;
      
      case 'purchase':
        history.purchases = [...(history.purchases || []), { itemId, timestamp: new Date().toISOString(), category, seller }];
        break;
      
      case 'search':
        history.searches = [...(history.searches || []), { query: itemId, timestamp: new Date().toISOString() }];
        // Keep only last 50 searches
        if (history.searches.length > 50) {
          history.searches = history.searches.slice(-50);
        }
        break;
    }

    // Update category preferences
    if (category) {
      history.categories = history.categories || {};
      history.categories[category] = (history.categories[category] || 0) + 1;
    }

    // Save updated history
    await kv.set(`user_history_${userId}`, history);

    return c.json({ success: true });

  } catch (error) {
    console.error('User interaction error:', error);
    return c.json({ error: 'Failed to record interaction' }, 500);
  }
});

// Helper functions for recommendation algorithms
function generateCollaborativeRecommendations(userId: string, userHistory: any, allItems: any[]) {
  if (!userHistory || !userHistory.purchases) {
    return [];
  }

  // Find items in similar categories to user's purchase history
  const userCategories = userHistory.purchases.map((p: any) => p.category);
  const categoryPreferences = userHistory.categories || {};
  
  return allItems
    .filter(item => 
      userCategories.includes(item.category) && 
      item.status === 'live' &&
      !userHistory.purchases.some((p: any) => p.itemId === item.id)
    )
    .sort((a, b) => (categoryPreferences[b.category] || 0) - (categoryPreferences[a.category] || 0))
    .slice(0, 5)
    .map(item => ({
      ...item,
      reason: `Similar to your previous ${item.category} purchases`,
      confidence: 0.85 + Math.random() * 0.1
    }));
}

function generateTrendingRecommendations(allItems: any[]) {
  return allItems
    .filter(item => item.status === 'live')
    .sort((a, b) => (b.views || 0) - (a.views || 0))
    .slice(0, 3)
    .map(item => ({
      ...item,
      reason: `Trending in ${item.category} this week`,
      confidence: 0.75 + Math.random() * 0.15
    }));
}

function generateFollowingRecommendations(followedSellers: any, allItems: any[]) {
  if (!followedSellers || !Array.isArray(followedSellers)) {
    return [];
  }

  return allItems
    .filter(item => 
      followedSellers.includes(item.seller?.id) && 
      item.status === 'live'
    )
    .slice(0, 3)
    .map(item => ({
      ...item,
      reason: `New listing from seller you follow`,
      confidence: 0.95
    }));
}

function generatePriceDropRecommendations(userId: string, userHistory: any, allItems: any[]) {
  // This would typically track price changes over time
  // For demo purposes, we'll simulate some price drops
  return allItems
    .filter(item => item.status === 'live')
    .slice(0, 2)
    .map(item => ({
      ...item,
      reason: `Price dropped $${Math.floor(Math.random() * 20 + 5)} since you watched`,
      confidence: 1.0
    }));
}

export default app;