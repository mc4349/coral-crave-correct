import { Hono } from 'npm:hono';
import { cors } from 'npm:hono/cors';
import { createClient } from 'npm:@supabase/supabase-js@2';

const app = new Hono();

app.use('*', cors({
  origin: '*',
  allowMethods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowHeaders: ['Content-Type', 'Authorization'],
}));

const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
);

// Performance metrics store
class PerformanceMonitor {
  private metrics = new Map<string, any[]>();
  private readonly maxMetrics = 1000; // Keep last 1000 entries per metric

  addMetric(type: string, data: any) {
    if (!this.metrics.has(type)) {
      this.metrics.set(type, []);
    }

    const typeMetrics = this.metrics.get(type)!;
    typeMetrics.push({
      ...data,
      timestamp: new Date().toISOString()
    });

    // Keep only recent metrics
    if (typeMetrics.length > this.maxMetrics) {
      typeMetrics.splice(0, typeMetrics.length - this.maxMetrics);
    }
  }

  getMetrics(type: string, limit = 100) {
    const metrics = this.metrics.get(type) || [];
    return metrics.slice(-limit);
  }

  getAverageResponseTime(minutes = 5) {
    const cutoff = new Date(Date.now() - minutes * 60 * 1000).toISOString();
    const responses = this.metrics.get('response_time') || [];
    
    const recentResponses = responses.filter(r => r.timestamp > cutoff);
    if (recentResponses.length === 0) return 0;

    const total = recentResponses.reduce((sum, r) => sum + r.duration, 0);
    return Math.round(total / recentResponses.length);
  }

  getErrorRate(minutes = 5) {
    const cutoff = new Date(Date.now() - minutes * 60 * 1000).toISOString();
    const responses = this.metrics.get('response_time') || [];
    
    const recentResponses = responses.filter(r => r.timestamp > cutoff);
    if (recentResponses.length === 0) return 0;

    const errors = recentResponses.filter(r => r.status >= 400);
    return Math.round((errors.length / recentResponses.length) * 100);
  }

  getStats() {
    return {
      averageResponseTime: this.getAverageResponseTime(),
      errorRate: this.getErrorRate(),
      totalRequests: (this.metrics.get('response_time') || []).length,
      activeStreams: (this.metrics.get('active_streams') || []).slice(-1)[0]?.count || 0,
      totalUsers: (this.metrics.get('total_users') || []).slice(-1)[0]?.count || 0
    };
  }
}

const monitor = new PerformanceMonitor();

// Middleware to track response times
app.use('*', async (c, next) => {
  const start = Date.now();
  const path = new URL(c.req.url).pathname;
  
  await next();
  
  const duration = Date.now() - start;
  
  monitor.addMetric('response_time', {
    path,
    method: c.req.method,
    status: c.res.status,
    duration
  });
});

// System health endpoint
app.get('/make-server-9f7745d8/system-health', async (c) => {
  try {
    const stats = monitor.getStats();
    
    // Check database health
    const dbStart = Date.now();
    const { data, error } = await supabase
      .from('coral_users')
      .select('count')
      .limit(1);
    const dbResponseTime = Date.now() - dbStart;

    // Check memory usage (if available)
    const memoryUsage = Deno.memoryUsage ? Deno.memoryUsage() : null;

    return c.json({
      status: 'healthy',
      timestamp: new Date().toISOString(),
      performance: {
        ...stats,
        databaseResponseTime: dbResponseTime
      },
      system: {
        memory: memoryUsage ? {
          rss: Math.round(memoryUsage.rss / 1024 / 1024), // MB
          heapUsed: Math.round(memoryUsage.heapUsed / 1024 / 1024), // MB
          heapTotal: Math.round(memoryUsage.heapTotal / 1024 / 1024) // MB
        } : null,
        uptime: process.uptime ? `${Math.floor(process.uptime())}s` : 'unknown'
      },
      thresholds: {
        responseTimeWarning: stats.averageResponseTime > 1000,
        errorRateWarning: stats.errorRate > 5,
        databaseWarning: dbResponseTime > 500
      }
    });

  } catch (error) {
    return c.json({
      status: 'unhealthy',
      error: error.message,
      timestamp: new Date().toISOString()
    }, 500);
  }
});

// Performance metrics endpoint
app.get('/make-server-9f7745d8/metrics', (c) => {
  const type = c.req.query('type') || 'response_time';
  const limit = parseInt(c.req.query('limit') || '100');
  
  return c.json({
    type,
    metrics: monitor.getMetrics(type, limit),
    stats: monitor.getStats()
  });
});

// Real-time stats update
app.post('/make-server-9f7745d8/update-stats', async (c) => {
  try {
    // Update active streams count
    const { data: streams, error: streamsError } = await supabase
      .from('live_streams')
      .select('id')
      .eq('is_live', true);

    if (!streamsError) {
      monitor.addMetric('active_streams', { count: streams.length });
    }

    // Update total users count
    const { data: users, error: usersError } = await supabase
      .from('coral_users')
      .select('id');

    if (!usersError) {
      monitor.addMetric('total_users', { count: users.length });
    }

    return c.json({
      success: true,
      activeStreams: streams?.length || 0,
      totalUsers: users?.length || 0
    });

  } catch (error) {
    return c.json({
      success: false,
      error: error.message
    }, 500);
  }
});

// Rate limiting tracking
app.post('/make-server-9f7745d8/track-rate-limit', async (c) => {
  try {
    const { userId, action, timestamp } = await c.req.json();
    
    monitor.addMetric('rate_limit', {
      userId,
      action,
      timestamp: timestamp || new Date().toISOString()
    });

    return c.json({ success: true });
  } catch (error) {
    return c.json({
      success: false,
      error: error.message
    }, 500);
  }
});

// Performance alerts
app.get('/make-server-9f7745d8/alerts', (c) => {
  const stats = monitor.getStats();
  const alerts = [];

  if (stats.averageResponseTime > 2000) {
    alerts.push({
      type: 'performance',
      severity: 'high',
      message: `High response time: ${stats.averageResponseTime}ms`,
      threshold: 2000
    });
  }

  if (stats.errorRate > 10) {
    alerts.push({
      type: 'errors',
      severity: 'high',
      message: `High error rate: ${stats.errorRate}%`,
      threshold: 10
    });
  }

  if (stats.activeStreams > 100) {
    alerts.push({
      type: 'capacity',
      severity: 'medium',
      message: `High stream count: ${stats.activeStreams}`,
      threshold: 100
    });
  }

  return c.json({
    alertCount: alerts.length,
    alerts,
    timestamp: new Date().toISOString()
  });
});

// Export performance data
app.get('/make-server-9f7745d8/export-metrics', (c) => {
  const metrics = {
    response_times: monitor.getMetrics('response_time'),
    active_streams: monitor.getMetrics('active_streams'),
    total_users: monitor.getMetrics('total_users'),
    rate_limits: monitor.getMetrics('rate_limit')
  };

  return c.json({
    exportedAt: new Date().toISOString(),
    totalMetrics: Object.values(metrics).reduce((sum, arr) => sum + arr.length, 0),
    metrics
  });
});

export default app;