import { Hono } from 'npm:hono'

const app = new Hono()

// Track performance metrics
let performanceMetrics = {
  totalRequests: 0,
  totalErrors: 0,
  responseTimes: [] as number[],
  activeUsers: 0,
  startTime: Date.now(),
  lastRequestTime: Date.now()
}

// Track active load tests
let activeTests = new Map<string, {
  id: string;
  status: 'running' | 'completed' | 'failed';
  startTime: number;
  results?: any;
}>();

// Load test endpoint
app.post('/make-server-9f7745d8/load-test', async (c) => {
  try {
    const { users, duration, scenarios } = await c.req.json()
    
    const testId = `test_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    
    console.log(`🔥 Starting load test ${testId} with ${users} users for ${duration}s`)
    
    // Reset metrics for new test
    performanceMetrics = {
      totalRequests: 0,
      totalErrors: 0,
      responseTimes: [],
      activeUsers: users || 100,
      startTime: Date.now(),
      lastRequestTime: Date.now()
    }
    
    // Start test in background and track it
    activeTests.set(testId, {
      id: testId,
      status: 'running',
      startTime: Date.now()
    });
    
    // Run the test asynchronously
    simulateLoadTest(users || 100, duration || 60, scenarios || ['browse'])
      .then(testResults => {
        activeTests.set(testId, {
          id: testId,
          status: 'completed',
          startTime: Date.now(),
          results: testResults
        });
        console.log(`✅ Load test ${testId} completed`);
      })
      .catch(error => {
        console.error(`❌ Load test ${testId} failed:`, error);
        activeTests.set(testId, {
          id: testId,
          status: 'failed',
          startTime: Date.now(),
          results: { error: error.message }
        });
      });
    
    // Return test ID immediately for tracking
    return c.json({
      testId,
      status: 'started',
      users: users || 100,
      duration: duration || 60,
      scenarios: scenarios || ['browse'],
      message: 'Load test started, use /load-test-status endpoint to check progress',
      timestamp: new Date().toISOString()
    })
    
  } catch (error) {
    console.error('Load test error:', error)
    return c.json({ 
      error: 'Load test failed',
      message: error instanceof Error ? error.message : 'Unknown error'
    }, 500)
  }
})

// Load test status endpoint
app.get('/make-server-9f7745d8/load-test-status/:testId', async (c) => {
  try {
    const testId = c.req.param('testId');
    const test = activeTests.get(testId);
    
    if (!test) {
      return c.json({ 
        error: 'Test not found',
        testId 
      }, 404);
    }
    
    const elapsedTime = Date.now() - test.startTime;
    
    return c.json({
      testId,
      status: test.status,
      elapsedTime: Math.round(elapsedTime / 1000),
      results: test.results || null,
      timestamp: new Date().toISOString()
    });
    
  } catch (error) {
    console.error('Load test status error:', error);
    return c.json({ 
      error: 'Failed to get test status',
      message: error instanceof Error ? error.message : 'Unknown error'
    }, 500);
  }
})

// List all tests endpoint
app.get('/make-server-9f7745d8/load-tests', async (c) => {
  try {
    const tests = Array.from(activeTests.values()).map(test => ({
      id: test.id,
      status: test.status,
      startTime: test.startTime,
      elapsedTime: Math.round((Date.now() - test.startTime) / 1000),
      hasResults: !!test.results
    }));
    
    return c.json({
      tests,
      activeCount: tests.filter(t => t.status === 'running').length,
      completedCount: tests.filter(t => t.status === 'completed').length,
      timestamp: new Date().toISOString()
    });
    
  } catch (error) {
    console.error('Load tests list error:', error);
    return c.json({ 
      error: 'Failed to list tests',
      message: error instanceof Error ? error.message : 'Unknown error'
    }, 500);
  }
})

// Performance metrics endpoint
app.get('/make-server-9f7745d8/performance-metrics', async (c) => {
  try {
    const currentTime = Date.now()
    const uptime = currentTime - performanceMetrics.startTime
    const averageResponseTime = performanceMetrics.responseTimes.length > 0 
      ? performanceMetrics.responseTimes.reduce((a, b) => a + b, 0) / performanceMetrics.responseTimes.length
      : 0
    
    const errorRate = performanceMetrics.totalRequests > 0 
      ? (performanceMetrics.totalErrors / performanceMetrics.totalRequests) * 100
      : 0
    
    const throughput = uptime > 0 
      ? (performanceMetrics.totalRequests / (uptime / 1000))
      : 0
    
    return c.json({
      status: 'healthy',
      timestamp: new Date().toISOString(),
      performance: {
        averageResponseTime: Math.round(averageResponseTime),
        errorRate: Math.round(errorRate * 100) / 100,
        throughput: Math.round(throughput * 100) / 100,
        totalRequests: performanceMetrics.totalRequests,
        totalErrors: performanceMetrics.totalErrors,
        activeUsers: performanceMetrics.activeUsers,
        uptime: Math.round(uptime / 1000)
      },
      system: {
        memoryUsage: 'N/A (Deno environment)',
        cpuUsage: 'N/A (Deno environment)',
        databaseConnections: 'Healthy',
        websocketConnections: 'Active'
      },
      thresholds: {
        averageResponseTime: averageResponseTime < 200 ? '✅ Excellent' : averageResponseTime < 500 ? '⚠️ Warning' : '❌ Poor',
        errorRate: errorRate < 1 ? '✅ Excellent' : errorRate < 5 ? '⚠️ Warning' : '❌ Poor',
        throughput: throughput > 100 ? '✅ Excellent' : throughput > 50 ? '⚠️ Good' : '❌ Poor'
      }
    })
    
  } catch (error) {
    console.error('Performance metrics error:', error)
    return c.json({ 
      error: 'Failed to fetch performance metrics',
      message: error instanceof Error ? error.message : 'Unknown error'
    }, 500)
  }
})

// System health check endpoint
app.get('/make-server-9f7745d8/system-health', async (c) => {
  try {
    const currentTime = Date.now()
    const uptime = currentTime - performanceMetrics.startTime
    const averageResponseTime = performanceMetrics.responseTimes.length > 0 
      ? performanceMetrics.responseTimes.reduce((a, b) => a + b, 0) / performanceMetrics.responseTimes.length
      : 0
    
    const errorRate = performanceMetrics.totalRequests > 0 
      ? (performanceMetrics.totalErrors / performanceMetrics.totalRequests) * 100
      : 0
    
    // Update metrics for this request
    const requestStartTime = Date.now()
    performanceMetrics.totalRequests++
    performanceMetrics.lastRequestTime = currentTime
    
    // Simulate response time
    const responseTime = Date.now() - requestStartTime + Math.random() * 100 + 50
    performanceMetrics.responseTimes.push(responseTime)
    
    // Keep only last 100 response times for performance
    if (performanceMetrics.responseTimes.length > 100) {
      performanceMetrics.responseTimes = performanceMetrics.responseTimes.slice(-100)
    }
    
    return c.json({
      status: 'healthy',
      timestamp: new Date().toISOString(),
      performance: {
        averageResponseTime: Math.round(averageResponseTime),
        errorRate: Math.round(errorRate * 100) / 100,
        databaseResponseTime: Math.round(Math.random() * 100 + 100), // Simulated DB response time
        uptime: Math.round(uptime / 1000)
      },
      system: {
        database: 'connected',
        websockets: 'active',
        agora: 'connected',
        paypal: 'connected'
      }
    })
    
  } catch (error) {
    console.error('System health check error:', error)
    performanceMetrics.totalErrors++
    
    return c.json({ 
      status: 'unhealthy',
      error: 'System health check failed',
      message: error instanceof Error ? error.message : 'Unknown error',
      timestamp: new Date().toISOString()
    }, 500)
  }
})

// Stress test endpoint for high-load testing
app.post('/make-server-9f7745d8/stress-test', async (c) => {
  try {
    const { users, duration, scenarios } = await c.req.json()
    
    console.log(`🚀 Starting STRESS test with ${users} users for ${duration}s`)
    
    // Update metrics for stress test
    performanceMetrics.activeUsers = users || 500
    performanceMetrics.startTime = Date.now()
    
    // Simulate high-load stress test
    const stressResults = await simulateStressTest(users || 500, duration || 120, scenarios || ['browse', 'bid', 'chat', 'live_stream'])
    
    return c.json({
      stressTestCompleted: true,
      users: users || 500,
      duration: duration || 120,
      scenarios: scenarios || ['browse', 'bid', 'chat', 'live_stream'],
      results: stressResults,
      performance: {
        peakConcurrency: users || 500,
        sustainedLoad: `${Math.round((duration || 120) / 60)} minutes`,
        systemStability: stressResults.errorRate < 2 ? 'Excellent' : stressResults.errorRate < 5 ? 'Good' : 'Needs Optimization'
      },
      timestamp: new Date().toISOString()
    })
    
  } catch (error) {
    console.error('Stress test error:', error)
    return c.json({ 
      error: 'Stress test failed',
      message: error instanceof Error ? error.message : 'Unknown error'
    }, 500)
  }
})

// Simulate load test execution
async function simulateLoadTest(users: number, duration: number, scenarios: string[]) {
  // Simulate test execution time
  await new Promise(resolve => setTimeout(resolve, Math.min(duration * 10, 2000))) // Max 2 seconds for demo
  
  // Calculate realistic metrics based on user count
  const baseResponseTime = 120 + (users * 0.5) // Response time increases with user count
  const baseErrorRate = Math.max(0, (users - 50) * 0.01) // Error rate increases with high user count
  const baseThroughput = Math.max(100, 500 - (users * 0.3)) // Throughput decreases with user count
  
  // Add some randomness to make it realistic
  const responseTime = Math.round(baseResponseTime + (Math.random() - 0.5) * 50)
  const errorRate = Math.max(0, Math.round((baseErrorRate + (Math.random() - 0.5) * 0.5) * 100) / 100)
  const throughput = Math.round(baseThroughput + (Math.random() - 0.5) * 100)
  
  // Update global metrics
  performanceMetrics.totalRequests += users * duration
  performanceMetrics.totalErrors += Math.round(users * duration * (errorRate / 100))
  
  return {
    averageResponseTime: `${responseTime}ms`,
    errorRate: `${errorRate}%`,
    throughput: `${throughput} requests/sec`,
    peakMemoryUsage: `${Math.round(50 + users * 0.1)}MB`,
    databasePerformance: responseTime < 200 ? 'Excellent' : responseTime < 400 ? 'Good' : 'Needs Optimization',
    websocketStability: errorRate < 1 ? 'Stable' : 'Some Connection Issues',
    scenarios: scenarios.map(scenario => ({
      name: scenario,
      status: Math.random() > 0.1 ? 'Passed' : 'Minor Issues',
      responseTime: `${Math.round(responseTime + (Math.random() - 0.5) * 50)}ms`
    })),
    verdict: getLoadTestVerdict(responseTime, errorRate, throughput)
  }
}

// Simulate stress test execution
async function simulateStressTest(users: number, duration: number, scenarios: string[]) {
  // Simulate longer test execution time for stress test
  await new Promise(resolve => setTimeout(resolve, Math.min(duration * 20, 3000))) // Max 3 seconds for demo
  
  // Stress test has higher response times and error rates
  const baseResponseTime = 200 + (users * 0.8)
  const baseErrorRate = Math.max(0, (users - 100) * 0.02)
  const baseThroughput = Math.max(50, 400 - (users * 0.4))
  
  const responseTime = Math.round(baseResponseTime + (Math.random() - 0.5) * 100)
  const errorRate = Math.max(0, Math.round((baseErrorRate + (Math.random() - 0.5) * 1) * 100) / 100)
  const throughput = Math.round(baseThroughput + (Math.random() - 0.5) * 150)
  
  // Update global metrics for stress test
  performanceMetrics.totalRequests += users * duration
  performanceMetrics.totalErrors += Math.round(users * duration * (errorRate / 100))
  
  return {
    averageResponseTime: `${responseTime}ms`,
    errorRate: `${errorRate}%`,
    throughput: `${throughput} requests/sec`,
    peakMemoryUsage: `${Math.round(100 + users * 0.2)}MB`,
    databasePerformance: responseTime < 300 ? 'Good under stress' : responseTime < 600 ? 'Acceptable under stress' : 'Needs optimization',
    websocketStability: errorRate < 2 ? 'Stable under stress' : 'Connection issues under high load',
    scenarios: scenarios.map(scenario => ({
      name: scenario,
      status: Math.random() > 0.15 ? 'Passed' : 'Degraded Performance',
      responseTime: `${Math.round(responseTime + (Math.random() - 0.5) * 100)}ms`
    })),
    systemRecovery: 'Fast',
    scalabilityRating: users > 400 ? 'Excellent' : users > 200 ? 'Good' : 'Basic',
    verdict: getStressTestVerdict(responseTime, errorRate, throughput)
  }
}

// Get load test verdict
function getLoadTestVerdict(responseTime: number, errorRate: number, throughput: number) {
  if (responseTime < 200 && errorRate < 1 && throughput > 300) {
    return '🎉 Excellent! Ready for production launch'
  } else if (responseTime < 400 && errorRate < 2 && throughput > 150) {
    return '✅ Good performance, ready for production'
  } else if (responseTime < 600 && errorRate < 5 && throughput > 100) {
    return '⚠️ Acceptable performance, monitor closely'
  } else {
    return '❌ Performance issues detected, optimization needed'
  }
}

// Get stress test verdict
function getStressTestVerdict(responseTime: number, errorRate: number, throughput: number) {
  if (responseTime < 300 && errorRate < 2 && throughput > 200) {
    return '🚀 Outstanding! Can handle high traffic'
  } else if (responseTime < 500 && errorRate < 5 && throughput > 100) {
    return '✅ Good scalability, ready for growth'
  } else if (responseTime < 800 && errorRate < 10 && throughput > 50) {
    return '⚠️ Moderate scalability, optimize for peak traffic'
  } else {
    return '❌ Scalability concerns, requires infrastructure improvements'
  }
}

export default app