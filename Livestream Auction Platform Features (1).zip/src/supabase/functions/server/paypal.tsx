import { Hono } from 'npm:hono'

// PayPal API configuration
const PAYPAL_CLIENT_ID = Deno.env.get('PAYPAL_CLIENT_ID')!
const PAYPAL_CLIENT_SECRET = Deno.env.get('PAYPAL_SECRET_KEY')!
const PAYPAL_BASE_URL = 'https://api-m.paypal.com' // Production PayPal API - LIVE MODE
const PLATFORM_PAYPAL_MERCHANT_ID = Deno.env.get('PLATFORM_PAYPAL_MERCHANT_ID')!
const PLATFORM_FEE_PERCENT = Number(Deno.env.get('PLATFORM_FEE_PERCENT') || '0.08')
const PLATFORM_FEE_FLAT = Number(Deno.env.get('PLATFORM_FEE_FLAT') || '0.30')

interface PayPalTokenResponse {
  access_token: string
  token_type: string
  expires_in: number
}

interface PayPalOrder {
  id: string
  status: string
  purchase_units: Array<{
    amount: {
      value: string
      currency_code: string
    }
    description: string
  }>
  links: Array<{
    href: string
    rel: string
    method: string
  }>
}

class PayPalService {
  private async getAccessToken(): Promise<string> {
    try {
      // Check if credentials are available
      if (!PAYPAL_CLIENT_ID || !PAYPAL_CLIENT_SECRET) {
        throw new Error('PayPal credentials not configured properly')
      }

      console.log('🔄 PayPal authentication attempt:', {
        clientId: PAYPAL_CLIENT_ID ? `${PAYPAL_CLIENT_ID.substring(0, 8)}...` : 'missing',
        clientSecret: PAYPAL_CLIENT_SECRET ? 'present' : 'missing',
        baseUrl: PAYPAL_BASE_URL
      })

      const auth = btoa(`${PAYPAL_CLIENT_ID}:${PAYPAL_CLIENT_SECRET}`)
      
      const response = await fetch(`${PAYPAL_BASE_URL}/v1/oauth2/token`, {
        method: 'POST',
        headers: {
          'Authorization': `Basic ${auth}`,
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: 'grant_type=client_credentials'
      })

      if (!response.ok) {
        const errorText = await response.text()
        console.error('PayPal auth response:', {
          status: response.status,
          statusText: response.statusText,
          body: errorText
        })
        throw new Error(`PayPal auth failed: ${response.status} - ${errorText}`)
      }

      const data: PayPalTokenResponse = await response.json()
      console.log('✅ PayPal access token obtained successfully')
      return data.access_token
    } catch (error) {
      console.error('❌ PayPal authentication error:', error)
      throw new Error(`Failed to authenticate with PayPal: ${error instanceof Error ? error.message : 'Unknown error'}`)
    }
  }

  async createOrder(amount: string, currency: string, description: string, auctionId: string): Promise<PayPalOrder> {
    try {
      const accessToken = await this.getAccessToken()
      
      const orderData = {
        intent: 'CAPTURE',
        purchase_units: [{
          amount: {
            currency_code: currency,
            value: amount
          },
          description: description,
          custom_id: auctionId // Store auction ID for reference
        }],
        application_context: {
          brand_name: 'Coral Crave',
          landing_page: 'NO_PREFERENCE',
          user_action: 'PAY_NOW',
          return_url: 'https://yourapp.com/payment/success',
          cancel_url: 'https://yourapp.com/payment/cancel'
        }
      }

      const response = await fetch(`${PAYPAL_BASE_URL}/v2/checkout/orders`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(orderData)
      })

      if (!response.ok) {
        const errorData = await response.json()
        console.error('PayPal order creation failed:', errorData)
        throw new Error(`PayPal order creation failed: ${response.status}`)
      }

      const order: PayPalOrder = await response.json()
      console.log('✅ PayPal order created:', order.id)
      return order
    } catch (error) {
      console.error('❌ PayPal order creation error:', error)
      throw error
    }
  }

  async captureOrder(orderId: string): Promise<PayPalOrder> {
    try {
      const accessToken = await this.getAccessToken()
      
      const response = await fetch(`${PAYPAL_BASE_URL}/v2/checkout/orders/${orderId}/capture`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json',
        }
      })

      if (!response.ok) {
        const errorData = await response.json()
        console.error('PayPal order capture failed:', errorData)
        throw new Error(`PayPal order capture failed: ${response.status}`)
      }

      const order: PayPalOrder = await response.json()
      console.log('✅ PayPal order captured:', order.id)
      return order
    } catch (error) {
      console.error('❌ PayPal order capture error:', error)
      throw error
    }
  }

  async getOrderDetails(orderId: string): Promise<PayPalOrder> {
    try {
      const accessToken = await this.getAccessToken()
      
      const response = await fetch(`${PAYPAL_BASE_URL}/v2/checkout/orders/${orderId}`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json',
        }
      })

      if (!response.ok) {
        throw new Error(`PayPal order fetch failed: ${response.status}`)
      }

      const order: PayPalOrder = await response.json()
      return order
    } catch (error) {
      console.error('❌ PayPal order fetch error:', error)
      throw error
    }
  }

  // Helper function to format money
  private toMoney(amount: number): string {
    return amount.toFixed(2)
  }

  // Create marketplace order with split payments
  async createMarketplaceOrder(
    amount: string, 
    currency: string, 
    description: string, 
    auctionId: string, 
    sellerMerchantId: string
  ): Promise<PayPalOrder> {
    try {
      const accessToken = await this.getAccessToken()
      const numAmount = parseFloat(amount)
      
      // Calculate platform fee: 8% + $0.30
      const platformFee = this.toMoney(numAmount * PLATFORM_FEE_PERCENT + PLATFORM_FEE_FLAT)
      
      console.log('💰 Creating marketplace order:', {
        amount: numAmount,
        platformFee,
        sellerMerchantId,
        platformMerchantId: PLATFORM_PAYPAL_MERCHANT_ID
      })
      
      const orderData = {
        intent: 'CAPTURE',
        purchase_units: [{
          amount: {
            currency_code: currency,
            value: this.toMoney(numAmount)
          },
          description: description,
          custom_id: auctionId,
          // Route the sale to the seller
          payee: {
            merchant_id: sellerMerchantId
          },
          // Take platform fee
          payment_instruction: {
            platform_fees: [{
              amount: {
                currency_code: currency,
                value: platformFee
              },
              payee: {
                merchant_id: PLATFORM_PAYPAL_MERCHANT_ID
              }
            }],
            disbursement_mode: 'INSTANT'
          }
        }],
        application_context: {
          brand_name: 'Coral Crave',
          landing_page: 'NO_PREFERENCE',
          user_action: 'PAY_NOW',
          return_url: 'https://yourapp.com/payment/success',
          cancel_url: 'https://yourapp.com/payment/cancel'
        }
      }

      const response = await fetch(`${PAYPAL_BASE_URL}/v2/checkout/orders`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(orderData)
      })

      if (!response.ok) {
        const errorData = await response.json()
        console.error('PayPal marketplace order creation failed:', errorData)
        throw new Error(`PayPal marketplace order creation failed: ${response.status}`)
      }

      const order: PayPalOrder = await response.json()
      console.log('✅ PayPal marketplace order created:', order.id)
      return order
    } catch (error) {
      console.error('❌ PayPal marketplace order creation error:', error)
      throw error
    }
  }

  // Create seller onboarding link
  async createOnboardingLink(userId: string): Promise<string> {
    try {
      const accessToken = await this.getAccessToken()
      
      const referralData = {
        tracking_id: userId,
        partner_config_override: {
          return_url: 'https://yourapp.com/paypal/connected',
          return_url_description: 'Return to Coral Crave',
          show_add_credit_card: true
        },
        operations: [{
          operation: 'API_INTEGRATION',
          api_integration_preference: {
            rest_api_integration: {
              integration_method: 'PAYPAL',
              integration_type: 'THIRD_PARTY'
            }
          }
        }],
        products: ['PPCP'], // Commerce Platform
        legal_consents: [{
          type: 'SHARE_DATA_CONSENT',
          granted: true
        }]
      }

      const response = await fetch(`${PAYPAL_BASE_URL}/v2/customer/partner-referrals`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(referralData)
      })

      if (!response.ok) {
        const errorData = await response.json()
        console.error('PayPal onboarding link creation failed:', errorData)
        throw new Error(`PayPal onboarding link creation failed: ${response.status}`)
      }

      const responseData = await response.json()
      
      // Find the action URL
      const actionUrl = responseData?.links?.find((link: any) => link.rel === 'action_url')?.href
      
      if (!actionUrl) {
        throw new Error('No action URL found in PayPal response')
      }

      console.log('✅ PayPal onboarding link created for user:', userId)
      return actionUrl
    } catch (error) {
      console.error('❌ PayPal onboarding link creation error:', error)
      throw error
    }
  }

  // Get merchant status
  async getMerchantStatus(merchantId: string): Promise<any> {
    try {
      const accessToken = await this.getAccessToken()
      
      const response = await fetch(`${PAYPAL_BASE_URL}/v1/customer/partners/${PAYPAL_CLIENT_ID}/merchant-integrations?merchant_id=${merchantId}`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${accessToken}`,
          'Content-Type': 'application/json',
        }
      })

      if (!response.ok) {
        const errorData = await response.json()
        console.error('PayPal merchant status fetch failed:', errorData)
        throw new Error(`PayPal merchant status fetch failed: ${response.status}`)
      }

      const statusData = await response.json()
      console.log('✅ PayPal merchant status fetched:', merchantId)
      return statusData
    } catch (error) {
      console.error('❌ PayPal merchant status fetch error:', error)
      throw error
    }
  }
}

// Create PayPal service instance
const paypalService = new PayPalService()

// Export the PayPalService class as default
export default PayPalService

// PayPal routes
export function createPayPalRoutes(app: Hono, supabase: any) {
  
  // Create payment order for auction win
  app.post('/make-server-9f7745d8/paypal/create-order', async (c) => {
    try {
      const accessToken = c.req.header('Authorization')?.split(' ')[1]
      
      if (!accessToken) {
        return c.json({ error: 'Authorization token required' }, 401)
      }

      const { data: { user }, error } = await supabase.auth.getUser(accessToken)
      
      if (error || !user) {
        return c.json({ error: 'Invalid or expired token' }, 401)
      }

      const { amount, currency = 'USD', description, auctionId, itemId, sellerMerchantId } = await c.req.json()

      if (!amount || !description || !auctionId) {
        return c.json({ error: 'Amount, description, and auction ID are required' }, 400)
      }

      // Check if seller is connected for marketplace orders
      if (!sellerMerchantId) {
        return c.json({ error: 'SELLER_NOT_CONNECTED', message: 'Seller must connect PayPal before accepting payments' }, 400)
      }

      // Validate amount format
      const numAmount = parseFloat(amount)
      if (isNaN(numAmount) || numAmount <= 0) {
        return c.json({ error: 'Invalid amount format' }, 400)
      }

      console.log('💳 Creating PayPal marketplace order:', { 
        amount, 
        currency, 
        description, 
        auctionId, 
        sellerMerchantId,
        userId: user.id 
      })

      // Use marketplace order for split payments
      const order = await paypalService.createMarketplaceOrder(
        amount.toString(),
        currency,
        description,
        auctionId,
        sellerMerchantId
      )

      // Store order details in KV store for tracking
      const orderData = {
        paypalOrderId: order.id,
        userId: user.id,
        auctionId,
        itemId,
        amount: numAmount,
        currency,
        description,
        sellerMerchantId,
        platformFee: numAmount * PLATFORM_FEE_PERCENT + PLATFORM_FEE_FLAT,
        status: 'created',
        createdAt: new Date().toISOString()
      }

      // Import KV store
      const kvModule = await import('./kv_store.tsx')
      await kvModule.set(`paypal_order:${order.id}`, orderData)

      return c.json({
        success: true,
        orderId: order.id,
        approvalUrl: order.links.find(link => link.rel === 'approve')?.href
      })

    } catch (error) {
      console.error('PayPal order creation error:', error)
      return c.json({ 
        error: 'Failed to create PayPal order', 
        details: error instanceof Error ? error.message : 'Unknown error' 
      }, 500)
    }
  })

  // Create seller onboarding link
  app.post('/make-server-9f7745d8/paypal/onboarding-link', async (c) => {
    try {
      const accessToken = c.req.header('Authorization')?.split(' ')[1]
      
      if (!accessToken) {
        return c.json({ error: 'Authorization token required' }, 401)
      }

      const { data: { user }, error } = await supabase.auth.getUser(accessToken)
      
      if (error || !user) {
        return c.json({ error: 'Invalid or expired token' }, 401)
      }

      console.log('🔗 Creating PayPal onboarding link for user:', user.id)

      const onboardingUrl = await paypalService.createOnboardingLink(user.id)

      return c.json({
        success: true,
        url: onboardingUrl
      })

    } catch (error) {
      console.error('PayPal onboarding link creation error:', error)
      return c.json({ 
        error: 'Failed to create PayPal onboarding link', 
        details: error instanceof Error ? error.message : 'Unknown error' 
      }, 500)
    }
  })

  // Get merchant status after onboarding
  app.get('/make-server-9f7745d8/paypal/merchant-status', async (c) => {
    try {
      const accessToken = c.req.header('Authorization')?.split(' ')[1]
      
      if (!accessToken) {
        return c.json({ error: 'Authorization token required' }, 401)
      }

      const { data: { user }, error } = await supabase.auth.getUser(accessToken)
      
      if (error || !user) {
        return c.json({ error: 'Invalid or expired token' }, 401)
      }

      // Get user's merchant ID from KV store
      const kvModule = await import('./kv_store.tsx')
      const userProfile = await kvModule.get(`user_profile:${user.id}`)

      if (!userProfile?.paypalMerchantId) {
        return c.json({ 
          success: true, 
          status: 'NOT_CONNECTED',
          message: 'User has not connected PayPal yet'
        })
      }

      const merchantStatus = await paypalService.getMerchantStatus(userProfile.paypalMerchantId)

      // Update user profile with status
      const updatedProfile = {
        ...userProfile,
        paypalOnboardingStatus: merchantStatus.primary_email_confirmed ? 'CONNECTED' : 'PENDING',
        lastStatusCheck: new Date().toISOString()
      }

      await kvModule.set(`user_profile:${user.id}`, updatedProfile)

      return c.json({
        success: true,
        status: updatedProfile.paypalOnboardingStatus,
        merchantData: merchantStatus
      })

    } catch (error) {
      console.error('PayPal merchant status fetch error:', error)
      return c.json({ 
        error: 'Failed to fetch PayPal merchant status', 
        details: error instanceof Error ? error.message : 'Unknown error' 
      }, 500)
    }
  })

  // Save merchant ID after successful onboarding
  app.post('/make-server-9f7745d8/paypal/save-merchant', async (c) => {
    try {
      const accessToken = c.req.header('Authorization')?.split(' ')[1]
      
      if (!accessToken) {
        return c.json({ error: 'Authorization token required' }, 401)
      }

      const { data: { user }, error } = await supabase.auth.getUser(accessToken)
      
      if (error || !user) {
        return c.json({ error: 'Invalid or expired token' }, 401)
      }

      const { merchantId, email } = await c.req.json()

      if (!merchantId) {
        return c.json({ error: 'Merchant ID is required' }, 400)
      }

      // Update user profile with PayPal info
      const kvModule = await import('./kv_store.tsx')
      const userProfile = await kvModule.get(`user_profile:${user.id}`) || {}

      const updatedProfile = {
        ...userProfile,
        paypalMerchantId: merchantId,
        paypalEmail: email,
        paypalOnboardingStatus: 'CONNECTED',
        paypalConnectedAt: new Date().toISOString()
      }

      await kvModule.set(`user_profile:${user.id}`, updatedProfile)

      console.log('✅ PayPal merchant info saved for user:', user.id)

      return c.json({
        success: true,
        message: 'PayPal account successfully connected'
      })

    } catch (error) {
      console.error('PayPal merchant save error:', error)
      return c.json({ 
        error: 'Failed to save PayPal merchant info', 
        details: error instanceof Error ? error.message : 'Unknown error' 
      }, 500)
    }
  })

  // Capture payment after user approval
  app.post('/make-server-9f7745d8/paypal/capture-order', async (c) => {
    try {
      const accessToken = c.req.header('Authorization')?.split(' ')[1]
      
      if (!accessToken) {
        return c.json({ error: 'Authorization token required' }, 401)
      }

      const { data: { user }, error } = await supabase.auth.getUser(accessToken)
      
      if (error || !user) {
        return c.json({ error: 'Invalid or expired token' }, 401)
      }

      const { orderId } = await c.req.json()

      if (!orderId) {
        return c.json({ error: 'Order ID is required' }, 400)
      }

      console.log('💰 Capturing PayPal order:', orderId)

      // Verify order belongs to user
      const kvModule = await import('./kv_store.tsx')
      const orderData = await kvModule.get(`paypal_order:${orderId}`)
      
      if (!orderData || orderData.userId !== user.id) {
        return c.json({ error: 'Order not found or unauthorized' }, 404)
      }

      const capturedOrder = await paypalService.captureOrder(orderId)

      // Update order status
      const updatedOrderData = {
        ...orderData,
        status: 'completed',
        capturedAt: new Date().toISOString(),
        paypalData: capturedOrder
      }

      await kvModule.set(`paypal_order:${orderId}`, updatedOrderData)

      // Create purchase record
      const purchaseData = {
        id: `purchase_${Date.now()}`,
        userId: user.id,
        auctionId: orderData.auctionId,
        itemId: orderData.itemId,
        amount: orderData.amount,
        currency: orderData.currency,
        paypalOrderId: orderId,
        status: 'completed',
        purchasedAt: new Date().toISOString()
      }

      await kvModule.set(`purchase:${purchaseData.id}`, purchaseData)
      
      // Add to user's purchase history
      const userPurchases = await kvModule.get(`user_purchases:${user.id}`) || []
      userPurchases.push(purchaseData.id)
      await kvModule.set(`user_purchases:${user.id}`, userPurchases)

      console.log('✅ Payment captured successfully:', orderId)

      return c.json({
        success: true,
        orderId: capturedOrder.id,
        status: capturedOrder.status,
        purchaseId: purchaseData.id
      })

    } catch (error) {
      console.error('PayPal order capture error:', error)
      return c.json({ 
        error: 'Failed to capture PayPal order', 
        details: error instanceof Error ? error.message : 'Unknown error' 
      }, 500)
    }
  })

  // Get order status
  app.get('/make-server-9f7745d8/paypal/order/:orderId', async (c) => {
    try {
      const accessToken = c.req.header('Authorization')?.split(' ')[1]
      
      if (!accessToken) {
        return c.json({ error: 'Authorization token required' }, 401)
      }

      const { data: { user }, error } = await supabase.auth.getUser(accessToken)
      
      if (error || !user) {
        return c.json({ error: 'Invalid or expired token' }, 401)
      }

      const orderId = c.req.param('orderId')

      // Get order from KV store
      const kvModule = await import('./kv_store.tsx')
      const orderData = await kvModule.get(`paypal_order:${orderId}`)
      
      if (!orderData || orderData.userId !== user.id) {
        return c.json({ error: 'Order not found or unauthorized' }, 404)
      }

      // Get latest status from PayPal
      const paypalOrder = await paypalService.getOrderDetails(orderId)

      return c.json({
        success: true,
        order: {
          ...orderData,
          paypalStatus: paypalOrder.status
        }
      })

    } catch (error) {
      console.error('PayPal order fetch error:', error)
      return c.json({ 
        error: 'Failed to fetch PayPal order', 
        details: error instanceof Error ? error.message : 'Unknown error' 
      }, 500)
    }
  })

  // Get user's purchase history
  app.get('/make-server-9f7745d8/purchases', async (c) => {
    try {
      const accessToken = c.req.header('Authorization')?.split(' ')[1]
      
      if (!accessToken) {
        return c.json({ error: 'Authorization token required' }, 401)
      }

      const { data: { user }, error } = await supabase.auth.getUser(accessToken)
      
      if (error || !user) {
        return c.json({ error: 'Invalid or expired token' }, 401)
      }

      const kvModule = await import('./kv_store.tsx')
      const purchaseIds = await kvModule.get(`user_purchases:${user.id}`) || []
      
      const purchases = []
      for (const purchaseId of purchaseIds) {
        const purchase = await kvModule.get(`purchase:${purchaseId}`)
        if (purchase) {
          purchases.push(purchase)
        }
      }

      // Sort by purchase date (newest first)
      purchases.sort((a, b) => new Date(b.purchasedAt).getTime() - new Date(a.purchasedAt).getTime())

      return c.json({
        success: true,
        purchases
      })

    } catch (error) {
      console.error('Purchase history fetch error:', error)
      return c.json({ 
        error: 'Failed to fetch purchase history', 
        details: error instanceof Error ? error.message : 'Unknown error' 
      }, 500)
    }
  })
}