import { Hono } from 'npm:hono';
import { cors } from 'npm:hono/cors';
import { createClient } from 'npm:@supabase/supabase-js@2';
import * as kv from './kv_store.tsx';

const app = new Hono();

app.use('*', cors({
  origin: '*',
  allowMethods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowHeaders: ['Content-Type', 'Authorization'],
}));

const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
);

interface LiveStream {
  id: string;
  title: string;
  description: string;
  sellerId: string;
  sellerName: string;
  sellerAvatar?: string;
  channelName: string;
  thumbnail: string;
  category: string;
  isLive: boolean;
  viewerCount: number;
  startedAt: string;
  currentItem?: {
    id: string;
    title: string;
    currentBid: number;
    timeLeft: string;
  };
  tags: string[];
}

// Get all active live streams
app.get('/make-server-9f7745d8/live-streams', async (c) => {
  try {
    console.log('Getting active live streams');

    const activeStreams = await kv.getByPrefix('live_stream_');
    const streams: LiveStream[] = activeStreams
      .map(item => item.value)
      .filter(stream => stream && stream.isLive)
      .sort((a, b) => b.viewerCount - a.viewerCount);

    return c.json({
      success: true,
      streams,
      count: streams.length
    });

  } catch (error) {
    console.error('Get live streams error:', error);
    return c.json({ error: 'Failed to get live streams' }, 500);
  }
});

// Start a new live stream
app.post('/make-server-9f7745d8/live-streams/start', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: 'Authorization token required' }, 401);
    }

    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (!user?.id) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const { title, description, channelName, thumbnail, category, productId, timer } = await c.req.json();

    if (!title || !channelName) {
      return c.json({ error: 'Title and channel name are required' }, 400);
    }

    // Check if user already has an active stream
    const existingStreams = await kv.getByPrefix(`live_stream_${user.id}_`);
    const activeStream = existingStreams.find(stream => stream.value?.isLive);
    
    if (activeStream) {
      return c.json({ error: 'You already have an active stream' }, 400);
    }

    // Get user profile for seller info
    const userProfile = await kv.get(`user_profile_${user.id}`);
    const profile = userProfile?.value || {};

    const streamId = `live_stream_${user.id}_${Date.now()}`;
    const liveStream: LiveStream = {
      id: streamId,
      title,
      description: description || '',
      sellerId: user.id,
      sellerName: profile.name || user.user_metadata?.name || 'Seller',
      sellerAvatar: profile.avatar,
      channelName,
      thumbnail: thumbnail || 'https://images.unsplash.com/photo-1583212292454-1fe6229603b7?w=400&h=225&fit=crop',
      category: category || 'General',
      isLive: true,
      viewerCount: 0,
      startedAt: new Date().toISOString(),
      tags: []
    };

    // If a product is selected, add it as current item
    if (productId) {
      const product = await kv.get(`queue_item:${productId}`);
      if (product?.value) {
        liveStream.currentItem = {
          id: product.value.id,
          title: product.value.title,
          currentBid: product.value.startingBid,
          timeLeft: `${timer || 30}s`
        };
      }
    }

    await kv.set(streamId, liveStream);

    // Add to global active streams list
    const globalStreams = await kv.get('global_active_streams') || { value: [] };
    globalStreams.value.push(streamId);
    await kv.set('global_active_streams', globalStreams.value);

    // Notify followers
    await notifyFollowers(user.id, liveStream);

    console.log('✅ Live stream started:', streamId);

    return c.json({
      success: true,
      stream: liveStream
    });

  } catch (error) {
    console.error('Start live stream error:', error);
    return c.json({ error: 'Failed to start live stream' }, 500);
  }
});

// Update stream viewer count
app.put('/make-server-9f7745d8/live-streams/:streamId/viewers', async (c) => {
  try {
    const streamId = c.req.param('streamId');
    const { action } = await c.req.json(); // 'join' or 'leave'

    const stream = await kv.get(streamId);
    if (!stream?.value) {
      return c.json({ error: 'Stream not found' }, 404);
    }

    const updatedStream = {
      ...stream.value,
      viewerCount: Math.max(0, stream.value.viewerCount + (action === 'join' ? 1 : -1))
    };

    await kv.set(streamId, updatedStream);

    return c.json({
      success: true,
      viewerCount: updatedStream.viewerCount
    });

  } catch (error) {
    console.error('Update viewer count error:', error);
    return c.json({ error: 'Failed to update viewer count' }, 500);
  }
});

// End a live stream
app.post('/make-server-9f7745d8/live-streams/:streamId/end', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: 'Authorization token required' }, 401);
    }

    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (!user?.id) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const streamId = c.req.param('streamId');
    const stream = await kv.get(streamId);
    
    if (!stream?.value) {
      return c.json({ error: 'Stream not found' }, 404);
    }

    if (stream.value.sellerId !== user.id) {
      return c.json({ error: 'Unauthorized to end this stream' }, 403);
    }

    // Update stream status
    const updatedStream = {
      ...stream.value,
      isLive: false,
      endedAt: new Date().toISOString()
    };

    await kv.set(streamId, updatedStream);

    // Remove from global active streams
    const globalStreams = await kv.get('global_active_streams') || { value: [] };
    const updatedGlobalStreams = globalStreams.value.filter((id: string) => id !== streamId);
    await kv.set('global_active_streams', updatedGlobalStreams);

    // Archive the stream
    await kv.set(`archived_stream_${streamId}`, updatedStream);

    console.log('✅ Live stream ended:', streamId);

    return c.json({
      success: true,
      message: 'Stream ended successfully'
    });

  } catch (error) {
    console.error('End live stream error:', error);
    return c.json({ error: 'Failed to end live stream' }, 500);
  }
});

// Get stream details
app.get('/make-server-9f7745d8/live-streams/:streamId', async (c) => {
  try {
    const streamId = c.req.param('streamId');
    const stream = await kv.get(streamId);
    
    if (!stream?.value) {
      return c.json({ error: 'Stream not found' }, 404);
    }

    return c.json({
      success: true,
      stream: stream.value
    });

  } catch (error) {
    console.error('Get stream details error:', error);
    return c.json({ error: 'Failed to get stream details' }, 500);
  }
});

// Update current auction item in stream
app.put('/make-server-9f7745d8/live-streams/:streamId/current-item', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    if (!accessToken) {
      return c.json({ error: 'Authorization token required' }, 401);
    }

    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (!user?.id) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const streamId = c.req.param('streamId');
    const { itemId, currentBid, timeLeft } = await c.req.json();

    const stream = await kv.get(streamId);
    
    if (!stream?.value) {
      return c.json({ error: 'Stream not found' }, 404);
    }

    if (stream.value.sellerId !== user.id) {
      return c.json({ error: 'Unauthorized to update this stream' }, 403);
    }

    // Get item details
    const item = await kv.get(`queue_item:${itemId}`);
    if (!item?.value) {
      return c.json({ error: 'Auction item not found' }, 404);
    }

    const updatedStream = {
      ...stream.value,
      currentItem: {
        id: itemId,
        title: item.value.title,
        currentBid: currentBid || item.value.startingBid,
        timeLeft: timeLeft || '30s'
      }
    };

    await kv.set(streamId, updatedStream);

    return c.json({
      success: true,
      stream: updatedStream
    });

  } catch (error) {
    console.error('Update current item error:', error);
    return c.json({ error: 'Failed to update current item' }, 500);
  }
});

// Get streams by category
app.get('/make-server-9f7745d8/live-streams/category/:category', async (c) => {
  try {
    const category = c.req.param('category');
    
    const activeStreams = await kv.getByPrefix('live_stream_');
    const streams: LiveStream[] = activeStreams
      .map(item => item.value)
      .filter(stream => stream && stream.isLive && stream.category === category)
      .sort((a, b) => b.viewerCount - a.viewerCount);

    return c.json({
      success: true,
      streams,
      category,
      count: streams.length
    });

  } catch (error) {
    console.error('Get streams by category error:', error);
    return c.json({ error: 'Failed to get streams by category' }, 500);
  }
});

// Search live streams
app.get('/make-server-9f7745d8/live-streams/search', async (c) => {
  try {
    const query = c.req.query('q') || '';
    const category = c.req.query('category');
    
    const activeStreams = await kv.getByPrefix('live_stream_');
    let streams: LiveStream[] = activeStreams
      .map(item => item.value)
      .filter(stream => stream && stream.isLive);

    // Apply search filter
    if (query) {
      const lowerQuery = query.toLowerCase();
      streams = streams.filter(stream =>
        stream.title.toLowerCase().includes(lowerQuery) ||
        stream.description.toLowerCase().includes(lowerQuery) ||
        stream.sellerName.toLowerCase().includes(lowerQuery) ||
        stream.tags.some(tag => tag.toLowerCase().includes(lowerQuery))
      );
    }

    // Apply category filter
    if (category && category !== 'all') {
      streams = streams.filter(stream => stream.category === category);
    }

    // Sort by relevance/viewer count
    streams.sort((a, b) => b.viewerCount - a.viewerCount);

    return c.json({
      success: true,
      streams,
      query,
      category,
      count: streams.length
    });

  } catch (error) {
    console.error('Search live streams error:', error);
    return c.json({ error: 'Failed to search live streams' }, 500);
  }
});

// Helper function to notify followers
async function notifyFollowers(sellerId: string, stream: LiveStream) {
  try {
    const followers = await kv.get(`followers_${sellerId}`);
    const followerIds = followers?.value || [];

    for (const followerId of followerIds) {
      const notificationId = `notif_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      const notification = {
        id: notificationId,
        type: 'live_stream_started',
        title: `${stream.sellerName} is now live!`,
        message: stream.title,
        timestamp: new Date().toISOString(),
        read: false,
        actionRequired: false,
        relatedItem: {
          id: stream.id,
          type: 'live_stream',
          title: stream.title,
          thumbnail: stream.thumbnail
        },
        sender: {
          id: sellerId,
          name: stream.sellerName,
          avatar: stream.sellerAvatar
        }
      };

      await kv.set(`notification_${followerId}_${notificationId}`, notification);
    }

    console.log('📢 Live stream notifications sent to', followerIds.length, 'followers');
  } catch (error) {
    console.error('Notify followers error:', error);
  }
}

export default app;