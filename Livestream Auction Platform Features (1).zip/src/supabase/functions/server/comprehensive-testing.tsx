import { Hono } from 'npm:hono';
import { cors } from 'npm:hono/cors';
import { createClient } from 'npm:@supabase/supabase-js@2';
import * as kv from './kv_store.tsx';

const app = new Hono();

// CORS middleware
app.use('*', cors({
  origin: '*',
  allowMethods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowHeaders: ['Content-Type', 'Authorization'],
}));

// Initialize Supabase client
const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
);

// Health check endpoint
app.get('/health', async (c) => {
  try {
    // Test database connectivity
    await kv.get('health-check');
    
    return c.json({
      status: 'healthy',
      timestamp: new Date().toISOString(),
      services: {
        database: 'connected',
        kv_store: 'operational'
      }
    });
  } catch (error) {
    return c.json({
      status: 'unhealthy',
      error: error.message,
      timestamp: new Date().toISOString()
    }, 500);
  }
});

// Environment variables check
app.get('/testing/env-check', async (c) => {
  const requiredVars = [
    'SUPABASE_URL',
    'SUPABASE_ANON_KEY', 
    'SUPABASE_SERVICE_ROLE_KEY',
    'PAYPAL_CLIENT_ID',
    'PAYPAL_SECRET_KEY'
  ];

  const optionalVars = [
    'AGORA_APP_ID',
    'AGORA_APP_CERTIFICATE',
    'PLATFORM_PAYPAL_MERCHANT_ID'
  ];

  const missing = requiredVars.filter(varName => !Deno.env.get(varName));
  const missingOptional = optionalVars.filter(varName => !Deno.env.get(varName));

  return c.json({
    required: {
      total: requiredVars.length,
      configured: requiredVars.length - missing.length,
      missing: missing
    },
    optional: {
      total: optionalVars.length,
      configured: optionalVars.length - missingOptional.length,
      missing: missingOptional
    },
    status: missing.length === 0 ? 'all_configured' : 'missing_required'
  });
});

// Database connectivity test
app.get('/testing/database-test', async (c) => {
  try {
    // Test KV store operations
    const testKey = `test-${Date.now()}`;
    const testValue = { message: 'Database test', timestamp: Date.now() };
    
    await kv.set(testKey, testValue);
    const retrieved = await kv.get(testKey);
    await kv.del(testKey);

    // Test Supabase Auth
    const { data: users, error } = await supabase.auth.admin.listUsers();
    
    return c.json({
      status: 'success',
      tests: {
        kv_store: retrieved ? 'passed' : 'failed',
        supabase_auth: error ? 'failed' : 'passed',
        user_count: users?.users?.length || 0
      },
      message: 'Database connectivity verified'
    });
  } catch (error) {
    return c.json({
      status: 'error',
      message: 'Database connectivity failed',
      error: error.message
    }, 500);
  }
});

// Profile system test
app.get('/testing/profile-test', async (c) => {
  try {
    // Test profile operations
    const testProfile = {
      id: `test-user-${Date.now()}`,
      email: 'test@example.com',
      name: 'Test User',
      type: 'buyer',
      created_at: new Date().toISOString()
    };

    await kv.set(`profile:${testProfile.id}`, testProfile);
    const retrieved = await kv.get(`profile:${testProfile.id}`);
    await kv.del(`profile:${testProfile.id}`);

    return c.json({
      status: 'success',
      message: 'Profile system operational',
      test_result: retrieved ? 'passed' : 'failed'
    });
  } catch (error) {
    return c.json({
      status: 'error',
      message: 'Profile system test failed',
      error: error.message
    }, 500);
  }
});

// PayPal configuration test
app.get('/testing/paypal-test', async (c) => {
  const clientId = Deno.env.get('PAYPAL_CLIENT_ID');
  const clientSecret = Deno.env.get('PAYPAL_SECRET_KEY');
  const merchantId = Deno.env.get('PLATFORM_PAYPAL_MERCHANT_ID');

  const configured = Boolean(clientId && clientSecret);
  const marketplaceReady = Boolean(merchantId);

  return c.json({
    configured: configured,
    marketplace_ready: marketplaceReady,
    message: configured ? 
      (marketplaceReady ? 'PayPal marketplace fully configured' : 'Basic PayPal configured, marketplace setup needed') :
      'PayPal credentials missing',
    details: {
      client_id: Boolean(clientId),
      client_secret: Boolean(clientSecret),
      merchant_id: Boolean(merchantId)
    }
  });
});

// Invoice system test
app.get('/testing/invoice-test', async (c) => {
  try {
    // Test invoice generation
    const testInvoice = {
      id: `inv-${Date.now()}`,
      buyer_id: 'test-buyer',
      seller_id: 'test-seller',
      amount: 100,
      platform_fee: 8,
      processing_fee: 3.20,
      status: 'pending',
      created_at: new Date().toISOString()
    };

    await kv.set(`invoice:${testInvoice.id}`, testInvoice);
    const retrieved = await kv.get(`invoice:${testInvoice.id}`);
    await kv.del(`invoice:${testInvoice.id}`);

    return c.json({
      status: 'success',
      message: 'Invoice system operational',
      test_invoice: retrieved
    });
  } catch (error) {
    return c.json({
      status: 'error',
      message: 'Invoice system test failed',
      error: error.message
    }, 500);
  }
});

// Notification system test
app.get('/testing/notification-test', async (c) => {
  try {
    // Test notification creation and retrieval
    const testNotification = {
      id: `notif-${Date.now()}`,
      user_id: 'test-user',
      type: 'bid_alert',
      title: 'Test Notification',
      message: 'This is a test notification',
      read: false,
      created_at: new Date().toISOString()
    };

    await kv.set(`notification:${testNotification.id}`, testNotification);
    const retrieved = await kv.get(`notification:${testNotification.id}`);
    await kv.del(`notification:${testNotification.id}`);

    return c.json({
      status: 'success',
      message: 'Notification system operational',
      test_result: retrieved ? 'passed' : 'failed'
    });
  } catch (error) {
    return c.json({
      status: 'error',
      message: 'Notification system test failed',
      error: error.message
    }, 500);
  }
});

// Schedule system test
app.get('/testing/schedule-test', async (c) => {
  try {
    // Test scheduled show creation
    const testShow = {
      id: `show-${Date.now()}`,
      seller_id: 'test-seller',
      title: 'Test Coral Show',
      description: 'Testing scheduled show functionality',
      scheduled_time: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
      status: 'scheduled',
      created_at: new Date().toISOString()
    };

    await kv.set(`scheduled_show:${testShow.id}`, testShow);
    const retrieved = await kv.get(`scheduled_show:${testShow.id}`);
    await kv.del(`scheduled_show:${testShow.id}`);

    return c.json({
      status: 'success',
      message: 'Scheduling system operational',
      test_result: retrieved ? 'passed' : 'failed'
    });
  } catch (error) {
    return c.json({
      status: 'error',
      message: 'Scheduling system test failed',
      error: error.message
    }, 500);
  }
});

// Comprehensive mock data initialization
app.post('/testing/init-comprehensive-mock-data', async (c) => {
  try {
    console.log('🔄 Initializing comprehensive mock data...');

    // Demo users
    const demoUsers = [
      {
        id: 'demo-seller',
        email: 'demo@coralcrave.com',
        name: 'Demo Seller',
        type: 'seller',
        avatar: null,
        rating: 4.8,
        total_sales: 2450,
        created_at: new Date().toISOString()
      },
      {
        id: 'demo-buyer',
        email: 'buyer@coralcrave.com',
        name: 'Demo Buyer',
        type: 'buyer',
        avatar: null,
        total_purchases: 12,
        created_at: new Date().toISOString()
      }
    ];

    // Create demo users in KV store
    for (const user of demoUsers) {
      await kv.set(`profile:${user.id}`, user);
    }

    // Mock coral products
    const coralProducts = [
      {
        id: 'coral-1',
        name: 'Rainbow Acropora Colony',
        description: 'Stunning rainbow acropora with vibrant colors',
        starting_bid: 25,
        current_bid: 45,
        category: 'SPS Coral',
        seller_id: 'demo-seller',
        image_url: 'https://images.unsplash.com/photo-1583212292454-1fe6229603b7?w=400',
        status: 'active'
      },
      {
        id: 'coral-2', 
        name: 'Orange Torch Coral',
        description: 'Beautiful torch coral with flowing tentacles',
        starting_bid: 35,
        current_bid: 65,
        category: 'LPS Coral',
        seller_id: 'demo-seller',
        image_url: 'https://images.unsplash.com/photo-1583212292454-1fe6229603b7?w=400',
        status: 'active'
      },
      {
        id: 'coral-3',
        name: 'Blue Zoa Colony',
        description: 'Bright blue zoanthid colony, easy care',
        starting_bid: 15,
        current_bid: 28,
        category: 'Soft Coral',
        seller_id: 'demo-seller',
        image_url: 'https://images.unsplash.com/photo-1583212292454-1fe6229603b7?w=400',
        status: 'active'
      }
    ];

    // Store coral products
    for (const coral of coralProducts) {
      await kv.set(`product:${coral.id}`, coral);
    }

    // Mock auction queue
    const auctionQueue = {
      id: 'queue-demo-seller',
      seller_id: 'demo-seller',
      products: coralProducts.map(c => c.id),
      current_index: 0,
      created_at: new Date().toISOString()
    };

    await kv.set(`auction_queue:demo-seller`, auctionQueue);

    // Mock bids
    const mockBids = [
      {
        id: 'bid-1',
        product_id: 'coral-1',
        bidder_id: 'demo-buyer',
        amount: 45,
        timestamp: new Date(Date.now() - 5 * 60 * 1000).toISOString()
      },
      {
        id: 'bid-2',
        product_id: 'coral-2',
        bidder_id: 'demo-buyer',
        amount: 65,
        timestamp: new Date(Date.now() - 2 * 60 * 1000).toISOString()
      }
    ];

    for (const bid of mockBids) {
      await kv.set(`bid:${bid.id}`, bid);
    }

    // Mock chat messages
    const chatMessages = [
      {
        id: 'chat-1',
        stream_id: 'demo-stream',
        user_id: 'demo-buyer',
        username: 'Demo Buyer',
        message: 'Beautiful corals! 🪸',
        timestamp: new Date(Date.now() - 10 * 60 * 1000).toISOString()
      },
      {
        id: 'chat-2',
        stream_id: 'demo-stream',
        user_id: 'demo-seller',
        username: 'Demo Seller',
        message: 'Thanks! These are premium quality specimens.',
        timestamp: new Date(Date.now() - 8 * 60 * 1000).toISOString()
      }
    ];

    for (const message of chatMessages) {
      await kv.set(`chat:${message.stream_id}:${message.id}`, message);
    }

    // Mock scheduled shows
    const scheduledShows = [
      {
        id: 'show-1',
        seller_id: 'demo-seller',
        title: 'Premium SPS Coral Auction',
        description: 'High-end SPS corals from our growout tank',
        scheduled_time: new Date(Date.now() + 4 * 60 * 60 * 1000).toISOString(),
        duration: 120,
        status: 'scheduled'
      },
      {
        id: 'show-2',
        seller_id: 'demo-seller',
        title: 'Weekend LPS Special',
        description: 'Large polyp stony corals at great prices',
        scheduled_time: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000).toISOString(),
        duration: 90,
        status: 'scheduled'
      }
    ];

    for (const show of scheduledShows) {
      await kv.set(`scheduled_show:${show.id}`, show);
    }

    // Mock notifications
    const notifications = [
      {
        id: 'notif-1',
        user_id: 'demo-buyer',
        type: 'bid_outbid',
        title: 'You were outbid!',
        message: 'Someone placed a higher bid on Rainbow Acropora Colony',
        read: false,
        created_at: new Date(Date.now() - 5 * 60 * 1000).toISOString()
      },
      {
        id: 'notif-2',
        user_id: 'demo-buyer',
        type: 'show_reminder',
        title: 'Show starting soon!',
        message: 'Premium SPS Coral Auction starts in 15 minutes',
        read: false,
        created_at: new Date(Date.now() - 1 * 60 * 1000).toISOString()
      }
    ];

    for (const notification of notifications) {
      await kv.set(`notification:${notification.user_id}:${notification.id}`, notification);
    }

    console.log('✅ Comprehensive mock data initialized successfully');

    return c.json({
      status: 'success',
      message: 'Comprehensive mock data initialized',
      data: {
        users: demoUsers.length,
        products: coralProducts.length,
        bids: mockBids.length,
        chat_messages: chatMessages.length,
        scheduled_shows: scheduledShows.length,
        notifications: notifications.length
      }
    });

  } catch (error) {
    console.error('❌ Failed to initialize mock data:', error);
    return c.json({
      status: 'error',
      message: 'Failed to initialize mock data',
      error: error.message
    }, 500);
  }
});

// Generate specific mock data types
app.post('/testing/generate-mock-data', async (c) => {
  try {
    const { type } = await c.req.json();
    let count = 0;
    let message = '';

    switch (type) {
      case 'users':
        // Generate demo users
        const users = [
          { id: 'demo-seller', email: 'demo@coralcrave.com', name: 'Demo Seller', type: 'seller' },
          { id: 'demo-buyer', email: 'buyer@coralcrave.com', name: 'Demo Buyer', type: 'buyer' }
        ];
        
        for (const user of users) {
          await kv.set(`profile:${user.id}`, { ...user, created_at: new Date().toISOString() });
        }
        count = users.length;
        message = 'Demo user accounts created';
        break;

      case 'products':
        // Generate coral products
        const products = Array.from({ length: 20 }, (_, i) => ({
          id: `product-${i + 1}`,
          name: `Coral Species ${i + 1}`,
          starting_bid: 10 + (i * 5),
          current_bid: 15 + (i * 8),
          category: ['SPS Coral', 'LPS Coral', 'Soft Coral'][i % 3],
          seller_id: 'demo-seller',
          status: 'active'
        }));

        for (const product of products) {
          await kv.set(`product:${product.id}`, product);
        }
        count = products.length;
        message = 'Coral product inventory created';
        break;

      case 'auctions':
        // Generate active auctions
        const auctions = Array.from({ length: 5 }, (_, i) => ({
          id: `auction-${i + 1}`,
          product_id: `product-${i + 1}`,
          current_bid: 25 + (i * 10),
          time_remaining: 300 - (i * 60),
          bidder_count: 3 + i,
          status: 'active'
        }));

        for (const auction of auctions) {
          await kv.set(`auction:${auction.id}`, auction);
        }
        count = auctions.length;
        message = 'Active auctions created';
        break;

      case 'bids':
        // Generate bid history
        const bids = Array.from({ length: 50 }, (_, i) => ({
          id: `bid-${i + 1}`,
          product_id: `product-${(i % 10) + 1}`,
          bidder_id: i % 2 === 0 ? 'demo-buyer' : 'buyer-2',
          amount: 10 + (i * 2),
          timestamp: new Date(Date.now() - (i * 60 * 1000)).toISOString()
        }));

        for (const bid of bids) {
          await kv.set(`bid:${bid.id}`, bid);
        }
        count = bids.length;
        message = 'Bid history generated';
        break;

      case 'chat':
        // Generate chat messages
        const messages = Array.from({ length: 30 }, (_, i) => ({
          id: `chat-${i + 1}`,
          stream_id: 'demo-stream',
          user_id: i % 2 === 0 ? 'demo-buyer' : 'demo-seller',
          username: i % 2 === 0 ? 'Demo Buyer' : 'Demo Seller',
          message: `Chat message ${i + 1}`,
          timestamp: new Date(Date.now() - (i * 30 * 1000)).toISOString()
        }));

        for (const message of messages) {
          await kv.set(`chat:demo-stream:${message.id}`, message);
        }
        count = messages.length;
        message = 'Chat conversation history created';
        break;

      case 'schedule':
        // Generate scheduled shows
        const shows = Array.from({ length: 7 }, (_, i) => ({
          id: `show-${i + 1}`,
          seller_id: 'demo-seller',
          title: `Coral Show ${i + 1}`,
          scheduled_time: new Date(Date.now() + (i + 1) * 24 * 60 * 60 * 1000).toISOString(),
          status: 'scheduled'
        }));

        for (const show of shows) {
          await kv.set(`scheduled_show:${show.id}`, show);
        }
        count = shows.length;
        message = 'Scheduled shows created for next 7 days';
        break;

      case 'notifications':
        // Generate notifications
        const notifications = Array.from({ length: 15 }, (_, i) => ({
          id: `notif-${i + 1}`,
          user_id: 'demo-buyer',
          type: ['bid_outbid', 'show_reminder', 'payment_received'][i % 3],
          title: `Notification ${i + 1}`,
          message: `Test notification message ${i + 1}`,
          read: i > 10,
          created_at: new Date(Date.now() - (i * 60 * 60 * 1000)).toISOString()
        }));

        for (const notification of notifications) {
          await kv.set(`notification:demo-buyer:${notification.id}`, notification);
        }
        count = notifications.length;
        message = 'Notification alerts generated';
        break;

      default:
        throw new Error(`Unknown mock data type: ${type}`);
    }

    return c.json({
      status: 'success',
      message: message,
      count: count,
      type: type
    });

  } catch (error) {
    console.error(`Failed to generate mock data:`, error);
    return c.json({
      status: 'error',
      message: 'Failed to generate mock data',
      error: error.message
    }, 500);
  }
});

// Clear all test data
app.delete('/testing/clear-mock-data', async (c) => {
  try {
    console.log('🗑️ Clearing all test data...');

    // Get all keys with test prefixes
    const prefixes = [
      'profile:demo-',
      'profile:test-',
      'product:',
      'auction:',
      'bid:',
      'chat:demo-stream:',
      'scheduled_show:',
      'notification:demo-buyer:',
      'notification:test-',
      'auction_queue:'
    ];

    let deletedCount = 0;

    // Note: This is a simplified deletion - in production you'd want more sophisticated cleanup
    for (const prefix of prefixes) {
      try {
        // Try to delete common test keys
        for (let i = 1; i <= 100; i++) {
          try {
            await kv.del(`${prefix}${i}`);
            deletedCount++;
          } catch (e) {
            // Key doesn't exist, continue
          }
        }
      } catch (error) {
        console.warn(`Failed to clear prefix ${prefix}:`, error);
      }
    }

    // Clear specific known keys
    const specificKeys = [
      'auction_queue:demo-seller',
      'profile:demo-seller',
      'profile:demo-buyer'
    ];

    for (const key of specificKeys) {
      try {
        await kv.del(key);
        deletedCount++;
      } catch (e) {
        // Key doesn't exist, continue
      }
    }

    console.log(`✅ Cleared ${deletedCount} test data entries`);

    return c.json({
      status: 'success',
      message: `Cleared ${deletedCount} test data entries`,
      deleted_count: deletedCount
    });

  } catch (error) {
    console.error('❌ Failed to clear test data:', error);
    return c.json({
      status: 'error',
      message: 'Failed to clear test data',
      error: error.message
    }, 500);
  }
});

export default app;