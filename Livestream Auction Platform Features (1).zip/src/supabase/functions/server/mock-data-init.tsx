import { Hono } from 'npm:hono';
import { cors } from 'npm:hono/cors';
import * as kv from './kv_store.tsx';

const app = new Hono();

app.use('*', cors({
  origin: '*',
  allowMethods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowHeaders: ['Content-Type', 'Authorization'],
}));

// Initialize mock data for development and demo
app.post('/make-server-9f7745d8/init-mock-data', async (c) => {
  try {
    console.log('Initializing mock data for Coral Crave platform...');

    // Initialize mock auction items
    await initMockAuctionItems();
    
    // Initialize mock user profiles
    await initMockUserProfiles();
    
    // Initialize mock forum posts
    await initMockForumPosts();
    
    // Initialize mock care guides
    await initMockCareGuides();
    
    // Initialize mock notifications
    await initMockNotifications();

    console.log('Mock data initialization completed');

    return c.json({ 
      success: true, 
      message: 'Mock data initialized successfully',
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    console.error('Mock data initialization error:', error);
    return c.json({ error: 'Failed to initialize mock data' }, 500);
  }
});

// Get initialization status
app.get('/make-server-9f7745d8/mock-data-status', async (c) => {
  try {
    const auctions = await kv.getByPrefix('auction_item_');
    const users = await kv.getByPrefix('user_profile_');
    const forumPosts = await kv.getByPrefix('forum_post_');
    const careGuides = await kv.getByPrefix('care_guide_');

    const status = {
      auctionItems: auctions.length,
      userProfiles: users.length,
      forumPosts: forumPosts.length,
      careGuides: careGuides.length,
      lastInitialized: new Date().toISOString()
    };

    return c.json(status);

  } catch (error) {
    console.error('Get mock data status error:', error);
    return c.json({ error: 'Failed to get mock data status' }, 500);
  }
});

async function initMockAuctionItems() {
  const auctionItems = [
    {
      id: 'auction_1',
      title: 'Rainbow Acropora Colony',
      description: 'Stunning rainbow acropora colony with amazing polyp extension. Approximately 6 inches in diameter. Under LED lighting for 2+ years.',
      category: 'SPS Corals',
      images: ['https://images.unsplash.com/photo-1583212292454-1fe6229603b7?w=300&h=200&fit=crop'],
      startingBid: 50,
      currentBid: 95,
      reservePrice: 80,
      status: 'live',
      endTime: new Date(Date.now() + 2 * 60 * 60 * 1000).toISOString(), // 2 hours from now
      seller: {
        id: 'seller_1',
        name: 'CoralKing_Reef',
        rating: 4.8,
        verified: true,
        location: 'California, US'
      },
      views: 245,
      watchers: 12,
      tags: ['acropora', 'rainbow', 'sps', 'colony'],
      createdAt: new Date().toISOString()
    },
    {
      id: 'auction_2',
      title: 'Blue Tang - Juvenile',
      description: 'Healthy juvenile blue tang (Paracanthurus hepatus). Eating well, disease-free, and ready for a new home.',
      category: 'Fish',
      images: ['https://images.unsplash.com/photo-1559827260-dc66d52bef19?w=300&h=200&fit=crop'],
      startingBid: 25,
      currentBid: 45,
      status: 'live',
      endTime: new Date(Date.now() + 1.5 * 60 * 60 * 1000).toISOString(), // 1.5 hours from now
      seller: {
        id: 'seller_2',
        name: 'AquaLife_Pro',
        rating: 4.9,
        verified: true,
        location: 'Florida, US'
      },
      views: 189,
      watchers: 8,
      tags: ['tang', 'fish', 'juvenile', 'marine'],
      createdAt: new Date().toISOString()
    },
    {
      id: 'auction_3',
      title: 'Torch Coral Frags (5 Pack)',
      description: 'Pack of 5 torch coral frags in various colors including green and orange. All frags are healthy and showing good extension.',
      category: 'LPS Corals',
      images: ['https://images.unsplash.com/photo-1583212292454-1fe6229603b7?w=300&h=200&fit=crop'],
      startingBid: 75,
      currentBid: 120,
      status: 'scheduled',
      startTime: new Date(Date.now() + 2 * 60 * 60 * 1000).toISOString(), // starts in 2 hours
      endTime: new Date(Date.now() + 4 * 60 * 60 * 1000).toISOString(), // ends in 4 hours
      seller: {
        id: 'seller_3',
        name: 'FragFarm_Direct',
        rating: 4.7,
        verified: false,
        location: 'Texas, US'
      },
      views: 67,
      watchers: 15,
      tags: ['torch', 'lps', 'frags', 'pack'],
      createdAt: new Date().toISOString()
    }
  ];

  for (const item of auctionItems) {
    await kv.set(`auction_item_${item.id}`, item);
  }

  console.log('Initialized', auctionItems.length, 'mock auction items');
}

async function initMockUserProfiles() {
  const userProfiles = [
    {
      id: 'seller_1',
      name: 'CoralKing Reef',
      username: '@coralking_reef',
      email: 'coralking@example.com',
      avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face',
      bio: 'Professional coral propagator with 15+ years of experience. Specializing in rare SPS and LPS corals.',
      location: 'San Diego, California',
      verified: true,
      rating: 4.8,
      totalRatings: 342,
      joinDate: '2019-03-15',
      stats: {
        totalSales: 1847,
        totalRevenue: 45720,
        successRate: 98.2
      },
      badges: ['Top Seller', 'Verified Propagator', 'Expert Shipper'],
      specializations: ['SPS Corals', 'LPS Corals', 'Coral Propagation']
    },
    {
      id: 'seller_2',
      name: 'AquaLife Pro',
      username: '@aqualife_pro',
      email: 'aqualife@example.com',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face',
      bio: 'Marine fish specialist and aquarium equipment expert. Quality fish and reliable service.',
      location: 'Miami, Florida',
      verified: true,
      rating: 4.9,
      totalRatings: 156,
      joinDate: '2020-01-10',
      stats: {
        totalSales: 892,
        totalRevenue: 32150,
        successRate: 96.8
      },
      badges: ['Fish Expert', 'Fast Shipping', 'Community Favorite'],
      specializations: ['Marine Fish', 'Equipment', 'Water Chemistry']
    },
    {
      id: 'seller_3',
      name: 'FragFarm Direct',
      username: '@fragfarm_direct',
      email: 'fragfarm@example.com',
      bio: 'Family-owned coral farm specializing in aquacultured corals and sustainable practices.',
      location: 'Austin, Texas',
      verified: false,
      rating: 4.7,
      totalRatings: 89,
      joinDate: '2021-06-20',
      stats: {
        totalSales: 634,
        totalRevenue: 28940,
        successRate: 94.1
      },
      badges: ['Sustainable Grower'],
      specializations: ['Coral Frags', 'Aquaculture', 'Soft Corals']
    }
  ];

  for (const profile of userProfiles) {
    await kv.set(`user_profile_${profile.id}`, profile);
  }

  console.log('Initialized', userProfiles.length, 'mock user profiles');
}

async function initMockForumPosts() {
  const forumPosts = [
    {
      id: 'post_1',
      title: 'Help! My Acropora is losing color',
      content: 'I noticed my rainbow acropora colony has been losing its vibrant colors over the past week. Water parameters seem fine - pH 8.2, salinity 1.025, nitrates <5ppm. Lighting is unchanged (AI Prime 16HD). Any suggestions?',
      author: {
        id: 'user_4',
        name: 'ReefNewbie_23',
        avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=40&h=40&fit=crop&crop=face',
        reputation: 156,
        badge: 'New Member'
      },
      category: 'SPS Corals',
      timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(), // 2 hours ago
      replies: 8,
      views: 124,
      likes: 3,
      isPinned: false,
      isAnswered: false,
      tags: ['acropora', 'color-loss', 'help']
    },
    {
      id: 'post_2',
      title: 'Best practices for coral fragging',
      content: 'Sharing my experience with fragging different types of corals. Here are some tips I\'ve learned over the years: 1) Always use clean, sharp tools, 2) Let cuts heal in low flow, 3) Monitor water quality closely...',
      author: {
        id: 'user_5',
        name: 'FragMaster_Dave',
        avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=40&h=40&fit=crop&crop=face',
        reputation: 2847,
        badge: 'Expert'
      },
      category: 'General Discussion',
      timestamp: new Date(Date.now() - 5 * 60 * 60 * 1000).toISOString(), // 5 hours ago
      replies: 23,
      views: 456,
      likes: 18,
      isPinned: true,
      isAnswered: true,
      tags: ['fragging', 'tips', 'coral-care']
    }
  ];

  for (const post of forumPosts) {
    await kv.set(`forum_post_${post.id}`, post);
  }

  console.log('Initialized', forumPosts.length, 'mock forum posts');
}

async function initMockCareGuides() {
  const careGuides = [
    {
      id: 'guide_1',
      title: 'Complete Guide to Acropora Care',
      description: 'Everything you need to know about keeping healthy SPS corals, from water parameters to lighting requirements.',
      content: 'Acropora corals are among the most beautiful and challenging corals to keep in a reef aquarium...',
      category: 'Coral Care',
      difficulty: 'Intermediate',
      readTime: 12,
      rating: 4.8,
      ratingCount: 156,
      author: {
        id: 'user_6',
        name: 'Dr. Sarah Reef',
        avatar: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?w=40&h=40&fit=crop&crop=face',
        verified: true
      },
      coverImage: 'https://images.unsplash.com/photo-1583212292454-1fe6229603b7?w=400&h=250&fit=crop',
      tags: ['acropora', 'sps', 'care-guide'],
      lastUpdated: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString() // 5 days ago
    },
    {
      id: 'guide_2',
      title: 'Beginner\'s Guide to Marine Aquariums',
      description: 'Starting your first saltwater tank? This comprehensive guide covers everything from equipment to first fish.',
      content: 'Welcome to the amazing world of marine aquariums! This guide will walk you through everything...',
      category: 'Getting Started',
      difficulty: 'Beginner',
      readTime: 20,
      rating: 4.9,
      ratingCount: 234,
      author: {
        id: 'user_7',
        name: 'Reef Mentor',
        avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=40&h=40&fit=crop&crop=face',
        verified: true
      },
      coverImage: 'https://images.unsplash.com/photo-1559827260-dc66d52bef19?w=400&h=250&fit=crop',
      tags: ['beginner', 'setup', 'equipment'],
      lastUpdated: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000).toISOString() // 10 days ago
    }
  ];

  for (const guide of careGuides) {
    await kv.set(`care_guide_${guide.id}`, guide);
  }

  console.log('Initialized', careGuides.length, 'mock care guides');
}

async function initMockNotifications() {
  // Create sample notifications for the first user
  const notifications = [
    {
      id: 'notif_1',
      type: 'auction_ending',
      title: 'Auction Ending Soon!',
      message: 'Rainbow Acropora Colony auction ends in 15 minutes',
      timestamp: new Date(Date.now() - 30 * 60 * 1000).toISOString(), // 30 minutes ago
      read: false,
      actionRequired: true,
      relatedItem: {
        id: 'auction_1',
        title: 'Rainbow Acropora Colony',
        image: 'https://images.unsplash.com/photo-1583212292454-1fe6229603b7?w=60&h=60&fit=crop',
        price: 95
      }
    },
    {
      id: 'notif_2',
      type: 'new_listing',
      title: 'New listing from CoralKing_Reef',
      message: 'Premium Clownfish Pair just went live',
      timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(), // 2 hours ago
      read: false,
      actionRequired: false,
      relatedItem: {
        id: 'auction_4',
        title: 'Premium Clownfish Pair',
        price: 75
      },
      sender: {
        name: 'CoralKing_Reef',
        avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=40&h=40&fit=crop&crop=face'
      }
    }
  ];

  // Add notifications for a sample user
  for (const notification of notifications) {
    await kv.set(`notification_seller_1_${notification.id}`, notification);
  }

  console.log('Initialized', notifications.length, 'mock notifications');
}

export default app;