# Coral Crave - Production PayPal Setup Guide

## 🎉 Production PayPal Configuration Complete!

Your Coral Crave platform has been successfully updated to use **live PayPal payments** instead of sandbox mode. 

### ✅ What's Been Updated:

#### 1. **PayPal Backend Configuration**
- **Live PayPal API**: Updated to use `https://api-m.paypal.com` (production endpoint)
- **Production Mode**: All PayPal transactions will now process real money
- **Marketplace Payments**: Split payment system with 8% + $0.30 platform fees

#### 2. **Frontend PayPal Integration**
- **Dynamic Client ID**: PayPal SDK now loads your live client ID from server
- **Production Mode**: PayPal buttons configured for live transactions
- **Error Handling**: Improved error messages for production use

#### 3. **Environment Variables Required**
Your platform is configured to use these live PayPal credentials:

```bash
PAYPAL_CLIENT_ID=your_live_paypal_client_id
PAYPAL_SECRET_KEY=your_live_paypal_secret_key
PLATFORM_PAYPAL_MERCHANT_ID=your_platform_merchant_id
PLATFORM_FEE_PERCENT=0.08
PLATFORM_FEE_FLAT=0.30
```

---

## 🔧 Next Steps for Production Deployment:

### 1. **Update PayPal Credentials**
You need to replace the environment variables with your **live PayPal credentials**:

1. **Go to PayPal Developer Console**: https://developer.paypal.com/
2. **Switch to Live Mode** (toggle in top right)
3. **Create Live App** or use existing live app
4. **Get Live Credentials**:
   - Client ID (starts with `A...`)
   - Client Secret 
   - Your merchant ID

### 2. **Update Supabase Environment Variables**
In your Supabase project dashboard:

1. Go to **Settings** → **Edge Functions** → **Environment Variables**
2. Update these variables with your **live PayPal credentials**:

```bash
PAYPAL_CLIENT_ID=your_live_client_id_here
PAYPAL_SECRET_KEY=your_live_secret_key_here
PLATFORM_PAYPAL_MERCHANT_ID=your_live_merchant_id_here
```

### 3. **Reset Supabase Database Password**
As you mentioned, you need to reset your Supabase database password:

1. Go to **Settings** → **Database** 
2. Click **Reset database password**
3. Update `SUPABASE_DB_URL` with new password
4. Restart your Edge Functions if needed

---

## 💰 PayPal Fee Structure (Production Ready):

### **Buyer Experience:**
- Pays **full winning bid amount**
- **No additional fees** to buyers
- Clean, transparent pricing

### **Seller Fee Structure:**
- **8% platform commission** on sale amount
- **2.9% + $0.30** PayPal processing fee
- **Example**: $100 sale = $88.70 to seller

### **Payment Flow:**
1. Buyer wins auction for $100
2. Buyer pays exactly $100 via PayPal
3. PayPal automatically splits:
   - **$88.70** → Seller (after all fees)
   - **$8.00** → Platform commission (8%)
   - **$3.30** → PayPal processing fees

---

## 🚨 Important Production Considerations:

### **1. PayPal App Approval**
Your live PayPal app may need approval for:
- **Marketplace payments** 
- **Split payment features**
- **High transaction volumes**

### **2. Testing Before Go-Live**
- Test with **small amounts first** ($1-5)
- Verify seller onboarding flow works
- Confirm fee calculations are correct
- Test refund/dispute processes

### **3. Compliance & Legal**
- Ensure your **Terms of Service** mention fees
- Add **Privacy Policy** for payment data
- Consider **tax implications** of platform fees
- Review **PayPal's Acceptable Use Policy**

### **4. Monitoring & Support**
- Monitor PayPal webhooks for payment status
- Set up alerts for failed transactions
- Have customer support process for payment issues
- Keep detailed transaction logs

---

## 🔍 How to Verify Production Setup:

### **1. Check PayPal Configuration**
```bash
# Test the PayPal client ID endpoint
curl https://your-project.supabase.co/functions/v1/make-server-9f7745d8/config/paypal-client-id
```

Should return:
```json
{
  "clientId": "your_live_client_id",
  "mode": "production",
  "timestamp": "2024-..."
}
```

### **2. Test Small Transaction**
1. Create test auction with $1 item
2. Go through full payment flow
3. Verify money actually transfers
4. Check seller receives correct amount

### **3. Verify Fee Calculation**
- Use PayPal's fee calculator
- Test with different amounts
- Ensure platform fees are correctly deducted

---

## 📞 Support & Resources:

### **PayPal Resources:**
- [PayPal Developer Docs](https://developer.paypal.com/docs/)
- [Marketplace Payments Guide](https://developer.paypal.com/docs/marketplaces/)
- [PayPal Support](https://www.paypal.com/us/smarthelp/contact-us)

### **If You Need Help:**
1. **PayPal Integration Issues**: Check PayPal developer logs
2. **Supabase Issues**: Check Edge Function logs
3. **Platform Issues**: Review server logs in Supabase dashboard

---

## 🎯 Status Summary:

### ✅ **COMPLETED:**
- PayPal backend switched to production API
- Frontend updated for live payments
- Fee structure implemented
- Error handling improved

### 🔄 **YOUR ACTION ITEMS:**
1. Get live PayPal credentials
2. Update Supabase environment variables  
3. Reset Supabase database password
4. Test with small transaction

### 🚀 **READY FOR:**
- Live PayPal transactions
- Real money processing
- Marketplace split payments
- Production deployment

---

**Your Coral Crave platform is now production-ready for PayPal payments! 🎉**

Just update those environment variables with your live PayPal credentials and you'll be processing real transactions.