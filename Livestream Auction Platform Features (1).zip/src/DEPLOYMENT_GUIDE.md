# 🚀 Coral Crave - Production Deployment Guide

## Pre-Deployment Checklist

### ✅ **Environment Variables**
Ensure these are configured in your hosting platform:

```bash
# Required - Supabase
SUPABASE_URL=your_production_supabase_url
SUPABASE_ANON_KEY=your_production_anon_key
SUPABASE_SERVICE_ROLE_KEY=your_production_service_role_key

# Required - Agora (Live Streaming)
AGORA_APP_ID=your_agora_app_id
AGORA_APP_CERTIFICATE=your_agora_app_certificate

# Required - PayPal (Payments)
PAYPAL_CLIENT_ID=your_production_paypal_client_id
PAYPAL_SECRET_KEY=your_production_paypal_secret_key

# Production Settings
NODE_ENV=production
NEXT_PUBLIC_SITE_URL=https://your-domain.com
```

### ✅ **OAuth Configuration**

#### Supabase Authentication Setup:
1. Go to Supabase Dashboard → Authentication → Settings
2. Add your production URLs to "Site URL" and "Redirect URLs":
   ```
   Site URL: https://your-domain.com
   Redirect URLs: 
   - https://your-domain.com
   - https://your-domain.com/**
   ```

#### Google OAuth Setup:
1. Go to [Google Cloud Console](https://console.cloud.google.com)
2. Navigate to APIs & Services → Credentials
3. Edit your OAuth 2.0 Client ID
4. Add Authorized domains:
   ```
   https://your-domain.com
   ```
5. Add Authorized redirect URIs:
   ```
   https://your-supabase-project.supabase.co/auth/v1/callback
   ```

## Deployment Options

### **Option 1: Vercel (Recommended)**

1. **Install Vercel CLI:**
   ```bash
   npm install -g vercel
   ```

2. **Deploy:**
   ```bash
   vercel --prod
   ```

3. **Configure Environment Variables in Vercel Dashboard:**
   - Go to your project settings
   - Add all environment variables from `.env.production`

### **Option 2: Netlify**

1. **Build and Deploy:**
   ```bash
   npm run build
   ```

2. **Upload `dist` folder to Netlify**

3. **Configure Environment Variables in Netlify Dashboard**

### **Option 3: Custom Server (VPS/AWS/DigitalOcean)**

1. **Build for production:**
   ```bash
   npm run build
   ```

2. **Serve with a production server (nginx + Node.js)**

## Post-Deployment Tasks

### **1. Initialize Database**
```bash
curl -X POST https://your-domain.com/functions/v1/make-server-9f7745d8/init-database \
  -H "Authorization: Bearer YOUR_SUPABASE_ANON_KEY"
```

### **2. Test Core Functionality**

#### Authentication Test:
- [ ] Google sign-in works
- [ ] User sessions persist
- [ ] Sign-out works

#### Live Streaming Test:
- [ ] Camera access works
- [ ] Agora streams connect
- [ ] Audio/video quality is good
- [ ] Multiple viewers can join

#### Bidding System Test:
- [ ] Bids are placed successfully
- [ ] Real-time updates work
- [ ] Timer countdown functions
- [ ] Authentication is required

#### Payment System Test:
- [ ] PayPal integration works
- [ ] Test transactions process
- [ ] Seller fees calculated correctly
- [ ] Invoices generate properly

### **3. Performance Monitoring**

#### Set up monitoring:
- [ ] Check Core Web Vitals
- [ ] Monitor API response times
- [ ] Track user engagement
- [ ] Monitor error rates

#### Key metrics to watch:
- **Page Load Time:** < 3 seconds
- **First Contentful Paint:** < 1.5 seconds
- **Largest Contentful Paint:** < 2.5 seconds
- **Time to Interactive:** < 3 seconds

### **4. Security Configuration**

#### SSL/HTTPS:
- [ ] SSL certificate installed
- [ ] HTTP redirects to HTTPS
- [ ] Mixed content warnings resolved

#### Content Security Policy:
- [ ] CSP headers configured (already in netlify.toml/vercel.json)
- [ ] XSS protection enabled
- [ ] Frame options set

## Troubleshooting Common Issues

### **OAuth Issues:**
```bash
# Check redirect URIs match exactly
# Ensure domain is added to authorized domains
# Verify Supabase auth settings
```

### **Agora Connection Issues:**
```bash
# Verify AGORA_APP_ID and AGORA_APP_CERTIFICATE
# Check firewall settings allow WebRTC
# Test in incognito mode
```

### **PayPal Integration Issues:**
```bash
# Ensure using production PayPal credentials
# Verify webhook URLs are configured
# Check PayPal app settings
```

### **Supabase Issues:**
```bash
# Verify all environment variables are set
# Check Supabase service status
# Ensure database is properly initialized
```

## Performance Optimization

### **Frontend Optimizations Applied:**
- ✅ Lazy loading of components
- ✅ Memoized components
- ✅ Error boundaries
- ✅ Code splitting
- ✅ Optimized images

### **Backend Optimizations:**
- ✅ Edge Functions for low latency
- ✅ Connection pooling
- ✅ Proper error handling
- ✅ Rate limiting

## Support & Maintenance

### **Regular Tasks:**
- Monitor user feedback
- Check error logs weekly
- Update dependencies monthly
- Backup database regularly
- Review performance metrics

### **Scaling Considerations:**
- Monitor Supabase usage limits
- Consider CDN for static assets
- Optimize database queries
- Add caching layers if needed

## Success Metrics

### **Day 1 Targets:**
- [ ] 99% uptime
- [ ] < 3 second page load
- [ ] Successful OAuth flow
- [ ] Working live streams
- [ ] Functional payments

### **Week 1 Targets:**
- [ ] User registrations
- [ ] Live auction completions
- [ ] Payment transactions
- [ ] Active community engagement

## 🎉 Launch Ready!

Your Coral Crave platform is now production-ready with:
- ✅ Real-time auction bidding
- ✅ Live video streaming  
- ✅ Secure payments
- ✅ Mobile-responsive design
- ✅ Error handling & monitoring
- ✅ Production optimizations

**Next Steps:**
1. Choose your deployment platform
2. Configure environment variables
3. Set up OAuth redirects
4. Deploy and test
5. Monitor and optimize

Good luck with your launch! 🚀