# Coral Crave - Unified Explore & Go Live Journey Testing Guide

## 🎯 **Overview**
This guide covers testing the new unified user journey that seamlessly connects buyers and sellers through the Explore discovery hub and streamlined Go Live experience.

## ✅ **Testing Checklist**

### **Phase 1: Explore Page (Buyer Discovery Hub)**

#### **1.1 Top Navigation Bar**
- [ ] **Logo Display**: Coral Crave logo appears correctly
- [ ] **Search Bar**: "Search Coral Crave" placeholder shows, typing works
- [ ] **Notification Bell**: Bell icon is clickable and shows notifications
- [ ] **Profile Icon**: Shows user avatar when logged in, generic icon when not

#### **1.2 Categories Carousel**
- [ ] **Category Buttons**: All categories (All, Corals 🌊, Fish 🐠, Equipment ⚙️, Trending) display
- [ ] **Horizontal Scroll**: Categories scroll smoothly on mobile
- [ ] **Selection State**: Selected category highlights properly
- [ ] **Filter Function**: Selecting categories filters the stream grid

#### **1.3 Featured Stream Banner**
- [ ] **Thumbnail Display**: Large banner image loads correctly
- [ ] **Live Badge**: Red "🔴 Live" badge animates with pulse effect
- [ ] **Viewer Count**: Eye icon + viewer count display in top-right
- [ ] **Seller Info**: Profile image, name, verification badge, rating visible
- [ ] **Current Item**: Auction item title, current bid, time left show
- [ ] **Join Live Button**: Button is prominent and clickable

#### **1.4 Live Stream Grid**
- [ ] **Card Layout**: Responsive grid (1 col mobile, 2-3 cols desktop)
- [ ] **Stream Thumbnails**: Images load and display properly
- [ ] **Live Badges**: Each card shows "🔴 Live" badge
- [ ] **Seller Profiles**: Avatar and name display on each card
- [ ] **Viewer Counts**: Eye icon + count show on each stream
- [ ] **Current Auction Info**: Item title, bid, time left appear
- [ ] **Hover Effects**: Cards have subtle hover animations
- [ ] **Join Live Buttons**: All buttons are functional

#### **1.5 Real-time Updates**
- [ ] **Auto-refresh**: Grid updates every 30 seconds
- [ ] **Viewer Counts**: Numbers update with live changes
- [ ] **Bid Updates**: Current bids refresh automatically
- [ ] **Time Countdown**: Auction timers count down in real-time
- [ ] **New Streams**: New live streams appear in grid automatically

#### **1.6 Search & Filtering**
- [ ] **Search Input**: Typing in search bar filters results
- [ ] **Category Filter**: Each category shows relevant streams only  
- [ ] **Trending Logic**: Trending sorts by highest viewer count
- [ ] **Empty States**: Proper messages when no results found
- [ ] **Search Clear**: Clearing search restores full results

### **Phase 2: Go Live Flow (Seller Journey)**

#### **2.1 Seller Dashboard**
- [ ] **Dashboard Access**: Go Live tab/button accessible when logged in
- [ ] **Stats Cards**: Active streams, total viewers, products ready display
- [ ] **Current Time**: Live clock shows accurate current time
- [ ] **Go Live Button**: Prominent red "Go Live" button visible

#### **2.2 Go Live Modal (Step 2)**
- [ ] **Modal Opening**: Clicking "Go Live" opens modal instantly
- [ ] **Stream Title**: Required field with proper validation
- [ ] **Description**: Optional textarea for stream description
- [ ] **Product Selection**: Dropdown shows queued products
- [ ] **Thumbnail Upload**: File upload button works
- [ ] **Auto Thumbnail**: "Auto Generate" creates placeholder image
- [ ] **Timer Options**: 30s, 1m, 2m, 5m options available
- [ ] **Form Validation**: Prevents submission without required fields

#### **2.3 Stream Start Process**
- [ ] **Loading State**: "Starting..." shows during stream creation
- [ ] **Backend Call**: API request to start stream succeeds
- [ ] **Channel Creation**: Agora channel name generated properly
- [ ] **Stream Data**: All form data passed to live stream correctly
- [ ] **Error Handling**: Failed starts show proper error messages
- [ ] **Modal Close**: Modal closes after successful start

#### **2.4 Product Queue Management**
- [ ] **Add Product**: "Add Product" button opens product form
- [ ] **Product Form**: Title, description, category, starting bid fields
- [ ] **Category Selection**: Dropdown with all coral/fish/equipment types
- [ ] **Image Generation**: Auto-generates placeholder product images
- [ ] **Product Cards**: Added products display in grid format
- [ ] **Product Selection**: Products available in Go Live modal dropdown

### **Phase 3: Live Stream Experience**

#### **3.1 Stream Visibility**
- [ ] **Instant Appearance**: Stream appears in Explore grid immediately
- [ ] **Stream Data**: Title, seller info, thumbnail display correctly
- [ ] **Live Badge**: Stream shows as live with animated badge
- [ ] **Viewer Count**: Starts at 0, increments when viewers join
- [ ] **Stream Quality**: Video/audio quality is acceptable

#### **3.2 Seller View (Host)**
- [ ] **Host Controls**: Seller has host privileges in stream
- [ ] **Stream Info**: Title and description display in stream
- [ ] **Product Management**: Can switch between queued products
- [ ] **Viewer Stats**: Can see current viewer count
- [ ] **Stream Controls**: Can end stream when ready

#### **3.3 Buyer View (Viewer)**
- [ ] **Stream Access**: Clicking "Join Live" enters stream properly
- [ ] **Video Quality**: Stream video displays clearly
- [ ] **Chat Function**: Live chat works between viewers
- [ ] **Bidding Panel**: Auction interface functions correctly
- [ ] **Back Navigation**: Can return to Explore page easily

### **Phase 4: Integration & Flow Testing**

#### **4.1 Complete Buyer Journey**
1. [ ] **Discovery**: Open app → Explore page loads with streams
2. [ ] **Browsing**: Browse categories, use search, view featured stream
3. [ ] **Selection**: Click on a stream card → "Join Live" button
4. [ ] **Stream Entry**: Successfully enter live stream viewer
5. [ ] **Interaction**: Chat messages send, bidding works
6. [ ] **Exit**: Return to Explore page seamlessly

#### **4.2 Complete Seller Journey**
1. [ ] **Dashboard**: Navigate to Go Live → Seller dashboard loads
2. [ ] **Preparation**: Add products to queue if needed
3. [ ] **Go Live Modal**: Click "Go Live" → Modal opens
4. [ ] **Stream Setup**: Fill form, select product, set timer
5. [ ] **Stream Start**: Click "Start Streaming" → Stream begins
6. [ ] **Live Management**: Stream appears in Explore, manage auction
7. [ ] **Stream End**: End stream → Removed from Explore grid

#### **4.3 Cross-Platform Testing**
- [ ] **Mobile Responsive**: All features work on mobile devices
- [ ] **Desktop Layout**: Proper sidebar navigation on desktop
- [ ] **Tablet View**: Medium screen sizes display correctly
- [ ] **Touch Interactions**: Mobile touch gestures work properly
- [ ] **Keyboard Navigation**: Desktop keyboard shortcuts function

### **Phase 5: Error Handling & Edge Cases**

#### **5.1 Authentication Flow**
- [ ] **Auth Required**: Proper prompts for login when needed
- [ ] **Auth Modal**: Login modal opens for protected actions
- [ ] **Session Handling**: Maintains login state across navigation
- [ ] **Auto-redirect**: Redirects properly after authentication

#### **5.2 Network & Error States**
- [ ] **Loading States**: Skeleton screens during data loading
- [ ] **Empty States**: Proper messages when no streams available
- [ ] **Error Messages**: Clear error messages for failed actions
- [ ] **Retry Logic**: Failed requests can be retried
- [ ] **Offline Handling**: Graceful degradation when offline

#### **5.3 Data Validation**
- [ ] **Form Validation**: Required fields properly validated
- [ ] **Input Limits**: Character limits enforced on text fields
- [ ] **Number Validation**: Numeric fields only accept valid numbers
- [ ] **Image Validation**: Only valid image files accepted for upload

## 🚨 **Common Issues & Solutions**

### **Issue: Streams Not Appearing**
- **Check**: Backend API is running and accessible
- **Check**: Mock data initialization completed
- **Solution**: Run `POST /init-mock-data` endpoint

### **Issue: Go Live Button Not Working**
- **Check**: User is properly authenticated
- **Check**: Form validation passing
- **Solution**: Ensure all required fields are filled

### **Issue: Stream Not Starting**
- **Check**: Agora configuration is correct
- **Check**: User has necessary permissions
- **Solution**: Verify Agora App ID and credentials

### **Issue: Real-time Updates Not Working**
- **Check**: WebSocket connections are established
- **Check**: Auto-refresh intervals are running
- **Solution**: Check browser console for connection errors

## 📊 **Success Metrics**

### **Buyer Experience Success**
- [ ] Can discover streams in under 5 seconds
- [ ] Can join a stream in under 3 clicks
- [ ] Stream loads within 10 seconds
- [ ] Can navigate back to Explore seamlessly

### **Seller Experience Success**
- [ ] Can start streaming in under 2 minutes
- [ ] Stream appears in Explore within 30 seconds
- [ ] Product queue management is intuitive
- [ ] Go Live modal completes in under 1 minute

### **Technical Performance**
- [ ] Page load times under 3 seconds
- [ ] Stream latency under 5 seconds
- [ ] Real-time updates within 30 seconds
- [ ] Mobile performance equivalent to desktop

## 🎉 **Final Validation**

The unified Explore & Go Live journey is successful when:

1. **Seamless Discovery**: Buyers can easily find and join live streams
2. **Intuitive Streaming**: Sellers can quickly start professional-looking streams
3. **Real-time Connection**: Live updates create dynamic, engaging experience
4. **Cross-platform Consistency**: Works equally well on all devices
5. **Error Recovery**: Gracefully handles all error conditions

## 📱 **Mobile-First Validation**

Special attention to mobile experience:
- [ ] **Bottom Navigation**: Easy thumb navigation
- [ ] **Touch Targets**: All buttons are finger-friendly
- [ ] **Swipe Gestures**: Category carousel swipes smoothly
- [ ] **Vertical Scrolling**: Infinite scroll works properly
- [ ] **Modal UX**: Modals are mobile-optimized

---

**🎯 Priority Testing Order:**
1. Basic Explore page functionality
2. Go Live modal completion
3. Stream visibility and joining
4. Real-time updates and interactions
5. Error states and edge cases
6. Mobile responsiveness
7. Cross-browser compatibility

This unified journey creates a seamless connection between buyers discovering content and sellers creating it, forming the core of the Coral Crave marketplace experience.