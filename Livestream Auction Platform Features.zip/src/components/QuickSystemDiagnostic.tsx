import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Alert, AlertDescription } from './ui/alert';
import { AlertTriangle, CheckCircle, XCircle, Clock } from 'lucide-react';
import { supabase } from '../utils/supabase/client';
import { projectId } from '../utils/supabase/info';

interface QuickSystemDiagnosticProps {
  user?: { id: string; email: string; name: string } | null;
}

export function QuickSystemDiagnostic({ user }: QuickSystemDiagnosticProps) {
  const [diagnostic, setDiagnostic] = useState<any>(null);
  const [isRunning, setIsRunning] = useState(false);

  const runDiagnostic = async () => {
    setIsRunning(true);
    setDiagnostic(null);

    const result = {
      timestamp: new Date().toISOString(),
      user: user ? { id: user.id, email: user.email } : null,
      auth: {
        sessionExists: false,
        accessToken: null,
        userValid: false,
        error: null
      },
      environment: {
        projectId,
        baseUrl: `https://${projectId}.supabase.co/functions/v1/make-server-9f7745d8`,
        userAgent: navigator.userAgent
      },
      apiTests: {
        serverHealth: null,
        paypalTest: null,
        biddingTest: null,
        debugInfo: null
      }
    };

    // Test 1: Authentication
    try {
      const { data: { session }, error } = await supabase.auth.getSession();
      result.auth.sessionExists = !!session;
      result.auth.accessToken = session?.access_token ? 'present' : 'missing';
      result.auth.userValid = !!session?.user;
      if (error) result.auth.error = error.message;
    } catch (authError) {
      result.auth.error = authError instanceof Error ? authError.message : 'Unknown auth error';
    }

    // Test 2: Server Health (try multiple endpoints)
    try {
      console.log('🔍 Testing server health...');
      
      // Try the main health endpoint first
      let healthResponse;
      try {
        healthResponse = await fetch(`${result.environment.baseUrl}/health`);
        console.log('🔍 Health endpoint response:', healthResponse.status);
      } catch (healthError) {
        console.log('🔍 Health endpoint failed, trying ping endpoint...');
        // If health fails, try ping endpoint
        healthResponse = await fetch(`${result.environment.baseUrl}/ping`);
        console.log('🔍 Ping endpoint response:', healthResponse.status);
      }
      
      result.apiTests.serverHealth = {
        status: healthResponse.status,
        ok: healthResponse.ok,
        statusText: healthResponse.statusText
      };

      if (healthResponse.ok) {
        try {
          const healthData = await healthResponse.json();
          result.apiTests.serverHealth.details = healthData;
          console.log('✅ Server health data:', healthData);
        } catch (jsonError) {
          const textData = await healthResponse.text();
          result.apiTests.serverHealth.text = textData;
          console.log('✅ Server health text:', textData);
        }
      } else {
        try {
          const errorData = await healthResponse.json();
          result.apiTests.serverHealth.error = errorData;
          console.log('❌ Server health error data:', errorData);
        } catch {
          const errorText = await healthResponse.text();
          result.apiTests.serverHealth.error = errorText;
          console.log('❌ Server health error text:', errorText);
        }
      }
    } catch (error) {
      console.error('💥 All server health tests failed:', error);
      result.apiTests.serverHealth = {
        error: error instanceof Error ? error.message : 'Unknown error',
        networkError: true
      };
    }

    // Test 3: PayPal API (if authenticated)
    if (result.auth.sessionExists) {
      try {
        const { data: { session } } = await supabase.auth.getSession();
        const testResponse = await fetch(`${result.environment.baseUrl}/test-paypal`, {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${session?.access_token}`,
          }
        });

        result.apiTests.paypalTest = {
          status: testResponse.status,
          ok: testResponse.ok,
          statusText: testResponse.statusText
        };

        if (testResponse.ok) {
          const testData = await testResponse.json();
          result.apiTests.paypalTest.details = testData;
        } else {
          const errorText = await testResponse.text();
          try {
            const errorData = JSON.parse(errorText);
            result.apiTests.paypalTest.error = errorData.error;
            result.apiTests.paypalTest.details = errorData.details;
          } catch {
            result.apiTests.paypalTest.error = errorText;
          }
        }
      } catch (error) {
        result.apiTests.paypalTest = {
          error: error instanceof Error ? error.message : 'Unknown error'
        };
      }
    }

    // Test Debug Info
    try {
      const { data: { session } } = await supabase.auth.getSession();
      const debugResponse = await fetch(`${result.environment.baseUrl}/debug`, {
        method: 'GET',
        headers: {
          'Authorization': session?.access_token ? `Bearer ${session.access_token}` : '',
        }
      });

      if (debugResponse.ok) {
        const debugData = await debugResponse.json();
        result.apiTests.debugInfo = debugData;
        console.log('🔍 Debug info:', debugData);
      }
    } catch (error) {
      console.log('Debug info request failed:', error);
    }

    // Test 4: Bidding API (if authenticated)
    if (result.auth.sessionExists) {
      try {
        const { data: { session } } = await supabase.auth.getSession();
        const bidResponse = await fetch(`${result.environment.baseUrl}/test-bidding`, {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${session?.access_token}`,
          }
        });

        result.apiTests.biddingTest = {
          status: bidResponse.status,
          ok: bidResponse.ok,
          statusText: bidResponse.statusText
        };

        if (bidResponse.ok) {
          const testData = await bidResponse.json();
          result.apiTests.biddingTest.details = testData;
        } else {
          const errorText = await bidResponse.text();
          try {
            const errorData = JSON.parse(errorText);
            result.apiTests.biddingTest.error = errorData.error;
            result.apiTests.biddingTest.details = errorData.details;
          } catch {
            result.apiTests.biddingTest.error = errorText;
          }
        }
      } catch (error) {
        result.apiTests.biddingTest = {
          error: error instanceof Error ? error.message : 'Unknown error'
        };
      }
    }

    setDiagnostic(result);
    setIsRunning(false);
    console.log('🔍 Quick System Diagnostic Result:', result);
  };

  const getStatusIcon = (status: boolean | null) => {
    if (status === null) return <Clock className="h-4 w-4 text-gray-400" />;
    return status ? <CheckCircle className="h-4 w-4 text-green-500" /> : <XCircle className="h-4 w-4 text-red-500" />;
  };

  return (
    <Card className="bg-gray-800 border-gray-700">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <AlertTriangle className="h-5 w-5 text-orange-400" />
          Quick System Diagnostic
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex gap-2 mb-4">
          <Button 
            onClick={runDiagnostic} 
            disabled={isRunning}
            className="bg-orange-500 hover:bg-orange-600"
          >
            {isRunning ? (
              <>
                <Clock className="h-4 w-4 mr-2 animate-spin" />
                Running...
              </>
            ) : (
              <>
                <AlertTriangle className="h-4 w-4 mr-2" />
                Run Quick Diagnostic
              </>
            )}
          </Button>

          <Button 
            onClick={async () => {
              console.log('🔧 Manual server test...');
              const baseUrl = `https://${projectId}.supabase.co/functions/v1/make-server-9f7745d8`;
              
              // Try multiple endpoints to see what works
              const tests = [
                { name: 'Health Endpoint', url: `${baseUrl}/health` },
                { name: 'Ping Endpoint', url: `${baseUrl}/ping` },
                { name: 'Status Endpoint', url: `${baseUrl}/status` }
              ];
              
              let results = [];
              
              for (const test of tests) {
                try {
                  console.log(`Testing ${test.name}:`, test.url);
                  const response = await fetch(test.url);
                  
                  const result = {
                    name: test.name,
                    status: response.status,
                    ok: response.ok,
                    statusText: response.statusText
                  };
                  
                  if (response.ok) {
                    try {
                      const data = await response.json();
                      result.data = data;
                      console.log(`✅ ${test.name} success:`, data);
                    } catch (jsonError) {
                      const text = await response.text();
                      result.text = text;
                      console.log(`✅ ${test.name} success (text):`, text);
                    }
                  } else {
                    try {
                      const errorData = await response.json();
                      result.error = errorData;
                      console.log(`❌ ${test.name} error:`, errorData);
                    } catch {
                      const errorText = await response.text();
                      result.errorText = errorText;
                      console.log(`❌ ${test.name} error (text):`, errorText);
                    }
                  }
                  
                  results.push(result);
                  
                } catch (error) {
                  console.error(`💥 ${test.name} failed:`, error);
                  results.push({
                    name: test.name,
                    error: error instanceof Error ? error.message : 'Network error'
                  });
                }
              }
              
              // Show results
              const workingTests = results.filter(r => r.ok);
              const failedTests = results.filter(r => !r.ok);
              
              if (workingTests.length > 0) {
                alert(`✅ ${workingTests.length} endpoint(s) working!\n${workingTests.map(t => `• ${t.name}: ${t.status}`).join('\n')}\n\nCheck console for full details.`);
              } else {
                alert(`❌ All endpoints failed!\n${failedTests.map(t => `• ${t.name}: ${t.status || 'Network Error'}`).join('\n')}\n\nCheck console for details.`);
              }
            }}
            variant="outline"
            size="sm"
            className="text-xs"
          >
            🔧 Manual Test
          </Button>
        </div>

        {!user && (
          <Alert className="mb-4">
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>
              ⚠️ Please sign in first for full diagnostic testing
            </AlertDescription>
          </Alert>
        )}

        {diagnostic && (
          <div className="space-y-4">
            <div className="grid gap-3">
              <div className="flex items-center justify-between p-3 bg-gray-700 rounded">
                <span>User Authentication</span>
                {getStatusIcon(diagnostic.auth.sessionExists)}
                <span className="text-sm">{diagnostic.auth.sessionExists ? 'Active' : 'Failed'}</span>
              </div>

              <div className="flex items-center justify-between p-3 bg-gray-700 rounded">
                <span>Access Token</span>
                {getStatusIcon(diagnostic.auth.accessToken === 'present')}
                <span className="text-sm">{diagnostic.auth.accessToken}</span>
              </div>

              <div className="flex items-center justify-between p-3 bg-gray-700 rounded">
                <span>Server Health</span>
                {getStatusIcon(diagnostic.apiTests.serverHealth?.ok)}
                <span className="text-sm">
                  {diagnostic.apiTests.serverHealth?.ok ? 'Online' : 
                   diagnostic.apiTests.serverHealth?.status ? `Failed (${diagnostic.apiTests.serverHealth.status})` :
                   diagnostic.apiTests.serverHealth?.error || 'Failed'}
                </span>
              </div>

              {diagnostic.auth.sessionExists && (
                <>
                  <div className="flex items-center justify-between p-3 bg-gray-700 rounded">
                    <span>PayPal API</span>
                    {getStatusIcon(diagnostic.apiTests.paypalTest?.ok)}
                    <span className="text-sm">
                      {diagnostic.apiTests.paypalTest?.ok ? 'Working' : 
                       diagnostic.apiTests.paypalTest?.error || 'Failed'}
                    </span>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-gray-700 rounded">
                    <span>Bidding API</span>
                    {getStatusIcon(diagnostic.apiTests.biddingTest?.ok)}
                    <span className="text-sm">
                      {diagnostic.apiTests.biddingTest?.ok ? 'Working' : 
                       diagnostic.apiTests.biddingTest?.error || 'Failed'}
                    </span>
                  </div>
                </>
              )}
            </div>

            {/* Error Details */}
            {diagnostic.apiTests.serverHealth?.error && (
              <Alert>
                <XCircle className="h-4 w-4" />
                <AlertDescription>
                  <strong>Server Health Error:</strong> 
                  {typeof diagnostic.apiTests.serverHealth.error === 'object' ? 
                    JSON.stringify(diagnostic.apiTests.serverHealth.error) : 
                    diagnostic.apiTests.serverHealth.error}
                  {diagnostic.apiTests.serverHealth.status && (
                    <div className="mt-1 text-xs">Status: {diagnostic.apiTests.serverHealth.status}</div>
                  )}
                </AlertDescription>
              </Alert>
            )}

            {diagnostic.auth.error && (
              <Alert>
                <XCircle className="h-4 w-4" />
                <AlertDescription>
                  <strong>Auth Error:</strong> {diagnostic.auth.error}
                </AlertDescription>
              </Alert>
            )}

            {diagnostic.apiTests.paypalTest?.error && (
              <Alert>
                <XCircle className="h-4 w-4" />
                <AlertDescription>
                  <strong>PayPal Error:</strong> {diagnostic.apiTests.paypalTest.error}
                  {diagnostic.apiTests.paypalTest.details && (
                    <div className="mt-1 text-xs">Details: {diagnostic.apiTests.paypalTest.details}</div>
                  )}
                </AlertDescription>
              </Alert>
            )}

            {diagnostic.apiTests.biddingTest?.error && (
              <Alert>
                <XCircle className="h-4 w-4" />
                <AlertDescription>
                  <strong>Bidding Error:</strong> {diagnostic.apiTests.biddingTest.error}
                  {diagnostic.apiTests.biddingTest.details && (
                    <div className="mt-1 text-xs">Details: {diagnostic.apiTests.biddingTest.details}</div>
                  )}
                </AlertDescription>
              </Alert>
            )}

            <div className="text-xs text-gray-500 bg-gray-700 p-2 rounded">
              <strong>Environment:</strong> {diagnostic.environment.projectId}<br/>
              <strong>User:</strong> {diagnostic.user?.email || 'Not signed in'}<br/>
              <strong>Base URL:</strong> {diagnostic.environment.baseUrl}
              {diagnostic.apiTests.debugInfo && (
                <>
                  <br/><strong>Server:</strong> {diagnostic.apiTests.debugInfo.server || 'Unknown'}
                  <br/><strong>Environment Keys:</strong> {JSON.stringify(diagnostic.apiTests.debugInfo.environment)}
                </>
              )}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}