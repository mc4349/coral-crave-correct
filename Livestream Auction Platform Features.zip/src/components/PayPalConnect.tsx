import React, { useState, useEffect } from 'react'
import { Button } from './ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card'
import { Badge } from './ui/badge'
import { CheckCircle2, ExternalLink, AlertCircle, Loader2 } from 'lucide-react'
import { createClient } from '@supabase/supabase-js'
import { projectId, publicAnonKey } from '../utils/supabase/info'

const supabase = createClient(
  `https://${projectId}.supabase.co`,
  publicAnonKey
)

interface PayPalConnectProps {
  onConnectionChange?: (isConnected: boolean, merchantId?: string) => void
  className?: string
}

interface PayPalStatus {
  status: 'NOT_CONNECTED' | 'PENDING' | 'CONNECTED'
  merchantId?: string
  email?: string
  lastChecked?: string
}

export function PayPalConnect({ onConnectionChange, className }: PayPalConnectProps) {
  const [paypalStatus, setPaypalStatus] = useState<PayPalStatus>({ status: 'NOT_CONNECTED' })
  const [loading, setLoading] = useState(false)
  const [checking, setChecking] = useState(true)
  const [error, setError] = useState<string | null>(null)

  // Check PayPal connection status
  const checkPayPalStatus = async () => {
    try {
      setChecking(true)
      const { data: { session } } = await supabase.auth.getSession()
      
      if (!session?.access_token) {
        throw new Error('Not authenticated')
      }

      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-9f7745d8/paypal/merchant-status`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
          'Content-Type': 'application/json'
        }
      })

      const data = await response.json()

      if (data.success) {
        const status: PayPalStatus = {
          status: data.status,
          merchantId: data.merchantData?.merchant_id,
          email: data.merchantData?.primary_email,
          lastChecked: new Date().toISOString()
        }
        
        setPaypalStatus(status)
        onConnectionChange?.(status.status === 'CONNECTED', status.merchantId)
      } else {
        throw new Error(data.error || 'Failed to check PayPal status')
      }
    } catch (error) {
      console.error('Error checking PayPal status:', error)
      setError(error instanceof Error ? error.message : 'Failed to check PayPal status')
    } finally {
      setChecking(false)
    }
  }

  // Create PayPal onboarding link
  const handleConnectPayPal = async () => {
    try {
      setLoading(true)
      setError(null)
      
      const { data: { session } } = await supabase.auth.getSession()
      
      if (!session?.access_token) {
        throw new Error('Not authenticated')
      }

      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-9f7745d8/paypal/onboarding-link`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
          'Content-Type': 'application/json'
        }
      })

      const data = await response.json()

      if (data.success && data.url) {
        // Open PayPal onboarding in new window
        window.open(data.url, '_blank', 'width=500,height=600,scrollbars=yes,resizable=yes')
        
        // Update status to pending
        setPaypalStatus({ status: 'PENDING' })
        
        // Check status periodically after onboarding starts
        const checkInterval = setInterval(async () => {
          await checkPayPalStatus()
          if (paypalStatus.status === 'CONNECTED') {
            clearInterval(checkInterval)
          }
        }, 5000)
        
        // Clear interval after 5 minutes
        setTimeout(() => clearInterval(checkInterval), 300000)
      } else {
        throw new Error(data.error || 'Failed to create PayPal onboarding link')
      }
    } catch (error) {
      console.error('Error connecting PayPal:', error)
      setError(error instanceof Error ? error.message : 'Failed to connect PayPal')
    } finally {
      setLoading(false)
    }
  }

  // Manually refresh status
  const handleRefreshStatus = async () => {
    await checkPayPalStatus()
  }

  // Check status on component mount
  useEffect(() => {
    checkPayPalStatus()
  }, [])

  // Handle return from PayPal onboarding (if using redirect flow)
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search)
    const merchantId = urlParams.get('merchantId')
    const merchantIdInFragment = urlParams.get('merchantIdInFragment')
    
    if (merchantId || merchantIdInFragment) {
      // PayPal returned with merchant info, save it
      const saveMerchantInfo = async () => {
        try {
          const { data: { session } } = await supabase.auth.getSession()
          
          if (session?.access_token) {
            await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-9f7745d8/paypal/save-merchant`, {
              method: 'POST',
              headers: {
                'Authorization': `Bearer ${session.access_token}`,
                'Content-Type': 'application/json'
              },
              body: JSON.stringify({
                merchantId: merchantId || merchantIdInFragment
              })
            })
            
            // Refresh status after saving
            await checkPayPalStatus()
          }
        } catch (error) {
          console.error('Error saving merchant info:', error)
        }
      }
      
      saveMerchantInfo()
    }
  }, [])

  const getStatusBadge = () => {
    switch (paypalStatus.status) {
      case 'CONNECTED':
        return <Badge variant="default" className="bg-green-500"><CheckCircle2 className="size-3 mr-1" />Connected</Badge>
      case 'PENDING':
        return <Badge variant="secondary"><Loader2 className="size-3 mr-1 animate-spin" />Pending</Badge>
      default:
        return <Badge variant="outline"><AlertCircle className="size-3 mr-1" />Not Connected</Badge>
    }
  }

  const getStatusDescription = () => {
    switch (paypalStatus.status) {
      case 'CONNECTED':
        return `Your PayPal account is connected and ready to receive payments. ${paypalStatus.email ? `Connected as: ${paypalStatus.email}` : ''}`
      case 'PENDING':
        return 'Your PayPal connection is being processed. Please complete the setup in the PayPal window if still open.'
      default:
        return 'Connect your PayPal account to receive payments from auction sales. The platform will automatically deduct an 8% commission plus $0.30 processing fee.'
    }
  }

  if (checking) {
    return (
      <Card className={className}>
        <CardContent className="flex items-center justify-center p-6">
          <Loader2 className="size-6 animate-spin mr-2" />
          <span>Checking PayPal connection...</span>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card className={className}>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-lg">PayPal Connection</CardTitle>
            <CardDescription>Required to receive auction payments</CardDescription>
          </div>
          {getStatusBadge()}
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="text-sm text-muted-foreground">
          {getStatusDescription()}
        </p>
        
        {error && (
          <div className="p-3 bg-red-50 border border-red-200 rounded-md">
            <p className="text-sm text-red-700">{error}</p>
          </div>
        )}

        {paypalStatus.status === 'CONNECTED' && (
          <div className="p-3 bg-green-50 border border-green-200 rounded-md">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-green-800">Ready to accept payments</p>
                <p className="text-xs text-green-600">
                  Fees: 8% + $0.30 per transaction
                </p>
              </div>
              <Button
                variant="outline"
                size="sm"
                onClick={handleRefreshStatus}
                disabled={checking}
              >
                Refresh Status
              </Button>
            </div>
          </div>
        )}

        {paypalStatus.status !== 'CONNECTED' && (
          <div className="flex flex-col sm:flex-row gap-2">
            <Button
              onClick={handleConnectPayPal}
              disabled={loading}
              className="flex-1"
            >
              {loading ? (
                <>
                  <Loader2 className="size-4 mr-2 animate-spin" />
                  Connecting...
                </>
              ) : (
                <>
                  <ExternalLink className="size-4 mr-2" />
                  Connect PayPal
                </>
              )}
            </Button>
            
            {paypalStatus.status === 'PENDING' && (
              <Button
                variant="outline"
                onClick={handleRefreshStatus}
                disabled={checking}
              >
                {checking ? (
                  <Loader2 className="size-4 animate-spin" />
                ) : (
                  'Check Status'
                )}
              </Button>
            )}
          </div>
        )}

        <div className="text-xs text-muted-foreground space-y-1">
          <p>• Buyers pay the full auction amount with no additional fees</p>
          <p>• Platform automatically deducts 8% + $0.30 from your earnings</p>
          <p>• Payments are processed instantly to your PayPal account</p>
          <p>• You maintain full control of your PayPal account</p>
        </div>
      </CardContent>
    </Card>
  )
}