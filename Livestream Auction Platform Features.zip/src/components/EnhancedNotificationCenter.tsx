import React from 'react';

interface User {
  id: string;
  email: string;
  name: string;
  avatar?: string;
}

interface EnhancedNotificationCenterProps {
  user: User | null;
  onNotificationClick: (notification: any) => void;
  onMarkAsRead: (notificationId: string) => void;
  onMarkAllAsRead: () => void;
}

export function EnhancedNotificationCenter({ user, onNotificationClick, onMarkAsRead, onMarkAllAsRead }: EnhancedNotificationCenterProps) {
  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold text-white mb-4">Notifications</h1>
      <p className="text-gray-400">Enhanced notifications coming soon...</p>
    </div>
  );
}

export default EnhancedNotificationCenter;