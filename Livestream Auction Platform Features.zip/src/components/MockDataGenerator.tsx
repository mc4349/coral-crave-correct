import React, { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Database, Users, ShoppingCart, Calendar, MessageSquare, Award, Zap, Check, X, Loader2 } from 'lucide-react';
import { toast } from 'sonner@2.0.3';
import { projectId, publicAnonKey } from '../utils/supabase/info';

interface MockDataItem {
  id: string;
  name: string;
  description: string;
  icon: React.ReactNode;
  status: 'pending' | 'loading' | 'success' | 'error';
  count?: number;
}

export function MockDataGenerator({ onClose }: { onClose: () => void }) {
  const [mockDataItems, setMockDataItems] = useState<MockDataItem[]>([
    {
      id: 'users',
      name: 'Demo Users',
      description: 'Create seller and buyer test accounts',
      icon: <Users className="h-5 w-5" />,
      status: 'pending'
    },
    {
      id: 'products',
      name: 'Coral Products',
      description: 'Generate realistic coral inventory',
      icon: <Award className="h-5 w-5" />,
      status: 'pending'
    },
    {
      id: 'auctions',
      name: 'Live Auctions',
      description: 'Create active auction scenarios',
      icon: <ShoppingCart className="h-5 w-5" />,
      status: 'pending'
    },
    {
      id: 'bids',
      name: 'Bid History',
      description: 'Generate realistic bidding patterns',
      icon: <Zap className="h-5 w-5" />,
      status: 'pending'
    },
    {
      id: 'chat',
      name: 'Chat Messages',
      description: 'Populate chat with sample conversations',
      icon: <MessageSquare className="h-5 w-5" />,
      status: 'pending'
    },
    {
      id: 'schedule',
      name: 'Scheduled Shows',
      description: 'Create upcoming show schedule',
      icon: <Calendar className="h-5 w-5" />,
      status: 'pending'
    },
    {
      id: 'notifications',
      name: 'Notifications',
      description: 'Generate sample alerts and notifications',
      icon: <Database className="h-5 w-5" />,
      status: 'pending'
    }
  ]);

  const updateItemStatus = (id: string, status: MockDataItem['status'], count?: number) => {
    setMockDataItems(prev => prev.map(item => 
      item.id === id ? { ...item, status, count } : item
    ));
  };

  const generateMockData = async (itemId: string) => {
    updateItemStatus(itemId, 'loading');
    
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-9f7745d8/testing/generate-mock-data`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`
        },
        body: JSON.stringify({ type: itemId })
      });

      if (response.ok) {
        const result = await response.json();
        updateItemStatus(itemId, 'success', result.count);
        toast.success(`${result.message}`);
      } else {
        throw new Error(`HTTP ${response.status}`);
      }
    } catch (error) {
      console.error(`Failed to generate ${itemId}:`, error);
      updateItemStatus(itemId, 'error');
      toast.error(`Failed to generate ${itemId}`);
    }
  };

  const generateAllMockData = async () => {
    toast.info('Generating all mock data...');
    
    for (const item of mockDataItems) {
      await generateMockData(item.id);
      // Small delay between requests
      await new Promise(resolve => setTimeout(resolve, 500));
    }
    
    toast.success('All mock data generated successfully!');
  };

  const clearAllData = async () => {
    if (!confirm('Are you sure you want to clear all test data? This cannot be undone.')) {
      return;
    }

    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-9f7745d8/testing/clear-mock-data`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`
        }
      });

      if (response.ok) {
        setMockDataItems(prev => prev.map(item => ({ ...item, status: 'pending', count: undefined })));
        toast.success('All test data cleared');
      } else {
        throw new Error(`HTTP ${response.status}`);
      }
    } catch (error) {
      console.error('Failed to clear data:', error);
      toast.error('Failed to clear test data');
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'success': return 'text-green-500';
      case 'error': return 'text-red-500';
      case 'loading': return 'text-blue-500';
      default: return 'text-gray-500';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'success': return <Check className="h-4 w-4" />;
      case 'error': return <X className="h-4 w-4" />;
      case 'loading': return <Loader2 className="h-4 w-4 animate-spin" />;
      default: return null;
    }
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-gray-900 rounded-xl max-w-4xl w-full max-h-[90vh] overflow-hidden">
        <div className="p-6 border-b border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold text-white mb-2">Mock Data Generator</h2>
              <p className="text-gray-400">Generate realistic test data for comprehensive platform testing</p>
            </div>
            <Button onClick={onClose} variant="outline" size="sm">
              Close
            </Button>
          </div>
          
          <div className="flex gap-3 mt-4">
            <Button 
              onClick={generateAllMockData}
              className="bg-cyan-500 hover:bg-cyan-600"
            >
              Generate All Data
            </Button>
            <Button 
              onClick={clearAllData}
              variant="destructive"
            >
              Clear All Data
            </Button>
          </div>
        </div>

        <div className="p-6 overflow-y-auto max-h-[calc(90vh-200px)]">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {mockDataItems.map((item) => (
              <Card key={item.id} className="bg-gray-800 border-gray-700">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="text-cyan-400">
                        {item.icon}
                      </div>
                      <div>
                        <CardTitle className="text-white text-lg">{item.name}</CardTitle>
                        <CardDescription className="text-gray-400 text-sm">
                          {item.description}
                        </CardDescription>
                      </div>
                    </div>
                    <div className={`flex items-center space-x-2 ${getStatusColor(item.status)}`}>
                      {getStatusIcon(item.status)}
                      <Badge 
                        variant={
                          item.status === 'success' ? 'default' :
                          item.status === 'error' ? 'destructive' :
                          item.status === 'loading' ? 'secondary' : 'outline'
                        }
                      >
                        {item.status === 'success' && item.count ? `${item.count} items` : item.status}
                      </Badge>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="pt-0">
                  <Button
                    onClick={() => generateMockData(item.id)}
                    disabled={item.status === 'loading'}
                    variant="outline"
                    size="sm"
                    className="w-full"
                  >
                    {item.status === 'loading' ? 'Generating...' : 
                     item.status === 'success' ? 'Regenerate' : 'Generate'}
                  </Button>
                  
                  {/* Specific data details */}
                  {item.id === 'users' && (
                    <div className="mt-2 text-xs text-gray-400">
                      Creates: demo@coralcrave.com (seller), buyer@coralcrave.com (buyer)
                    </div>
                  )}
                  {item.id === 'products' && (
                    <div className="mt-2 text-xs text-gray-400">
                      Creates: 50+ coral species with realistic pricing
                    </div>
                  )}
                  {item.id === 'auctions' && (
                    <div className="mt-2 text-xs text-gray-400">
                      Creates: Active auctions with various time remaining
                    </div>
                  )}
                  {item.id === 'bids' && (
                    <div className="mt-2 text-xs text-gray-400">
                      Creates: Realistic bidding patterns and history
                    </div>
                  )}
                  {item.id === 'chat' && (
                    <div className="mt-2 text-xs text-gray-400">
                      Creates: Sample chat conversations for streams
                    </div>
                  )}
                  {item.id === 'schedule' && (
                    <div className="mt-2 text-xs text-gray-400">
                      Creates: Shows scheduled for next 7 days
                    </div>
                  )}
                  {item.id === 'notifications' && (
                    <div className="mt-2 text-xs text-gray-400">
                      Creates: Bid alerts, show reminders, system notifications
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Data Preview */}
          <div className="mt-8">
            <h3 className="text-lg font-bold text-white mb-4">Generated Data Summary</h3>
            <div className="bg-gray-800 rounded-lg p-4">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                {mockDataItems.map((item) => (
                  <div key={item.id} className="space-y-1">
                    <div className="text-cyan-400">{item.icon}</div>
                    <div className="text-sm text-gray-300">{item.name}</div>
                    <div className="text-lg font-bold text-white">
                      {item.status === 'success' && item.count ? item.count : '0'}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Mock Data Scenarios */}
          <div className="mt-6">
            <h3 className="text-lg font-bold text-white mb-4">Testing Scenarios</h3>
            <div className="space-y-3">
              <div className="bg-blue-500/10 border border-blue-500/20 rounded-lg p-4">
                <h4 className="text-blue-400 font-medium mb-2">🛒 Buyer Testing Scenario</h4>
                <p className="text-gray-300 text-sm">
                  Sign in as buyer@coralcrave.com → Browse live auctions → Place bids → Test payment flow
                </p>
              </div>
              <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-4">
                <h4 className="text-green-400 font-medium mb-2">🐠 Seller Testing Scenario</h4>
                <p className="text-gray-300 text-sm">
                  Sign in as demo@coralcrave.com → Start live stream → Add products to queue → Monitor bids
                </p>
              </div>
              <div className="bg-purple-500/10 border border-purple-500/20 rounded-lg p-4">
                <h4 className="text-purple-400 font-medium mb-2">⚡ Multi-User Testing</h4>
                <p className="text-gray-300 text-sm">
                  Open multiple browser tabs → Sign in with different accounts → Test real-time interactions
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}