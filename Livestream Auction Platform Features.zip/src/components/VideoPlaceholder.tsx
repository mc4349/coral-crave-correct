import React from 'react';
import { Video, Play } from 'lucide-react';

interface VideoPlaceholderProps {
  width?: string;
  height?: string;
  showPlayButton?: boolean;
  className?: string;
  onPlay?: () => void;
}

export function VideoPlaceholder({ 
  width = "100%", 
  height = "300px", 
  showPlayButton = false, 
  className = "",
  onPlay 
}: VideoPlaceholderProps) {
  return (
    <div 
      className={`bg-gray-800 border border-gray-700 rounded-lg flex items-center justify-center relative ${className}`}
      style={{ width, height }}
    >
      {/* Video Icon */}
      <div className="text-center">
        <Video size={48} className="text-gray-500 mx-auto mb-2" />
        <p className="text-gray-400 text-sm">Video Stream</p>
        <p className="text-gray-500 text-xs">Camera feed will appear here</p>
      </div>
      
      {/* Play Button Overlay */}
      {showPlayButton && (
        <button
          onClick={onPlay}
          className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-40 hover:bg-opacity-60 transition-colors rounded-lg"
        >
          <div className="w-16 h-16 bg-cyan-500 rounded-full flex items-center justify-center hover:bg-cyan-600 transition-colors">
            <Play size={24} className="text-white ml-1" />
          </div>
        </button>
      )}
    </div>
  );
}