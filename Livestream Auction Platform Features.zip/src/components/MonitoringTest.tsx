import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { monitoring, trackUserAction, createSystemAlert } from '../utils/monitoring';
import { CheckCircle, AlertTriangle, Zap, Activity } from 'lucide-react';

export function MonitoringTest() {
  const [testResults, setTestResults] = useState<any[]>([]);
  const [isRunning, setIsRunning] = useState(false);

  const runTest = async (testName: string, testFn: () => Promise<any>) => {
    const startTime = Date.now();
    try {
      const result = await testFn();
      const duration = Date.now() - startTime;
      
      setTestResults(prev => [...prev, {
        name: testName,
        status: 'success',
        duration,
        result,
        timestamp: new Date().toISOString()
      }]);
    } catch (error) {
      const duration = Date.now() - startTime;
      
      setTestResults(prev => [...prev, {
        name: testName,
        status: 'error',
        duration,
        error: error instanceof Error ? error.message : 'Unknown error',
        timestamp: new Date().toISOString()
      }]);
    }
  };

  const runAllTests = async () => {
    setIsRunning(true);
    setTestResults([]);

    try {
      // Test 1: Log a test request
      await runTest('Log Test Request', async () => {
        await monitoring.logRequest('/test', 'GET', 150, 200);
        return 'Request logged successfully';
      });

      // Test 2: Log a test error
      await runTest('Log Test Error', async () => {
        await monitoring.logError('Test error message', '/test', 'Test stack trace', 'test-user');
        return 'Error logged successfully';
      });

      // Test 3: Log user activity
      await runTest('Log User Activity', async () => {
        await trackUserAction('test-user-123', 'test_action', { testData: true });
        return 'User activity logged successfully';
      });

      // Test 4: Create system alert
      await runTest('Create System Alert', async () => {
        const alertId = await createSystemAlert('info', 'Test Alert', 'This is a test alert from monitoring system');
        return { alertId, message: 'Alert created successfully' };
      });

      // Test 5: Get dashboard data
      await runTest('Fetch Dashboard Data', async () => {
        const data = await monitoring.getDashboardData();
        return { 
          status: data.status, 
          totalRequests: data.metrics?.totalRequests || 0,
          activeUsers: data.metrics?.activeUsers || 0
        };
      });

      // Test 6: Get detailed health
      await runTest('Fetch Detailed Health', async () => {
        const health = await monitoring.getDetailedHealth();
        return {
          status: health.status,
          uptime: health.metrics?.uptime || 0,
          services: Object.keys(health.services || {}).length
        };
      });

      // Test 7: Get monitoring stats
      await runTest('Fetch Monitoring Stats', async () => {
        const stats = await monitoring.getStats();
        return {
          totalRequests: stats.overview?.totalRequests || 0,
          totalUsers: stats.overview?.totalUsers || 0,
          statsCount: stats.statistics?.length || 0
        };
      });

    } finally {
      setIsRunning(false);
    }
  };

  const clearResults = () => {
    setTestResults([]);
  };

  return (
    <div className="max-w-4xl mx-auto p-6">
      <Card className="bg-gray-800 border-gray-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center">
            <Activity className="mr-2 h-5 w-5 text-cyan-400" />
            Monitoring System Test
          </CardTitle>
          <CardDescription>
            Test all monitoring endpoints and functionality
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex items-center space-x-4 mb-6">
            <Button
              onClick={runAllTests}
              disabled={isRunning}
              className="bg-cyan-600 hover:bg-cyan-700"
            >
              {isRunning ? (
                <>
                  <div className="animate-spin mr-2 h-4 w-4 border-2 border-white border-t-transparent rounded-full"></div>
                  Running Tests...
                </>
              ) : (
                <>
                  <Zap className="mr-2 h-4 w-4" />
                  Run All Tests
                </>
              )}
            </Button>
            
            <Button
              onClick={clearResults}
              variant="outline"
              className="border-gray-600"
            >
              Clear Results
            </Button>
            
            <div className="text-sm text-gray-400">
              {testResults.length > 0 && (
                <>
                  {testResults.filter(r => r.status === 'success').length} passed, {' '}
                  {testResults.filter(r => r.status === 'error').length} failed
                </>
              )}
            </div>
          </div>

          {testResults.length > 0 && (
            <div className="space-y-3">
              <h3 className="text-lg font-medium text-white mb-4">Test Results</h3>
              
              {testResults.map((result, index) => (
                <div
                  key={index}
                  className={`p-4 rounded-lg border ${
                    result.status === 'success' 
                      ? 'bg-green-900/20 border-green-700' 
                      : 'bg-red-900/20 border-red-700'
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-start space-x-3">
                      <div className={`mt-1 ${
                        result.status === 'success' ? 'text-green-400' : 'text-red-400'
                      }`}>
                        {result.status === 'success' ? (
                          <CheckCircle className="h-5 w-5" />
                        ) : (
                          <AlertTriangle className="h-5 w-5" />
                        )}
                      </div>
                      <div>
                        <h4 className="font-medium text-white">{result.name}</h4>
                        <p className="text-sm text-gray-300 mt-1">
                          {result.status === 'success' 
                            ? typeof result.result === 'string' 
                              ? result.result 
                              : JSON.stringify(result.result, null, 2)
                            : result.error
                          }
                        </p>
                        <div className="flex items-center space-x-4 mt-2 text-xs text-gray-400">
                          <span>Duration: {result.duration}ms</span>
                          <span>Time: {new Date(result.timestamp).toLocaleTimeString()}</span>
                        </div>
                      </div>
                    </div>
                    
                    <Badge 
                      variant={result.status === 'success' ? 'default' : 'destructive'}
                      className="text-xs"
                    >
                      {result.status}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          )}

          {testResults.length === 0 && !isRunning && (
            <div className="text-center py-8 text-gray-400">
              <Activity className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>Click "Run All Tests" to test the monitoring system</p>
              <p className="text-sm mt-2">
                This will test logging, alerts, and monitoring data retrieval
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}