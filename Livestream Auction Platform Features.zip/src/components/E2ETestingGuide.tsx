import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Alert, AlertDescription } from './ui/alert';
import { 
  CheckCircle, 
  Circle, 
  DollarSign, 
  Video, 
  Gavel,
  Users,
  ArrowRight,
  Play,
  ShoppingCart,
  CreditCard,
  Monitor,
  MessageCircle
} from 'lucide-react';

interface TestStep {
  id: string;
  title: string;
  description: string;
  icon: React.ReactNode;
  completed: boolean;
  instructions: string[];
  expectedResult: string;
}

interface E2ETestingGuideProps {
  user?: { id: string; email: string; name: string } | null;
  onNavigateToTab?: (tab: string) => void;
}

export function E2ETestingGuide({ user, onNavigateToTab }: E2ETestingGuideProps) {
  const [testSteps, setTestSteps] = useState<TestStep[]>([
    {
      id: 'auth-test',
      title: 'User Authentication',
      description: 'Test sign up, sign in, and profile management',
      icon: <Users className="h-5 w-5 text-blue-400" />,
      completed: false,
      instructions: [
        'Click "Account" tab',
        'Test sign up with new email',
        'Test sign in with existing account',
        'Verify profile information is displayed'
      ],
      expectedResult: 'User can successfully authenticate and view profile'
    },
    {
      id: 'livestream-test',
      title: 'Livestream Creation',
      description: 'Test going live and streaming setup',
      icon: <Video className="h-5 w-5 text-purple-400" />,
      completed: false,
      instructions: [
        'Click "Go Live" tab',
        'Fill in stream title and description',
        'Start the livestream',
        'Verify Agora video feed appears',
        'Check that stream appears in "Explore" for other users'
      ],
      expectedResult: 'Stream starts successfully with video feed and appears publicly'
    },
    {
      id: 'bidding-test',
      title: 'Live Bidding',
      description: 'Test placing bids during live auctions',
      icon: <Gavel className="h-5 w-5 text-orange-400" />,
      completed: false,
      instructions: [
        'Join an active livestream',
        'Scroll to bidding panel',
        'Place a test bid (e.g., $15.00)',
        'Verify bid appears in bid history',
        'Test outbidding yourself with higher amount'
      ],
      expectedResult: 'Bids are placed successfully and update in real-time'
    },
    {
      id: 'chat-test',
      title: 'Live Chat',
      description: 'Test real-time chat during streams',
      icon: <MessageCircle className="h-5 w-5 text-green-400" />,
      completed: false,
      instructions: [
        'In an active livestream, find the chat section',
        'Type a test message',
        'Send the message',
        'Verify message appears in chat feed',
        'Test emoji reactions if available'
      ],
      expectedResult: 'Messages send successfully and appear in real-time'
    },
    {
      id: 'payment-flow',
      title: 'Payment Processing',
      description: 'Test winning auction and payment flow',
      icon: <DollarSign className="h-5 w-5 text-green-400" />,
      completed: false,
      instructions: [
        'Win an auction by being highest bidder',
        'Navigate to cart/checkout',
        'Review order details and fees',
        'Complete PayPal payment (use sandbox)',
        'Verify payment confirmation and invoice'
      ],
      expectedResult: 'Payment processes successfully with proper fee calculations'
    },
    {
      id: 'mobile-test',
      title: 'Mobile Experience',
      description: 'Test mobile responsiveness and touch interactions',
      icon: <Monitor className="h-5 w-5 text-cyan-400" />,
      completed: false,
      instructions: [
        'Open app on mobile device or use browser dev tools',
        'Test bottom navigation',
        'Try swiping gestures on livestream',
        'Test bidding with touch interface',
        'Verify all features work on mobile'
      ],
      expectedResult: 'App is fully functional and responsive on mobile devices'
    }
  ]);

  const [currentStep, setCurrentStep] = useState<string | null>(null);

  const toggleStepCompletion = (stepId: string) => {
    setTestSteps(prev => prev.map(step => 
      step.id === stepId ? { ...step, completed: !step.completed } : step
    ));
  };

  const startStep = (stepId: string) => {
    setCurrentStep(stepId);
    
    // Navigate to appropriate tab based on step
    if (onNavigateToTab) {
      switch (stepId) {
        case 'auth-test':
          onNavigateToTab('account');
          break;
        case 'livestream-test':
          onNavigateToTab('go-live');
          break;
        case 'bidding-test':
        case 'chat-test':
          onNavigateToTab('explore');
          break;
        case 'payment-flow':
          onNavigateToTab('cart');
          break;
        case 'mobile-test':
          // Stay on current page for mobile testing
          break;
      }
    }
  };

  const completedSteps = testSteps.filter(step => step.completed).length;
  const totalSteps = testSteps.length;
  const progress = (completedSteps / totalSteps) * 100;

  return (
    <div className="space-y-6">
      <Card className="bg-gray-800 border-gray-700">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Play className="h-6 w-6 text-cyan-400" />
            End-to-End Testing Guide
          </CardTitle>
          <CardDescription>
            Manual testing checklist to verify all core functionality works together
          </CardDescription>
        </CardHeader>

        <CardContent>
          {/* Progress Overview */}
          <div className="mb-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium">Testing Progress</span>
              <span className="text-sm text-gray-400">{completedSteps}/{totalSteps} completed</span>
            </div>
            <div className="w-full bg-gray-700 rounded-full h-2">
              <div 
                className="bg-cyan-500 h-2 rounded-full transition-all duration-300"
                style={{ width: `${progress}%` }}
              ></div>
            </div>
          </div>

          {/* User Status */}
          {!user ? (
            <Alert className="mb-6">
              <Users className="h-4 w-4" />
              <AlertDescription>
                Please sign in to begin testing. Start with the "User Authentication" test below.
              </AlertDescription>
            </Alert>
          ) : (
            <Alert className="mb-6 border-green-500/20 bg-green-500/10">
              <CheckCircle className="h-4 w-4 text-green-500" />
              <AlertDescription className="text-green-200">
                Signed in as <strong>{user.name}</strong> - Ready to test!
              </AlertDescription>
            </Alert>
          )}

          {/* Test Steps */}
          <div className="space-y-4">
            {testSteps.map((step, index) => (
              <Card key={step.id} className="bg-gray-700 border-gray-600">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <button
                        onClick={() => toggleStepCompletion(step.id)}
                        className="flex-shrink-0"
                      >
                        {step.completed ? (
                          <CheckCircle className="h-6 w-6 text-green-500" />
                        ) : (
                          <Circle className="h-6 w-6 text-gray-400 hover:text-gray-300" />
                        )}
                      </button>
                      
                      <div className="flex items-center gap-2">
                        {step.icon}
                        <div>
                          <CardTitle className="text-lg">{step.title}</CardTitle>
                          <CardDescription className="text-sm">
                            {step.description}
                          </CardDescription>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      {currentStep === step.id && (
                        <Badge variant="secondary">Active</Badge>
                      )}
                      {step.completed && (
                        <Badge className="bg-green-500">Completed</Badge>
                      )}
                      <Button
                        size="sm"
                        onClick={() => startStep(step.id)}
                        className="bg-cyan-500 hover:bg-cyan-600"
                      >
                        {currentStep === step.id ? 'Testing...' : 'Start Test'}
                      </Button>
                    </div>
                  </div>
                </CardHeader>

                {currentStep === step.id && (
                  <CardContent className="pt-0">
                    <div className="bg-gray-800 rounded-lg p-4">
                      <h4 className="font-medium text-cyan-400 mb-3">Test Instructions:</h4>
                      <ol className="space-y-2 text-sm">
                        {step.instructions.map((instruction, idx) => (
                          <li key={idx} className="flex items-start gap-2">
                            <span className="flex-shrink-0 w-5 h-5 bg-cyan-500 text-white rounded-full text-xs flex items-center justify-center mt-0.5">
                              {idx + 1}
                            </span>
                            <span className="text-gray-300">{instruction}</span>
                          </li>
                        ))}
                      </ol>
                      
                      <div className="mt-4 p-3 bg-blue-900/20 rounded border border-blue-500/20">
                        <div className="text-sm">
                          <div className="font-medium text-blue-400 mb-1">Expected Result:</div>
                          <div className="text-gray-300">{step.expectedResult}</div>
                        </div>
                      </div>
                      
                      <div className="mt-4 flex items-center gap-2">
                        <Button
                          size="sm"
                          onClick={() => toggleStepCompletion(step.id)}
                          className="bg-green-500 hover:bg-green-600"
                        >
                          <CheckCircle className="h-4 w-4 mr-2" />
                          Mark as Completed
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => setCurrentStep(null)}
                        >
                          Close Test
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                )}
              </Card>
            ))}
          </div>

          {/* Completion Status */}
          {completedSteps === totalSteps && (
            <Card className="bg-green-900/20 border-green-500/20 mt-6">
              <CardContent className="pt-6">
                <div className="text-center">
                  <CheckCircle className="h-12 w-12 text-green-500 mx-auto mb-4" />
                  <h3 className="text-xl font-bold text-green-400 mb-2">
                    🎉 All Tests Completed!
                  </h3>
                  <p className="text-gray-300 mb-4">
                    Your Coral Crave platform has passed all end-to-end tests and is ready for production use.
                  </p>
                  
                  <div className="grid gap-2 text-sm text-gray-300">
                    <div>✅ User authentication working</div>
                    <div>✅ Livestream functionality verified</div>
                    <div>✅ Bidding system operational</div>
                    <div>✅ Chat system functioning</div>
                    <div>✅ Payment processing ready</div>
                    <div>✅ Mobile experience optimized</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </CardContent>
      </Card>
    </div>
  );
}