import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { 
  Gavel, 
  Clock, 
  DollarSign, 
  TrendingUp, 
  Plus, 
  Timer, 
  CreditCard, 
  Trophy,
  Users,
  Zap,
  Target,
  Shield,
  AlertCircle,
  CheckCircle,
  Bot,
  Play,
  Pause
} from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { PayPalCheckout } from './PayPalCheckout';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Switch } from './ui/switch';
import { Progress } from './ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { toast } from 'sonner@2.0.3';
import { projectId, publicAnonKey } from '../utils/supabase/info';
import { supabase } from '../utils/supabase/client';

interface User {
  id: string;
  email: string;
  name: string;
  avatar?: string;
}

interface AuctionItem {
  id: string;
  title: string;
  description: string;
  startingBid: number;
  currentBid: number;
  bidCount: number;
  timeLeft: number;
  endTime: string;
  image: string;
  isActive: boolean;
  reservePrice?: number;
  buyItNowPrice?: number;
  autoExtend: boolean;
  incrementType: 'fixed' | 'percentage';
  minimumIncrement: number;
  highestBidder?: string;
  sellerId: string;
  sellerName: string;
}

interface Bid {
  id: string;
  userId: string;
  userName: string;
  amount: number;
  maxAmount?: number;
  isProxyBid: boolean;
  timestamp: string;
  status: 'active' | 'outbid' | 'winning';
}

interface EnhancedBiddingPanelProps {
  currentItem?: AuctionItem;
  upcomingItems: AuctionItem[];
  user: User | null;
  onBid: (amount: number) => void;
  onAuthRequired: () => void;
}

export function EnhancedBiddingPanel({ 
  currentItem, 
  upcomingItems, 
  user, 
  onBid, 
  onAuthRequired 
}: EnhancedBiddingPanelProps) {
  const [customBid, setCustomBid] = useState<string>('');
  const [maxBid, setMaxBid] = useState<string>('');
  const [bidHistory, setBidHistory] = useState<Bid[]>([]);
  const [showPayment, setShowPayment] = useState(false);
  const [isWinning, setIsWinning] = useState(false);
  const [auctionEnded, setAuctionEnded] = useState(false);
  const [myHighestBid, setMyHighestBid] = useState<number | null>(null);
  const [autoBidEnabled, setAutoBidEnabled] = useState(false);
  const [autoBidActive, setAutoBidActive] = useState(false);
  const [timeLeftSeconds, setTimeLeftSeconds] = useState(0);
  const [activeBidders, setActiveBidders] = useState(0);
  const [reserveMet, setReserveMet] = useState(false);
  const [isPlacingBid, setIsPlacingBid] = useState(false);

  // Refs to track previous values and prevent unnecessary re-renders
  const prevCurrentBidRef = useRef<number>(0);
  const prevBidHistoryLengthRef = useRef<number>(0);

  // Memoize quick bid amounts to prevent recalculation on every render
  const quickBidAmounts = useMemo(() => {
    if (!currentItem) return [5, 10, 25, 50];
    
    const current = currentItem.currentBid;
    const increment = currentItem.minimumIncrement;
    
    if (current < 50) {
      return [increment, increment * 2, increment * 3, increment * 5];
    } else if (current < 200) {
      return [10, 20, 50, 100];
    } else {
      return [25, 50, 100, 250];
    }
  }, [currentItem?.currentBid, currentItem?.minimumIncrement]);

  // Memoize minimum bid calculation
  const minBid = useMemo(() => {
    if (!currentItem) return 0;
    
    if (currentItem.incrementType === 'percentage') {
      return currentItem.currentBid * (1 + currentItem.minimumIncrement / 100);
    } else {
      return currentItem.currentBid + currentItem.minimumIncrement;
    }
  }, [currentItem?.currentBid, currentItem?.incrementType, currentItem?.minimumIncrement]);

  // Stable fetch function with useCallback
  const fetchBidHistory = useCallback(async () => {
    if (!currentItem?.id) return;
    
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-9f7745d8/bids/${currentItem.id}`, {
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`,
        }
      });

      if (response.ok) {
        const data = await response.json();
        const newBids = data.bids || [];
        
        // Only update if the data actually changed
        if (newBids.length !== prevBidHistoryLengthRef.current) {
          setBidHistory(newBids);
          setActiveBidders(new Set(newBids.map((bid: Bid) => bid.userId)).size);
          prevBidHistoryLengthRef.current = newBids.length;
        }
      }
    } catch (error) {
      console.error('Failed to fetch bid history:', error);
    }
  }, [currentItem?.id, projectId, publicAnonKey]);

  // Stable place bid function
  const placeBid = useCallback(async (amount: number, isProxyBid: boolean = false) => {
    if (isPlacingBid || !currentItem?.id) return;

    console.log('🎯 Attempting to place bid:', { auctionId: currentItem.id, amount, user: user?.id });
    
    if (!user) {
      toast.error('Please sign in to place bids');
      onAuthRequired();
      return;
    }

    try {
      setIsPlacingBid(true);
      
      // Get the user's access token
      const { data: { session } } = await supabase.auth.getSession();
      const accessToken = session?.access_token;
      
      if (!accessToken) {
        toast.error('Authentication expired. Please sign in again.');
        onAuthRequired();
        return;
      }
      
      console.log('🔑 Using access token for bid placement');
      
      // Fixed URL - match server route exactly
      const url = `https://${projectId}.supabase.co/functions/v1/make-server-9f7745d8/bid/place`;
      const requestData = {
        itemId: currentItem.id,
        amount,
        maxAmount: isProxyBid ? parseFloat(maxBid) : undefined,
        isProxyBid
      };
      
      console.log('📡 Making bid request:', { url, requestData });

      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`,
          'X-Idempotency-Key': crypto.randomUUID(), // Prevent double-charges
        },
        body: JSON.stringify(requestData)
      });

      console.log('📊 Response status:', response.status, response.statusText);

      if (!response.ok) {
        const errorText = await response.text();
        console.error('❌ Bid response error:', { status: response.status, body: errorText });
        
        let errorData;
        try {
          errorData = JSON.parse(errorText);
        } catch {
          errorData = { error: errorText || `Request failed (${response.status})` };
        }
        
        // More specific error handling
        if (response.status === 401) {
          toast.error('Authentication failed. Please sign in again.');
          onAuthRequired();
          return;
        } else if (response.status === 403) {
          toast.error('Access denied. You may not have permission to bid.');
          return;
        } else if (response.status >= 500) {
          toast.error('Server error. Please try again in a moment.');
          return;
        }
        
        throw new Error(errorData.error || errorData.message || `Bid failed (${response.status})`);
      }

      const data = await response.json();
      console.log('✅ Bid response data:', data);
      
      // Show success message
      const successMessage = isProxyBid ? '🤖 Auto-bid placed successfully!' : `✅ Bid placed: $${amount}`;
      toast.success(successMessage);
      
      // Refresh data and notify parent
      await fetchBidHistory();
      onBid(amount);
      
    } catch (error) {
      console.error('💥 Bid placement failed:', error);
      
      // More detailed error logging
      if (error instanceof TypeError && error.message.includes('fetch')) {
        console.error('🌐 Network error - possible CORS or connectivity issue');
        toast.error('Network error. Please check your connection and try again.');
      } else {
        const errorMessage = error instanceof Error ? error.message : 'Failed to place bid';
        toast.error(`Bid failed: ${errorMessage}`);
      }
    } finally {
      setIsPlacingBid(false);
    }
  }, [currentItem?.id, maxBid, isPlacingBid, onBid, onAuthRequired, fetchBidHistory, projectId, user]);

  // Stable handler functions
  const handleQuickBid = useCallback(async (amount: number) => {
    if (!user) {
      onAuthRequired();
      return;
    }

    if (!currentItem || auctionEnded) return;

    const newBidAmount = currentItem.currentBid + amount;
    await placeBid(newBidAmount, false);
  }, [user, currentItem, auctionEnded, placeBid, onAuthRequired]);

  const handleCustomBid = useCallback(async () => {
    if (!user) {
      onAuthRequired();
      return;
    }

    const bidAmount = parseFloat(customBid);
    if (!bidAmount || !currentItem || bidAmount <= currentItem.currentBid || auctionEnded) {
      return;
    }

    await placeBid(bidAmount, false);
    setCustomBid('');
  }, [user, customBid, currentItem, auctionEnded, placeBid, onAuthRequired]);

  const handleBuyItNow = useCallback(async () => {
    if (!user || !currentItem?.buyItNowPrice) return;
    
    await placeBid(currentItem.buyItNowPrice, false);
    setAuctionEnded(true);
    toast.success('🎯 You bought this item instantly!');
  }, [user, currentItem?.buyItNowPrice, placeBid]);

  const setupAutoBid = useCallback(async () => {
    if (!user || !currentItem) return;

    const maxAmount = parseFloat(maxBid);
    if (!maxAmount || maxAmount <= currentItem.currentBid) {
      toast.error('Max bid must be higher than current bid');
      return;
    }

    try {
      const { data: { session } } = await supabase.auth.getSession();
      const accessToken = session?.access_token;
      
      if (!accessToken) {
        toast.error('Please sign in to set up auto-bidding');
        onAuthRequired();
        return;
      }

      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-9f7745d8/bid/auto-setup`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`,
        },
        body: JSON.stringify({
          itemId: currentItem.id,
          maxAmount
        })
      });

      if (!response.ok) {
        throw new Error('Failed to set up auto-bidding');
      }

      setAutoBidEnabled(true);
      setAutoBidActive(true);
      toast.success(`🤖 Auto-bidding enabled up to $${maxAmount}`);
    } catch (error) {
      console.error('Auto-bid setup failed:', error);
      toast.error('Failed to set up auto-bidding');
    }
  }, [user, currentItem, maxBid, onAuthRequired, projectId]);

  // Timer and initial setup effect - only run when currentItem.id changes
  useEffect(() => {
    if (!currentItem) return;

    // Only fetch if this is a new item or if current bid changed significantly
    if (currentItem.currentBid !== prevCurrentBidRef.current) {
      fetchBidHistory();
      prevCurrentBidRef.current = currentItem.currentBid;
    }

    setTimeLeftSeconds(currentItem.timeLeft);
    setReserveMet(!currentItem.reservePrice || currentItem.currentBid >= currentItem.reservePrice);
    
    // Set up timer
    const timer = setInterval(() => {
      setTimeLeftSeconds(prev => {
        if (prev <= 0) {
          setAuctionEnded(true);
          clearInterval(timer);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [currentItem?.id, currentItem?.timeLeft, currentItem?.currentBid, currentItem?.reservePrice, fetchBidHistory]);

  // User winning status effect - only when relevant data changes
  useEffect(() => {
    if (!user?.id || bidHistory.length === 0) {
      setMyHighestBid(null);
      setIsWinning(false);
      return;
    }

    const userBids = bidHistory.filter(bid => bid.userId === user.id);
    const userHighest = userBids.length > 0 ? Math.max(...userBids.map(bid => bid.amount)) : 0;
    
    // Only update if values actually changed
    const newHighestBid = userHighest > 0 ? userHighest : null;
    const newIsWinning = currentItem?.highestBidder === user.id;
    
    if (newHighestBid !== myHighestBid) {
      setMyHighestBid(newHighestBid);
    }
    if (newIsWinning !== isWinning) {
      setIsWinning(newIsWinning);
    }
  }, [user?.id, bidHistory, currentItem?.highestBidder, myHighestBid, isWinning]);

  // Memoized time formatting function
  const formatTime = useCallback((seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  }, []);

  // Memoized time percentage calculation
  const timeLeftPercentage = useMemo(() => {
    if (!currentItem) return 100;
    const totalTime = new Date(currentItem.endTime).getTime() - new Date().getTime() + timeLeftSeconds * 1000;
    const elapsed = totalTime - timeLeftSeconds * 1000;
    return Math.max(0, ((totalTime - elapsed) / totalTime) * 100);
  }, [currentItem?.endTime, timeLeftSeconds]);

  // Stable payment handlers
  const handlePaymentSuccess = useCallback((purchaseId: string) => {
    toast.success('🎉 Payment successful! Your purchase is complete.');
    setShowPayment(false);
  }, []);

  const handlePaymentError = useCallback((error: string) => {
    toast.error(`Payment failed: ${error}`);
  }, []);
  
  if (!currentItem) {
    return (
      <div className="flex flex-col h-full p-4">
        <div className="text-center py-8">
          <Gavel className="mx-auto text-gray-400 mb-4" size={48} />
          <h3 className="text-lg font-medium text-gray-300 mb-2">No Active Auction</h3>
          <p className="text-gray-500">Check back soon for the next item</p>
        </div>
        
        {/* Upcoming Items */}
        {upcomingItems.length > 0 && (
          <div className="flex-1">
            <h4 className="font-medium text-white mb-3">Coming Up Next</h4>
            <div className="space-y-3">
              {upcomingItems.slice(0, 3).map((item, index) => (
                <div key={item.id} className="bg-gray-700 rounded-lg p-3">
                  <div className="flex items-center gap-3">
                    <ImageWithFallback 
                      src={item.image}
                      alt={item.title}
                      className="w-12 h-12 object-cover rounded"
                    />
                    <div className="flex-1">
                      <h5 className="text-sm font-medium text-white">{item.title}</h5>
                      <p className="text-xs text-gray-400">Starting at ${item.startingBid}</p>
                    </div>
                    <span className="text-xs text-gray-500">#{index + 1}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      {/* Current Item Header */}
      <div className="p-4 border-b border-gray-700">
        <div className="relative mb-4">
          <ImageWithFallback 
            src={currentItem.image}
            alt={currentItem.title}
            className="w-full h-32 object-cover rounded-lg"
          />
          
          {/* Time and Status Overlay */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent rounded-lg" />
          <div className="absolute bottom-2 left-2 right-2">
            <div className="flex items-center justify-between text-white text-sm">
              <div className="flex items-center gap-2">
                <Timer size={12} />
                <span className={timeLeftSeconds <= 60 ? 'animate-pulse text-red-400' : ''}>
                  {formatTime(timeLeftSeconds)}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <Users size={12} />
                <span>{activeBidders} bidders</span>
              </div>
            </div>
            
            {/* Time Progress Bar */}
            <Progress 
              value={timeLeftPercentage} 
              className="h-1 mt-1"
            />
          </div>
        </div>
        
        <h3 className="font-medium text-white mb-1">{currentItem.title}</h3>
        <p className="text-sm text-gray-400 mb-3 line-clamp-2">{currentItem.description}</p>
        
        {/* Current Status */}
        <div className="grid grid-cols-2 gap-4 mb-4">
          <div className="bg-gray-700 rounded-lg p-3 text-center">
            <p className="text-xs text-gray-400 mb-1">Current Bid</p>
            <p className="text-lg font-bold text-green-400">${currentItem.currentBid}</p>
          </div>
          <div className="bg-gray-700 rounded-lg p-3 text-center">
            <p className="text-xs text-gray-400 mb-1">Total Bids</p>
            <p className="text-lg font-bold text-blue-400">{currentItem.bidCount}</p>
          </div>
        </div>

        {/* Reserve & Buy It Now */}
        <div className="flex items-center gap-2 mb-4">
          {currentItem.reservePrice && (
            <Badge variant={reserveMet ? "default" : "secondary"} className="flex items-center gap-1">
              <Shield className="w-3 h-3" />
              Reserve {reserveMet ? 'Met' : `$${currentItem.reservePrice}`}
            </Badge>
          )}
          
          {currentItem.buyItNowPrice && (
            <Badge variant="outline" className="flex items-center gap-1 border-yellow-500 text-yellow-400">
              <Zap className="w-3 h-3" />
              Buy Now: ${currentItem.buyItNowPrice}
            </Badge>
          )}
        </div>

        {/* Winning Status */}
        {user && myHighestBid && (
          <div className={`mb-4 p-3 rounded-lg border ${
            isWinning 
              ? 'bg-green-500/20 border-green-500 text-green-400' 
              : 'bg-yellow-500/20 border-yellow-500 text-yellow-400'
          }`}>
            <div className="flex items-center gap-2 mb-1">
              {isWinning ? <Trophy className="w-4 h-4" /> : <TrendingUp className="w-4 h-4" />}
              <span className="text-sm font-medium">
                {isWinning ? 'You\'re winning!' : 'You\'ve been outbid'}
              </span>
            </div>
            <p className="text-xs opacity-90">
              Your highest bid: ${myHighestBid}
            </p>
          </div>
        )}

        {/* Auction Ended - Payment Required */}
        {auctionEnded && isWinning && user && (
          <div className="mb-4 p-4 bg-green-500/20 border border-green-500 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <Trophy className="w-5 h-5 text-green-400" />
              <h4 className="font-medium text-green-400">Auction Won!</h4>
            </div>
            <p className="text-sm text-green-300 mb-3">
              Congratulations! You won this auction for ${myHighestBid}.
            </p>
            <Button 
              onClick={() => setShowPayment(true)}
              className="w-full bg-green-500 hover:bg-green-600 text-white"
            >
              <CreditCard className="w-4 h-4 mr-2" />
              Pay Now - ${myHighestBid}
            </Button>
          </div>
        )}
      </div>

      {/* Bidding Interface */}
      {!auctionEnded && (
        <div className="p-4 border-b border-gray-700">
          <Tabs defaultValue="quick" className="w-full">
            <TabsList className="grid w-full grid-cols-3 bg-gray-700">
              <TabsTrigger value="quick">Quick Bid</TabsTrigger>
              <TabsTrigger value="custom">Custom</TabsTrigger>
              <TabsTrigger value="auto">Auto-Bid</TabsTrigger>
            </TabsList>
            
            <TabsContent value="quick" className="space-y-3 mt-4">
              <h4 className="font-medium text-white">Quick Bid</h4>
              <div className="grid grid-cols-2 gap-2">
                {quickBidAmounts.map((amount) => (
                  <Button
                    key={amount}
                    onClick={() => handleQuickBid(amount)}
                    disabled={!user}
                    className="bg-yellow-400 text-gray-900 hover:bg-yellow-300 transition-colors disabled:opacity-50"
                  >
                    <Plus size={14} className="mr-1" />
                    ${amount}
                  </Button>
                ))}
              </div>
              
              {currentItem.buyItNowPrice && (
                <Button
                  onClick={handleBuyItNow}
                  disabled={!user}
                  className="w-full bg-orange-500 hover:bg-orange-600 text-white"
                >
                  <Zap className="w-4 h-4 mr-2" />
                  Buy It Now - ${currentItem.buyItNowPrice}
                </Button>
              )}
            </TabsContent>
            
            <TabsContent value="custom" className="space-y-3 mt-4">
              <h4 className="font-medium text-white">Custom Bid</h4>
              <div className="flex gap-2">
                <div className="flex-1 relative">
                  <DollarSign className="absolute left-2 top-2 text-gray-400" size={16} />
                  <Input
                    type="number"
                    value={customBid}
                    onChange={(e) => setCustomBid(e.target.value)}
                    placeholder={`Min: ${minBid.toFixed(2)}`}
                    min={minBid}
                    step="0.01"
                    disabled={!user}
                    className="w-full bg-gray-700 text-white pl-8 pr-3 py-2 border-gray-600"
                  />
                </div>
                <Button
                  onClick={handleCustomBid}
                  disabled={!user || !customBid || parseFloat(customBid) < minBid}
                  className="bg-green-500 text-white hover:bg-green-400"
                >
                  Bid
                </Button>
              </div>
            </TabsContent>
            
            <TabsContent value="auto" className="space-y-3 mt-4">
              <div className="flex items-center justify-between">
                <h4 className="font-medium text-white">Auto-Bidding</h4>
                {autoBidActive && (
                  <Badge className="bg-blue-500 text-white flex items-center gap-1">
                    <Bot className="w-3 h-3" />
                    Active
                  </Badge>
                )}
              </div>
              
              {!autoBidEnabled ? (
                <>
                  <div className="relative">
                    <DollarSign className="absolute left-2 top-2 text-gray-400" size={16} />
                    <Input
                      type="number"
                      value={maxBid}
                      onChange={(e) => setMaxBid(e.target.value)}
                      placeholder="Maximum bid amount"
                      min={minBid}
                      step="0.01"
                      disabled={!user}
                      className="w-full bg-gray-700 text-white pl-8 pr-3 py-2 border-gray-600"
                    />
                  </div>
                  <Button
                    onClick={setupAutoBid}
                    disabled={!user || !maxBid || parseFloat(maxBid) < minBid}
                    className="w-full bg-blue-500 hover:bg-blue-600 text-white"
                  >
                    <Bot className="w-4 h-4 mr-2" />
                    Enable Auto-Bidding
                  </Button>
                </>
              ) : (
                <div className="bg-blue-500/20 border border-blue-500 rounded-lg p-3">
                  <div className="flex items-center gap-2 mb-2">
                    <Bot className="w-4 h-4 text-blue-400" />
                    <span className="text-sm font-medium text-blue-400">Auto-bidding enabled</span>
                  </div>
                  <p className="text-xs text-blue-300">
                    Will automatically bid up to ${maxBid} to keep you winning
                  </p>
                  <div className="flex items-center justify-between mt-2">
                    <span className="text-xs text-blue-300">Active</span>
                    <Switch
                      checked={autoBidActive}
                      onCheckedChange={setAutoBidActive}
                    />
                  </div>
                </div>
              )}
            </TabsContent>
          </Tabs>
          
          {!user && (
            <p className="text-xs text-gray-500 mt-3 text-center">
              <button 
                onClick={onAuthRequired}
                className="text-yellow-400 hover:text-yellow-300 transition-colors"
              >
                Sign in
              </button>
              {' '}to place bids
            </p>
          )}
        </div>
      )}

      {/* Bid History */}
      <div className="flex-1 p-4">
        <h4 className="font-medium text-white mb-3">Recent Bids</h4>
        <div className="space-y-2 max-h-48 overflow-y-auto">
          {bidHistory.length === 0 ? (
            <p className="text-gray-500 text-sm text-center py-4">No bids yet</p>
          ) : (
            bidHistory.slice(0, 10).map((bid, index) => (
              <div key={bid.id} className="flex items-center justify-between bg-gray-700 rounded-lg p-2">
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 bg-gray-600 rounded-full flex items-center justify-center">
                    <span className="text-xs text-white">{bid.userName[0]}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <span className="text-sm text-white">{bid.userName}</span>
                    {bid.isProxyBid && <Bot className="w-3 h-3 text-blue-400" />}
                    {bid.status === 'winning' && <Trophy className="w-3 h-3 text-green-400" />}
                  </div>
                </div>
                <div className="text-right">
                  <div className={`text-sm font-medium ${
                    bid.status === 'winning' ? 'text-green-400' : 
                    bid.status === 'outbid' ? 'text-gray-400' : 'text-yellow-400'
                  }`}>
                    ${bid.amount}
                  </div>
                  <div className="text-xs text-gray-400">
                    {new Date(bid.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Upcoming Items Preview */}
      {upcomingItems.length > 0 && (
        <div className="p-4 border-t border-gray-700">
          <h4 className="font-medium text-white mb-3">Next Up</h4>
          <div className="flex gap-2 overflow-x-auto">
            {upcomingItems.slice(0, 3).map((item, index) => (
              <div key={item.id} className="flex-shrink-0 w-16">
                <ImageWithFallback 
                  src={item.image}
                  alt={item.title}
                  className="w-16 h-16 object-cover rounded-lg"
                />
                <p className="text-xs text-gray-400 mt-1 text-center">#{index + 1}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* PayPal Checkout Modal */}
      {showPayment && currentItem && myHighestBid && (
        <PayPalCheckout
          isOpen={showPayment}
          onClose={() => setShowPayment(false)}
          amount={myHighestBid}
          description={`Payment for auction win: ${currentItem.title}`}
          auctionId={currentItem.id}
          itemId={currentItem.id}
          itemTitle={currentItem.title}
          onSuccess={handlePaymentSuccess}
          onError={handlePaymentError}
        />
      )}
    </div>
  );
}