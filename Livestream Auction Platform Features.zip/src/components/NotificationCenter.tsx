import React, { useState, useEffect } from 'react';
import { 
  Bell, 
  BellOff, 
  Check, 
  X, 
  Filter, 
  Settings,
  Trash2,
  Clock,
  DollarSign,
  Gavel,
  Package,
  AlertTriangle,
  Trophy,
  User,
  Eye,
  EyeOff
} from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Switch } from './ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Skeleton } from './ui/skeleton';
import { toast } from 'sonner@2.0.3';
import { projectId, publicAnonKey } from '../utils/supabase/info';

interface Notification {
  id: string;
  userId: string;
  type: 'outbid' | 'auction_ending' | 'auction_won' | 'new_item' | 'price_drop' | 'payment_required' | 'system';
  itemId?: string;
  sellerId?: string;
  title: string;
  message: string;
  data?: any;
  read: boolean;
  priority: 'low' | 'medium' | 'high' | 'urgent';
  createdAt: string;
  expiresAt?: string;
}

interface NotificationPreferences {
  userId: string;
  outbidAlerts: boolean;
  auctionEndingAlerts: boolean;
  newItemAlerts: boolean;
  priceDropAlerts: boolean;
  systemAlerts: boolean;
  emailNotifications: boolean;
  pushNotifications: boolean;
  quietHours: {
    enabled: boolean;
    startTime: string;
    endTime: string;
  };
}

interface NotificationCenterProps {
  user: any;
  isOpen: boolean;
  onClose: () => void;
}

export function NotificationCenter({ user, isOpen, onClose }: NotificationCenterProps) {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [preferences, setPreferences] = useState<NotificationPreferences | null>(null);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | 'unread' | 'high'>('all');
  const [showSettings, setShowSettings] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);

  useEffect(() => {
    if (user && isOpen) {
      fetchNotifications();
      fetchPreferences();
      
      // Set up polling for real-time updates
      const interval = setInterval(fetchNotifications, 30000); // Poll every 30 seconds
      return () => clearInterval(interval);
    }
  }, [user, isOpen]);

  const fetchNotifications = async () => {
    try {
      if (!user) return;

      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-9f7745d8/notifications/${user.id}`, {
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`,
        }
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to fetch notifications');
      }

      const data = await response.json();
      setNotifications(data.notifications || []);
      setUnreadCount(data.unreadCount || 0);
    } catch (error) {
      console.error('❌ Failed to fetch notifications:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchPreferences = async () => {
    try {
      if (!user) return;

      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-9f7745d8/notifications/${user.id}/preferences`, {
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`,
        }
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to fetch preferences');
      }

      const data = await response.json();
      setPreferences(data.preferences);
    } catch (error) {
      console.error('❌ Failed to fetch preferences:', error);
    }
  };

  const markAsRead = async (notificationId: string) => {
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-9f7745d8/notifications/${notificationId}/read`, {
        method: 'PATCH',
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`,
        }
      });

      if (!response.ok) {
        throw new Error('Failed to mark as read');
      }

      // Update local state
      setNotifications(prev => 
        prev.map(n => n.id === notificationId ? { ...n, read: true } : n)
      );
      setUnreadCount(prev => Math.max(0, prev - 1));
    } catch (error) {
      console.error('❌ Failed to mark as read:', error);
      toast.error('Failed to mark notification as read');
    }
  };

  const markAllAsRead = async () => {
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-9f7745d8/notifications/${user.id}/read-all`, {
        method: 'PATCH',
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`,
        }
      });

      if (!response.ok) {
        throw new Error('Failed to mark all as read');
      }

      setNotifications(prev => prev.map(n => ({ ...n, read: true })));
      setUnreadCount(0);
      toast.success('All notifications marked as read');
    } catch (error) {
      console.error('❌ Failed to mark all as read:', error);
      toast.error('Failed to mark all notifications as read');
    }
  };

  const deleteNotification = async (notificationId: string) => {
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-9f7745d8/notifications/${notificationId}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`,
        }
      });

      if (!response.ok) {
        throw new Error('Failed to delete notification');
      }

      setNotifications(prev => prev.filter(n => n.id !== notificationId));
      setUnreadCount(prev => {
        const notification = notifications.find(n => n.id === notificationId);
        return notification && !notification.read ? Math.max(0, prev - 1) : prev;
      });
    } catch (error) {
      console.error('❌ Failed to delete notification:', error);
      toast.error('Failed to delete notification');
    }
  };

  const updatePreferences = async (newPreferences: Partial<NotificationPreferences>) => {
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-9f7745d8/notifications/${user.id}/preferences`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`,
        },
        body: JSON.stringify(newPreferences)
      });

      if (!response.ok) {
        throw new Error('Failed to update preferences');
      }

      const data = await response.json();
      setPreferences(data.preferences);
      toast.success('Notification preferences updated');
    } catch (error) {
      console.error('❌ Failed to update preferences:', error);
      toast.error('Failed to update preferences');
    }
  };

  const sendTestNotification = async () => {
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-9f7745d8/notifications/test`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`,
        }
      });

      if (!response.ok) {
        throw new Error('Failed to send test notification');
      }

      toast.success('Test notification sent');
      setTimeout(fetchNotifications, 1000); // Refresh notifications after 1 second
    } catch (error) {
      console.error('❌ Failed to send test notification:', error);
      toast.error('Failed to send test notification');
    }
  };

  const getNotificationIcon = (type: string, priority: string) => {
    const className = `w-5 h-5 ${
      priority === 'urgent' ? 'text-red-400' :
      priority === 'high' ? 'text-orange-400' :
      priority === 'medium' ? 'text-cyan-400' :
      'text-gray-400'
    }`;

    switch (type) {
      case 'outbid':
        return <Gavel className={className} />;
      case 'auction_ending':
        return <Clock className={className} />;
      case 'auction_won':
        return <Trophy className={className} />;
      case 'new_item':
        return <Package className={className} />;
      case 'price_drop':
        return <DollarSign className={className} />;
      case 'payment_required':
        return <AlertTriangle className={className} />;
      case 'system':
      default:
        return <Bell className={className} />;
    }
  };

  const getPriorityBadge = (priority: string) => {
    switch (priority) {
      case 'urgent':
        return <Badge variant="destructive">Urgent</Badge>;
      case 'high':
        return <Badge variant="secondary">High</Badge>;
      default:
        return null;
    }
  };

  const filteredNotifications = notifications.filter(notification => {
    switch (filter) {
      case 'unread':
        return !notification.read;
      case 'high':
        return notification.priority === 'high' || notification.priority === 'urgent';
      default:
        return true;
    }
  });

  const formatTimeAgo = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffInMs = now.getTime() - date.getTime();
    const diffInMinutes = Math.floor(diffInMs / (1000 * 60));
    const diffInHours = Math.floor(diffInMinutes / 60);
    const diffInDays = Math.floor(diffInHours / 24);

    if (diffInMinutes < 1) return 'Just now';
    if (diffInMinutes < 60) return `${diffInMinutes}m ago`;
    if (diffInHours < 24) return `${diffInHours}h ago`;
    if (diffInDays < 7) return `${diffInDays}d ago`;
    return date.toLocaleDateString();
  };

  if (!isOpen) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-2xl max-h-[80vh] bg-gray-800 border-gray-700">
        <DialogHeader className="flex flex-row items-center justify-between">
          <DialogTitle className="text-white flex items-center gap-2">
            <Bell className="w-5 h-5" />
            Notifications
            {unreadCount > 0 && (
              <Badge className="bg-cyan-500 text-white">
                {unreadCount > 99 ? '99+' : unreadCount}
              </Badge>
            )}
          </DialogTitle>
          
          <div className="flex items-center gap-2">
            <Dialog open={showSettings} onOpenChange={setShowSettings}>
              <DialogTrigger asChild>
                <Button size="sm" variant="outline" className="border-gray-600">
                  <Settings className="w-4 h-4" />
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-md bg-gray-800 border-gray-700">
                <DialogHeader>
                  <DialogTitle className="text-white">Notification Settings</DialogTitle>
                </DialogHeader>
                
                {preferences && (
                  <div className="space-y-6">
                    <div className="space-y-4">
                      <h3 className="text-sm font-medium text-white">Alert Types</h3>
                      
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <label className="text-sm text-gray-300">Outbid notifications</label>
                          <Switch
                            checked={preferences.outbidAlerts}
                            onCheckedChange={(checked) => 
                              updatePreferences({ ...preferences, outbidAlerts: checked })
                            }
                          />
                        </div>
                        
                        <div className="flex items-center justify-between">
                          <label className="text-sm text-gray-300">Auction ending alerts</label>
                          <Switch
                            checked={preferences.auctionEndingAlerts}
                            onCheckedChange={(checked) => 
                              updatePreferences({ ...preferences, auctionEndingAlerts: checked })
                            }
                          />
                        </div>
                        
                        <div className="flex items-center justify-between">
                          <label className="text-sm text-gray-300">New item alerts</label>
                          <Switch
                            checked={preferences.newItemAlerts}
                            onCheckedChange={(checked) => 
                              updatePreferences({ ...preferences, newItemAlerts: checked })
                            }
                          />
                        </div>
                        
                        <div className="flex items-center justify-between">
                          <label className="text-sm text-gray-300">Price drop alerts</label>
                          <Switch
                            checked={preferences.priceDropAlerts}
                            onCheckedChange={(checked) => 
                              updatePreferences({ ...preferences, priceDropAlerts: checked })
                            }
                          />
                        </div>
                        
                        <div className="flex items-center justify-between">
                          <label className="text-sm text-gray-300">System notifications</label>
                          <Switch
                            checked={preferences.systemAlerts}
                            onCheckedChange={(checked) => 
                              updatePreferences({ ...preferences, systemAlerts: checked })
                            }
                          />
                        </div>
                      </div>
                    </div>

                    <div className="border-t border-gray-700 pt-4">
                      <Button 
                        onClick={sendTestNotification}
                        variant="outline"
                        size="sm"
                        className="w-full border-gray-600"
                      >
                        Send Test Notification
                      </Button>
                    </div>
                  </div>
                )}
              </DialogContent>
            </Dialog>
          </div>
        </DialogHeader>

        <div className="space-y-4">
          {/* Filter Tabs */}
          <Tabs value={filter} onValueChange={(value) => setFilter(value as any)}>
            <div className="flex items-center justify-between">
              <TabsList className="bg-gray-700">
                <TabsTrigger value="all" className="data-[state=active]:bg-cyan-500">
                  All ({notifications.length})
                </TabsTrigger>
                <TabsTrigger value="unread" className="data-[state=active]:bg-cyan-500">
                  Unread ({unreadCount})
                </TabsTrigger>
                <TabsTrigger value="high" className="data-[state=active]:bg-cyan-500">
                  Priority
                </TabsTrigger>
              </TabsList>
              
              {unreadCount > 0 && (
                <Button
                  onClick={markAllAsRead}
                  size="sm"
                  variant="outline"
                  className="border-gray-600 text-gray-300"
                >
                  <Check className="w-4 h-4 mr-2" />
                  Mark All Read
                </Button>
              )}
            </div>

            <TabsContent value={filter} className="mt-4">
              <div className="max-h-96 overflow-y-auto space-y-2">
                {loading ? (
                  // Loading skeleton
                  [...Array(5)].map((_, i) => (
                    <div key={i} className="flex items-start gap-3 p-3 bg-gray-700 rounded-lg">
                      <Skeleton className="w-5 h-5 bg-gray-600" />
                      <div className="flex-1 space-y-2">
                        <Skeleton className="h-4 w-3/4 bg-gray-600" />
                        <Skeleton className="h-3 w-1/2 bg-gray-600" />
                      </div>
                    </div>
                  ))
                ) : filteredNotifications.length === 0 ? (
                  <div className="text-center py-8">
                    <BellOff className="w-12 h-12 text-gray-600 mx-auto mb-3" />
                    <p className="text-gray-400">
                      {filter === 'unread' ? 'No unread notifications' : 
                       filter === 'high' ? 'No priority notifications' : 
                       'No notifications yet'}
                    </p>
                  </div>
                ) : (
                  filteredNotifications.map((notification) => (
                    <div
                      key={notification.id}
                      className={`flex items-start gap-3 p-3 rounded-lg border transition-colors ${
                        notification.read 
                          ? 'bg-gray-700 border-gray-600' 
                          : 'bg-gray-600 border-cyan-500/20'
                      }`}
                    >
                      <div className="flex-shrink-0 mt-1">
                        {getNotificationIcon(notification.type, notification.priority)}
                      </div>
                      
                      <div className="flex-1 min-w-0">
                        <div className="flex items-start justify-between gap-2">
                          <div className="flex-1">
                            <h4 className="text-sm font-medium text-white mb-1">
                              {notification.title}
                            </h4>
                            <p className="text-sm text-gray-300 mb-2">
                              {notification.message}
                            </p>
                            <div className="flex items-center gap-2">
                              <span className="text-xs text-gray-500">
                                {formatTimeAgo(notification.createdAt)}
                              </span>
                              {getPriorityBadge(notification.priority)}
                            </div>
                          </div>
                          
                          <div className="flex items-center gap-1">
                            {!notification.read && (
                              <Button
                                onClick={() => markAsRead(notification.id)}
                                size="sm"
                                variant="ghost"
                                className="h-6 w-6 p-0 text-gray-400 hover:text-white"
                              >
                                <Eye className="w-3 h-3" />
                              </Button>
                            )}
                            <Button
                              onClick={() => deleteNotification(notification.id)}
                              size="sm"
                              variant="ghost"
                              className="h-6 w-6 p-0 text-gray-400 hover:text-red-400"
                            >
                              <X className="w-3 h-3" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </DialogContent>
    </Dialog>
  );
}