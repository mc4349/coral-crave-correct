import React from 'react';
import { QuickSystemDiagnostic } from './QuickSystemDiagnostic';

interface DiagnosticContainerProps {
  user?: { id: string; email: string; name: string } | null;
}

export function DiagnosticContainer({ user }: DiagnosticContainerProps) {
  return (
    <div className="mb-8">
      <QuickSystemDiagnostic user={user} />
    </div>
  );
}