import React from 'react';

interface AdminDashboardProps {
  userId: string;
}

export function AdminDashboard({ userId }: AdminDashboardProps) {
  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold text-white mb-4">Admin Dashboard</h1>
      <p className="text-gray-400">Admin features coming soon...</p>
    </div>
  );
}

export default AdminDashboard;