import React, { useState } from 'react';
import { Receipt, Package, Truck, DollarSign, Check, Clock, AlertCircle } from 'lucide-react';

interface InvoiceData {
  id: string;
  itemName: string;
  sellerName: string;
  buyerName: string;
  finalBid: number;
  commission: number;
  processingFee: number;
  netPayout: number;
  status: 'paid' | 'shipped' | 'delivered';
  paymentDate: Date;
  shippingDate?: Date;
  trackingNumber?: string;
}

interface InvoiceCardProps {
  invoice: InvoiceData;
  userType: 'buyer' | 'seller';
  onEnterTracking?: (invoiceId: string, trackingNumber: string) => void;
  onMarkShipped?: (invoiceId: string) => void;
}

export function InvoiceCard({ invoice, userType, onEnterTracking, onMarkShipped }: InvoiceCardProps) {
  const [activeTab, setActiveTab] = useState<'buyer' | 'seller'>('buyer');
  const [trackingInput, setTrackingInput] = useState('');
  const [showTrackingInput, setShowTrackingInput] = useState(false);

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'paid':
        return <Clock className="text-yellow-400" size={16} />;
      case 'shipped':
        return <Truck className="text-blue-400" size={16} />;
      case 'delivered':
        return <Check className="text-green-400" size={16} />;
      default:
        return <AlertCircle className="text-gray-400" size={16} />;
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'paid':
        return 'Paid - Awaiting Shipment';
      case 'shipped':
        return 'Shipped';
      case 'delivered':
        return 'Delivered';
      default:
        return 'Unknown Status';
    }
  };

  const handleSubmitTracking = () => {
    if (trackingInput.trim() && onEnterTracking) {
      onEnterTracking(invoice.id, trackingInput.trim());
      setTrackingInput('');
      setShowTrackingInput(false);
    }
  };

  return (
    <div className="bg-gray-800 rounded-xl border border-gray-700 overflow-hidden">
      {/* Header with Tabs */}
      <div className="border-b border-gray-700">
        <div className="flex">
          <button
            onClick={() => setActiveTab('buyer')}
            className={`flex-1 px-4 py-3 text-sm font-medium transition-colors ${
              activeTab === 'buyer'
                ? 'bg-cyan-500 text-white'
                : 'text-gray-400 hover:text-white hover:bg-gray-700'
            }`}
          >
            <Receipt className="inline mr-2" size={16} />
            Buyer View
          </button>
          <button
            onClick={() => setActiveTab('seller')}
            className={`flex-1 px-4 py-3 text-sm font-medium transition-colors ${
              activeTab === 'seller'
                ? 'bg-cyan-500 text-white'
                : 'text-gray-400 hover:text-white hover:bg-gray-700'
            }`}
          >
            <DollarSign className="inline mr-2" size={16} />
            Seller View
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="p-6">
        {activeTab === 'buyer' ? (
          /* Buyer View */
          <div>
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-white">Purchase Receipt</h3>
              <div className="flex items-center gap-2">
                {getStatusIcon(invoice.status)}
                <span className="text-sm text-gray-300">{getStatusText(invoice.status)}</span>
              </div>
            </div>

            {/* Item Details */}
            <div className="space-y-4 mb-6">
              <div className="flex justify-between">
                <span className="text-gray-400">Item:</span>
                <span className="text-white font-medium">{invoice.itemName}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Seller:</span>
                <span className="text-white">{invoice.sellerName}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Winning Bid:</span>
                <span className="text-green-400 font-bold">${invoice.finalBid.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Payment Date:</span>
                <span className="text-white">{invoice.paymentDate.toLocaleDateString()}</span>
              </div>
            </div>

            {/* Payment Summary */}
            <div className="bg-green-600/10 border border-green-500/20 rounded-lg p-4 mb-6">
              <h4 className="font-medium text-white mb-2">Payment Summary</h4>
              <div className="flex justify-between">
                <span className="text-green-400">Total Paid:</span>
                <span className="text-green-400 font-bold">${invoice.finalBid.toFixed(2)}</span>
              </div>
              <p className="text-sm text-green-300 mt-2">
                ✓ No additional fees for buyers!
              </p>
            </div>

            {/* Shipping Info */}
            {invoice.trackingNumber && (
              <div className="bg-blue-600/10 border border-blue-500/20 rounded-lg p-4">
                <h4 className="font-medium text-white mb-2 flex items-center gap-2">
                  <Truck size={16} />
                  Shipping Information
                </h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-400">Tracking Number:</span>
                    <span className="text-blue-400 font-mono">{invoice.trackingNumber}</span>
                  </div>
                  {invoice.shippingDate && (
                    <div className="flex justify-between">
                      <span className="text-gray-400">Shipped Date:</span>
                      <span className="text-white">{invoice.shippingDate.toLocaleDateString()}</span>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        ) : (
          /* Seller View */
          <div>
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-white">Seller Payout</h3>
              <div className="flex items-center gap-2">
                {getStatusIcon(invoice.status)}
                <span className="text-sm text-gray-300">{getStatusText(invoice.status)}</span>
              </div>
            </div>

            {/* Item Details */}
            <div className="space-y-4 mb-6">
              <div className="flex justify-between">
                <span className="text-gray-400">Item:</span>
                <span className="text-white font-medium">{invoice.itemName}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Buyer:</span>
                <span className="text-white">{invoice.buyerName}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Final Bid:</span>
                <span className="text-white font-bold">${invoice.finalBid.toFixed(2)}</span>
              </div>
            </div>

            {/* Fee Breakdown */}
            <div className="bg-yellow-600/10 border border-yellow-500/20 rounded-lg p-4 mb-6">
              <h4 className="font-medium text-white mb-3">Fee Breakdown</h4>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-400">Final Bid:</span>
                  <span className="text-white">${invoice.finalBid.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-yellow-400">Commission (8%):</span>
                  <span className="text-yellow-400">-${invoice.commission.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-yellow-400">Processing (2.9% + $0.30):</span>
                  <span className="text-yellow-400">-${invoice.processingFee.toFixed(2)}</span>
                </div>
                <div className="border-t border-gray-600 pt-2 flex justify-between font-bold">
                  <span className="text-green-400">Net Payout:</span>
                  <span className="text-green-400">${invoice.netPayout.toFixed(2)}</span>
                </div>
              </div>
            </div>

            {/* Payout Formula */}
            <div className="bg-gray-700 rounded-lg p-3 mb-6">
              <p className="text-xs text-gray-300">
                <strong>Formula:</strong> Payout = Bid - (Bid × 0.08) - (Bid × 0.029 + 0.30)
              </p>
            </div>

            {/* Shipping Management */}
            {invoice.status === 'paid' && userType === 'seller' && (
              <div className="bg-gray-700 rounded-lg p-4">
                <h4 className="font-medium text-white mb-3 flex items-center gap-2">
                  <Package size={16} />
                  Shipping Management
                </h4>
                
                {!showTrackingInput ? (
                  <button
                    onClick={() => setShowTrackingInput(true)}
                    className="w-full bg-blue-500 text-white py-2 px-4 rounded-lg hover:bg-blue-600 transition-colors"
                  >
                    Enter Tracking Number
                  </button>
                ) : (
                  <div className="space-y-3">
                    <input
                      type="text"
                      value={trackingInput}
                      onChange={(e) => setTrackingInput(e.target.value)}
                      placeholder="Enter tracking number..."
                      className="w-full bg-gray-600 text-white px-3 py-2 rounded border border-gray-500 focus:border-blue-400 focus:outline-none"
                    />
                    <div className="flex gap-2">
                      <button
                        onClick={handleSubmitTracking}
                        disabled={!trackingInput.trim()}
                        className="flex-1 bg-green-500 text-white py-2 px-4 rounded hover:bg-green-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                      >
                        Mark as Shipped
                      </button>
                      <button
                        onClick={() => {
                          setShowTrackingInput(false);
                          setTrackingInput('');
                        }}
                        className="flex-1 bg-gray-600 text-white py-2 px-4 rounded hover:bg-gray-500 transition-colors"
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Tracking Info */}
            {invoice.trackingNumber && (
              <div className="bg-blue-600/10 border border-blue-500/20 rounded-lg p-4 mt-4">
                <h4 className="font-medium text-white mb-2 flex items-center gap-2">
                  <Check className="text-green-400" size={16} />
                  Shipped
                </h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-400">Tracking Number:</span>
                    <span className="text-blue-400 font-mono">{invoice.trackingNumber}</span>
                  </div>
                  {invoice.shippingDate && (
                    <div className="flex justify-between">
                      <span className="text-gray-400">Shipped Date:</span>
                      <span className="text-white">{invoice.shippingDate.toLocaleDateString()}</span>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}