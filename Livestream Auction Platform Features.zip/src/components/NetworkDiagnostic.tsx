import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { CheckCircle, XCircle, Loader, AlertTriangle, Wifi, Globe, Activity } from 'lucide-react';
import { projectId, publicAnonKey } from '../utils/supabase/info';

export function NetworkDiagnostic() {
  const [tests, setTests] = useState({
    basicConnectivity: { status: 'idle', message: '', duration: 0 },
    corsTest: { status: 'idle', message: '', duration: 0 },
    serverHealth: { status: 'idle', message: '', duration: 0 },
    authEndpoint: { status: 'idle', message: '', duration: 0 }
  });
  const [isRunning, setIsRunning] = useState(false);

  const runTest = async (testName: string, testFn: () => Promise<{ success: boolean; message: string }>) => {
    const startTime = Date.now();
    
    setTests(prev => ({
      ...prev,
      [testName]: { status: 'loading', message: 'Running...', duration: 0 }
    }));

    try {
      const result = await testFn();
      const duration = Date.now() - startTime;
      
      setTests(prev => ({
        ...prev,
        [testName]: {
          status: result.success ? 'success' : 'error',
          message: result.message,
          duration
        }
      }));
    } catch (error) {
      const duration = Date.now() - startTime;
      const message = error instanceof Error ? error.message : 'Unknown error';
      
      setTests(prev => ({
        ...prev,
        [testName]: {
          status: 'error',
          message: `Failed: ${message}`,
          duration
        }
      }));
    }
  };

  const testBasicConnectivity = async () => {
    return new Promise<{ success: boolean; message: string }>((resolve) => {
      if (!navigator.onLine) {
        resolve({ success: false, message: 'No internet connection detected' });
        return;
      }

      // Test basic DNS resolution with a simple fetch to a known endpoint
      fetch('https://httpbin.org/get', { method: 'HEAD', mode: 'no-cors' })
        .then(() => {
          resolve({ success: true, message: 'Internet connectivity confirmed' });
        })
        .catch(() => {
          resolve({ success: false, message: 'Internet connectivity issues detected' });
        });
    });
  };

  const testCORS = async () => {
    try {
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-9f7745d8/ping`, {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json',
        }
      });

      if (response.ok) {
        const data = await response.json();
        return { 
          success: true, 
          message: `CORS OK - Server responded: ${data.ping || 'pong'}` 
        };
      } else {
        return { 
          success: false, 
          message: `CORS/Server issue - HTTP ${response.status}` 
        };
      }
    } catch (error) {
      if (error instanceof TypeError && error.message.includes('CORS')) {
        return { success: false, message: 'CORS policy blocking request' };
      } else if (error instanceof TypeError && error.message.includes('fetch')) {
        return { success: false, message: 'Network/DNS resolution failed' };
      } else {
        return { success: false, message: `Network error: ${error.message}` };
      }
    }
  };

  const testServerHealth = async () => {
    try {
      console.log('🔍 Testing server health endpoint...');
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-9f7745d8/health`);
      
      console.log('📊 Health response status:', response.status, response.statusText);
      
      if (response.ok) {
        const data = await response.json();
        console.log('✅ Health response data:', data);
        return { 
          success: true, 
          message: `Server healthy - Status: ${data.status} (v${data.version})` 
        };
      } else {
        const errorText = await response.text();
        console.error('❌ Health response error:', errorText);
        return { 
          success: false, 
          message: `Server unhealthy - ${response.status}: ${errorText}` 
        };
      }
    } catch (error) {
      console.error('💥 Health check network error:', error);
      return { 
        success: false, 
        message: `Health check failed: ${error.message}` 
      };
    }
  };

  const testAuthEndpoint = async () => {
    try {
      // Test the signup endpoint with invalid data to see if it responds
      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-9f7745d8/signup`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({}) // Empty body should return 400
      });

      if (response.status === 400) {
        const data = await response.json();
        return { 
          success: true, 
          message: `Auth endpoint accessible - Validation working: ${data.error}` 
        };
      } else if (response.ok) {
        return { 
          success: true, 
          message: 'Auth endpoint responding correctly' 
        };
      } else {
        return { 
          success: false, 
          message: `Auth endpoint error - HTTP ${response.status}` 
        };
      }
    } catch (error) {
      return { 
        success: false, 
        message: `Auth endpoint failed: ${error.message}` 
      };
    }
  };

  const runAllTests = async () => {
    setIsRunning(true);
    
    await runTest('basicConnectivity', testBasicConnectivity);
    await runTest('corsTest', testCORS);
    await runTest('serverHealth', testServerHealth);
    await runTest('authEndpoint', testAuthEndpoint);
    
    setIsRunning(false);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'loading':
        return <Loader className="animate-spin text-yellow-400" size={16} />;
      case 'success':
        return <CheckCircle className="text-green-400" size={16} />;
      case 'error':
        return <XCircle className="text-red-400" size={16} />;
      default:
        return <div className="w-4 h-4 bg-gray-600 rounded-full" />;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'success':
        return <Badge className="bg-green-500/20 text-green-400 border-green-400">OK</Badge>;
      case 'error':
        return <Badge className="bg-red-500/20 text-red-400 border-red-400">Failed</Badge>;
      case 'loading':
        return <Badge className="bg-yellow-500/20 text-yellow-400 border-yellow-400">Testing</Badge>;
      default:
        return <Badge className="bg-gray-500/20 text-gray-400 border-gray-400">Not Tested</Badge>;
    }
  };

  // Auto-run tests on mount
  useEffect(() => {
    runAllTests();
  }, []);

  return (
    <Card className="bg-gray-800 border-gray-700">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center space-x-2">
            <Activity className="text-blue-400" size={20} />
            <span>🌐 Network Diagnostics</span>
          </CardTitle>
          <Button 
            onClick={runAllTests}
            disabled={isRunning}
            size="sm"
            variant="outline"
            className="border-gray-600 text-gray-300 hover:bg-gray-700"
          >
            {isRunning ? (
              <>
                <Loader className="animate-spin mr-2" size={14} />
                Testing...
              </>
            ) : (
              'Run Tests'
            )}
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Test Results */}
        <div className="space-y-3">
          <div className="flex items-center justify-between p-3 bg-gray-700/50 rounded-lg">
            <div className="flex items-center space-x-3">
              <Wifi size={16} className="text-cyan-400" />
              {getStatusIcon(tests.basicConnectivity.status)}
              <div>
                <span className="text-sm font-medium">Internet Connection</span>
                <p className="text-xs text-gray-400">{tests.basicConnectivity.message}</p>
              </div>
            </div>
            <div className="text-right">
              {getStatusBadge(tests.basicConnectivity.status)}
              {tests.basicConnectivity.duration > 0 && (
                <p className="text-xs text-gray-500 mt-1">{tests.basicConnectivity.duration}ms</p>
              )}
            </div>
          </div>

          <div className="flex items-center justify-between p-3 bg-gray-700/50 rounded-lg">
            <div className="flex items-center space-x-3">
              <Globe size={16} className="text-purple-400" />
              {getStatusIcon(tests.corsTest.status)}
              <div>
                <span className="text-sm font-medium">CORS & Connectivity</span>
                <p className="text-xs text-gray-400">{tests.corsTest.message}</p>
              </div>
            </div>
            <div className="text-right">
              {getStatusBadge(tests.corsTest.status)}
              {tests.corsTest.duration > 0 && (
                <p className="text-xs text-gray-500 mt-1">{tests.corsTest.duration}ms</p>
              )}
            </div>
          </div>

          <div className="flex items-center justify-between p-3 bg-gray-700/50 rounded-lg">
            <div className="flex items-center space-x-3">
              <Activity size={16} className="text-green-400" />
              {getStatusIcon(tests.serverHealth.status)}
              <div>
                <span className="text-sm font-medium">Server Health</span>
                <p className="text-xs text-gray-400">{tests.serverHealth.message}</p>
              </div>
            </div>
            <div className="text-right">
              {getStatusBadge(tests.serverHealth.status)}
              {tests.serverHealth.duration > 0 && (
                <p className="text-xs text-gray-500 mt-1">{tests.serverHealth.duration}ms</p>
              )}
            </div>
          </div>

          <div className="flex items-center justify-between p-3 bg-gray-700/50 rounded-lg">
            <div className="flex items-center space-x-3">
              <AlertTriangle size={16} className="text-orange-400" />
              {getStatusIcon(tests.authEndpoint.status)}
              <div>
                <span className="text-sm font-medium">Auth Endpoints</span>
                <p className="text-xs text-gray-400">{tests.authEndpoint.message}</p>
              </div>
            </div>
            <div className="text-right">
              {getStatusBadge(tests.authEndpoint.status)}
              {tests.authEndpoint.duration > 0 && (
                <p className="text-xs text-gray-500 mt-1">{tests.authEndpoint.duration}ms</p>
              )}
            </div>
          </div>
        </div>

        {/* Overall Status */}
        {!isRunning && (
          <div className="border-t border-gray-600 pt-4">
            <div className="text-center">
              {Object.values(tests).every(test => test.status === 'success') ? (
                <div className="text-green-400">
                  <CheckCircle size={20} className="mx-auto mb-2" />
                  <p className="text-sm">All network tests passed!</p>
                </div>
              ) : Object.values(tests).some(test => test.status === 'error') ? (
                <div className="text-red-400">
                  <XCircle size={20} className="mx-auto mb-2" />
                  <p className="text-sm">Network issues detected</p>
                </div>
              ) : (
                <div className="text-yellow-400">
                  <Loader size={20} className="mx-auto mb-2 animate-spin" />
                  <p className="text-sm">Running diagnostics...</p>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Debug Info */}
        <div className="text-xs text-gray-500 space-y-1">
          <p>Project: {projectId}</p>
          <p>Server URL: https://{projectId}.supabase.co/functions/v1/make-server-9f7745d8</p>
          <p>Browser: {navigator.userAgent.split(' ').slice(-2).join(' ')}</p>
        </div>
      </CardContent>
    </Card>
  );
}