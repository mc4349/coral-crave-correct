import React, { useState } from 'react';
import { Truck, Package, Check, CreditCard } from 'lucide-react';

interface ShippingItem {
  id: string;
  itemName: string;
  sellerName: string;
  shippingCost: number;
  weight: string;
  dimensions: string;
}

interface CartShippingOnlyProps {
  items: ShippingItem[];
  onPayShipping: (items: ShippingItem[], combineShipping: boolean) => void;
  onRemoveItem: (itemId: string) => void;
}

export function CartShippingOnly({ items, onPayShipping, onRemoveItem }: CartShippingOnlyProps) {
  const [combineShipping, setCombineShipping] = useState(true);

  const calculateTotal = () => {
    if (combineShipping) {
      // Group by seller and take highest shipping cost per seller
      const sellerGroups = items.reduce((acc, item) => {
        if (!acc[item.sellerName]) {
          acc[item.sellerName] = [];
        }
        acc[item.sellerName].push(item);
        return acc;
      }, {} as Record<string, ShippingItem[]>);

      return Object.values(sellerGroups).reduce((total, sellerItems) => {
        const maxShipping = Math.max(...sellerItems.map(item => item.shippingCost));
        return total + maxShipping;
      }, 0);
    } else {
      return items.reduce((total, item) => total + item.shippingCost, 0);
    }
  };

  const savings = combineShipping ? 
    items.reduce((total, item) => total + item.shippingCost, 0) - calculateTotal() : 0;

  if (items.length === 0) {
    return (
      <div className="p-4">
        <div className="text-center py-12">
          <Package className="mx-auto text-gray-400 mb-4" size={64} />
          <h2 className="text-2xl font-bold text-gray-300 mb-2">No Items to Ship</h2>
          <p className="text-gray-500">Items requiring shipping will appear here</p>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 max-w-2xl mx-auto">
      <div className="bg-gray-800 rounded-xl p-6">
        <h2 className="text-2xl font-bold text-white mb-6 flex items-center gap-2">
          <Truck className="text-cyan-400" />
          Shipping Payment
        </h2>

        {/* Combine Shipping Option */}
        <div className="mb-6 p-4 bg-cyan-600/10 border border-cyan-500/20 rounded-lg">
          <label className="flex items-center gap-3 cursor-pointer">
            <input
              type="checkbox"
              checked={combineShipping}
              onChange={(e) => setCombineShipping(e.target.checked)}
              className="w-4 h-4 text-cyan-500 rounded"
            />
            <div className="flex-1">
              <span className="text-white font-medium">Combine Shipping</span>
              <p className="text-sm text-cyan-400">
                Save money by combining items from the same seller
              </p>
              {savings > 0 && (
                <p className="text-sm text-green-400 font-medium">
                  You save ${savings.toFixed(2)}!
                </p>
              )}
            </div>
          </label>
        </div>

        {/* Items List */}
        <div className="space-y-4 mb-6">
          {items.map((item) => (
            <div key={item.id} className="bg-gray-700 rounded-lg p-4">
              <div className="flex items-start justify-between mb-2">
                <div className="flex-1">
                  <h3 className="font-medium text-white">{item.itemName}</h3>
                  <p className="text-sm text-gray-400">from {item.sellerName}</p>
                </div>
                <button
                  onClick={() => onRemoveItem(item.id)}
                  className="text-red-400 hover:text-red-300 transition-colors"
                >
                  Remove
                </button>
              </div>
              
              <div className="flex items-center justify-between text-sm">
                <div className="text-gray-400">
                  {item.weight} • {item.dimensions}
                </div>
                <div className="text-green-400 font-bold">
                  ${item.shippingCost.toFixed(2)}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Summary */}
        <div className="border-t border-gray-700 pt-4 mb-6">
          <div className="flex items-center justify-between mb-2">
            <span className="text-gray-400">
              {combineShipping ? 'Combined Shipping:' : 'Total Shipping:'}
            </span>
            <span className="text-xl font-bold text-green-400">
              ${calculateTotal().toFixed(2)}
            </span>
          </div>
          
          {combineShipping && savings > 0 && (
            <div className="flex items-center justify-between text-sm">
              <span className="text-gray-500">Original total:</span>
              <span className="text-gray-500 line-through">
                ${(calculateTotal() + savings).toFixed(2)}
              </span>
            </div>
          )}
        </div>

        {/* Payment Button */}
        <button
          onClick={() => onPayShipping(items, combineShipping)}
          className="w-full bg-cyan-500 text-white py-3 px-4 rounded-lg hover:bg-cyan-600 transition-colors flex items-center justify-center gap-2 font-medium"
        >
          <CreditCard size={20} />
          Pay Shipping Fees (${calculateTotal().toFixed(2)})
        </button>

        {/* Info */}
        <div className="mt-4 p-3 bg-gray-700 rounded-lg">
          <p className="text-sm text-gray-300">
            <Check className="inline text-green-400 mr-1" size={16} />
            Secure payment processing • Items will ship after payment
          </p>
        </div>
      </div>
    </div>
  );
}