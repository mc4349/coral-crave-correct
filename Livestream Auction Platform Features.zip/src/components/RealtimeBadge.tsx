import React from 'react';

interface RealtimeBadgeProps {
  className?: string;
}

export function RealtimeBadge({ className = '' }: RealtimeBadgeProps) {
  return (
    <div className={`flex items-center gap-1 bg-red-500 text-white px-2 py-1 rounded text-xs font-medium ${className}`}>
      <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
      LIVE
    </div>
  );
}