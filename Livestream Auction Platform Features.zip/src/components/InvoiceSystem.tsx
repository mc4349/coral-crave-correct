import React, { useState, useEffect } from 'react';
import { Download, Eye, Calendar, DollarSign, Package, CheckCircle, Clock } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface Invoice {
  id: string;
  invoiceNumber: string;
  dateIssued: string;
  paymentStatus: 'paid' | 'pending';
  shippingStatus: 'pending' | 'shipped' | 'delivered';
  trackingNumber?: string;
  item: {
    id: string;
    title: string;
    image: string;
    winningBid: number;
    quantity: number;
  };
  buyer: {
    id: string;
    name: string;
    email: string;
    shippingAddress: {
      street: string;
      city: string;
      state: string;
      zipCode: string;
      country: string;
    };
  };
  seller: {
    id: string;
    name: string;
    email: string;
    paypalAccount: string; // Last 4 digits for security
  };
  fees: {
    coralCraveCommission: number;
    paymentProcessingFee: number;
    sellerNetPayout: number;
  };
  shippingCharges: number;
}

interface InvoiceSystemProps {
  userId: string;
  userType: 'buyer' | 'seller';
  onUpdateTracking?: (invoiceId: string, trackingNumber: string) => void;
}

export function InvoiceSystem({ userId, userType, onUpdateTracking }: InvoiceSystemProps) {
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedInvoice, setSelectedInvoice] = useState<Invoice | null>(null);
  const [trackingInput, setTrackingInput] = useState('');

  useEffect(() => {
    fetchInvoices();
  }, [userId, userType]);

  const fetchInvoices = async () => {
    try {
      const response = await fetch(
        `https://${window.supabase?.supabaseUrl?.split('//')[1]}/functions/v1/make-server-9f7745d8/invoices?userId=${userId}&userType=${userType}`,
        {
          headers: {
            'Authorization': `Bearer ${window.supabase?.supabaseKey}`
          }
        }
      );

      if (response.ok) {
        const data = await response.json();
        setInvoices(data.invoices || []);
      }
    } catch (error) {
      console.error('Failed to fetch invoices:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleUpdateTracking = async (invoiceId: string) => {
    if (!trackingInput.trim()) return;

    try {
      const response = await fetch(
        `https://${window.supabase?.supabaseUrl?.split('//')[1]}/functions/v1/make-server-9f7745d8/update-tracking`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${window.supabase?.supabaseKey}`
          },
          body: JSON.stringify({
            invoiceId,
            trackingNumber: trackingInput
          })
        }
      );

      if (response.ok) {
        // Update local state
        setInvoices(prev => prev.map(inv => 
          inv.id === invoiceId 
            ? { ...inv, trackingNumber: trackingInput, shippingStatus: 'shipped' as const }
            : inv
        ));
        setTrackingInput('');
        onUpdateTracking?.(invoiceId, trackingInput);
      }
    } catch (error) {
      console.error('Failed to update tracking:', error);
    }
  };

  const downloadInvoice = async (invoice: Invoice) => {
    try {
      const response = await fetch(
        `https://${window.supabase?.supabaseUrl?.split('//')[1]}/functions/v1/make-server-9f7745d8/download-invoice/${invoice.id}`,
        {
          headers: {
            'Authorization': `Bearer ${window.supabase?.supabaseKey}`
          }
        }
      );

      if (response.ok) {
        const blob = await response.blob();
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `invoice-${invoice.invoiceNumber}.pdf`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
      }
    } catch (error) {
      console.error('Failed to download invoice:', error);
    }
  };

  if (loading) {
    return (
      <div className="p-6">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-gray-700 rounded w-1/4"></div>
          <div className="space-y-3">
            {[1, 2, 3].map(i => (
              <div key={i} className="h-20 bg-gray-700 rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  const InvoiceDetails = ({ invoice }: { invoice: Invoice }) => (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-white mb-1">🪸 Coral Crave</h2>
          <p className="text-lg font-semibold text-cyan-400">Auction Invoice</p>
        </div>
        <div className="text-right">
          <p className="text-sm text-gray-400">Invoice #{invoice.invoiceNumber}</p>
          <p className="text-sm text-gray-400">Date: {new Date(invoice.dateIssued).toLocaleDateString()}</p>
          <Badge variant={invoice.paymentStatus === 'paid' ? 'default' : 'secondary'}>
            {invoice.paymentStatus === 'paid' ? 'Paid' : 'Pending'}
          </Badge>
        </div>
      </div>

      <Separator className="bg-gray-700" />

      {/* Buyer & Seller Info */}
      <div className="grid md:grid-cols-2 gap-6">
        <div>
          <h3 className="font-semibold text-white mb-2">Buyer Information</h3>
          <div className="text-sm text-gray-300 space-y-1">
            <p>{invoice.buyer.name}</p>
            <p>{invoice.buyer.email}</p>
            <div>
              <p>{invoice.buyer.shippingAddress.street}</p>
              <p>{invoice.buyer.shippingAddress.city}, {invoice.buyer.shippingAddress.state} {invoice.buyer.shippingAddress.zipCode}</p>
              <p>{invoice.buyer.shippingAddress.country}</p>
            </div>
          </div>
        </div>

        <div>
          <h3 className="font-semibold text-white mb-2">Seller Information</h3>
          <div className="text-sm text-gray-300 space-y-1">
            <p>{invoice.seller.name}</p>
            <p>{invoice.seller.email}</p>
            <p>PayPal: ****{invoice.seller.paypalAccount}</p>
          </div>
        </div>
      </div>

      <Separator className="bg-gray-700" />

      {/* Item Details */}
      <div>
        <h3 className="font-semibold text-white mb-4">Item Details</h3>
        <div className="bg-gray-700 rounded-lg p-4">
          <div className="flex items-center space-x-4">
            <ImageWithFallback
              src={invoice.item.image}
              alt={invoice.item.title}
              className="w-16 h-16 object-cover rounded-lg"
            />
            <div className="flex-1">
              <h4 className="font-medium text-white">{invoice.item.title}</h4>
              <div className="flex justify-between items-center mt-2">
                <span className="text-sm text-gray-400">Quantity: {invoice.item.quantity}</span>
                <span className="font-semibold text-white">${invoice.item.winningBid.toFixed(2)}</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Separator className="bg-gray-700" />

      {/* Fee Breakdown */}
      <div>
        <h3 className="font-semibold text-white mb-4">Fee Breakdown</h3>
        <div className="space-y-2">
          <div className="flex justify-between">
            <span className="text-gray-300">Winning Bid (Buyer Paid)</span>
            <span className="text-white">${invoice.item.winningBid.toFixed(2)}</span>
          </div>
          <div className="flex justify-between text-red-400">
            <span>Coral Crave Commission (8%)</span>
            <span>-${invoice.fees.coralCraveCommission.toFixed(2)}</span>
          </div>
          <div className="flex justify-between text-red-400">
            <span>Payment Processing Fee (2.9% + $0.30)</span>
            <span>-${invoice.fees.paymentProcessingFee.toFixed(2)}</span>
          </div>
          <Separator className="bg-gray-600" />
          <div className="flex justify-between text-lg font-semibold">
            <span className="text-green-400">Seller Net Payout</span>
            <span className="text-green-400">${invoice.fees.sellerNetPayout.toFixed(2)}</span>
          </div>
        </div>
      </div>

      <Separator className="bg-gray-700" />

      {/* Shipping */}
      <div>
        <h3 className="font-semibold text-white mb-4">Shipping</h3>
        <div className="bg-gray-700 rounded-lg p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-gray-300">Shipping Charges</span>
            <span className="text-orange-400">
              {invoice.shippingCharges > 0 ? `$${invoice.shippingCharges.toFixed(2)}` : 'Pending'}
            </span>
          </div>
          <p className="text-sm text-cyan-400 mb-3">
            Buyer will be billed separately in Cart after stream.
          </p>
          
          {userType === 'seller' && (
            <div className="space-y-3">
              <div className="flex items-center space-x-2">
                <div className={`w-3 h-3 rounded-full ${
                  invoice.shippingStatus === 'shipped' ? 'bg-green-500' : 
                  invoice.shippingStatus === 'pending' ? 'bg-yellow-500' : 'bg-gray-500'
                }`} />
                <span className="text-sm text-gray-300 capitalize">{invoice.shippingStatus}</span>
              </div>
              
              {invoice.trackingNumber && (
                <div className="text-sm">
                  <span className="text-gray-400">Tracking: </span>
                  <span className="text-white font-mono">{invoice.trackingNumber}</span>
                </div>
              )}
              
              {invoice.shippingStatus === 'pending' && (
                <div className="flex space-x-2">
                  <input
                    type="text"
                    placeholder="Enter tracking number"
                    value={trackingInput}
                    onChange={(e) => setTrackingInput(e.target.value)}
                    className="flex-1 px-3 py-2 bg-gray-600 border border-gray-500 rounded text-white text-sm"
                  />
                  <Button
                    onClick={() => handleUpdateTracking(invoice.id)}
                    disabled={!trackingInput.trim()}
                    size="sm"
                    className="bg-cyan-600 hover:bg-cyan-700"
                  >
                    <Package className="w-4 h-4 mr-1" />
                    Ship
                  </Button>
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Footer */}
      <div className="text-center text-sm text-gray-400 border-t border-gray-700 pt-4">
        <p>This invoice was automatically generated by Coral Crave.</p>
        <p>Please keep a copy for your records.</p>
        <p className="mt-2">
          <span className="text-cyan-400 hover:underline cursor-pointer">
            Contact Coral Crave Support
          </span>
        </p>
      </div>
    </div>
  );

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-white">
          {userType === 'seller' ? 'Sales Invoices' : 'Purchase Invoices'}
        </h1>
        {selectedInvoice && (
          <Button
            onClick={() => setSelectedInvoice(null)}
            variant="outline"
            className="border-gray-600 text-gray-300 hover:bg-gray-700"
          >
            Back to List
          </Button>
        )}
      </div>

      {selectedInvoice ? (
        <Card className="bg-gray-800 border-gray-700">
          <CardContent className="p-6">
            <InvoiceDetails invoice={selectedInvoice} />
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {invoices.length === 0 ? (
            <Card className="bg-gray-800 border-gray-700">
              <CardContent className="p-8 text-center">
                <Calendar className="w-12 h-12 text-gray-500 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-400">No Invoices Yet</h3>
                <p className="text-gray-500">
                  {userType === 'seller' 
                    ? 'Your sale invoices will appear here after successful auctions.'
                    : 'Your purchase invoices will appear here after winning auctions.'
                  }
                </p>
              </CardContent>
            </Card>
          ) : (
            invoices.map((invoice) => (
              <Card key={invoice.id} className="bg-gray-800 border-gray-700 hover:bg-gray-750 transition-colors">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <ImageWithFallback
                        src={invoice.item.image}
                        alt={invoice.item.title}
                        className="w-12 h-12 object-cover rounded-lg"
                      />
                      <div>
                        <h3 className="font-medium text-white">{invoice.item.title}</h3>
                        <p className="text-sm text-gray-400">#{invoice.invoiceNumber}</p>
                        <div className="flex items-center space-x-2 mt-1">
                          <Badge variant={invoice.paymentStatus === 'paid' ? 'default' : 'secondary'}>
                            {invoice.paymentStatus}
                          </Badge>
                          {invoice.shippingStatus === 'shipped' && (
                            <Badge variant="outline" className="border-green-500 text-green-400">
                              <CheckCircle className="w-3 h-3 mr-1" />
                              Shipped
                            </Badge>
                          )}
                          {invoice.shippingStatus === 'pending' && (
                            <Badge variant="outline" className="border-yellow-500 text-yellow-400">
                              <Clock className="w-3 h-3 mr-1" />
                              Pending Ship
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>
                    
                    <div className="text-right">
                      <p className="text-lg font-semibold text-white">
                        ${userType === 'seller' ? invoice.fees.sellerNetPayout.toFixed(2) : invoice.item.winningBid.toFixed(2)}
                      </p>
                      <p className="text-sm text-gray-400">
                        {new Date(invoice.dateIssued).toLocaleDateString()}
                      </p>
                      <div className="flex space-x-2 mt-2">
                        <Button
                          onClick={() => setSelectedInvoice(invoice)}
                          size="sm"
                          variant="outline"
                          className="border-gray-600 text-gray-300 hover:bg-gray-700"
                        >
                          <Eye className="w-4 h-4 mr-1" />
                          View
                        </Button>
                        <Button
                          onClick={() => downloadInvoice(invoice)}
                          size="sm"
                          className="bg-cyan-600 hover:bg-cyan-700"
                        >
                          <Download className="w-4 h-4 mr-1" />
                          PDF
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      )}
    </div>
  );
}