import React, { useEffect, useState } from 'react';
import { PayPalScriptProvider, PayPalButtons } from '@paypal/react-paypal-js';
import { CreditCard, Loader2, CheckCircle, XCircle, AlertTriangle } from 'lucide-react';
import { Button } from './ui/button';
import { Alert, AlertDescription } from './ui/alert';
import { projectId, publicAnonKey } from '../utils/supabase/info';
import { supabase } from '../utils/supabase/client';

interface SimplePayPalCheckoutProps {
  amount: number;
  currency?: string;
  onSuccess: (details: any) => void;
  onError: (error: any) => void;
  itemDetails?: {
    name: string;
    description: string;
  };
}

export function SimplePayPalCheckout({
  amount,
  currency = 'USD',
  onSuccess,
  onError,
  itemDetails
}: SimplePayPalCheckoutProps) {
  const [status, setStatus] = useState<'idle' | 'creating' | 'approving' | 'capturing' | 'success' | 'error'>('idle');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  
  // Format amount to two decimals
  const formattedAmount = amount.toFixed(2);

  // PayPal script options
  const paypalOptions = {
    clientId: 'AbaLVJ8ORlm5lRkHufYnUW8AyGRXc8iDN1tD-j0iGDa3RFts4Mqklnu4SsuiMIY_HDvk_ZufEOuzKGdz',
    currency: currency.toUpperCase(),
    intent: 'capture',
    components: 'buttons',
    // Add debug for sandbox
    debug: true,
    // Disable funding sources that might cause issues in sandbox
    disableFunding: ['credit', 'card', 'sepa', 'bancontact', 'eps', 'giropay', 'ideal', 'mybank', 'p24', 'sofort', 'venmo']
  };

  const createTestOrder = async (): Promise<string> => {
    try {
      setStatus('creating');
      console.log('🔄 Creating PayPal order for amount:', formattedAmount);

      // Validate amount
      if (!formattedAmount || isNaN(Number(formattedAmount)) || Number(formattedAmount) <= 0) {
        throw new Error(`Invalid amount: "${formattedAmount}"`);
      }

      // Get access token from Supabase session
      const { data: { session } } = await supabase.auth.getSession();
      
      if (!session?.access_token) {
        throw new Error('Please log in to make a purchase');
      }
      
      const accessToken = session.access_token;
      console.log('🔑 Using access token for PayPal order creation');

      const requestBody = {
        amount: formattedAmount,
        currency: currency.toUpperCase(),
        description: itemDetails?.description || 'Test auction item',
        auctionId: 'test-auction',
        itemId: 'test-item'
      };

      console.log('📦 PayPal create order request:', requestBody);

      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-9f7745d8/paypal/create-order`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`,
        },
        body: JSON.stringify(requestBody)
      });

      console.log('📡 PayPal create order response status:', response.status);

      if (!response.ok) {
        const errorText = await response.text();
        console.error('❌ PayPal create order error:', response.status, errorText);
        throw new Error(`Create order failed: ${response.status}`);
      }

      const data = await response.json();
      console.log('✅ PayPal create order success:', data);

      if (!data.orderId) {
        console.error('❌ Create order missing order ID:', data);
        throw new Error('Create order missing order ID');
      }

      return data.orderId; // PayPal requires returning the orderID string

    } catch (error) {
      console.error('❌ createOrder exception:', error);
      const message = error instanceof Error ? error.message : 'Failed to create PayPal order';
      setErrorMessage(message);
      setStatus('error');
      onError({ message });
      throw error; // Re-throw for PayPal SDK
    }
  };

  const captureTestOrder = async (orderID: string): Promise<void> => {
    try {
      setStatus('capturing');
      console.log('💰 Capturing PayPal order:', orderID);

      // Get access token from Supabase session
      const { data: { session } } = await supabase.auth.getSession();
      const accessToken = session?.access_token;

      const response = await fetch(`https://${projectId}.supabase.co/functions/v1/make-server-9f7745d8/paypal/capture-order`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${accessToken}`,
        },
        body: JSON.stringify({ orderId: orderID })
      });

      // Fix: Don't consume the response body multiple times
      let body;
      const responseText = await response.text();
      
      try {
        body = JSON.parse(responseText);
      } catch (parseError) {
        console.warn('⚠️ Failed to parse JSON response, using raw text:', responseText);
        body = { raw: responseText };
      }

      if (!response.ok) {
        console.error('❌ Capture order HTTP error:', response.status, body);
        throw new Error(`Capture failed: ${response.status}`);
      }

      const status = body?.status || body?.purchase_units?.[0]?.payments?.captures?.[0]?.status;
      if (status !== 'COMPLETED') {
        console.warn('⚠️ Unexpected capture status:', status, body);
      }

      console.log('✅ Payment completed:', body);
      setStatus('success');
      
      onSuccess({
        id: body.purchaseId || orderID,
        status: 'COMPLETED',
        purchase_units: [{
          amount: {
            value: formattedAmount,
            currency_code: currency
          }
        }]
      });

    } catch (error) {
      console.error('❌ onApprove exception:', error);
      const message = error instanceof Error ? error.message : 'Failed to capture payment';
      setErrorMessage(message);
      setStatus('error');
      onError({ message });
    }
  };

  const getStatusIcon = () => {
    switch (status) {
      case 'creating':
      case 'approving':
      case 'capturing':
        return <Loader2 className="w-4 h-4 animate-spin text-cyan-400" />;
      case 'success':
        return <CheckCircle className="w-4 h-4 text-green-400" />;
      case 'error':
        return <XCircle className="w-4 h-4 text-red-400" />;
      default:
        return <CreditCard className="w-4 h-4 text-cyan-400" />;
    }
  };

  const getStatusMessage = () => {
    switch (status) {
      case 'creating':
        return 'Creating payment order...';
      case 'approving':
        return 'Processing your approval...';
      case 'capturing':
        return 'Completing your purchase...';
      case 'success':
        return 'Payment successful! 🎉';
      case 'error':
        return errorMessage || 'An error occurred';
      default:
        return 'Complete your purchase with PayPal';
    }
  };

  return (
    <div className="space-y-4">
      {/* Purchase Summary */}
      <div className="bg-gray-700 p-4 rounded-lg">
        <h4 className="font-medium text-white mb-2">
          {itemDetails?.name || 'Test Purchase'}
        </h4>
        {itemDetails?.description && (
          <p className="text-sm text-gray-300 mb-3">{itemDetails.description}</p>
        )}
        <div className="flex justify-between items-center">
          <span className="text-gray-300">Total:</span>
          <span className="text-xl font-bold text-cyan-400">
            ${formattedAmount} {currency}
          </span>
        </div>
      </div>

      {/* Status Message */}
      <Alert className="bg-gray-700 border-gray-600">
        <div className="flex items-center gap-2">
          {getStatusIcon()}
          <AlertDescription className="text-gray-300">
            {getStatusMessage()}
          </AlertDescription>
        </div>
      </Alert>

      {/* PayPal Buttons */}
      {status !== 'success' && status !== 'error' && (
        <PayPalScriptProvider options={paypalOptions}>
          <PayPalButtons
            style={{ layout: "vertical" }}
            fundingSource={undefined}
            createOrder={createTestOrder}
            onApprove={async (data, actions) => {
              try {
                setStatus('approving');
                if (!data?.orderID) {
                  throw new Error('onApprove missing orderID');
                }
                console.log('✅ PayPal payment approved:', data.orderID);
                await captureTestOrder(data.orderID);
              } catch (error) {
                console.error('PayPal onApprove error:', error);
              }
            }}
            onError={async (err) => {
              console.error('PayPal onError:', err);
              
              // Log the raw error AND the last network response from PayPal (if any)
              try {
                const last = (window as any).__paypalCheckout__?.lastResponse;
                if (last) console.error('PayPal last response:', last);
              } catch {}
              
              setErrorMessage('PayPal payment error occurred');
              setStatus('error');
              onError({ message: 'PayPal payment error occurred' });
            }}
          />
        </PayPalScriptProvider>
      )}

      {/* Success State */}
      {status === 'success' && (
        <div className="text-center py-4 bg-green-500/20 border border-green-500/30 rounded-lg">
          <CheckCircle className="w-8 h-8 text-green-400 mx-auto mb-2" />
          <h4 className="font-medium text-green-300 mb-1">Payment Successful!</h4>
          <p className="text-sm text-gray-300">
            Your test purchase has been completed successfully.
          </p>
        </div>
      )}

      {/* Error State */}
      {status === 'error' && (
        <div className="text-center py-4 bg-red-500/20 border border-red-500/30 rounded-lg">
          <XCircle className="w-8 h-8 text-red-400 mx-auto mb-2" />
          <h4 className="font-medium text-red-300 mb-1">Payment Failed</h4>
          <p className="text-sm text-gray-300 mb-3">
            {errorMessage || 'An error occurred during payment processing.'}
          </p>
          <Button 
            variant="outline" 
            onClick={() => setStatus('idle')}
            className="text-sm"
          >
            Try Again
          </Button>
        </div>
      )}
    </div>
  );
}