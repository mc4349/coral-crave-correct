import React, { useState, useEffect } from 'react';
import { Wifi, WifiOff, AlertCircle } from 'lucide-react';
import { checkNetworkConnectivity } from '../utils/network-fallback';
import { toast } from 'sonner@2.0.3';

interface NetworkStatusProps {
  className?: string;
}

export function NetworkStatus({ className = '' }: NetworkStatusProps) {
  const [isOnline, setIsOnline] = useState(true);
  const [checking, setChecking] = useState(false);
  const [lastChecked, setLastChecked] = useState<Date | null>(null);

  const checkStatus = async () => {
    if (checking) return;
    
    setChecking(true);
    try {
      const online = await checkNetworkConnectivity();
      setIsOnline(online);
      setLastChecked(new Date());
      
      if (!online && !lastChecked) {
        // First time detecting offline status
        toast.info('🎭 Running in Demo Mode', {
          description: 'Server unavailable - actions are simulated locally.',
          duration: 3000
        });
      }
    } catch (error) {
      console.warn('Network status check failed:', error);
      setIsOnline(false);
    } finally {
      setChecking(false);
    }
  };

  useEffect(() => {
    // Initial check
    checkStatus();
    
    // Check every 30 seconds
    const interval = setInterval(checkStatus, 30000);
    
    return () => clearInterval(interval);
  }, []);

  const getStatusColor = () => {
    if (checking) return 'text-yellow-400';
    return isOnline ? 'text-green-400' : 'text-orange-400';
  };

  const getStatusIcon = () => {
    if (checking) return <AlertCircle size={12} className="animate-pulse" />;
    return isOnline ? <Wifi size={12} /> : <WifiOff size={12} />;
  };

  const getStatusText = () => {
    if (checking) return 'Checking...';
    return isOnline ? 'Connected' : 'Demo Mode';
  };

  return (
    <div 
      className={`flex items-center gap-1 ${getStatusColor()} ${className}`}
      title={`Network status: ${getStatusText()}${lastChecked ? ` (Last checked: ${lastChecked.toLocaleTimeString()})` : ''}`}
    >
      {getStatusIcon()}
      <span className="text-xs">{getStatusText()}</span>
    </div>
  );
}

export default NetworkStatus;