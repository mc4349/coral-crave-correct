import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { CheckCircle, XCircle, AlertTriangle, FileText } from 'lucide-react';

export function ImportTestDiagnostic() {
  const [testResults, setTestResults] = useState<{ [key: string]: { status: 'idle' | 'success' | 'error', message: string } }>({});
  const [isRunning, setIsRunning] = useState(false);

  const testComponentImport = async (componentName: string, importPath: string) => {
    try {
      setTestResults(prev => ({
        ...prev,
        [componentName]: { status: 'idle', message: 'Testing import...' }
      }));

      console.log(`Testing import of ${componentName} from ${importPath}`);
      
      const module = await import(importPath);
      console.log(`Import successful for ${componentName}:`, Object.keys(module));
      
      if (module[componentName]) {
        setTestResults(prev => ({
          ...prev,
          [componentName]: { status: 'success', message: `Named export found: ${componentName}` }
        }));
      } else if (module.default) {
        setTestResults(prev => ({
          ...prev,
          [componentName]: { status: 'success', message: `Default export found (expected named export)` }
        }));
      } else {
        setTestResults(prev => ({
          ...prev,
          [componentName]: { status: 'error', message: `No ${componentName} export found` }
        }));
      }
    } catch (error) {
      console.error(`Import failed for ${componentName}:`, error);
      setTestResults(prev => ({
        ...prev,
        [componentName]: { status: 'error', message: error.message }
      }));
    }
  };

  const runAllTests = async () => {
    setIsRunning(true);
    setTestResults({});

    const tests = [
      { name: 'GoLiveScreen', path: './GoLiveScreen' },
      { name: 'HomeScreen', path: './HomeScreen' },
      { name: 'ExploreScreen', path: './ExploreScreen' },
      { name: 'LiveStreamScreen', path: './LiveStreamScreen' }
    ];

    for (const test of tests) {
      await testComponentImport(test.name, test.path);
    }

    setIsRunning(false);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'success':
        return <CheckCircle className="text-green-400" size={16} />;
      case 'error':
        return <XCircle className="text-red-400" size={16} />;
      default:
        return <div className="w-4 h-4 bg-gray-600 rounded-full" />;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'success':
        return <Badge className="bg-green-500/20 text-green-400 border-green-400">OK</Badge>;
      case 'error':
        return <Badge className="bg-red-500/20 text-red-400 border-red-400">Failed</Badge>;
      default:
        return <Badge className="bg-gray-500/20 text-gray-400 border-gray-400">Not Tested</Badge>;
    }
  };

  return (
    <Card className="bg-gray-800 border-gray-700">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center space-x-2">
            <FileText className="text-blue-400" size={20} />
            <span>📦 Component Import Test</span>
          </CardTitle>
          <Button 
            onClick={runAllTests}
            disabled={isRunning}
            size="sm"
            variant="outline"
            className="border-gray-600 text-gray-300 hover:bg-gray-700"
          >
            Test Imports
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {Object.keys(testResults).length === 0 ? (
          <div className="text-center py-4 text-gray-400">
            Click "Test Imports" to check component loading
          </div>
        ) : (
          <div className="space-y-3">
            {Object.entries(testResults).map(([componentName, result]) => (
              <div key={componentName} className="flex items-center justify-between p-3 bg-gray-700/50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <FileText size={16} className="text-blue-400" />
                  {getStatusIcon(result.status)}
                  <div>
                    <span className="text-sm font-medium">{componentName}</span>
                    <p className="text-xs text-gray-400">{result.message}</p>
                  </div>
                </div>
                <div className="text-right">
                  {getStatusBadge(result.status)}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Instructions */}
        <div className="bg-blue-500/20 border border-blue-500/30 rounded-lg p-3">
          <p className="text-blue-300 text-xs">
            <strong>Component Import Diagnostics:</strong> This test checks if React components can be imported correctly. 
            If GoLiveScreen shows an error, there may be a syntax error or export issue in the component file.
          </p>
        </div>
      </CardContent>
    </Card>
  );
}