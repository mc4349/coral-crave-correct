import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Alert, AlertDescription } from './ui/alert';
import { 
  CheckCircle, 
  XCircle, 
  Clock, 
  DollarSign, 
  Video, 
  Gavel,
  Play,
  Zap,
  AlertTriangle
} from 'lucide-react';
import { projectId, publicAnonKey } from '../utils/supabase/info';

interface QuickSystemCheckProps {
  user?: { id: string; email: string; name: string } | null;
  onNavigateToFullTest?: () => void;
}

export function QuickSystemCheck({ user, onNavigateToFullTest }: QuickSystemCheckProps) {
  const [isChecking, setIsChecking] = useState(false);
  const [results, setResults] = useState<{[key: string]: 'pending' | 'passed' | 'failed'}>({
    payments: 'pending',
    livestream: 'pending',
    bidding: 'pending'
  });
  const [details, setDetails] = useState<{[key: string]: string}>({});

  const baseUrl = `https://${projectId}.supabase.co/functions/v1/make-server-9f7745d8`;

  const runQuickCheck = async () => {
    if (!user) {
      alert('Please sign in to run system checks');
      return;
    }

    setIsChecking(true);
    setResults({ payments: 'pending', livestream: 'pending', bidding: 'pending' });
    setDetails({});

    // Get user access token from supabase
    let accessToken = publicAnonKey;
    try {
      const { createClient } = await import('../utils/supabase/client');
      const supabase = createClient();
      const { data: { session } } = await supabase.auth.getSession();
      if (session?.access_token) {
        accessToken = session.access_token;
      }
    } catch (error) {
      console.warn('Could not get user access token, using anon key');
    }

    // Check Payment System
    try {
      const paymentResponse = await fetch(`${baseUrl}/paypal/health`, {
        headers: { 'Authorization': `Bearer ${publicAnonKey}` } // PayPal health should be public
      });
      
      if (paymentResponse.ok) {
        setResults(prev => ({ ...prev, payments: 'passed' }));
        setDetails(prev => ({ ...prev, payments: 'PayPal integration active' }));
      } else {
        setResults(prev => ({ ...prev, payments: 'failed' }));
        setDetails(prev => ({ ...prev, payments: 'PayPal connection issues' }));
      }
    } catch (error) {
      setResults(prev => ({ ...prev, payments: 'failed' }));
      setDetails(prev => ({ ...prev, payments: 'Payment system offline' }));
    }

    // Check Livestream System
    try {
      const agoraResponse = await fetch(`${baseUrl}/agora/token`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${publicAnonKey}`, // Agora token generation should be public
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          channelName: 'quick-test-' + Date.now(),
          role: 'publisher'
        })
      });
      
      if (agoraResponse.ok) {
        const data = await agoraResponse.json();
        setResults(prev => ({ ...prev, livestream: 'passed' }));
        setDetails(prev => ({ ...prev, livestream: `Agora ready (${data.tokenType})` }));
      } else {
        setResults(prev => ({ ...prev, livestream: 'failed' }));
        setDetails(prev => ({ ...prev, livestream: 'Agora token issues' }));
      }
    } catch (error) {
      setResults(prev => ({ ...prev, livestream: 'failed' }));
      setDetails(prev => ({ ...prev, livestream: 'Livestream system offline' }));
    }

    // Check Bidding System
    try {
      const bidResponse = await fetch(`${baseUrl}/bid`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${accessToken}`, // Use user access token for bidding
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          itemId: 'quick-test-item',
          amount: 10.00
        })
      });
      
      if (bidResponse.ok) {
        setResults(prev => ({ ...prev, bidding: 'passed' }));
        setDetails(prev => ({ ...prev, bidding: 'Bidding system operational' }));
      } else {
        const errorText = await bidResponse.text();
        setResults(prev => ({ ...prev, bidding: 'failed' }));
        setDetails(prev => ({ ...prev, bidding: `Bidding issues: ${bidResponse.status}` }));
      }
    } catch (error) {
      setResults(prev => ({ ...prev, bidding: 'failed' }));
      setDetails(prev => ({ ...prev, bidding: 'Bidding system offline' }));
    }

    setIsChecking(false);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'passed':
        return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'failed':
        return <XCircle className="h-5 w-5 text-red-500" />;
      default:
        return <Clock className="h-5 w-5 text-gray-400" />;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'passed':
        return <Badge className="bg-green-500">✓ Working</Badge>;
      case 'failed':
        return <Badge variant="destructive">✗ Issues</Badge>;
      default:
        return <Badge variant="outline">Pending</Badge>;
    }
  };

  const allSystemsWorking = Object.values(results).every(status => status === 'passed');
  const hasIssues = Object.values(results).some(status => status === 'failed');

  return (
    <Card className="bg-gray-800 border-gray-700">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Zap className="h-6 w-6 text-yellow-500" />
            <div>
              <CardTitle>Quick System Check</CardTitle>
              <p className="text-sm text-gray-400">Verify core systems are working</p>
            </div>
          </div>
          
          <div className="flex gap-2">
            <Button
              onClick={runQuickCheck}
              disabled={isChecking || !user}
              size="sm"
              className="bg-cyan-500 hover:bg-cyan-600"
            >
              {isChecking ? (
                <>
                  <Clock className="h-4 w-4 mr-2 animate-spin" />
                  Checking...
                </>
              ) : (
                <>
                  <Play className="h-4 w-4 mr-2" />
                  Quick Check
                </>
              )}
            </Button>
            
            {onNavigateToFullTest && (
              <Button
                onClick={onNavigateToFullTest}
                variant="outline"
                size="sm"
              >
                Full Test
              </Button>
            )}
          </div>
        </div>
      </CardHeader>

      <CardContent>
        {!user && (
          <Alert className="mb-4">
            <AlertTriangle className="h-4 w-4" />
            <AlertDescription>
              Please sign in to run system checks
            </AlertDescription>
          </Alert>
        )}

        <div className="space-y-4">
          {/* Payment System */}
          <div className="flex items-center justify-between p-3 bg-gray-700 rounded-lg">
            <div className="flex items-center gap-3">
              <DollarSign className="h-5 w-5 text-green-400" />
              <div>
                <div className="font-medium">Payment System</div>
                <div className="text-sm text-gray-400">
                  {details.payments || 'PayPal integration & processing'}
                </div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              {getStatusIcon(results.payments)}
              {getStatusBadge(results.payments)}
            </div>
          </div>

          {/* Livestream System */}
          <div className="flex items-center justify-between p-3 bg-gray-700 rounded-lg">
            <div className="flex items-center gap-3">
              <Video className="h-5 w-5 text-purple-400" />
              <div>
                <div className="font-medium">Livestream System</div>
                <div className="text-sm text-gray-400">
                  {details.livestream || 'Agora video streaming & channels'}
                </div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              {getStatusIcon(results.livestream)}
              {getStatusBadge(results.livestream)}
            </div>
          </div>

          {/* Bidding System */}
          <div className="flex items-center justify-between p-3 bg-gray-700 rounded-lg">
            <div className="flex items-center gap-3">
              <Gavel className="h-5 w-5 text-orange-400" />
              <div>
                <div className="font-medium">Bidding System</div>
                <div className="text-sm text-gray-400">
                  {details.bidding || 'Real-time auctions & bid processing'}
                </div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              {getStatusIcon(results.bidding)}
              {getStatusBadge(results.bidding)}
            </div>
          </div>
        </div>

        {/* System Status Summary */}
        {!isChecking && Object.values(results).some(status => status !== 'pending') && (
          <div className="mt-4 p-4 rounded-lg border-2 border-dashed">
            {allSystemsWorking && (
              <div className="text-center text-green-400">
                <CheckCircle className="h-8 w-8 mx-auto mb-2" />
                <div className="font-medium">All Systems Operational! 🎉</div>
                <div className="text-sm text-gray-400">
                  Your Coral Crave platform is ready for production
                </div>
              </div>
            )}
            
            {hasIssues && !allSystemsWorking && (
              <div className="text-center text-yellow-400">
                <AlertTriangle className="h-8 w-8 mx-auto mb-2" />
                <div className="font-medium">Some Issues Detected ⚠️</div>
                <div className="text-sm text-gray-400">
                  Check the full testing dashboard for details
                </div>
              </div>
            )}
            
            {Object.values(results).every(status => status === 'pending') && (
              <div className="text-center text-gray-400">
                <Clock className="h-8 w-8 mx-auto mb-2" />
                <div className="font-medium">Ready to Test</div>
                <div className="text-sm">
                  Click "Quick Check" to verify your systems
                </div>
              </div>
            )}
          </div>
        )}

        {/* Test Instructions */}
        <div className="mt-4 p-3 bg-blue-900/20 rounded-lg border border-blue-500/20">
          <div className="text-sm">
            <div className="font-medium text-blue-400 mb-1">💡 What This Tests:</div>
            <ul className="text-gray-300 space-y-1 text-xs">
              <li>• PayPal API connectivity and payment processing</li>
              <li>• Agora token generation and livestream channels</li>
              <li>• Bid placement and auction system validation</li>
              <li>• Backend server health and responsiveness</li>
            </ul>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}