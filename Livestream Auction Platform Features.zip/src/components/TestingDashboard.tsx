import React, { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { 
  TestTube, 
  Play, 
  CheckCircle, 
  XCircle, 
  AlertTriangle,
  Users,
  ShoppingCart,
  Video,
  MessageSquare,
  CreditCard,
  Settings,
  Database,
  Monitor,
  Rocket,
  FileText
} from 'lucide-react';
import { ComprehensiveTestingSuite } from './ComprehensiveTestingSuite';
import { MockDataGenerator } from './MockDataGenerator';
import { DeploymentReadinessChecker } from './DeploymentReadinessChecker';
import { MultiUserTestingInstructions } from './MultiUserTestingInstructions';
import { E2ETestingGuide } from './E2ETestingGuide';

export function TestingDashboard({ user, onAuthRequired }: { user: any; onAuthRequired: () => void }) {
  const [activeModal, setActiveModal] = useState<string | null>(null);
  const [testResults, setTestResults] = useState({
    auth: 'pending',
    bidding: 'pending', 
    payments: 'pending',
    chat: 'pending',
    streaming: 'pending'
  });

  const testCategories = [
    {
      id: 'comprehensive',
      name: 'Comprehensive Testing',
      description: 'Complete platform functionality verification',
      icon: <TestTube className="h-6 w-6" />,
      color: 'bg-cyan-500',
      action: () => setActiveModal('comprehensive')
    },
    {
      id: 'mock-data',
      name: 'Mock Data Generator', 
      description: 'Generate realistic test data for all features',
      icon: <Database className="h-6 w-6" />,
      color: 'bg-blue-500',
      action: () => setActiveModal('mockData')
    },
    {
      id: 'deployment',
      name: 'Deployment Readiness',
      description: 'Pre-deployment verification checklist',
      icon: <Rocket className="h-6 w-6" />,
      color: 'bg-green-500',
      action: () => setActiveModal('deployment')
    },
    {
      id: 'multi-user',
      name: 'Multi-User Testing',
      description: 'Step-by-step multi-user testing guide',
      icon: <Users className="h-6 w-6" />,
      color: 'bg-purple-500',
      action: () => setActiveModal('multiUser')
    },
    {
      id: 'e2e-guide',
      name: 'E2E Testing Guide',
      description: 'End-to-end testing scenarios and flows',
      icon: <FileText className="h-6 w-6" />,
      color: 'bg-orange-500',
      action: () => setActiveModal('e2eGuide')
    }
  ];

  const featureTests = [
    {
      name: 'Authentication System',
      description: 'User signup, signin, session management',
      status: user ? 'passed' : 'warning',
      icon: <Users className="h-5 w-5" />,
      details: user ? `Signed in as ${user.email}` : 'Sign in to test authenticated features'
    },
    {
      name: 'Real-time Bidding',
      description: 'Bid placement, timer updates, anti-snipe protection',
      status: 'ready',
      icon: <ShoppingCart className="h-5 w-5" />,
      details: 'Mock bidding system ready for testing'
    },
    {
      name: 'Payment Processing',
      description: 'PayPal integration, marketplace fees',
      status: 'ready',
      icon: <CreditCard className="h-5 w-5" />,
      details: 'PayPal mock system configured'
    },
    {
      name: 'Live Chat System',
      description: 'Real-time messaging, moderation',
      status: 'ready',
      icon: <MessageSquare className="h-5 w-5" />,
      details: 'WebSocket connections ready'
    },
    {
      name: 'Video Streaming',
      description: 'Agora integration, camera/microphone',  
      status: 'ready',
      icon: <Video className="h-5 w-5" />,
      details: 'Real camera enabled with ?realCamera=true'
    }
  ];

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'passed': return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'failed': return <XCircle className="h-4 w-4 text-red-500" />;
      case 'warning': return <AlertTriangle className="h-4 w-4 text-yellow-500" />;
      case 'ready': return <Play className="h-4 w-4 text-blue-500" />;
      default: return <div className="h-4 w-4 rounded-full border-2 border-gray-400" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'passed': return 'text-green-400';
      case 'failed': return 'text-red-400';
      case 'warning': return 'text-yellow-400';
      case 'ready': return 'text-blue-400';
      default: return 'text-gray-400';
    }
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white p-4">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Testing Dashboard</h1>
          <p className="text-gray-400">Comprehensive testing tools for the Coral Crave platform</p>
        </div>

        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-1 md:grid-cols-3 bg-gray-800">
            <TabsTrigger value="overview" className="data-[state=active]:bg-cyan-500">
              <Monitor className="h-4 w-4 mr-2" />
              Overview
            </TabsTrigger>
            <TabsTrigger value="features" className="data-[state=active]:bg-cyan-500">
              <Settings className="h-4 w-4 mr-2" />
              Feature Tests
            </TabsTrigger>
            <TabsTrigger value="tools" className="data-[state=active]:bg-cyan-500">
              <TestTube className="h-4 w-4 mr-2" />
              Testing Tools
            </TabsTrigger>
          </TabsList>

          <TabsContent value="overview">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <Card className="bg-gray-800 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-cyan-400">Platform Status</CardTitle>
                  <CardDescription>Overall system health</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Frontend</span>
                      <Badge variant="default" className="bg-green-500">Online</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Backend API</span>
                      <Badge variant="default" className="bg-green-500">Connected</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Database</span>
                      <Badge variant="default" className="bg-green-500">Operational</Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Real-time</span>
                      <Badge variant="default" className="bg-green-500">Active</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gray-800 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-cyan-400">Test Coverage</CardTitle>
                  <CardDescription>Feature testing status</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {featureTests.slice(0, 4).map((test, index) => (
                      <div key={index} className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          {test.icon}
                          <span className="text-sm">{test.name}</span>
                        </div>
                        {getStatusIcon(test.status)}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gray-800 border-gray-700">
                <CardHeader>
                  <CardTitle className="text-cyan-400">Quick Actions</CardTitle>
                  <CardDescription>Start testing features</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <Button 
                      onClick={() => setActiveModal('comprehensive')}
                      className="w-full bg-cyan-500 hover:bg-cyan-600"
                      size="sm"
                    >
                      <TestTube className="h-4 w-4 mr-2" />
                      Run All Tests
                    </Button>
                    <Button 
                      onClick={() => setActiveModal('mockData')}
                      variant="outline"
                      className="w-full"
                      size="sm"
                    >
                      <Database className="h-4 w-4 mr-2" />
                      Generate Mock Data
                    </Button>
                    <Button 
                      onClick={() => setActiveModal('deployment')}
                      variant="outline"
                      className="w-full"
                      size="sm"
                    >
                      <Rocket className="h-4 w-4 mr-2" />
                      Check Deployment
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* System Requirements */}
            <Card className="bg-gray-800 border-gray-700 mt-6">
              <CardHeader>
                <CardTitle className="text-white">Testing Requirements</CardTitle>
                <CardDescription>What you need to test all features</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-medium text-white mb-3">Browser Requirements</h4>
                    <ul className="space-y-2 text-sm text-gray-300">
                      <li className="flex items-center">
                        <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                        Chrome/Firefox/Safari (latest)
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                        Camera & microphone permissions
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                        JavaScript enabled
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                        Stable internet connection
                      </li>
                    </ul>
                  </div>
                  <div>
                    <h4 className="font-medium text-white mb-3">Testing Setup</h4>
                    <ul className="space-y-2 text-sm text-gray-300">
                      <li className="flex items-center">
                        <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                        Multiple browser tabs/windows
                      </li>
                      <li className="flex items-center">
                        <AlertTriangle className="h-4 w-4 text-yellow-500 mr-2" />
                        ?realCamera=true for livestreaming
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                        Demo accounts ready
                      </li>
                      <li className="flex items-center">
                        <CheckCircle className="h-4 w-4 text-green-500 mr-2" />
                        Mock data initialized
                      </li>
                    </ul>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="features">
            <div className="space-y-4">
              {featureTests.map((test, index) => (
                <Card key={index} className="bg-gray-800 border-gray-700">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between">
                      <div className="flex items-start space-x-4">
                        <div className="text-cyan-400 mt-1">
                          {test.icon}
                        </div>
                        <div>
                          <h3 className="font-medium text-white mb-1">{test.name}</h3>
                          <p className="text-gray-400 text-sm mb-2">{test.description}</p>
                          <p className={`text-sm ${getStatusColor(test.status)}`}>
                            {test.details}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        {getStatusIcon(test.status)}
                        <Badge 
                          variant={
                            test.status === 'passed' ? 'default' :
                            test.status === 'failed' ? 'destructive' :
                            test.status === 'warning' ? 'secondary' : 'outline'
                          }
                        >
                          {test.status}
                        </Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="tools">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {testCategories.map((category) => (
                <Card key={category.id} className="bg-gray-800 border-gray-700 cursor-pointer hover:bg-gray-750 transition-colors">
                  <CardContent className="p-6">
                    <div className="flex items-start space-x-4">
                      <div className={`p-3 rounded-lg ${category.color}`}>
                        {category.icon}
                      </div>
                      <div className="flex-1">
                        <h3 className="font-medium text-white mb-2">{category.name}</h3>
                        <p className="text-gray-400 text-sm mb-4">{category.description}</p>
                        <Button 
                          onClick={category.action}
                          variant="outline"
                          size="sm"
                          className="w-full"
                        >
                          Open Tool
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>

        {/* Modals */}
        {activeModal === 'comprehensive' && (
          <ComprehensiveTestingSuite 
            user={user}
            onClose={() => setActiveModal(null)}
          />
        )}

        {activeModal === 'mockData' && (
          <MockDataGenerator 
            onClose={() => setActiveModal(null)}
          />
        )}

        {activeModal === 'deployment' && (
          <DeploymentReadinessChecker 
            onClose={() => setActiveModal(null)}
          />
        )}

        {activeModal === 'multiUser' && (
          <MultiUserTestingInstructions
            onClose={() => setActiveModal(null)}
            onCreateBuyerAccount={async () => {
              // Handle buyer account creation
              setActiveModal(null);
            }}
          />
        )}

        {activeModal === 'e2eGuide' && (
          <E2ETestingGuide 
            onClose={() => setActiveModal(null)}
          />
        )}
      </div>
    </div>
  );
}