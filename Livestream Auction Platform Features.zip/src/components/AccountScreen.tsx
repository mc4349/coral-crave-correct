import React, { useState, useEffect } from 'react';
import { User, Settings, ShoppingBag, Heart, TrendingUp, Award, LogOut, Edit, Camera, CreditCard, MapPin, Mail, Lock, Eye, EyeOff, Save, Receipt, DollarSign, ShoppingCart } from 'lucide-react';
import { PurchaseHistory } from './PurchaseHistory';
import { PayPalConnect } from './PayPalConnect';

interface UserProfile {
  id: string;
  email: string;
  name: string;
  avatar?: string;
}

interface AccountScreenProps {
  user: UserProfile | null;
  onAuthRequired: () => void;
  onSignOut: () => void;
  onNavigate?: (tab: string) => void;
}

interface UserStats {
  totalBids: number;
  itemsWon: number;
  totalSpent: number;
  followedSellers: number;
  memberSince: Date;
}

interface RecentActivity {
  id: string;
  type: 'bid' | 'won' | 'follow';
  title: string;
  description: string;
  amount?: number;
  timestamp: Date;
  image: string;
}

interface PersonalInfo {
  name: string;
  email: string;
  phone: string;
  currentPassword: string;
  newPassword: string;
  confirmPassword: string;
}

interface ShippingInfo {
  firstName: string;
  lastName: string;
  address: string;
  city: string;
  state: string;
  zipCode: string;
  country: string;
}

interface PaymentInfo {
  cardNumber: string;
  expiryDate: string;
  cvv: string;
  cardName: string;
  billingAddress: string;
  billingCity: string;
  billingState: string;
  billingZip: string;
}

export function AccountScreen({ user, onAuthRequired, onSignOut, onNavigate }: AccountScreenProps) {
  const [userStats, setUserStats] = useState<UserStats | null>(null);
  const [recentActivity, setRecentActivity] = useState<RecentActivity[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'overview' | 'orders' | 'following' | 'personal' | 'shipping' | 'payment' | 'settings'>('overview');
  const [showPassword, setShowPassword] = useState(false);
  const [saving, setSaving] = useState(false);

  // Form states
  const [personalInfo, setPersonalInfo] = useState<PersonalInfo>({
    name: '',
    email: '',
    phone: '',
    currentPassword: '',
    newPassword: '',
    confirmPassword: ''
  });

  const [shippingInfo, setShippingInfo] = useState<ShippingInfo>({
    firstName: '',
    lastName: '',
    address: '',
    city: '',
    state: '',
    zipCode: '',
    country: 'United States'
  });

  const [paymentInfo, setPaymentInfo] = useState<PaymentInfo>({
    cardNumber: '',
    expiryDate: '',
    cvv: '',
    cardName: '',
    billingAddress: '',
    billingCity: '',
    billingState: '',
    billingZip: ''
  });

  useEffect(() => {
    if (!user) {
      setLoading(false);
      return;
    }

    // Initialize with user data
    setPersonalInfo(prev => ({
      ...prev,
      name: user.name,
      email: user.email
    }));

    // Mock user stats and activity
    const mockStats: UserStats = {
      totalBids: 47,
      itemsWon: 12,
      totalSpent: 1247,
      followedSellers: 8,
      memberSince: new Date('2024-01-15')
    };

    const mockActivity: RecentActivity[] = [
      {
        id: '1',
        type: 'won',
        title: 'Orange Torch Coral',
        description: 'Won auction for $67',
        amount: 67,
        timestamp: new Date(Date.now() - 1800000),
        image: 'https://images.unsplash.com/photo-1583212292454-1fe6229603b7?w=100'
      },
      {
        id: '2',
        type: 'bid',
        title: 'Rainbow Acropora Colony',
        description: 'Placed bid of $125',
        amount: 125,
        timestamp: new Date(Date.now() - 3600000),
        image: 'https://images.unsplash.com/photo-1544551763-46a013bb70d5?w=100'
      },
      {
        id: '3',
        type: 'follow',
        title: 'Deep Blue Aquatics',
        description: 'Started following seller',
        timestamp: new Date(Date.now() - 86400000),
        image: 'https://images.unsplash.com/photo-1559827260-dc66d52bef19?w=100'
      }
    ];

    setUserStats(mockStats);
    setRecentActivity(mockActivity);
    setLoading(false);
  }, [user]);

  const handleSavePersonalInfo = async () => {
    setSaving(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    console.log('Saving personal info:', personalInfo);
    setSaving(false);
  };

  const handleSaveShippingInfo = async () => {
    setSaving(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    console.log('Saving shipping info:', shippingInfo);
    setSaving(false);
  };

  const handleSavePaymentInfo = async () => {
    setSaving(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    console.log('Saving payment info:', paymentInfo);
    setSaving(false);
  };

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'bid':
        return <TrendingUp className="text-blue-400" size={16} />;
      case 'won':
        return <Award className="text-green-400" size={16} />;
      case 'follow':
        return <Heart className="text-red-400" size={16} />;
      default:
        return <User className="text-gray-400" size={16} />;
    }
  };

  if (!user) {
    return (
      <div className="p-4">
        <div className="text-center py-12">
          <User className="mx-auto text-gray-400 mb-4" size={64} />
          <h2 className="text-2xl font-bold text-gray-300 mb-2">Your Account</h2>
          <p className="text-gray-500 mb-6">Sign in to view your profile, orders, and auction history</p>
          <button
            onClick={onAuthRequired}
            className="bg-cyan-500 text-white px-6 py-3 rounded-lg hover:bg-cyan-400 transition-colors"
          >
            Sign In
          </button>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="p-4">
        <div className="animate-pulse space-y-4">
          <div className="h-32 bg-gray-700 rounded"></div>
          <div className="h-8 bg-gray-700 rounded w-48"></div>
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-16 bg-gray-700 rounded"></div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="p-4">
      {/* Profile Header */}
      <div className="bg-gray-800 rounded-xl p-6 mb-6">
        <div className="flex flex-col md:flex-row items-start md:items-center gap-6">
          <div className="relative">
            <div className="w-20 h-20 bg-gradient-to-r from-cyan-400 to-teal-500 rounded-full flex items-center justify-center">
              <span className="text-2xl font-bold text-white">
                {user.name[0].toUpperCase()}
              </span>
            </div>
            <button className="absolute -bottom-1 -right-1 bg-gray-700 text-white p-1 rounded-full hover:bg-gray-600 transition-colors">
              <Camera size={16} />
            </button>
          </div>
          
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              <h1 className="text-2xl font-bold text-white">{user.name}</h1>
              <button className="text-gray-400 hover:text-white transition-colors">
                <Edit size={16} />
              </button>
            </div>
            <p className="text-gray-400 mb-4">{user.email}</p>
            
            {userStats && (
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="text-center">
                  <div className="text-lg font-bold text-cyan-400">{userStats.totalBids}</div>
                  <div className="text-xs text-gray-400">Total Bids</div>
                </div>
                <div className="text-center">
                  <div className="text-lg font-bold text-green-400">{userStats.itemsWon}</div>
                  <div className="text-xs text-gray-400">Items Won</div>
                </div>
                <div className="text-center">
                  <div className="text-lg font-bold text-blue-400">${userStats.totalSpent}</div>
                  <div className="text-xs text-gray-400">Total Spent</div>
                </div>
                <div className="text-center">
                  <div className="text-lg font-bold text-purple-400">{userStats.followedSellers}</div>
                  <div className="text-xs text-gray-400">Following</div>
                </div>
              </div>
            )}
          </div>
          
          <div className="flex gap-2">
            <button
              onClick={onSignOut}
              className="bg-red-500 text-white px-4 py-2 rounded-lg hover:bg-red-400 transition-colors flex items-center gap-2"
            >
              <LogOut size={16} />
              Sign Out
            </button>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="flex gap-2 mb-6 overflow-x-auto">
        {[
          { id: 'overview', label: 'Overview', icon: User },
          { id: 'orders', label: 'Orders', icon: ShoppingBag },
          { id: 'following', label: 'Following', icon: Heart },
          { id: 'personal', label: 'Personal Info', icon: User },
          { id: 'shipping', label: 'Shipping', icon: MapPin },
          { id: 'payment', label: 'Payment', icon: CreditCard },
          { id: 'settings', label: 'Settings', icon: Settings }
        ].map(({ id, label, icon: Icon }) => (
          <button
            key={id}
            onClick={() => setActiveTab(id as any)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors whitespace-nowrap ${
              activeTab === id 
                ? 'bg-cyan-500 text-white' 
                : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
            }`}
          >
            <Icon size={16} />
            {label}
          </button>
        ))}
      </div>

      {/* Tab Content */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          {/* Quick Payment Actions */}
          <div className="bg-gray-800 rounded-xl p-6">
            <h2 className="text-xl font-bold text-white mb-4">Payment Center</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <button
                onClick={() => onNavigate?.('cart')}
                className="flex items-center gap-3 p-4 bg-cyan-600/20 border border-cyan-500/30 rounded-lg hover:bg-cyan-600/30 transition-colors"
              >
                <ShoppingCart className="text-cyan-400" size={20} />
                <div className="text-left">
                  <div className="font-medium text-white">Cart & Shipping</div>
                  <div className="text-sm text-cyan-400">Pay for shipping</div>
                </div>
              </button>
              
              <button
                onClick={() => onNavigate?.('invoices')}
                className="flex items-center gap-3 p-4 bg-green-600/20 border border-green-500/30 rounded-lg hover:bg-green-600/30 transition-colors"
              >
                <Receipt className="text-green-400" size={20} />
                <div className="text-left">
                  <div className="font-medium text-white">Invoices</div>
                  <div className="text-sm text-green-400">View purchases</div>
                </div>
              </button>

              <button
                onClick={() => onNavigate?.('seller-dashboard')}
                className="flex items-center gap-3 p-4 bg-yellow-600/20 border border-yellow-500/30 rounded-lg hover:bg-yellow-600/30 transition-colors"
              >
                <DollarSign className="text-yellow-400" size={20} />
                <div className="text-left">
                  <div className="font-medium text-white">Seller Tools</div>
                  <div className="text-sm text-yellow-400">Manage payouts</div>
                </div>
              </button>

              <button
                onClick={() => setActiveTab('payment')}
                className="flex items-center gap-3 p-4 bg-purple-600/20 border border-purple-500/30 rounded-lg hover:bg-purple-600/30 transition-colors"
              >
                <CreditCard className="text-purple-400" size={20} />
                <div className="text-left">
                  <div className="font-medium text-white">PayPal Setup</div>
                  <div className="text-sm text-purple-400">Connect PayPal</div>
                </div>
              </button>
            </div>
          </div>

          {/* Recent Activity */}
          <div className="bg-gray-800 rounded-xl p-6">
            <h2 className="text-xl font-bold text-white mb-4">Recent Activity</h2>
            
            {recentActivity.length === 0 ? (
              <div className="text-center py-8">
                <div className="text-4xl mb-2">🎯</div>
                <p className="text-gray-400">No recent activity</p>
              </div>
            ) : (
              <div className="space-y-3">
                {recentActivity.map((activity) => (
                  <div key={activity.id} className="flex items-center gap-4 p-3 bg-gray-700 rounded-lg">
                    <img 
                      src={activity.image}
                      alt={activity.title}
                      className="w-12 h-12 object-cover rounded-lg"
                    />
                    
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        {getActivityIcon(activity.type)}
                        <h3 className="font-medium text-white">{activity.title}</h3>
                      </div>
                      <p className="text-sm text-gray-400">{activity.description}</p>
                      <p className="text-xs text-gray-500">
                        {activity.timestamp.toLocaleDateString()}
                      </p>
                    </div>
                    
                    {activity.amount && (
                      <div className="text-right">
                        <div className="text-green-400 font-bold">${activity.amount}</div>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Member Since */}
          {userStats && (
            <div className="bg-gray-800 rounded-xl p-6">
              <h2 className="text-xl font-bold text-white mb-4">Membership</h2>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-cyan-500 rounded-full flex items-center justify-center">
                  <Award className="text-white" size={24} />
                </div>
                <div>
                  <h3 className="font-medium text-white">Member since</h3>
                  <p className="text-gray-400">
                    {userStats.memberSince.toLocaleDateString('en-US', { 
                      year: 'numeric', 
                      month: 'long', 
                      day: 'numeric' 
                    })}
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {activeTab === 'personal' && (
        <div className="bg-gray-800 rounded-xl p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-white">Personal Information</h2>
            <button
              onClick={handleSavePersonalInfo}
              disabled={saving}
              className="bg-cyan-500 text-white px-4 py-2 rounded-lg hover:bg-cyan-400 transition-colors flex items-center gap-2 disabled:opacity-50"
            >
              <Save size={16} />
              {saving ? 'Saving...' : 'Save Changes'}
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm text-gray-300 mb-2">Full Name</label>
              <input
                type="text"
                value={personalInfo.name}
                onChange={(e) => setPersonalInfo({...personalInfo, name: e.target.value})}
                className="w-full bg-gray-700 text-white px-4 py-3 rounded-lg border border-gray-600 focus:border-cyan-400 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-sm text-gray-300 mb-2">Email Address</label>
              <input
                type="email"
                value={personalInfo.email}
                onChange={(e) => setPersonalInfo({...personalInfo, email: e.target.value})}
                className="w-full bg-gray-700 text-white px-4 py-3 rounded-lg border border-gray-600 focus:border-cyan-400 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-sm text-gray-300 mb-2">Phone Number</label>
              <input
                type="tel"
                value={personalInfo.phone}
                onChange={(e) => setPersonalInfo({...personalInfo, phone: e.target.value})}
                className="w-full bg-gray-700 text-white px-4 py-3 rounded-lg border border-gray-600 focus:border-cyan-400 focus:outline-none"
                placeholder="(555) 123-4567"
              />
            </div>

            <div>
              <label className="block text-sm text-gray-300 mb-2">Current Password</label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={personalInfo.currentPassword}
                  onChange={(e) => setPersonalInfo({...personalInfo, currentPassword: e.target.value})}
                  className="w-full bg-gray-700 text-white px-4 py-3 pr-12 rounded-lg border border-gray-600 focus:border-cyan-400 focus:outline-none"
                  placeholder="Enter current password"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-3 text-gray-400 hover:text-white"
                >
                  {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                </button>
              </div>
            </div>

            <div>
              <label className="block text-sm text-gray-300 mb-2">New Password</label>
              <input
                type="password"
                value={personalInfo.newPassword}
                onChange={(e) => setPersonalInfo({...personalInfo, newPassword: e.target.value})}
                className="w-full bg-gray-700 text-white px-4 py-3 rounded-lg border border-gray-600 focus:border-cyan-400 focus:outline-none"
                placeholder="Enter new password"
              />
            </div>

            <div>
              <label className="block text-sm text-gray-300 mb-2">Confirm New Password</label>
              <input
                type="password"
                value={personalInfo.confirmPassword}
                onChange={(e) => setPersonalInfo({...personalInfo, confirmPassword: e.target.value})}
                className="w-full bg-gray-700 text-white px-4 py-3 rounded-lg border border-gray-600 focus:border-cyan-400 focus:outline-none"
                placeholder="Confirm new password"
              />
            </div>
          </div>
        </div>
      )}

      {activeTab === 'shipping' && (
        <div className="bg-gray-800 rounded-xl p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-white">Shipping Information</h2>
            <button
              onClick={handleSaveShippingInfo}
              disabled={saving}
              className="bg-cyan-500 text-white px-4 py-2 rounded-lg hover:bg-cyan-400 transition-colors flex items-center gap-2 disabled:opacity-50"
            >
              <Save size={16} />
              {saving ? 'Saving...' : 'Save Changes'}
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm text-gray-300 mb-2">First Name</label>
              <input
                type="text"
                value={shippingInfo.firstName}
                onChange={(e) => setShippingInfo({...shippingInfo, firstName: e.target.value})}
                className="w-full bg-gray-700 text-white px-4 py-3 rounded-lg border border-gray-600 focus:border-cyan-400 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-sm text-gray-300 mb-2">Last Name</label>
              <input
                type="text"
                value={shippingInfo.lastName}
                onChange={(e) => setShippingInfo({...shippingInfo, lastName: e.target.value})}
                className="w-full bg-gray-700 text-white px-4 py-3 rounded-lg border border-gray-600 focus:border-cyan-400 focus:outline-none"
              />
            </div>

            <div className="md:col-span-2">
              <label className="block text-sm text-gray-300 mb-2">Address</label>
              <input
                type="text"
                value={shippingInfo.address}
                onChange={(e) => setShippingInfo({...shippingInfo, address: e.target.value})}
                className="w-full bg-gray-700 text-white px-4 py-3 rounded-lg border border-gray-600 focus:border-cyan-400 focus:outline-none"
                placeholder="123 Main Street"
              />
            </div>

            <div>
              <label className="block text-sm text-gray-300 mb-2">City</label>
              <input
                type="text"
                value={shippingInfo.city}
                onChange={(e) => setShippingInfo({...shippingInfo, city: e.target.value})}
                className="w-full bg-gray-700 text-white px-4 py-3 rounded-lg border border-gray-600 focus:border-cyan-400 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-sm text-gray-300 mb-2">State</label>
              <input
                type="text"
                value={shippingInfo.state}
                onChange={(e) => setShippingInfo({...shippingInfo, state: e.target.value})}
                className="w-full bg-gray-700 text-white px-4 py-3 rounded-lg border border-gray-600 focus:border-cyan-400 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-sm text-gray-300 mb-2">ZIP Code</label>
              <input
                type="text"
                value={shippingInfo.zipCode}
                onChange={(e) => setShippingInfo({...shippingInfo, zipCode: e.target.value})}
                className="w-full bg-gray-700 text-white px-4 py-3 rounded-lg border border-gray-600 focus:border-cyan-400 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-sm text-gray-300 mb-2">Country</label>
              <select
                value={shippingInfo.country}
                onChange={(e) => setShippingInfo({...shippingInfo, country: e.target.value})}
                className="w-full bg-gray-700 text-white px-4 py-3 rounded-lg border border-gray-600 focus:border-cyan-400 focus:outline-none"
              >
                <option value="United States">United States</option>
                <option value="Canada">Canada</option>
                <option value="United Kingdom">United Kingdom</option>
                <option value="Australia">Australia</option>
              </select>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'payment' && (
        <div className="space-y-6">
          {/* PayPal Connection Section */}
          <PayPalConnect className="bg-gray-800" />
          
          {/* Credit Card Information */}
          <div className="bg-gray-800 rounded-xl p-6">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-xl font-bold text-white">Credit Card Information</h2>
              <button
                onClick={handleSavePaymentInfo}
                disabled={saving}
                className="bg-cyan-500 text-white px-4 py-2 rounded-lg hover:bg-cyan-400 transition-colors flex items-center gap-2 disabled:opacity-50"
              >
                <Save size={16} />
                {saving ? 'Saving...' : 'Save Changes'}
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="md:col-span-2">
                <label className="block text-sm text-gray-300 mb-2">Card Number</label>
                <input
                  type="text"
                  value={paymentInfo.cardNumber}
                  onChange={(e) => setPaymentInfo({...paymentInfo, cardNumber: e.target.value})}
                  className="w-full bg-gray-700 text-white px-4 py-3 rounded-lg border border-gray-600 focus:border-cyan-400 focus:outline-none"
                  placeholder="1234 5678 9012 3456"
                />
              </div>

              <div>
                <label className="block text-sm text-gray-300 mb-2">Expiry Date</label>
                <input
                  type="text"
                  value={paymentInfo.expiryDate}
                  onChange={(e) => setPaymentInfo({...paymentInfo, expiryDate: e.target.value})}
                  className="w-full bg-gray-700 text-white px-4 py-3 rounded-lg border border-gray-600 focus:border-cyan-400 focus:outline-none"
                  placeholder="MM/YY"
                />
              </div>

              <div>
                <label className="block text-sm text-gray-300 mb-2">CVV</label>
                <input
                  type="text"
                  value={paymentInfo.cvv}
                  onChange={(e) => setPaymentInfo({...paymentInfo, cvv: e.target.value})}
                  className="w-full bg-gray-700 text-white px-4 py-3 rounded-lg border border-gray-600 focus:border-cyan-400 focus:outline-none"
                  placeholder="123"
                />
              </div>

              <div className="md:col-span-2">
                <label className="block text-sm text-gray-300 mb-2">Cardholder Name</label>
                <input
                  type="text"
                  value={paymentInfo.cardName}
                  onChange={(e) => setPaymentInfo({...paymentInfo, cardName: e.target.value})}
                  className="w-full bg-gray-700 text-white px-4 py-3 rounded-lg border border-gray-600 focus:border-cyan-400 focus:outline-none"
                  placeholder="John Doe"
                />
              </div>

              <div className="md:col-span-2">
                <h3 className="text-lg font-medium text-white mb-4">Billing Address</h3>
              </div>

              <div className="md:col-span-2">
                <label className="block text-sm text-gray-300 mb-2">Address</label>
                <input
                  type="text"
                  value={paymentInfo.billingAddress}
                  onChange={(e) => setPaymentInfo({...paymentInfo, billingAddress: e.target.value})}
                  className="w-full bg-gray-700 text-white px-4 py-3 rounded-lg border border-gray-600 focus:border-cyan-400 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-sm text-gray-300 mb-2">City</label>
                <input
                  type="text"
                  value={paymentInfo.billingCity}
                  onChange={(e) => setPaymentInfo({...paymentInfo, billingCity: e.target.value})}
                  className="w-full bg-gray-700 text-white px-4 py-3 rounded-lg border border-gray-600 focus:border-cyan-400 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-sm text-gray-300 mb-2">State</label>
                <input
                  type="text"
                  value={paymentInfo.billingState}
                  onChange={(e) => setPaymentInfo({...paymentInfo, billingState: e.target.value})}
                  className="w-full bg-gray-700 text-white px-4 py-3 rounded-lg border border-gray-600 focus:border-cyan-400 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-sm text-gray-300 mb-2">ZIP Code</label>
                <input
                  type="text"
                  value={paymentInfo.billingZip}
                  onChange={(e) => setPaymentInfo({...paymentInfo, billingZip: e.target.value})}
                  className="w-full bg-gray-700 text-white px-4 py-3 rounded-lg border border-gray-600 focus:border-cyan-400 focus:outline-none"
                />
              </div>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'orders' && (
        <PurchaseHistory user={user} />
      )}

      {activeTab === 'following' && (
        <div className="bg-gray-800 rounded-xl p-6">
          <h2 className="text-xl font-bold text-white mb-4">Following Sellers</h2>
          <div className="text-center py-8">
            <Heart className="mx-auto text-gray-400 mb-4" size={48} />
            <h3 className="text-lg font-medium text-gray-300 mb-2">Not following anyone yet</h3>
            <p className="text-gray-500">Follow sellers to get notified when they go live</p>
          </div>
        </div>
      )}

      {activeTab === 'settings' && (
        <div className="bg-gray-800 rounded-xl p-6">
          <h2 className="text-xl font-bold text-white mb-4">Account Settings</h2>
          <div className="space-y-6">
            {/* Quick Actions */}
            <div className="border-b border-gray-700 pb-6">
              <h3 className="font-medium text-white mb-4">Quick Actions</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <button
                  onClick={() => onNavigate?.('cart')}
                  className="flex items-center gap-3 p-4 bg-gray-700 rounded-lg hover:bg-gray-600 transition-colors"
                >
                  <ShoppingCart className="text-cyan-400" size={20} />
                  <div className="text-left">
                    <div className="font-medium text-white">Cart & Shipping</div>
                    <div className="text-sm text-gray-400">Manage pending payments</div>
                  </div>
                </button>
                
                <button
                  onClick={() => onNavigate?.('invoices')}
                  className="flex items-center gap-3 p-4 bg-gray-700 rounded-lg hover:bg-gray-600 transition-colors"
                >
                  <Receipt className="text-green-400" size={20} />
                  <div className="text-left">
                    <div className="font-medium text-white">Invoices</div>
                    <div className="text-sm text-gray-400">View payment history</div>
                  </div>
                </button>

                <button
                  onClick={() => onNavigate?.('seller-dashboard')}
                  className="flex items-center gap-3 p-4 bg-gray-700 rounded-lg hover:bg-gray-600 transition-colors"
                >
                  <DollarSign className="text-yellow-400" size={20} />
                  <div className="text-left">
                    <div className="font-medium text-white">Seller Dashboard</div>
                    <div className="text-sm text-gray-400">Manage payouts & sales</div>
                  </div>
                </button>
              </div>
            </div>

            <div className="border-b border-gray-700 pb-4">
              <h3 className="font-medium text-white mb-2">Notifications</h3>
              <div className="space-y-2">
                <label className="flex items-center gap-3">
                  <input type="checkbox" defaultChecked className="rounded" />
                  <span className="text-gray-300">Auction updates</span>
                </label>
                <label className="flex items-center gap-3">
                  <input type="checkbox" defaultChecked className="rounded" />
                  <span className="text-gray-300">Outbid notifications</span>
                </label>
                <label className="flex items-center gap-3">
                  <input type="checkbox" defaultChecked className="rounded" />
                  <span className="text-gray-300">Winning confirmations</span>
                </label>
                <label className="flex items-center gap-3">
                  <input type="checkbox" defaultChecked className="rounded" />
                  <span className="text-gray-300">Payment reminders</span>
                </label>
                <label className="flex items-center gap-3">
                  <input type="checkbox" className="rounded" />
                  <span className="text-gray-300">Marketing emails</span>
                </label>
              </div>
            </div>

            <div className="border-b border-gray-700 pb-4">
              <h3 className="font-medium text-white mb-2">Privacy</h3>
              <div className="space-y-2">
                <label className="flex items-center gap-3">
                  <input type="checkbox" defaultChecked className="rounded" />
                  <span className="text-gray-300">Public profile</span>
                </label>
                <label className="flex items-center gap-3">
                  <input type="checkbox" className="rounded" />
                  <span className="text-gray-300">Show bidding activity</span>
                </label>
              </div>
            </div>

            {/* Developer Tools */}
            {onTestAgora && (
              <div className="border-b border-gray-700 pb-4">
                <h3 className="font-medium text-white mb-2">Developer Tools</h3>
                <div className="flex flex-wrap gap-2">
                  <button
                    onClick={onTestAgora}
                    className="bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-500 transition-colors"
                  >
                    Test Agora Stream
                  </button>
                  <button
                    onClick={async () => {
                      try {
                        const response = await fetch(
                          `https://${window.supabase?.supabaseUrl?.split('//')[1]}/functions/v1/make-server-9f7745d8/create-test-data`,
                          {
                            method: 'POST',
                            headers: {
                              'Content-Type': 'application/json',
                              'Authorization': `Bearer ${window.supabase?.supabaseKey}`
                            },
                            body: JSON.stringify({ userId: user?.id })
                          }
                        );
                        if (response.ok) {
                          alert('Test payment data created! Check Cart, Invoices, and Seller Dashboard.');
                        }
                      } catch (error) {
                        console.error('Failed to create test data:', error);
                      }
                    }}
                    className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-500 transition-colors"
                  >
                    Create Test Payment Data
                  </button>
                </div>
              </div>
            )}

            <div>
              <h3 className="font-medium text-white mb-2">Danger Zone</h3>
              <div className="space-y-2">
                <button className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-500 transition-colors">
                  Delete Account
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// Add default export for lazy loading
export default AccountScreen;