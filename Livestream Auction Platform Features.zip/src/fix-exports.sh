#!/bin/bash

# Script to add default exports to components that need them
# This will fix the lazy loading import issues

echo "Adding default exports to components..."

# List of components that need default exports
components=(
  "LiveStreamScreen"
  "AlertsScreen" 
  "AccountScreen"
  "CartScreen"
  "InvoiceSystem"
  "SellerDashboard"
  "SearchScreen"
  "UserProfileScreen"
  "ScheduleScreen"
  "EnhancedNotificationCenter"
  "CommunityScreen"
  "AdminDashboard"
)

for component in "${components[@]}"; do
  file="./components/${component}.tsx"
  if [ -f "$file" ]; then
    # Check if default export already exists
    if ! grep -q "export default ${component}" "$file"; then
      echo "Adding default export to ${component}.tsx"
      echo "" >> "$file"
      echo "// Add default export for lazy loading" >> "$file"
      echo "export default ${component};" >> "$file"
    else
      echo "${component}.tsx already has default export"
    fi
  else
    echo "Warning: ${file} not found"
  fi
done

echo "Done adding default exports!"