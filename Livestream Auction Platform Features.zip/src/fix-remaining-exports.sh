#!/bin/bash

# Add default exports to remaining components
echo "Adding default exports to remaining components..."

components=(
  "CartScreen"
  "InvoiceSystem" 
  "SellerDashboard"
  "SearchScreen"
  "UserProfileScreen"
  "ScheduleScreen"
  "EnhancedNotificationCenter"
  "CommunityScreen"
  "AdminDashboard"
)

for component in "${components[@]}"; do
  file="./components/${component}.tsx"
  if [ -f "$file" ]; then
    if ! grep -q "export default ${component}" "$file"; then
      echo "" >> "$file"
      echo "// Add default export for lazy loading" >> "$file"
      echo "export default ${component};" >> "$file"
      echo "Added default export to ${component}.tsx"
    else
      echo "${component}.tsx already has default export"
    fi
  else
    echo "Warning: ${file} not found"
  fi
done

echo "Completed adding default exports!"