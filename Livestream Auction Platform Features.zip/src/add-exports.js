const fs = require('fs');
const path = require('path');

const components = [
  'InvoiceSystem',
  'SearchScreen', 
  'UserProfileScreen',
  'ScheduleScreen',
  'EnhancedNotificationCenter',
  'CommunityScreen',
  'AdminDashboard'
];

components.forEach(component => {
  const filePath = path.join(__dirname, 'components', `${component}.tsx`);
  
  if (fs.existsSync(filePath)) {
    const content = fs.readFileSync(filePath, 'utf8');
    
    // Check if default export already exists
    if (!content.includes(`export default ${component}`)) {
      const newContent = content + `\n\n// Add default export for lazy loading\nexport default ${component};`;
      fs.writeFileSync(filePath, newContent);
      console.log(`Added default export to ${component}.tsx`);
    } else {
      console.log(`${component}.tsx already has default export`);
    }
  } else {
    console.log(`Warning: ${filePath} not found`);
  }
});