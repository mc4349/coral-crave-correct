export interface Config {
  supabaseUrl: string;
  supabaseAnonKey: string;
  projectId: string;
  publicSiteUrl?: string;
  paypalClientId?: string;
}

export const validateConfig = (): Config => {
  const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string | undefined;
  const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined;
  const projectId = import.meta.env.VITE_PROJECT_ID as string | undefined;

  if (!supabaseUrl || !supabaseAnonKey || !projectId) {
    console.error('Missing environment variables:', {
      supabaseUrl: !!supabaseUrl,
      supabaseAnonKey: !!supabaseAnonKey,
      projectId: !!projectId
    });
    throw new Error("Missing required environment variables (SUPABASE URL/ANON/PROJECT_ID).");
  }

  return {
    supabaseUrl,
    supabaseAnonKey,
    projectId,
    publicSiteUrl: import.meta.env.VITE_PUBLIC_SITE_URL,
    paypalClientId: import.meta.env.VITE_PAYPAL_CLIENT_ID,
  };
};

// Validate config on module load
try {
  validateConfig();
  console.log('✅ Environment configuration validated successfully');
} catch (error) {
  console.error('❌ Environment configuration error:', error);
}