import React, { useState, useEffect } from 'react';
import { Loader2, Home, Search, Video, Bell, User } from 'lucide-react';

// Simple working App without complex dependencies
function App() {
  const [activeTab, setActiveTab] = useState<'home' | 'explore' | 'go-live' | 'alerts' | 'account'>('home');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulate loading
    setTimeout(() => setLoading(false), 1000);
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin text-cyan-400 mx-auto mb-4" />
          <p className="text-gray-300">Loading Coral Crave...</p>
        </div>
      </div>
    );
  }

  const renderContent = () => {
    switch (activeTab) {
      case 'home':
        return (
          <div className="min-h-screen bg-gray-900 text-white">
            <section className="relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-br from-cyan-900 via-teal-900 to-blue-900 opacity-90"></div>
              <div className="relative px-4 py-16 md:py-24">
                <div className="max-w-6xl mx-auto text-center">
                  <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
                    Welcome to <span className="text-cyan-400">Coral Crave</span>
                  </h1>
                  <p className="text-xl md:text-2xl text-gray-200 mb-8 max-w-3xl mx-auto">
                    The premier livestream auction platform for the aquarium and reef community.
                  </p>
                  <div className="flex flex-col sm:flex-row gap-4 justify-center">
                    <button className="bg-cyan-500 text-white px-8 py-4 rounded-lg hover:bg-cyan-400 transition-colors">
                      Explore Live Auctions
                    </button>
                    <button className="bg-transparent border-2 border-cyan-400 text-cyan-400 px-8 py-4 rounded-lg hover:bg-cyan-400 hover:text-white transition-colors">
                      Start Selling
                    </button>
                  </div>
                </div>
              </div>
            </section>

            <section className="py-16 px-4">
              <div className="max-w-4xl mx-auto">
                <div className="bg-gray-800 rounded-xl p-8">
                  <h2 className="text-2xl font-bold text-white mb-6">🚀 Deployment Test</h2>
                  <div className="bg-green-500/20 border border-green-500/30 rounded-lg p-4">
                    <h3 className="text-green-300 font-medium mb-2">✅ App Successfully Deployed!</h3>
                    <p className="text-gray-300">Basic version is working. Ready to add more features.</p>
                  </div>
                </div>
              </div>
            </section>
          </div>
        );
      case 'explore':
        return (
          <div className="min-h-screen bg-gray-900 text-white p-4">
            <h1 className="text-3xl font-bold mb-4">Explore Auctions</h1>
            <p className="text-gray-400">Live auctions coming soon...</p>
          </div>
        );
      case 'go-live':
        return (
          <div className="min-h-screen bg-gray-900 text-white p-4">
            <h1 className="text-3xl font-bold mb-4">Go Live</h1>
            <p className="text-gray-400">Streaming features coming soon...</p>
          </div>
        );
      case 'alerts':
        return (
          <div className="min-h-screen bg-gray-900 text-white p-4">
            <h1 className="text-3xl font-bold mb-4">Alerts</h1>
            <p className="text-gray-400">Notifications coming soon...</p>
          </div>
        );
      case 'account':
        return (
          <div className="min-h-screen bg-gray-900 text-white p-4">
            <h1 className="text-3xl font-bold mb-4">My Account</h1>
            <p className="text-gray-400">Account features coming soon...</p>
          </div>
        );
      default:
        return (
          <div className="min-h-screen bg-gray-900 text-white p-4">
            <h1 className="text-3xl font-bold mb-4">Welcome</h1>
            <p className="text-gray-400">Select a tab to continue...</p>
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      {/* Success Banner */}
      <div className="bg-green-500/20 border-b border-green-500/30 px-4 py-2">
        <div className="flex items-center justify-center max-w-6xl mx-auto">
          <div className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
            <span className="text-green-300 text-sm font-medium">
              🎉 Coral Crave - Successfully Deployed to Netlify! ✅
            </span>
          </div>
        </div>
      </div>

      {/* Desktop Sidebar */}
      <div className="hidden md:block fixed left-0 top-0 h-full w-64 bg-gray-800/95 backdrop-blur-sm border-r border-gray-700 z-40">
        <div className="p-6">
          <div className="flex items-center space-x-3 mb-8">
            <div className="text-3xl">🪸</div>
            <div>
              <h1 className="text-xl font-bold text-cyan-400">Coral Crave</h1>
              <p className="text-xs text-gray-400">Live Auction Platform</p>
            </div>
          </div>
          
          <nav className="space-y-1">
            <button
              onClick={() => setActiveTab('home')}
              className={`w-full flex items-center px-4 py-3 rounded-lg transition-colors text-left ${
                activeTab === 'home' ? 'bg-cyan-500 text-white' : 'text-gray-300 hover:bg-gray-700'
              }`}
            >
              <Home size={20} className="mr-3" />
              Home
            </button>
            
            <button
              onClick={() => setActiveTab('explore')}
              className={`w-full flex items-center px-4 py-3 rounded-lg transition-colors text-left ${
                activeTab === 'explore' ? 'bg-cyan-500 text-white' : 'text-gray-300 hover:bg-gray-700'
              }`}
            >
              <Search size={20} className="mr-3" />
              Explore
            </button>

            <button
              onClick={() => setActiveTab('go-live')}
              className={`w-full flex items-center px-4 py-3 rounded-lg transition-colors text-left ${
                activeTab === 'go-live' ? 'bg-red-500 text-white' : 'text-gray-300 hover:bg-gray-700'
              }`}
            >
              <Video size={20} className="mr-3" />
              Go Live
            </button>

            <button
              onClick={() => setActiveTab('alerts')}
              className={`w-full flex items-center px-4 py-3 rounded-lg transition-colors text-left ${
                activeTab === 'alerts' ? 'bg-cyan-500 text-white' : 'text-gray-300 hover:bg-gray-700'
              }`}
            >
              <Bell size={20} className="mr-3" />
              Alerts
            </button>

            <button
              onClick={() => setActiveTab('account')}
              className={`w-full flex items-center px-4 py-3 rounded-lg transition-colors text-left ${
                activeTab === 'account' ? 'bg-cyan-500 text-white' : 'text-gray-300 hover:bg-gray-700'
              }`}
            >
              <User size={20} className="mr-3" />
              Account
            </button>
          </nav>
        </div>
      </div>

      {/* Main Content */}
      <div className="md:ml-64 min-h-screen">
        <div className="pb-20 md:pb-0">
          {renderContent()}
        </div>
      </div>

      {/* Mobile Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-gray-800/95 backdrop-blur-sm border-t border-gray-700 md:hidden z-50">
        <div className="flex items-center justify-around py-2">
          <button
            onClick={() => setActiveTab('home')}
            className={`flex flex-col items-center px-3 py-2 rounded-lg transition-colors ${
              activeTab === 'home' ? 'text-cyan-400' : 'text-gray-400 hover:text-white'
            }`}
          >
            <Home size={20} />
            <span className="text-xs mt-1">Home</span>
          </button>
          
          <button
            onClick={() => setActiveTab('explore')}
            className={`flex flex-col items-center px-3 py-2 rounded-lg transition-colors ${
              activeTab === 'explore' ? 'text-cyan-400' : 'text-gray-400 hover:text-white'
            }`}
          >
            <Search size={20} />
            <span className="text-xs mt-1">Explore</span>
          </button>

          <button
            onClick={() => setActiveTab('go-live')}
            className={`flex flex-col items-center px-3 py-2 rounded-lg transition-colors ${
              activeTab === 'go-live' ? 'text-red-400' : 'text-gray-400 hover:text-white'
            }`}
          >
            <Video size={20} />
            <span className="text-xs mt-1">Go Live</span>
          </button>

          <button
            onClick={() => setActiveTab('alerts')}
            className={`flex flex-col items-center px-3 py-2 rounded-lg transition-colors ${
              activeTab === 'alerts' ? 'text-cyan-400' : 'text-gray-400 hover:text-white'
            }`}
          >
            <Bell size={20} />
            <span className="text-xs mt-1">Alerts</span>
          </button>

          <button
            onClick={() => setActiveTab('account')}
            className={`flex flex-col items-center px-3 py-2 rounded-lg transition-colors ${
              activeTab === 'account' ? 'text-cyan-400' : 'text-gray-400 hover:text-white'
            }`}
          >
            <User size={20} />
            <span className="text-xs mt-1">Account</span>
          </button>
        </div>
      </div>
    </div>
  );
}

export default App;