import { Hono } from 'npm:hono';
import { cors } from 'npm:hono/cors';

const app = new Hono();

app.use('*', cors({
  origin: '*',
  allowMethods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowHeaders: ['Content-Type', 'Authorization'],
}));

// Rate limiting store
class RateLimiter {
  private limits = new Map<string, { count: number; resetTime: number }>();
  private readonly cleanupInterval: number;

  constructor() {
    // Clean up expired entries every 5 minutes
    this.cleanupInterval = setInterval(() => {
      this.cleanup();
    }, 5 * 60 * 1000);
  }

  private cleanup() {
    const now = Date.now();
    for (const [key, data] of this.limits.entries()) {
      if (data.resetTime < now) {
        this.limits.delete(key);
      }
    }
  }

  isAllowed(key: string, maxRequests: number, windowMs: number): boolean {
    const now = Date.now();
    const data = this.limits.get(key);

    if (!data || data.resetTime < now) {
      // First request or window expired
      this.limits.set(key, { count: 1, resetTime: now + windowMs });
      return true;
    }

    if (data.count >= maxRequests) {
      return false;
    }

    data.count++;
    return true;
  }

  getRemainingRequests(key: string, maxRequests: number): number {
    const data = this.limits.get(key);
    if (!data || data.resetTime < Date.now()) {
      return maxRequests;
    }
    return Math.max(0, maxRequests - data.count);
  }

  getResetTime(key: string): number {
    const data = this.limits.get(key);
    return data ? data.resetTime : Date.now();
  }

  destroy() {
    if (this.cleanupInterval) {
      clearInterval(this.cleanupInterval);
    }
  }
}

const rateLimiter = new RateLimiter();

// Rate limiting rules
const RATE_LIMITS = {
  // Authentication endpoints
  auth: { maxRequests: 5, windowMs: 15 * 60 * 1000 }, // 5 requests per 15 minutes
  
  // API endpoints
  api: { maxRequests: 100, windowMs: 60 * 1000 }, // 100 requests per minute
  
  // Live streaming
  streaming: { maxRequests: 10, windowMs: 60 * 1000 }, // 10 streams per minute
  
  // Bidding
  bidding: { maxRequests: 30, windowMs: 60 * 1000 }, // 30 bids per minute
  
  // Chat messages
  chat: { maxRequests: 60, windowMs: 60 * 1000 }, // 60 messages per minute
  
  // File uploads
  upload: { maxRequests: 20, windowMs: 60 * 1000 }, // 20 uploads per minute
  
  // Search
  search: { maxRequests: 50, windowMs: 60 * 1000 }, // 50 searches per minute
};

// Create rate limiting middleware
function createRateLimit(limitType: keyof typeof RATE_LIMITS) {
  return async (c: any, next: any) => {
    try {
      const { maxRequests, windowMs } = RATE_LIMITS[limitType];
      
      // Get client identifier (IP + User ID if available)
      const clientIp = c.req.header('x-forwarded-for') || 
                      c.req.header('x-real-ip') || 
                      'unknown';
      
      const userId = c.req.header('x-user-id') || 'anonymous';
      const key = `${limitType}:${clientIp}:${userId}`;

      if (!rateLimiter.isAllowed(key, maxRequests, windowMs)) {
        const resetTime = rateLimiter.getResetTime(key);
        const retryAfter = Math.ceil((resetTime - Date.now()) / 1000);

        // Log rate limit violation
        console.warn(`🚫 Rate limit exceeded: ${limitType} for ${clientIp} (${userId})`);

        return c.json({
          error: 'Rate limit exceeded',
          type: limitType,
          retryAfter,
          resetTime: new Date(resetTime).toISOString()
        }, 429, {
          'Retry-After': retryAfter.toString(),
          'X-RateLimit-Limit': maxRequests.toString(),
          'X-RateLimit-Remaining': '0',
          'X-RateLimit-Reset': resetTime.toString()
        });
      }

      // Add rate limit headers
      const remaining = rateLimiter.getRemainingRequests(key, maxRequests);
      const resetTime = rateLimiter.getResetTime(key);

      c.res.headers.set('X-RateLimit-Limit', maxRequests.toString());
      c.res.headers.set('X-RateLimit-Remaining', remaining.toString());
      c.res.headers.set('X-RateLimit-Reset', resetTime.toString());

      await next();
    } catch (error) {
      console.error('Rate limiting error:', error);
      await next(); // Continue on error
    }
  };
}

// Security headers middleware
app.use('*', async (c, next) => {
  await next();
  
  // Add security headers
  c.res.headers.set('X-Content-Type-Options', 'nosniff');
  c.res.headers.set('X-Frame-Options', 'DENY');
  c.res.headers.set('X-XSS-Protection', '1; mode=block');
  c.res.headers.set('Referrer-Policy', 'strict-origin-when-cross-origin');
  c.res.headers.set('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
});

// Input validation helpers
const validateEmail = (email: string): boolean => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

const sanitizeString = (str: string, maxLength = 1000): string => {
  if (typeof str !== 'string') return '';
  return str.trim().substring(0, maxLength);
};

const validatePositiveNumber = (num: any): number => {
  const parsed = parseFloat(num);
  return isNaN(parsed) || parsed < 0 ? 0 : parsed;
};

// Rate limiting endpoints
app.post('/make-server-9f7745d8/auth/login', createRateLimit('auth'), async (c) => {
  try {
    const { email, password } = await c.req.json();

    // Validate input
    if (!validateEmail(email)) {
      return c.json({ error: 'Invalid email format' }, 400);
    }

    if (!password || password.length < 6) {
      return c.json({ error: 'Password must be at least 6 characters' }, 400);
    }

    // Continue with actual auth logic...
    return c.json({ success: true, message: 'Login rate limit passed' });

  } catch (error) {
    return c.json({ error: 'Invalid request' }, 400);
  }
});

app.post('/make-server-9f7745d8/streams/start', createRateLimit('streaming'), async (c) => {
  return c.json({ success: true, message: 'Stream start rate limit passed' });
});

app.post('/make-server-9f7745d8/bids/place', createRateLimit('bidding'), async (c) => {
  try {
    const { itemId, amount } = await c.req.json();
    
    // Validate bid amount
    const bidAmount = validatePositiveNumber(amount);
    if (bidAmount <= 0) {
      return c.json({ error: 'Invalid bid amount' }, 400);
    }

    return c.json({ success: true, message: 'Bid rate limit passed' });
  } catch (error) {
    return c.json({ error: 'Invalid request' }, 400);
  }
});

app.post('/make-server-9f7745d8/chat/message', createRateLimit('chat'), async (c) => {
  try {
    const { message, streamId } = await c.req.json();
    
    // Validate and sanitize message
    const sanitizedMessage = sanitizeString(message, 500);
    if (!sanitizedMessage) {
      return c.json({ error: 'Message cannot be empty' }, 400);
    }

    return c.json({ success: true, message: 'Chat rate limit passed' });
  } catch (error) {
    return c.json({ error: 'Invalid request' }, 400);
  }
});

app.post('/make-server-9f7745d8/upload', createRateLimit('upload'), async (c) => {
  return c.json({ success: true, message: 'Upload rate limit passed' });
});

app.get('/make-server-9f7745d8/search', createRateLimit('search'), async (c) => {
  return c.json({ success: true, message: 'Search rate limit passed' });
});

// Rate limit status endpoint
app.get('/make-server-9f7745d8/rate-limit-status', async (c) => {
  const clientIp = c.req.header('x-forwarded-for') || 
                  c.req.header('x-real-ip') || 
                  'unknown';
  const userId = c.req.header('x-user-id') || 'anonymous';

  const status: any = {};

  for (const [limitType, { maxRequests }] of Object.entries(RATE_LIMITS)) {
    const key = `${limitType}:${clientIp}:${userId}`;
    status[limitType] = {
      remaining: rateLimiter.getRemainingRequests(key, maxRequests),
      resetTime: new Date(rateLimiter.getResetTime(key)).toISOString(),
      maxRequests
    };
  }

  return c.json({
    clientId: `${clientIp}:${userId}`,
    limits: status,
    timestamp: new Date().toISOString()
  });
});

// Security validation functions
export const security = {
  validateEmail,
  sanitizeString,
  validatePositiveNumber,
  createRateLimit
};

export default app;