import { Hono } from 'npm:hono'
import { cors } from 'npm:hono/cors'
import { logger } from 'npm:hono/logger'
import { createClient } from 'npm:@supabase/supabase-js@2'

const app = new Hono()

// Middleware
app.use('*', cors({
  origin: '*',
  allowHeaders: ['Content-Type', 'Authorization'],
  allowMethods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
}))
app.use('*', logger(console.log))

// Initialize Supabase client with service role key
const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
)

// Health endpoint - simplest possible version
app.get('/make-server-9f7745d8/health', async (c) => {
  try {
    console.log('✅ Health check requested at:', new Date().toISOString());
    
    return c.json({ 
      status: 'ok', 
      timestamp: new Date().toISOString(),
      server: 'running',
      environment: 'production',
      version: '1.0.0-simple',
      supabase: !!Deno.env.get('SUPABASE_URL'),
      serviceRole: !!Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')
    })
  } catch (error) {
    console.error('❌ Health check error:', error);
    return c.json({ 
      status: 'error', 
      timestamp: new Date().toISOString(),
      error: error instanceof Error ? error.message : 'Unknown error' 
    }, 500)
  }
})

// Ping endpoint for basic connectivity test
app.get('/make-server-9f7745d8/ping', async (c) => {
  return c.json({ 
    ping: 'pong', 
    timestamp: new Date().toISOString(),
    server: 'online-simple'
  })
})

// User signup endpoint - essential for demo login
app.post('/make-server-9f7745d8/signup', async (c) => {
  try {
    console.log('🔵 Signup request received');
    
    const { email, password, name } = await c.req.json()
    console.log('📋 Signup data:', { email, name: !!name, password: !!password });

    if (!email || !password || !name) {
      console.log('❌ Missing required fields');
      return c.json({ error: 'Email, password, and name are required' }, 400)
    }

    console.log('🔑 Creating user with Supabase Admin API...');
    
    // Create user with Supabase Admin API
    const { data, error } = await supabase.auth.admin.createUser({
      email,
      password,
      user_metadata: { name },
      email_confirm: true // Auto-confirm since no email server configured
    })

    if (error) {
      console.error('❌ User creation error:', error);
      return c.json({ error: error.message }, 400)
    }

    console.log('✅ User created successfully:', data.user?.email);

    return c.json({ 
      message: 'User created successfully',
      user: {
        id: data.user.id,
        email: data.user.email,
        name: data.user.user_metadata?.name
      }
    })

  } catch (error) {
    console.error('💥 Signup error:', error);
    return c.json({ error: 'Failed to create user account' }, 500)
  }
})

// Simple streams endpoint for basic functionality
app.get('/make-server-9f7745d8/streams', async (c) => {
  try {
    const streams = [
      {
        id: '1',
        title: 'Premium Coral Collection - Live Auction',
        seller: {
          name: 'AquaReef Co.',
          verified: true
        },
        viewerCount: 847,
        category: 'Coral',
        isLive: true
      }
    ]

    return c.json({ streams })

  } catch (error) {
    console.error('Streams fetch error:', error)
    return c.json({ error: 'Failed to fetch streams' }, 500)
  }
})

// Error handler
app.onError((err, c) => {
  console.error('💥 Server error:', err)
  return c.json({ 
    error: 'Internal server error',
    message: err.message,
    timestamp: new Date().toISOString()
  }, 500)
})

// Start server
console.log('🚀 Starting simplified Coral Crave server...');
Deno.serve(app.fetch)