import { Hono } from 'npm:hono';
import { cors } from 'npm:hono/cors';
import { createClient } from 'npm:@supabase/supabase-js@2';
import * as kv from './kv_store.tsx';

const app = new Hono();

app.use('*', cors({
  origin: '*',
  allowMethods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowHeaders: ['Content-Type', 'Authorization'],
}));

const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
);

// Get platform overview metrics
app.get('/make-server-9f7745d8/analytics/overview', async (c) => {
  try {
    console.log('Getting platform overview metrics');

    // Get various data from KV store
    const users = await kv.getByPrefix('user_profile_');
    const auctions = await kv.getByPrefix('auction_item_');
    const payments = await kv.getByPrefix('payment_');
    const orders = await kv.getByPrefix('order_');

    // Calculate metrics
    const totalUsers = users.length;
    const totalAuctions = auctions.length;
    const completedAuctions = auctions.filter(a => a.value?.status === 'completed').length;
    const liveAuctions = auctions.filter(a => a.value?.status === 'live').length;

    // Calculate revenue
    const totalRevenue = payments.reduce((sum, payment) => {
      return sum + (payment.value?.amount || 0);
    }, 0);

    // Calculate average auction value
    const completedAuctionValues = auctions
      .filter(a => a.value?.status === 'completed')
      .map(a => a.value?.finalPrice || 0);
    
    const avgAuctionValue = completedAuctionValues.length > 0 
      ? completedAuctionValues.reduce((sum, val) => sum + val, 0) / completedAuctionValues.length 
      : 0;

    // Platform fees (8% commission + payment processing)
    const platformFees = totalRevenue * 0.08; // 8% commission
    const processingFees = payments.length * 0.30 + totalRevenue * 0.029; // PayPal fees

    // Success rate
    const successRate = totalAuctions > 0 ? (completedAuctions / totalAuctions) * 100 : 0;

    // Mock some real-time data
    const onlineUsers = Math.floor(Math.random() * 500) + 200;
    const activeStreams = Math.floor(Math.random() * 25) + 5;

    const overview = {
      users: {
        total: totalUsers,
        online: onlineUsers,
        newToday: Math.floor(Math.random() * 50) + 10
      },
      auctions: {
        total: totalAuctions,
        live: liveAuctions,
        completed: completedAuctions,
        successRate: successRate.toFixed(1)
      },
      revenue: {
        total: totalRevenue,
        platformFees: platformFees,
        processingFees: processingFees,
        avgAuctionValue: avgAuctionValue.toFixed(2)
      },
      activity: {
        activeStreams,
        totalViews: Math.floor(Math.random() * 10000) + 50000,
        totalBids: Math.floor(Math.random() * 5000) + 25000
      }
    };

    return c.json(overview);

  } catch (error) {
    console.error('Analytics overview error:', error);
    return c.json({ error: 'Failed to get analytics overview' }, 500);
  }
});

// Get revenue analytics
app.get('/make-server-9f7745d8/analytics/revenue', async (c) => {
  try {
    const timeRange = c.req.query('timeRange') || '30d';
    const granularity = c.req.query('granularity') || 'daily';

    console.log('Getting revenue analytics:', { timeRange, granularity });

    // Get payment data
    const payments = await kv.getByPrefix('payment_');
    const orders = await kv.getByPrefix('order_');

    // Process revenue data by time period
    const revenueData = generateRevenueTimeSeries(payments, timeRange, granularity);
    const categoryBreakdown = generateCategoryBreakdown(orders);
    const topSellers = await generateTopSellers();

    return c.json({
      timeSeries: revenueData,
      categoryBreakdown,
      topSellers,
      summary: {
        totalRevenue: revenueData.reduce((sum, item) => sum + item.revenue, 0),
        totalCommission: revenueData.reduce((sum, item) => sum + item.commission, 0),
        totalFees: revenueData.reduce((sum, item) => sum + item.fees, 0),
        growthRate: calculateGrowthRate(revenueData)
      }
    });

  } catch (error) {
    console.error('Revenue analytics error:', error);
    return c.json({ error: 'Failed to get revenue analytics' }, 500);
  }
});

// Get user analytics
app.get('/make-server-9f7745d8/analytics/users', async (c) => {
  try {
    const timeRange = c.req.query('timeRange') || '30d';

    console.log('Getting user analytics:', { timeRange });

    const users = await kv.getByPrefix('user_profile_');
    const logins = await kv.getByPrefix('user_login_');

    // Generate user growth data
    const userGrowth = generateUserGrowthData(users, timeRange);
    const retentionData = generateRetentionData(logins, timeRange);
    const engagementMetrics = generateEngagementMetrics(users);

    return c.json({
      growth: userGrowth,
      retention: retentionData,
      engagement: engagementMetrics,
      demographics: {
        totalUsers: users.length,
        verifiedUsers: users.filter(u => u.value?.verified).length,
        activeLastWeek: Math.floor(users.length * 0.6),
        activeLastMonth: Math.floor(users.length * 0.8)
      }
    });

  } catch (error) {
    console.error('User analytics error:', error);
    return c.json({ error: 'Failed to get user analytics' }, 500);
  }
});

// Get auction performance analytics
app.get('/make-server-9f7745d8/analytics/auctions', async (c) => {
  try {
    const timeRange = c.req.query('timeRange') || '30d';

    console.log('Getting auction analytics:', { timeRange });

    const auctions = await kv.getByPrefix('auction_item_');
    const bids = await kv.getByPrefix('bid_');

    // Process auction metrics
    const auctionMetrics = generateAuctionMetrics(auctions, bids, timeRange);
    const categoryPerformance = generateCategoryPerformance(auctions);
    const bidDistribution = generateBidDistribution(bids);

    return c.json({
      metrics: auctionMetrics,
      categoryPerformance,
      bidDistribution,
      summary: {
        totalAuctions: auctions.length,
        avgBidsPerAuction: bids.length / auctions.length || 0,
        conversionRate: calculateConversionRate(auctions),
        avgDuration: calculateAvgDuration(auctions)
      }
    });

  } catch (error) {
    console.error('Auction analytics error:', error);
    return c.json({ error: 'Failed to get auction analytics' }, 500);
  }
});

// Track user action for analytics
app.post('/make-server-9f7745d8/analytics/track', async (c) => {
  try {
    const { userId, action, metadata } = await c.req.json();

    if (!action) {
      return c.json({ error: 'Action is required' }, 400);
    }

    const eventId = `event_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const event = {
      id: eventId,
      userId: userId || 'anonymous',
      action,
      metadata: metadata || {},
      timestamp: new Date().toISOString(),
      ip: c.req.header('x-forwarded-for') || 'unknown',
      userAgent: c.req.header('user-agent') || 'unknown'
    };

    await kv.set(`analytics_event_${eventId}`, event);

    // Also update user activity if userId provided
    if (userId) {
      const userActivity = await kv.get(`user_activity_${userId}`) || { value: { events: [] } };
      userActivity.value.events.push({
        action,
        timestamp: event.timestamp,
        metadata
      });

      // Keep only last 100 events per user
      if (userActivity.value.events.length > 100) {
        userActivity.value.events = userActivity.value.events.slice(-100);
      }

      await kv.set(`user_activity_${userId}`, userActivity.value);
    }

    return c.json({ success: true });

  } catch (error) {
    console.error('Track analytics error:', error);
    return c.json({ error: 'Failed to track analytics event' }, 500);
  }
});

// Get real-time metrics
app.get('/make-server-9f7745d8/analytics/realtime', async (c) => {
  try {
    console.log('Getting real-time metrics');

    // Mock real-time data (in production, this would come from actual real-time sources)
    const realTimeMetrics = {
      currentUsers: Math.floor(Math.random() * 500) + 200,
      activeAuctions: Math.floor(Math.random() * 25) + 5,
      bidsLastHour: Math.floor(Math.random() * 200) + 50,
      revenueToday: Math.floor(Math.random() * 10000) + 5000,
      newSignupsToday: Math.floor(Math.random() * 50) + 10,
      conversionRateToday: (Math.random() * 20 + 80).toFixed(1), // 80-100%
      avgSessionDuration: Math.floor(Math.random() * 30 + 15), // 15-45 minutes
      topCategories: [
        { name: 'SPS Corals', percentage: 35 },
        { name: 'LPS Corals', percentage: 28 },
        { name: 'Soft Corals', percentage: 15 },
        { name: 'Fish', percentage: 12 },
        { name: 'Equipment', percentage: 10 }
      ]
    };

    return c.json(realTimeMetrics);

  } catch (error) {
    console.error('Real-time metrics error:', error);
    return c.json({ error: 'Failed to get real-time metrics' }, 500);
  }
});

// Helper functions for analytics calculations
function generateRevenueTimeSeries(payments: any[], timeRange: string, granularity: string) {
  // Mock revenue time series data
  const data = [];
  const days = timeRange === '7d' ? 7 : timeRange === '30d' ? 30 : 365;
  
  for (let i = days - 1; i >= 0; i--) {
    const date = new Date();
    date.setDate(date.getDate() - i);
    
    const revenue = Math.floor(Math.random() * 5000) + 2000;
    const commission = revenue * 0.08;
    const fees = revenue * 0.029 + 30; // Simplified PayPal fee calculation
    
    data.push({
      date: date.toISOString().split('T')[0],
      revenue,
      commission,
      fees
    });
  }
  
  return data;
}

function generateCategoryBreakdown(orders: any[]) {
  return [
    { category: 'SPS Corals', revenue: 25000, percentage: 35 },
    { category: 'LPS Corals', revenue: 20000, percentage: 28 },
    { category: 'Soft Corals', revenue: 10000, percentage: 15 },
    { category: 'Fish', revenue: 8000, percentage: 12 },
    { category: 'Equipment', revenue: 7000, percentage: 10 }
  ];
}

async function generateTopSellers() {
  const sellers = await kv.getByPrefix('user_profile_');
  
  return sellers.slice(0, 10).map((seller, index) => ({
    id: seller.value?.id || `seller_${index}`,
    name: seller.value?.name || `Seller ${index + 1}`,
    revenue: Math.floor(Math.random() * 50000) + 10000,
    sales: Math.floor(Math.random() * 500) + 100,
    rating: (Math.random() * 1 + 4).toFixed(1) // 4.0-5.0
  }));
}

function generateUserGrowthData(users: any[], timeRange: string) {
  const data = [];
  const days = timeRange === '7d' ? 7 : timeRange === '30d' ? 30 : 90;
  
  for (let i = days - 1; i >= 0; i--) {
    const date = new Date();
    date.setDate(date.getDate() - i);
    
    data.push({
      date: date.toISOString().split('T')[0],
      newUsers: Math.floor(Math.random() * 50) + 10,
      activeUsers: Math.floor(Math.random() * 500) + 200,
      retention: Math.floor(Math.random() * 20) + 75 // 75-95%
    });
  }
  
  return data;
}

function generateRetentionData(logins: any[], timeRange: string) {
  return {
    day1: 85,
    day7: 72,
    day30: 58,
    day90: 45
  };
}

function generateEngagementMetrics(users: any[]) {
  return {
    avgSessionDuration: 28, // minutes
    avgPagesPerSession: 8.5,
    bounceRate: 15.2, // percentage
    avgTimeOnSite: 42 // minutes
  };
}

function generateAuctionMetrics(auctions: any[], bids: any[], timeRange: string) {
  const data = [];
  const days = timeRange === '7d' ? 7 : timeRange === '30d' ? 30 : 90;
  
  for (let i = days - 1; i >= 0; i--) {
    const date = new Date();
    date.setDate(date.getDate() - i);
    
    const totalAuctions = Math.floor(Math.random() * 20) + 10;
    const completedAuctions = Math.floor(totalAuctions * 0.85);
    
    data.push({
      date: date.toISOString().split('T')[0],
      totalAuctions,
      completedAuctions,
      averageBids: Math.floor(Math.random() * 5) + 5,
      conversionRate: (completedAuctions / totalAuctions * 100).toFixed(1)
    });
  }
  
  return data;
}

function generateCategoryPerformance(auctions: any[]) {
  return [
    { category: 'SPS Corals', auctions: 156, avgValue: 125, successRate: 92 },
    { category: 'LPS Corals', auctions: 134, avgValue: 95, successRate: 89 },
    { category: 'Soft Corals', auctions: 89, avgValue: 65, successRate: 94 },
    { category: 'Fish', auctions: 67, avgValue: 85, successRate: 87 },
    { category: 'Equipment', auctions: 45, avgValue: 155, successRate: 96 }
  ];
}

function generateBidDistribution(bids: any[]) {
  return {
    ranges: [
      { range: '$0-$25', count: 1250 },
      { range: '$25-$50', count: 890 },
      { range: '$50-$100', count: 650 },
      { range: '$100-$200', count: 420 },
      { range: '$200+', count: 180 }
    ]
  };
}

function calculateGrowthRate(data: any[]) {
  if (data.length < 2) return 0;
  
  const current = data[data.length - 1].revenue;
  const previous = data[data.length - 2].revenue;
  
  return ((current - previous) / previous * 100).toFixed(1);
}

function calculateConversionRate(auctions: any[]) {
  const completed = auctions.filter(a => a.value?.status === 'completed').length;
  return auctions.length > 0 ? (completed / auctions.length * 100).toFixed(1) : 0;
}

function calculateAvgDuration(auctions: any[]) {
  // Mock average duration in hours
  return Math.floor(Math.random() * 4) + 2; // 2-6 hours
}

export default app;