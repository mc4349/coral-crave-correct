import { Hono } from 'npm:hono';
import { cors } from 'npm:hono/cors';
import { createClient } from 'npm:@supabase/supabase-js@2';
import * as kv from './kv_store.tsx';

const app = new Hono();

// CORS middleware
app.use('*', cors({
  origin: '*',
  allowMethods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowHeaders: ['Content-Type', 'Authorization'],
}));

// Initialize Supabase client
const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
);

// Helper function to validate auth token
const validateAuth = async (authHeader: string | undefined) => {
  if (!authHeader) {
    return { error: 'Authorization header missing', user: null };
  }

  const token = authHeader.startsWith('Bearer ') ? authHeader.split(' ')[1] : authHeader;
  
  if (!token || token === 'undefined' || token === 'null') {
    return { error: 'Invalid token format', user: null };
  }

  try {
    const { data: { user }, error } = await supabase.auth.getUser(token);
    
    if (error || !user) {
      return { error: 'Invalid or expired token', user: null };
    }
    
    return { error: null, user };
  } catch (error) {
    return { error: 'Token validation failed', user: null };
  }
};

// Get user's conversations
app.get('/messages/conversations', async (c) => {
  try {
    console.log('💬 Get conversations request received');
    
    const authHeader = c.req.header('Authorization');
    const { error, user } = await validateAuth(authHeader);
    
    if (error || !user) {
      console.log('❌ Auth failed for conversations:', error);
      return c.json({ error: error || 'Authentication required' }, 401);
    }
    
    console.log('✅ User validated for conversations:', user.id);
    
    // Get user's conversations
    const conversationsKey = `conversations:${user.id}`;
    const conversationIds = await kv.get(conversationsKey) || [];
    
    const conversations = [];
    
    for (const conversationId of conversationIds) {
      const conversation = await kv.get(`conversation:${conversationId}`);
      if (conversation) {
        // Get last message
        const messagesKey = `messages:${conversationId}`;
        const messages = await kv.get(messagesKey) || [];
        const lastMessage = messages[messages.length - 1];
        
        // Count unread messages
        const unreadCount = messages.filter(msg => 
          msg.senderId !== user.id && !msg.read
        ).length;
        
        conversations.push({
          ...conversation,
          lastMessage,
          unreadCount
        });
      }
    }
    
    // Sort by last activity
    conversations.sort((a, b) => 
      new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()
    );
    
    console.log('💬 Retrieved conversations for user:', conversations.length);
    
    return c.json({
      success: true,
      conversations
    });
    
  } catch (error) {
    console.error('💥 Get conversations error:', error);
    return c.json({ error: 'Failed to get conversations' }, 500);
  }
});

// Get messages for a conversation
app.get('/messages/:conversationId', async (c) => {
  try {
    const conversationId = c.req.param('conversationId');
    console.log('💬 Get messages request received:', conversationId);
    
    const authHeader = c.req.header('Authorization');
    const { error, user } = await validateAuth(authHeader);
    
    if (error || !user) {
      console.log('❌ Auth failed for messages:', error);
      return c.json({ error: error || 'Authentication required' }, 401);
    }
    
    console.log('✅ User validated for messages:', user.id);
    
    // Verify user is part of this conversation
    const conversation = await kv.get(`conversation:${conversationId}`);
    
    if (!conversation) {
      return c.json({ error: 'Conversation not found' }, 404);
    }
    
    const isParticipant = conversation.participants.some(p => p.id === user.id);
    
    if (!isParticipant) {
      return c.json({ error: 'Unauthorized - not a participant in this conversation' }, 403);
    }
    
    // Get messages
    const messagesKey = `messages:${conversationId}`;
    const messages = await kv.get(messagesKey) || [];
    
    console.log('💬 Retrieved messages for conversation:', messages.length);
    
    return c.json({
      success: true,
      messages: messages.sort((a, b) => 
        new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()
      )
    });
    
  } catch (error) {
    console.error('💥 Get messages error:', error);
    return c.json({ error: 'Failed to get messages' }, 500);
  }
});

// Send a message
app.post('/messages/send', async (c) => {
  try {
    console.log('💬 Send message request received');
    
    const authHeader = c.req.header('Authorization');
    const { error, user } = await validateAuth(authHeader);
    
    if (error || !user) {
      console.log('❌ Auth failed for send message:', error);
      return c.json({ error: error || 'Authentication required' }, 401);
    }
    
    console.log('✅ User validated for send message:', user.id);
    
    const { conversationId, content, type = 'text', metadata } = await c.req.json();
    
    if (!conversationId || !content) {
      return c.json({ error: 'Conversation ID and content are required' }, 400);
    }
    
    // Verify user is part of this conversation
    const conversation = await kv.get(`conversation:${conversationId}`);
    
    if (!conversation) {
      return c.json({ error: 'Conversation not found' }, 404);
    }
    
    const isParticipant = conversation.participants.some(p => p.id === user.id);
    
    if (!isParticipant) {
      return c.json({ error: 'Unauthorized - not a participant in this conversation' }, 403);
    }
    
    // Create message
    const message = {
      id: `msg_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      conversationId,
      senderId: user.id,
      senderName: user.user_metadata?.name || user.email || 'Unknown',
      content,
      type,
      metadata,
      timestamp: new Date().toISOString(),
      read: false
    };
    
    // Add message to conversation
    const messagesKey = `messages:${conversationId}`;
    const messages = await kv.get(messagesKey) || [];
    messages.push(message);
    await kv.set(messagesKey, messages);
    
    // Update conversation timestamp
    const updatedConversation = {
      ...conversation,
      updatedAt: new Date().toISOString()
    };
    await kv.set(`conversation:${conversationId}`, updatedConversation);
    
    // Create notifications for other participants
    for (const participant of conversation.participants) {
      if (participant.id !== user.id) {
        const notification = {
          id: `notif_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
          userId: participant.id,
          type: 'message',
          title: 'New Message',
          message: `${user.user_metadata?.name || user.email}: ${content}`,
          read: false,
          createdAt: new Date().toISOString(),
          metadata: {
            senderId: user.id,
            senderName: user.user_metadata?.name || user.email,
            conversationId: conversationId
          }
        };
        
        // Add to participant's notifications
        const notificationsKey = `notifications:${participant.id}`;
        const notifications = await kv.get(notificationsKey) || [];
        notifications.push(notification);
        await kv.set(notificationsKey, notifications);
      }
    }
    
    console.log('✅ Message sent successfully:', message.id);
    
    return c.json({
      success: true,
      message,
      messageText: 'Message sent successfully'
    });
    
  } catch (error) {
    console.error('💥 Send message error:', error);
    return c.json({ error: 'Failed to send message' }, 500);
  }
});

// Create a new conversation
app.post('/messages/conversations/create', async (c) => {
  try {
    console.log('💬 Create conversation request received');
    
    const authHeader = c.req.header('Authorization');
    const { error, user } = await validateAuth(authHeader);
    
    if (error || !user) {
      console.log('❌ Auth failed for create conversation:', error);
      return c.json({ error: error || 'Authentication required' }, 401);
    }
    
    console.log('✅ User validated for create conversation:', user.id);
    
    const { participantId, participantName } = await c.req.json();
    
    if (!participantId || !participantName) {
      return c.json({ error: 'Participant ID and name are required' }, 400);
    }
    
    if (participantId === user.id) {
      return c.json({ error: 'Cannot create conversation with yourself' }, 400);
    }
    
    // Check if conversation already exists between these users
    const userConversations = await kv.get(`conversations:${user.id}`) || [];
    
    for (const conversationId of userConversations) {
      const existingConversation = await kv.get(`conversation:${conversationId}`);
      
      if (existingConversation && 
          existingConversation.participants.length === 2 &&
          existingConversation.participants.some(p => p.id === participantId)) {
        
        // Return existing conversation
        console.log('✅ Returning existing conversation:', conversationId);
        
        return c.json({
          success: true,
          conversation: existingConversation,
          message: 'Conversation already exists'
        });
      }
    }
    
    // Create new conversation
    const conversationId = `conv_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    
    const conversation = {
      id: conversationId,
      participants: [
        {
          id: user.id,
          name: user.user_metadata?.name || user.email || 'Unknown',
          isOnline: true
        },
        {
          id: participantId,
          name: participantName,
          isOnline: false // We don't track online status yet
        }
      ],
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    
    // Save conversation
    await kv.set(`conversation:${conversationId}`, conversation);
    
    // Add to both users' conversation lists
    const updatedUserConversations = [...userConversations, conversationId];
    await kv.set(`conversations:${user.id}`, updatedUserConversations);
    
    const participantConversations = await kv.get(`conversations:${participantId}`) || [];
    const updatedParticipantConversations = [...participantConversations, conversationId];
    await kv.set(`conversations:${participantId}`, updatedParticipantConversations);
    
    console.log('✅ Conversation created successfully:', conversationId);
    
    return c.json({
      success: true,
      conversation,
      message: 'Conversation created successfully'
    });
    
  } catch (error) {
    console.error('💥 Create conversation error:', error);
    return c.json({ error: 'Failed to create conversation' }, 500);
  }
});

// Mark conversation as read
app.post('/messages/:conversationId/read', async (c) => {
  try {
    const conversationId = c.req.param('conversationId');
    console.log('💬 Mark conversation as read request received:', conversationId);
    
    const authHeader = c.req.header('Authorization');
    const { error, user } = await validateAuth(authHeader);
    
    if (error || !user) {
      console.log('❌ Auth failed for mark as read:', error);
      return c.json({ error: error || 'Authentication required' }, 401);
    }
    
    console.log('✅ User validated for mark as read:', user.id);
    
    // Verify user is part of this conversation
    const conversation = await kv.get(`conversation:${conversationId}`);
    
    if (!conversation) {
      return c.json({ error: 'Conversation not found' }, 404);
    }
    
    const isParticipant = conversation.participants.some(p => p.id === user.id);
    
    if (!isParticipant) {
      return c.json({ error: 'Unauthorized - not a participant in this conversation' }, 403);
    }
    
    // Mark all messages as read for this user
    const messagesKey = `messages:${conversationId}`;
    const messages = await kv.get(messagesKey) || [];
    
    const updatedMessages = messages.map(msg => {
      if (msg.senderId !== user.id) {
        return { ...msg, read: true };
      }
      return msg;
    });
    
    await kv.set(messagesKey, updatedMessages);
    
    console.log('✅ Conversation marked as read:', conversationId);
    
    return c.json({
      success: true,
      message: 'Conversation marked as read'
    });
    
  } catch (error) {
    console.error('💥 Mark conversation as read error:', error);
    return c.json({ error: 'Failed to mark conversation as read' }, 500);
  }
});

// Get user's notifications
app.get('/notifications', async (c) => {
  try {
    console.log('🔔 Get notifications request received');
    
    const authHeader = c.req.header('Authorization');
    const { error, user } = await validateAuth(authHeader);
    
    if (error || !user) {
      console.log('❌ Auth failed for notifications:', error);
      return c.json({ error: error || 'Authentication required' }, 401);
    }
    
    console.log('✅ User validated for notifications:', user.id);
    
    // Get user's notifications
    const notificationsKey = `notifications:${user.id}`;
    const notifications = await kv.get(notificationsKey) || [];
    
    // Sort by newest first
    const sortedNotifications = notifications.sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
    
    console.log('🔔 Retrieved notifications for user:', notifications.length);
    
    return c.json({
      success: true,
      notifications: sortedNotifications
    });
    
  } catch (error) {
    console.error('💥 Get notifications error:', error);
    return c.json({ error: 'Failed to get notifications' }, 500);
  }
});

// Mark notification as read
app.post('/notifications/:notificationId/read', async (c) => {
  try {
    const notificationId = c.req.param('notificationId');
    console.log('🔔 Mark notification as read request received:', notificationId);
    
    const authHeader = c.req.header('Authorization');
    const { error, user } = await validateAuth(authHeader);
    
    if (error || !user) {
      console.log('❌ Auth failed for mark notification as read:', error);
      return c.json({ error: error || 'Authentication required' }, 401);
    }
    
    console.log('✅ User validated for mark notification as read:', user.id);
    
    // Get user's notifications
    const notificationsKey = `notifications:${user.id}`;
    const notifications = await kv.get(notificationsKey) || [];
    
    // Update notification
    const updatedNotifications = notifications.map(notif => 
      notif.id === notificationId ? { ...notif, read: true } : notif
    );
    
    await kv.set(notificationsKey, updatedNotifications);
    
    console.log('✅ Notification marked as read:', notificationId);
    
    return c.json({
      success: true,
      message: 'Notification marked as read'
    });
    
  } catch (error) {
    console.error('💥 Mark notification as read error:', error);
    return c.json({ error: 'Failed to mark notification as read' }, 500);
  }
});

// Mark all notifications as read
app.post('/notifications/mark-all-read', async (c) => {
  try {
    console.log('🔔 Mark all notifications as read request received');
    
    const authHeader = c.req.header('Authorization');
    const { error, user } = await validateAuth(authHeader);
    
    if (error || !user) {
      console.log('❌ Auth failed for mark all notifications as read:', error);
      return c.json({ error: error || 'Authentication required' }, 401);
    }
    
    console.log('✅ User validated for mark all notifications as read:', user.id);
    
    // Get user's notifications
    const notificationsKey = `notifications:${user.id}`;
    const notifications = await kv.get(notificationsKey) || [];
    
    // Mark all as read
    const updatedNotifications = notifications.map(notif => ({ ...notif, read: true }));
    
    await kv.set(notificationsKey, updatedNotifications);
    
    console.log('✅ All notifications marked as read for user:', user.id);
    
    return c.json({
      success: true,
      message: 'All notifications marked as read'
    });
    
  } catch (error) {
    console.error('💥 Mark all notifications as read error:', error);
    return c.json({ error: 'Failed to mark all notifications as read' }, 500);
  }
});

// Delete notification
app.delete('/notifications/:notificationId', async (c) => {
  try {
    const notificationId = c.req.param('notificationId');
    console.log('🔔 Delete notification request received:', notificationId);
    
    const authHeader = c.req.header('Authorization');
    const { error, user } = await validateAuth(authHeader);
    
    if (error || !user) {
      console.log('❌ Auth failed for delete notification:', error);
      return c.json({ error: error || 'Authentication required' }, 401);
    }
    
    console.log('✅ User validated for delete notification:', user.id);
    
    // Get user's notifications
    const notificationsKey = `notifications:${user.id}`;
    const notifications = await kv.get(notificationsKey) || [];
    
    // Remove notification
    const updatedNotifications = notifications.filter(notif => notif.id !== notificationId);
    
    await kv.set(notificationsKey, updatedNotifications);
    
    console.log('✅ Notification deleted:', notificationId);
    
    return c.json({
      success: true,
      message: 'Notification deleted'
    });
    
  } catch (error) {
    console.error('💥 Delete notification error:', error);
    return c.json({ error: 'Failed to delete notification' }, 500);
  }
});

export default app;