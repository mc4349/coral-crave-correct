import { Hono } from 'npm:hono'
import { SupabaseClient } from 'npm:@supabase/supabase-js@2'
import * as kv from './kv_store.tsx'

export function createAuctionPaymentRoutes(app: Hono, supabase: SupabaseClient) {
  
  // Process auction payment after buyer wins
  app.post('/make-server-9f7745d8/process-auction-payment', async (c) => {
    try {
      const { auctionItemId, buyerId, paymentId, winningBid, sellerId } = await c.req.json()

      if (!auctionItemId || !buyerId || !paymentId || !winningBid || !sellerId) {
        return c.json({ error: 'Missing required payment information' }, 400)
      }

      // Calculate fees
      const coralCraveCommission = winningBid * 0.08 // 8%
      const paymentProcessingFee = (winningBid * 0.029) + 0.30 // 2.9% + $0.30
      const sellerNetPayout = winningBid - coralCraveCommission - paymentProcessingFee

      // Get buyer and seller information
      const [buyerData, sellerData] = await Promise.all([
        supabase.auth.admin.getUserById(buyerId),
        supabase.auth.admin.getUserById(sellerId)
      ])

      if (!buyerData.data.user || !sellerData.data.user) {
        return c.json({ error: 'Invalid buyer or seller ID' }, 400)
      }

      // Get auction item details
      const auctionItemKey = `auction_item:${auctionItemId}`
      const auctionItem = await kv.get(auctionItemKey)

      if (!auctionItem) {
        return c.json({ error: 'Auction item not found' }, 404)
      }

      // Generate invoice
      const invoiceNumber = `INV-${new Date().getFullYear()}-${String(Date.now()).slice(-6)}`
      const invoice = {
        id: `invoice_${Date.now()}`,
        invoiceNumber,
        dateIssued: new Date().toISOString(),
        paymentStatus: 'paid',
        shippingStatus: 'pending',
        item: {
          id: auctionItemId,
          title: auctionItem.title,
          image: auctionItem.image,
          winningBid,
          quantity: 1
        },
        buyer: {
          id: buyerId,
          name: buyerData.data.user.user_metadata?.name || buyerData.data.user.email,
          email: buyerData.data.user.email,
          shippingAddress: {
            street: '123 Main St', // This would come from user profile
            city: 'Anytown',
            state: 'ST',
            zipCode: '12345',
            country: 'USA'
          }
        },
        seller: {
          id: sellerId,
          name: sellerData.data.user.user_metadata?.name || sellerData.data.user.email,
          email: sellerData.data.user.email,
          paypalAccount: '1234' // Last 4 digits - would come from seller setup
        },
        fees: {
          coralCraveCommission,
          paymentProcessingFee,
          sellerNetPayout
        },
        shippingCharges: 0, // To be calculated later
        paymentId
      }

      // Store invoice
      await kv.set(`invoice:${invoice.id}`, invoice)
      
      // Add to buyer's invoices
      const buyerInvoicesKey = `buyer_invoices:${buyerId}`
      const buyerInvoices = await kv.get(buyerInvoicesKey) || []
      buyerInvoices.push(invoice.id)
      await kv.set(buyerInvoicesKey, buyerInvoices)

      // Add to seller's invoices
      const sellerInvoicesKey = `seller_invoices:${sellerId}`
      const sellerInvoices = await kv.get(sellerInvoicesKey) || []
      sellerInvoices.push(invoice.id)
      await kv.set(sellerInvoicesKey, sellerInvoices)

      // Add item to cart for shipping
      const cartItem = {
        id: `cart_${Date.now()}`,
        auctionItemId,
        title: auctionItem.title,
        image: auctionItem.image,
        winningBid,
        sellerId,
        sellerName: sellerData.data.user.user_metadata?.name || sellerData.data.user.email,
        weight: auctionItem.weight || 1, // Default weight
        dimensions: auctionItem.dimensions || { length: 6, width: 6, height: 3 },
        itemPaidStatus: 'paid',
        shippingStatus: 'pending',
        canCombineShipping: auctionItem.canCombineShipping || true
      }

      const cartKey = `cart:${buyerId}`
      const cart = await kv.get(cartKey) || []
      cart.push(cartItem)
      await kv.set(cartKey, cart)

      // Update seller stats
      const sellerStatsKey = `seller_stats:${sellerId}`
      const sellerStats = await kv.get(sellerStatsKey) || {
        totalEarings: 0,
        pendingPayouts: 0,
        totalSales: 0,
        averageItemValue: 0,
        monthlyEarnings: 0
      }

      sellerStats.totalEarings += sellerNetPayout
      sellerStats.pendingPayouts += sellerNetPayout
      sellerStats.totalSales += 1

      const allSales = await kv.get(`seller_sales:${sellerId}`) || []
      const totalValue = allSales.reduce((sum: number, sale: any) => sum + sale.winningBid, 0) + winningBid
      sellerStats.averageItemValue = totalValue / (allSales.length + 1)

      await kv.set(sellerStatsKey, sellerStats)

      // Add to seller's sales history
      const sale = {
        id: `sale_${Date.now()}`,
        itemTitle: auctionItem.title,
        winningBid,
        buyerName: buyerData.data.user.user_metadata?.name || buyerData.data.user.email,
        dateCompleted: new Date().toISOString(),
        commissionFee: coralCraveCommission,
        processingFee: paymentProcessingFee,
        netPayout: sellerNetPayout,
        status: 'completed'
      }

      allSales.push(sale)
      await kv.set(`seller_sales:${sellerId}`, allSales)

      console.log(`✅ Auction payment processed: $${winningBid} -> Seller gets $${sellerNetPayout}`)

      return c.json({
        success: true,
        invoice,
        fees: {
          coralCraveCommission,
          paymentProcessingFee,
          sellerNetPayout
        }
      })

    } catch (error) {
      console.error('Payment processing error:', error)
      return c.json({ error: 'Failed to process auction payment' }, 500)
    }
  })

  // Get invoices for a user
  app.get('/make-server-9f7745d8/invoices', async (c) => {
    try {
      const userId = c.req.query('userId')
      const userType = c.req.query('userType') // 'buyer' | 'seller'

      if (!userId || !userType) {
        return c.json({ error: 'User ID and user type are required' }, 400)
      }

      const invoicesKey = `${userType}_invoices:${userId}`
      const invoiceIds = await kv.get(invoicesKey) || []

      const invoices = await Promise.all(
        invoiceIds.map(async (id: string) => {
          const invoice = await kv.get(`invoice:${id}`)
          return invoice
        })
      )

      return c.json({ 
        invoices: invoices.filter(Boolean).sort((a, b) => 
          new Date(b.dateIssued).getTime() - new Date(a.dateIssued).getTime()
        )
      })

    } catch (error) {
      console.error('Failed to fetch invoices:', error)
      return c.json({ error: 'Failed to fetch invoices' }, 500)
    }
  })

  // Update tracking number
  app.post('/make-server-9f7745d8/update-tracking', async (c) => {
    try {
      const { invoiceId, trackingNumber } = await c.req.json()

      if (!invoiceId || !trackingNumber) {
        return c.json({ error: 'Invoice ID and tracking number are required' }, 400)
      }

      const invoice = await kv.get(`invoice:${invoiceId}`)
      if (!invoice) {
        return c.json({ error: 'Invoice not found' }, 404)
      }

      invoice.trackingNumber = trackingNumber
      invoice.shippingStatus = 'shipped'
      
      await kv.set(`invoice:${invoiceId}`, invoice)

      return c.json({ success: true })

    } catch (error) {
      console.error('Failed to update tracking:', error)
      return c.json({ error: 'Failed to update tracking number' }, 500)
    }
  })

  // Get cart items for shipping
  app.get('/make-server-9f7745d8/cart-items', async (c) => {
    try {
      const userId = c.req.query('userId')

      if (!userId) {
        return c.json({ error: 'User ID is required' }, 400)
      }

      const cartKey = `cart:${userId}`
      const cartItems = await kv.get(cartKey) || []

      return c.json({ items: cartItems })

    } catch (error) {
      console.error('Failed to fetch cart items:', error)
      return c.json({ error: 'Failed to fetch cart items' }, 500)
    }
  })

  // Calculate shipping costs
  app.post('/make-server-9f7745d8/calculate-shipping', async (c) => {
    try {
      const { shippingGroups, buyerId } = await c.req.json()

      if (!shippingGroups || !Array.isArray(shippingGroups)) {
        return c.json({ error: 'Invalid shipping groups' }, 400)
      }

      const shippingCosts = shippingGroups.map((group: any) => {
        const baseRate = 8.99
        const perPoundRate = 1.50
        const combinedDiscount = 0.8

        let cost = baseRate + (group.totalWeight * perPoundRate)
        if (group.combinedShipping && group.items.length > 1) {
          cost *= combinedDiscount
        }

        return Math.max(cost, 5.99) // Minimum shipping cost
      })

      return c.json({ shippingCosts })

    } catch (error) {
      console.error('Failed to calculate shipping:', error)
      return c.json({ error: 'Failed to calculate shipping costs' }, 500)
    }
  })

  // Process shipping payment
  app.post('/make-server-9f7745d8/process-shipping-payment', async (c) => {
    try {
      const { userId, paymentId, shippingGroups, totalAmount } = await c.req.json()

      if (!userId || !paymentId || !shippingGroups || !totalAmount) {
        return c.json({ error: 'Missing required shipping payment information' }, 400)
      }

      // Update cart items with shipping payment status
      const cartKey = `cart:${userId}`
      const cartItems = await kv.get(cartKey) || []

      const updatedItems = cartItems.map((item: any) => ({
        ...item,
        shippingStatus: 'paid'
      }))

      await kv.set(cartKey, updatedItems)

      // Update invoices with shipping charges
      for (const group of shippingGroups) {
        for (const item of group.items) {
          const invoiceIds = await kv.get(`buyer_invoices:${userId}`) || []
          
          for (const invoiceId of invoiceIds) {
            const invoice = await kv.get(`invoice:${invoiceId}`)
            if (invoice && invoice.item.id === item.auctionItemId) {
              invoice.shippingCharges = group.shippingCost / group.items.length
              await kv.set(`invoice:${invoiceId}`, invoice)
              break
            }
          }
        }
      }

      console.log(`✅ Shipping payment processed: $${totalAmount} for ${shippingGroups.length} shipping groups`)

      return c.json({ success: true, paymentId })

    } catch (error) {
      console.error('Shipping payment processing error:', error)
      return c.json({ error: 'Failed to process shipping payment' }, 500)
    }
  })
  
  // Get seller stats
  app.get('/make-server-9f7745d8/seller-stats', async (c) => {
    try {
      const userId = c.req.query('userId')

      if (!userId) {
        return c.json({ error: 'User ID is required' }, 400)
      }

      const sellerStatsKey = `seller_stats:${userId}`
      const stats = await kv.get(sellerStatsKey) || {
        totalEarings: 0,
        pendingPayouts: 0,
        totalSales: 0,
        averageItemValue: 0,
        monthlyEarnings: 0,
        payoutStatus: 'not_connected'
      }

      return c.json(stats)

    } catch (error) {
      console.error('Failed to fetch seller stats:', error)
      return c.json({ error: 'Failed to fetch seller stats' }, 500)
    }
  })

  // Get seller sales
  app.get('/make-server-9f7745d8/seller-sales', async (c) => {
    try {
      const userId = c.req.query('userId')

      if (!userId) {
        return c.json({ error: 'User ID is required' }, 400)
      }

      const salesKey = `seller_sales:${userId}`
      const sales = await kv.get(salesKey) || []

      return c.json({ 
        sales: sales.sort((a: any, b: any) => 
          new Date(b.dateCompleted).getTime() - new Date(a.dateCompleted).getTime()
        )
      })

    } catch (error) {
      console.error('Failed to fetch seller sales:', error)
      return c.json({ error: 'Failed to fetch seller sales' }, 500)
    }
  })

  // Connect PayPal seller account
  app.post('/make-server-9f7745d8/connect-paypal-seller', async (c) => {
    try {
      const { userId } = await c.req.json()

      if (!userId) {
        return c.json({ error: 'User ID is required' }, 400)
      }

      // In production, this would integrate with PayPal's Partner API
      // For now, we'll simulate the connection
      const onboardingUrl = `https://www.paypal.com/connect-seller?user=${userId}&return_url=${encodeURIComponent('https://coralcrave.com/seller/paypal-connected')}`

      return c.json({ onboardingUrl })

    } catch (error) {
      console.error('Failed to connect PayPal seller:', error)
      return c.json({ error: 'Failed to connect PayPal seller account' }, 500)
    }
  })

  // Download invoice (placeholder - would generate PDF in production)
  app.get('/make-server-9f7745d8/download-invoice/:invoiceId', async (c) => {
    try {
      const invoiceId = c.req.param('invoiceId')
      const invoice = await kv.get(`invoice:${invoiceId}`)

      if (!invoice) {
        return c.json({ error: 'Invoice not found' }, 404)
      }

      // In production, this would generate a PDF
      // For now, return JSON data
      return c.json(invoice)

    } catch (error) {
      console.error('Failed to download invoice:', error)
      return c.json({ error: 'Failed to download invoice' }, 500)
    }
  })

  // Create test data for payment flow testing
  app.post('/make-server-9f7745d8/create-test-data', async (c) => {
    try {
      const { userId } = await c.req.json()

      if (!userId) {
        return c.json({ error: 'User ID is required' }, 400)
      }

      const userData = await supabase.auth.admin.getUserById(userId)
      if (!userData.data.user) {
        return c.json({ error: 'User not found' }, 404)
      }

      const user = userData.data.user

      // Create test auction items
      const testItems = [
        {
          id: `test_item_${Date.now()}_1`,
          title: 'Rainbow Acropora Fragment',
          image: 'https://images.unsplash.com/photo-1583212292454-1fe6229603b7?w=300',
          winningBid: 67.50,
          weight: 0.5,
          dimensions: { length: 3, width: 3, height: 2 },
          canCombineShipping: true
        },
        {
          id: `test_item_${Date.now()}_2`,
          title: 'Orange Torch Coral',
          image: 'https://images.unsplash.com/photo-1544551763-46a013bb70d5?w=300',
          winningBid: 45.00,
          weight: 0.8,
          dimensions: { length: 4, width: 4, height: 3 },
          canCombineShipping: true
        }
      ]

      // Store auction items
      for (const item of testItems) {
        await kv.set(`auction_item:${item.id}`, item)
      }

      // Create cart items
      const cartItems = testItems.map(item => ({
        id: `cart_${Date.now()}_${item.id}`,
        auctionItemId: item.id,
        title: item.title,
        image: item.image,
        winningBid: item.winningBid,
        sellerId: 'test_seller_123',
        sellerName: 'Deep Blue Aquatics',
        weight: item.weight,
        dimensions: item.dimensions,
        itemPaidStatus: 'paid',
        shippingStatus: 'pending',
        canCombineShipping: item.canCombineShipping
      }))

      await kv.set(`cart:${userId}`, cartItems)

      // Create test invoices
      const invoices = testItems.map((item, index) => {
        const coralCraveCommission = item.winningBid * 0.08
        const paymentProcessingFee = (item.winningBid * 0.029) + 0.30
        const sellerNetPayout = item.winningBid - coralCraveCommission - paymentProcessingFee

        return {
          id: `test_invoice_${Date.now()}_${index}`,
          invoiceNumber: `INV-2024-${String(Date.now() + index).slice(-6)}`,
          dateIssued: new Date(Date.now() - (index * 86400000)).toISOString(), // Spread over days
          paymentStatus: 'paid',
          shippingStatus: index === 0 ? 'pending' : 'shipped',
          trackingNumber: index === 1 ? '1Z999AA1234567890' : undefined,
          item: {
            id: item.id,
            title: item.title,
            image: item.image,
            winningBid: item.winningBid,
            quantity: 1
          },
          buyer: {
            id: userId,
            name: user.user_metadata?.name || user.email || 'Test User',
            email: user.email,
            shippingAddress: {
              street: '123 Reef Street',
              city: 'Coral City',
              state: 'FL',
              zipCode: '33101',
              country: 'USA'
            }
          },
          seller: {
            id: 'test_seller_123',
            name: 'Deep Blue Aquatics',
            email: 'seller@deepblue.com',
            paypalAccount: '1234' // Last 4 digits
          },
          fees: {
            coralCraveCommission,
            paymentProcessingFee,
            sellerNetPayout
          },
          shippingCharges: 0,
          paymentId: `test_payment_${Date.now()}_${index}`
        }
      })

      // Store invoices
      const invoiceIds = []
      for (const invoice of invoices) {
        await kv.set(`invoice:${invoice.id}`, invoice)
        invoiceIds.push(invoice.id)
      }

      // Add to buyer's invoices
      await kv.set(`buyer_invoices:${userId}`, invoiceIds)

      // Create seller stats
      const totalEarnings = invoices.reduce((sum, inv) => sum + inv.fees.sellerNetPayout, 0)
      const sellerStats = {
        totalEarings: totalEarnings,
        pendingPayouts: totalEarnings,
        totalSales: invoices.length,
        averageItemValue: testItems.reduce((sum, item) => sum + item.winningBid, 0) / testItems.length,
        monthlyEarnings: totalEarnings,
        payoutStatus: 'connected',
        paypalAccount: '1234'
      }

      await kv.set(`seller_stats:${userId}`, sellerStats)

      // Create seller sales
      const sales = testItems.map((item, index) => ({
        id: `test_sale_${Date.now()}_${index}`,
        itemTitle: item.title,
        winningBid: item.winningBid,
        buyerName: user.user_metadata?.name || user.email || 'Test User',
        dateCompleted: new Date(Date.now() - (index * 86400000)).toISOString(),
        commissionFee: item.winningBid * 0.08,
        processingFee: (item.winningBid * 0.029) + 0.30,
        netPayout: item.winningBid - (item.winningBid * 0.08) - ((item.winningBid * 0.029) + 0.30),
        status: 'completed',
        trackingNumber: index === 1 ? '1Z999AA1234567890' : undefined
      }))

      await kv.set(`seller_sales:${userId}`, sales)
      await kv.set(`seller_invoices:${userId}`, invoiceIds)

      console.log(`✅ Created test data for user ${userId}`)

      return c.json({ 
        success: true, 
        message: 'Test payment data created successfully',
        data: {
          cartItems: cartItems.length,
          invoices: invoices.length,
          totalValue: testItems.reduce((sum, item) => sum + item.winningBid, 0)
        }
      })

    } catch (error) {
      console.error('Failed to create test data:', error)
      return c.json({ error: 'Failed to create test data' }, 500)
    }
  })
}