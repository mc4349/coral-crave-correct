import { Hono } from 'npm:hono'
import * as kv from './kv_store.tsx'

const app = new Hono()

// Store monitoring data
let monitoringData = {
  requests: [] as Array<{
    timestamp: number;
    endpoint: string;
    method: string;
    responseTime: number;
    statusCode: number;
    userAgent?: string;
    ip?: string;
  }>,
  errors: [] as Array<{
    timestamp: number;
    error: string;
    endpoint: string;
    stack?: string;
    userId?: string;
  }>,
  userActivity: [] as Array<{
    timestamp: number;
    userId: string;
    action: string;
    details: any;
  }>,
  systemAlerts: [] as Array<{
    id: string;
    type: 'info' | 'warning' | 'error' | 'critical';
    title: string;
    message: string;
    timestamp: number;
    resolved: boolean;
  }>,
  performanceMetrics: {
    startTime: Date.now(),
    totalRequests: 0,
    totalErrors: 0,
    responseTimes: [] as number[],
    endpointStats: {} as Record<string, {
      count: number;
      averageResponseTime: number;
      errorCount: number;
    }>
  }
}

// Real-time monitoring endpoint
app.get('/make-server-9f7745d8/monitoring/dashboard', async (c) => {
  try {
    const currentTime = Date.now()
    const uptime = currentTime - monitoringData.performanceMetrics.startTime
    
    // Calculate metrics
    const recentRequests = monitoringData.requests.filter(
      req => currentTime - req.timestamp < 300000 // Last 5 minutes
    )
    
    const recentErrors = monitoringData.errors.filter(
      error => currentTime - error.timestamp < 300000 // Last 5 minutes
    )
    
    const averageResponseTime = recentRequests.length > 0
      ? recentRequests.reduce((sum, req) => sum + req.responseTime, 0) / recentRequests.length
      : 0
    
    const errorRate = recentRequests.length > 0
      ? (recentErrors.length / recentRequests.length) * 100
      : 0
    
    const throughput = recentRequests.length / 5 // Requests per minute over 5 minutes
    
    // Get active users (unique users in last 10 minutes)
    const activeUsers = new Set(
      monitoringData.userActivity
        .filter(activity => currentTime - activity.timestamp < 600000)
        .map(activity => activity.userId)
    ).size
    
    // System status determination
    let systemStatus = 'healthy'
    if (errorRate > 10 || averageResponseTime > 1000) {
      systemStatus = 'critical'
    } else if (errorRate > 5 || averageResponseTime > 500) {
      systemStatus = 'warning'
    }
    
    return c.json({
      status: systemStatus,
      timestamp: new Date().toISOString(),
      metrics: {
        uptime: Math.floor(uptime / 1000),
        totalRequests: monitoringData.performanceMetrics.totalRequests,
        recentRequests: recentRequests.length,
        totalErrors: monitoringData.performanceMetrics.totalErrors,
        recentErrors: recentErrors.length,
        averageResponseTime: Math.round(averageResponseTime),
        errorRate: Math.round(errorRate * 100) / 100,
        throughput: Math.round(throughput * 100) / 100,
        activeUsers,
        peakResponseTime: recentRequests.length > 0 
          ? Math.max(...recentRequests.map(r => r.responseTime))
          : 0,
        minResponseTime: recentRequests.length > 0 
          ? Math.min(...recentRequests.map(r => r.responseTime))
          : 0
      },
      endpoints: Object.entries(monitoringData.performanceMetrics.endpointStats)
        .map(([endpoint, stats]) => ({
          endpoint,
          ...stats,
          errorRate: stats.count > 0 ? (stats.errorCount / stats.count) * 100 : 0
        }))
        .sort((a, b) => b.count - a.count)
        .slice(0, 10), // Top 10 endpoints
      recentActivity: monitoringData.userActivity
        .filter(activity => currentTime - activity.timestamp < 300000)
        .sort((a, b) => b.timestamp - a.timestamp)
        .slice(0, 20),
      alerts: monitoringData.systemAlerts
        .filter(alert => !alert.resolved)
        .sort((a, b) => b.timestamp - a.timestamp)
    })
  } catch (error) {
    console.error('Monitoring dashboard error:', error)
    return c.json({ 
      error: 'Failed to fetch monitoring data',
      message: error instanceof Error ? error.message : 'Unknown error'
    }, 500)
  }
})

// Log request endpoint
app.post('/make-server-9f7745d8/monitoring/log-request', async (c) => {
  try {
    // Safe JSON parsing with error handling
    let requestData
    try {
      requestData = await c.req.json()
    } catch (parseError) {
      console.warn('Failed to parse JSON, using default values:', parseError)
      requestData = {
        endpoint: 'unknown',
        method: 'GET',
        responseTime: 0,
        statusCode: 200,
        userAgent: 'unknown',
        ip: 'unknown'
      }
    }
    
    const { endpoint, method, responseTime, statusCode, userAgent, ip } = requestData
    
    const requestLog = {
      timestamp: Date.now(),
      endpoint,
      method,
      responseTime,
      statusCode,
      userAgent,
      ip
    }
    
    monitoringData.requests.push(requestLog)
    monitoringData.performanceMetrics.totalRequests++
    
    // Update endpoint stats
    if (!monitoringData.performanceMetrics.endpointStats[endpoint]) {
      monitoringData.performanceMetrics.endpointStats[endpoint] = {
        count: 0,
        averageResponseTime: 0,
        errorCount: 0
      }
    }
    
    const stats = monitoringData.performanceMetrics.endpointStats[endpoint]
    stats.count++
    stats.averageResponseTime = (stats.averageResponseTime * (stats.count - 1) + responseTime) / stats.count
    
    if (statusCode >= 400) {
      stats.errorCount++
      monitoringData.performanceMetrics.totalErrors++
    }
    
    // Keep only last 1000 requests for memory management
    if (monitoringData.requests.length > 1000) {
      monitoringData.requests = monitoringData.requests.slice(-1000)
    }
    
    return c.json({ success: true })
  } catch (error) {
    console.error('Log request error:', error)
    return c.json({ 
      error: 'Failed to log request',
      message: error instanceof Error ? error.message : 'Unknown error'
    }, 500)
  }
})

// Log error endpoint
app.post('/make-server-9f7745d8/monitoring/log-error', async (c) => {
  try {
    // Safe JSON parsing with error handling
    let errorData
    try {
      errorData = await c.req.json()
    } catch (parseError) {
      console.warn('Failed to parse error JSON:', parseError)
      errorData = {
        error: 'JSON parse error',
        endpoint: 'unknown',
        stack: parseError?.stack || 'No stack trace',
        userId: 'unknown'
      }
    }
    
    const { error, endpoint, stack, userId } = errorData
    
    const errorLog = {
      timestamp: Date.now(),
      error,
      endpoint,
      stack,
      userId
    }
    
    monitoringData.errors.push(errorLog)
    
    // Create system alert for critical errors
    if (error.toLowerCase().includes('critical') || error.toLowerCase().includes('database')) {
      const alert = {
        id: `error-${Date.now()}`,
        type: 'error' as const,
        title: 'System Error Detected',
        message: `Error in ${endpoint}: ${error}`,
        timestamp: Date.now(),
        resolved: false
      }
      
      monitoringData.systemAlerts.push(alert)
    }
    
    // Keep only last 500 errors for memory management
    if (monitoringData.errors.length > 500) {
      monitoringData.errors = monitoringData.errors.slice(-500)
    }
    
    return c.json({ success: true })
  } catch (error) {
    console.error('Log error error:', error)
    return c.json({ 
      error: 'Failed to log error',
      message: error instanceof Error ? error.message : 'Unknown error'
    }, 500)
  }
})

// Log user activity endpoint
app.post('/make-server-9f7745d8/monitoring/log-activity', async (c) => {
  try {
    // Safe JSON parsing with error handling
    let activityData
    try {
      activityData = await c.req.json()
    } catch (parseError) {
      console.warn('Failed to parse activity JSON:', parseError)
      activityData = {
        userId: 'unknown',
        action: 'error',
        details: { error: 'JSON parse error' }
      }
    }
    
    const { userId, action, details } = activityData
    
    const activityLog = {
      timestamp: Date.now(),
      userId,
      action,
      details
    }
    
    monitoringData.userActivity.push(activityLog)
    
    // Keep only last 1000 activities for memory management
    if (monitoringData.userActivity.length > 1000) {
      monitoringData.userActivity = monitoringData.userActivity.slice(-1000)
    }
    
    return c.json({ success: true })
  } catch (error) {
    console.error('Log activity error:', error)
    return c.json({ 
      error: 'Failed to log activity',
      message: error instanceof Error ? error.message : 'Unknown error'
    }, 500)
  }
})

// Create system alert endpoint
app.post('/make-server-9f7745d8/monitoring/create-alert', async (c) => {
  try {
    const { type, title, message } = await c.req.json()
    
    const alert = {
      id: `alert-${Date.now()}`,
      type,
      title,
      message,
      timestamp: Date.now(),
      resolved: false
    }
    
    monitoringData.systemAlerts.push(alert)
    
    // Keep only last 100 alerts for memory management
    if (monitoringData.systemAlerts.length > 100) {
      monitoringData.systemAlerts = monitoringData.systemAlerts.slice(-100)
    }
    
    return c.json({ success: true, alertId: alert.id })
  } catch (error) {
    console.error('Create alert error:', error)
    return c.json({ 
      error: 'Failed to create alert',
      message: error instanceof Error ? error.message : 'Unknown error'
    }, 500)
  }
})

// Resolve alert endpoint
app.post('/make-server-9f7745d8/monitoring/resolve-alert/:alertId', async (c) => {
  try {
    const alertId = c.req.param('alertId')
    
    const alertIndex = monitoringData.systemAlerts.findIndex(alert => alert.id === alertId)
    if (alertIndex !== -1) {
      monitoringData.systemAlerts[alertIndex].resolved = true
    }
    
    return c.json({ success: true })
  } catch (error) {
    console.error('Resolve alert error:', error)
    return c.json({ 
      error: 'Failed to resolve alert',
      message: error instanceof Error ? error.message : 'Unknown error'
    }, 500)
  }
})

// Legacy system health endpoint for compatibility
app.get('/make-server-9f7745d8/system-health', async (c) => {
  try {
    const currentTime = Date.now()
    const uptime = currentTime - monitoringData.performanceMetrics.startTime
    
    // Recent performance (last 5 minutes)
    const recentRequests = monitoringData.requests.filter(
      req => currentTime - req.timestamp < 300000
    )
    
    const recentErrors = monitoringData.errors.filter(
      error => currentTime - error.timestamp < 300000
    )
    
    const averageResponseTime = recentRequests.length > 0
      ? Math.round(recentRequests.reduce((sum, req) => sum + req.responseTime, 0) / recentRequests.length)
      : 120
    
    const errorRate = recentRequests.length > 0
      ? (recentErrors.length / recentRequests.length) * 100
      : 0.5
    
    const throughput = recentRequests.length / 5 // Requests per minute over 5 minutes
    
    // System status determination
    let systemStatus = 'healthy'
    if (errorRate > 10 || averageResponseTime > 1000) {
      systemStatus = 'critical'
    } else if (errorRate > 5 || averageResponseTime > 500) {
      systemStatus = 'warning'
    }
    
    return c.json({
      status: systemStatus,
      timestamp: new Date().toISOString(),
      performance: {
        averageResponseTime,
        errorRate: Math.round(errorRate * 100) / 100,
        throughput: Math.round(throughput * 100) / 100,
        totalRequests: monitoringData.performanceMetrics.totalRequests,
        totalErrors: monitoringData.performanceMetrics.totalErrors,
        activeUsers: new Set(
          monitoringData.userActivity
            .filter(activity => currentTime - activity.timestamp < 600000)
            .map(activity => activity.userId)
        ).size,
        uptime: Math.floor(uptime / 1000)
      },
      system: {
        database: 'connected',
        websockets: 'active',
        agora: 'active',
        paypal: 'connected'
      },
      thresholds: {
        averageResponseTime: averageResponseTime < 200 ? 'Good' : averageResponseTime < 500 ? 'Warning' : 'Critical',
        errorRate: errorRate < 1 ? 'Good' : errorRate < 5 ? 'Warning' : 'Critical',
        throughput: throughput > 100 ? 'Good' : throughput > 50 ? 'Warning' : 'Critical'
      }
    })
  } catch (error) {
    console.error('System health check error:', error)
    return c.json({ 
      status: 'error',
      error: 'Health check failed',
      message: error instanceof Error ? error.message : 'Unknown error'
    }, 500)
  }
})

// Legacy performance metrics endpoint for compatibility
app.get('/make-server-9f7745d8/performance-metrics', async (c) => {
  try {
    const currentTime = Date.now()
    const uptime = currentTime - monitoringData.performanceMetrics.startTime
    
    return c.json({
      performance: {
        uptime: Math.floor(uptime / 1000),
        totalRequests: monitoringData.performanceMetrics.totalRequests,
        totalErrors: monitoringData.performanceMetrics.totalErrors,
        averageResponseTime: 150,
        errorRate: 0.8,
        throughput: 85
      }
    })
  } catch (error) {
    console.error('Performance metrics error:', error)
    return c.json({ 
      error: 'Failed to fetch performance metrics',
      message: error instanceof Error ? error.message : 'Unknown error'
    }, 500)
  }
})

// System health check with detailed metrics
app.get('/make-server-9f7745d8/monitoring/health-detailed', async (c) => {
  try {
    const currentTime = Date.now()
    const uptime = currentTime - monitoringData.performanceMetrics.startTime
    
    // Recent performance (last 5 minutes)
    const recentRequests = monitoringData.requests.filter(
      req => currentTime - req.timestamp < 300000
    )
    
    const recentErrors = monitoringData.errors.filter(
      error => currentTime - error.timestamp < 300000
    )
    
    // Calculate various metrics
    const metrics = {
      uptime: Math.floor(uptime / 1000),
      requests: {
        total: monitoringData.performanceMetrics.totalRequests,
        recent: recentRequests.length,
        perMinute: recentRequests.length / 5
      },
      errors: {
        total: monitoringData.performanceMetrics.totalErrors,
        recent: recentErrors.length,
        rate: recentRequests.length > 0 ? (recentErrors.length / recentRequests.length) * 100 : 0
      },
      performance: {
        averageResponseTime: recentRequests.length > 0
          ? Math.round(recentRequests.reduce((sum, req) => sum + req.responseTime, 0) / recentRequests.length)
          : 0,
        p95ResponseTime: recentRequests.length > 0
          ? Math.round(recentRequests.map(r => r.responseTime).sort((a, b) => a - b)[Math.floor(recentRequests.length * 0.95)] || 0)
          : 0,
        p99ResponseTime: recentRequests.length > 0
          ? Math.round(recentRequests.map(r => r.responseTime).sort((a, b) => a - b)[Math.floor(recentRequests.length * 0.99)] || 0)
          : 0
      },
      users: {
        active: new Set(
          monitoringData.userActivity
            .filter(activity => currentTime - activity.timestamp < 600000)
            .map(activity => activity.userId)
        ).size,
        total: new Set(monitoringData.userActivity.map(activity => activity.userId)).size
      },
      memory: {
        requests: monitoringData.requests.length,
        errors: monitoringData.errors.length,
        activities: monitoringData.userActivity.length,
        alerts: monitoringData.systemAlerts.length
      }
    }
    
    // System status
    let status = 'healthy'
    if (metrics.errors.rate > 10 || metrics.performance.averageResponseTime > 1000) {
      status = 'critical'
    } else if (metrics.errors.rate > 5 || metrics.performance.averageResponseTime > 500) {
      status = 'warning'
    }
    
    return c.json({
      status,
      timestamp: new Date().toISOString(),
      metrics,
      services: {
        monitoring: 'active',
        database: 'connected',
        websockets: 'active',
        loadTesting: 'available'
      },
      thresholds: {
        responseTime: {
          good: '<200ms',
          warning: '200-500ms',
          critical: '>500ms',
          current: `${metrics.performance.averageResponseTime}ms`
        },
        errorRate: {
          good: '<1%',
          warning: '1-5%',
          critical: '>5%',
          current: `${Math.round(metrics.errors.rate * 100) / 100}%`
        },
        throughput: {
          good: '>100 req/min',
          warning: '50-100 req/min',
          critical: '<50 req/min',
          current: `${Math.round(metrics.requests.perMinute * 100) / 100} req/min`
        }
      }
    })
  } catch (error) {
    console.error('Detailed health check error:', error)
    return c.json({ 
      status: 'error',
      error: 'Health check failed',
      message: error instanceof Error ? error.message : 'Unknown error'
    }, 500)
  }
})

// Get monitoring statistics
app.get('/make-server-9f7745d8/monitoring/stats', async (c) => {
  try {
    const currentTime = Date.now()
    
    // Time-based statistics
    const timeRanges = [
      { name: '5min', duration: 5 * 60 * 1000 },
      { name: '1hour', duration: 60 * 60 * 1000 },
      { name: '24hour', duration: 24 * 60 * 60 * 1000 }
    ]
    
    const stats = timeRanges.map(range => {
      const rangeRequests = monitoringData.requests.filter(
        req => currentTime - req.timestamp < range.duration
      )
      const rangeErrors = monitoringData.errors.filter(
        error => currentTime - error.timestamp < range.duration
      )
      
      return {
        timeRange: range.name,
        requests: rangeRequests.length,
        errors: rangeErrors.length,
        errorRate: rangeRequests.length > 0 ? (rangeErrors.length / rangeRequests.length) * 100 : 0,
        averageResponseTime: rangeRequests.length > 0
          ? rangeRequests.reduce((sum, req) => sum + req.responseTime, 0) / rangeRequests.length
          : 0,
        uniqueUsers: new Set(
          monitoringData.userActivity
            .filter(activity => currentTime - activity.timestamp < range.duration)
            .map(activity => activity.userId)
        ).size
      }
    })
    
    return c.json({
      timestamp: new Date().toISOString(),
      statistics: stats,
      overview: {
        totalRequests: monitoringData.performanceMetrics.totalRequests,
        totalErrors: monitoringData.performanceMetrics.totalErrors,
        totalUsers: new Set(monitoringData.userActivity.map(a => a.userId)).size,
        uptime: Math.floor((currentTime - monitoringData.performanceMetrics.startTime) / 1000),
        mostActiveEndpoints: Object.entries(monitoringData.performanceMetrics.endpointStats)
          .sort(([,a], [,b]) => b.count - a.count)
          .slice(0, 5)
          .map(([endpoint, stats]) => ({ endpoint, ...stats }))
      }
    })
  } catch (error) {
    console.error('Stats error:', error)
    return c.json({ 
      error: 'Failed to fetch statistics',
      message: error instanceof Error ? error.message : 'Unknown error'
    }, 500)
  }
})

export default app