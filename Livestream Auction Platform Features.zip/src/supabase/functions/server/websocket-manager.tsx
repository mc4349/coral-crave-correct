import { Hono } from 'npm:hono';
import { cors } from 'npm:hono/cors';
import { upgradeWebSocket } from 'npm:hono/deno';

const app = new Hono();

app.use('*', cors({
  origin: '*',
  allowMethods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowHeaders: ['Content-Type', 'Authorization'],
}));

// WebSocket connection manager
class WebSocketManager {
  private connections = new Map<string, WebSocket>();
  private streamConnections = new Map<string, Set<string>>();
  private userConnections = new Map<string, string>();

  addConnection(connectionId: string, ws: WebSocket, userId?: string) {
    this.connections.set(connectionId, ws);
    if (userId) {
      this.userConnections.set(userId, connectionId);
    }
    console.log(`📡 WebSocket connected: ${connectionId} (User: ${userId})`);
  }

  removeConnection(connectionId: string) {
    this.connections.delete(connectionId);
    
    // Remove from user mapping
    for (const [userId, connId] of this.userConnections.entries()) {
      if (connId === connectionId) {
        this.userConnections.delete(userId);
        break;
      }
    }

    // Remove from stream connections
    for (const [streamId, connections] of this.streamConnections.entries()) {
      connections.delete(connectionId);
      if (connections.size === 0) {
        this.streamConnections.delete(streamId);
      }
    }

    console.log(`📡 WebSocket disconnected: ${connectionId}`);
  }

  joinStream(connectionId: string, streamId: string) {
    if (!this.streamConnections.has(streamId)) {
      this.streamConnections.set(streamId, new Set());
    }
    this.streamConnections.get(streamId)!.add(connectionId);
    console.log(`👥 User joined stream: ${streamId}`);
  }

  leaveStream(connectionId: string, streamId: string) {
    const connections = this.streamConnections.get(streamId);
    if (connections) {
      connections.delete(connectionId);
      if (connections.size === 0) {
        this.streamConnections.delete(streamId);
      }
    }
    console.log(`👋 User left stream: ${streamId}`);
  }

  broadcastToStream(streamId: string, message: any) {
    const connections = this.streamConnections.get(streamId);
    if (!connections) return;

    const messageStr = JSON.stringify(message);
    let sent = 0;

    for (const connectionId of connections) {
      const ws = this.connections.get(connectionId);
      if (ws && ws.readyState === WebSocket.OPEN) {
        try {
          ws.send(messageStr);
          sent++;
        } catch (error) {
          console.error(`Failed to send to ${connectionId}:`, error);
          this.removeConnection(connectionId);
        }
      }
    }

    console.log(`📢 Broadcast to stream ${streamId}: ${sent} recipients`);
    return sent;
  }

  sendToUser(userId: string, message: any) {
    const connectionId = this.userConnections.get(userId);
    if (!connectionId) return false;

    const ws = this.connections.get(connectionId);
    if (ws && ws.readyState === WebSocket.OPEN) {
      try {
        ws.send(JSON.stringify(message));
        return true;
      } catch (error) {
        console.error(`Failed to send to user ${userId}:`, error);
        this.removeConnection(connectionId);
      }
    }
    return false;
  }

  getStreamViewerCount(streamId: string): number {
    return this.streamConnections.get(streamId)?.size || 0;
  }

  getAllStreamStats() {
    const stats = new Map();
    for (const [streamId, connections] of this.streamConnections.entries()) {
      stats.set(streamId, connections.size);
    }
    return Object.fromEntries(stats);
  }

  getTotalConnections(): number {
    return this.connections.size;
  }
}

const wsManager = new WebSocketManager();

// WebSocket endpoint for real-time features
app.get('/make-server-9f7745d8/ws', upgradeWebSocket((c) => {
  const url = new URL(c.req.url);
  const userId = url.searchParams.get('userId');
  const streamId = url.searchParams.get('streamId');
  
  return {
    onOpen: (event, ws) => {
      const connectionId = crypto.randomUUID();
      wsManager.addConnection(connectionId, ws, userId || undefined);
      
      if (streamId) {
        wsManager.joinStream(connectionId, streamId);
        
        // Send current viewer count
        wsManager.broadcastToStream(streamId, {
          type: 'viewer_count_update',
          streamId,
          viewerCount: wsManager.getStreamViewerCount(streamId)
        });
      }

      // Send welcome message
      ws.send(JSON.stringify({
        type: 'connection_established',
        connectionId,
        userId,
        streamId
      }));
    },

    onMessage: (event, ws) => {
      try {
        const data = JSON.parse(event.data.toString());
        const { type, streamId: msgStreamId, ...payload } = data;

        switch (type) {
          case 'join_stream':
            if (msgStreamId) {
              wsManager.joinStream(data.connectionId, msgStreamId);
              wsManager.broadcastToStream(msgStreamId, {
                type: 'viewer_count_update',
                streamId: msgStreamId,
                viewerCount: wsManager.getStreamViewerCount(msgStreamId)
              });
            }
            break;

          case 'leave_stream':
            if (msgStreamId) {
              wsManager.leaveStream(data.connectionId, msgStreamId);
              wsManager.broadcastToStream(msgStreamId, {
                type: 'viewer_count_update',
                streamId: msgStreamId,
                viewerCount: wsManager.getStreamViewerCount(msgStreamId)
              });
            }
            break;

          case 'chat_message':
            if (msgStreamId) {
              wsManager.broadcastToStream(msgStreamId, {
                type: 'chat_message',
                streamId: msgStreamId,
                ...payload
              });
            }
            break;

          case 'bid_placed':
            if (msgStreamId) {
              wsManager.broadcastToStream(msgStreamId, {
                type: 'bid_update',
                streamId: msgStreamId,
                ...payload
              });
            }
            break;

          case 'auction_timer_update':
            if (msgStreamId) {
              wsManager.broadcastToStream(msgStreamId, {
                type: 'timer_update',
                streamId: msgStreamId,
                ...payload
              });
            }
            break;

          default:
            console.warn('Unknown message type:', type);
        }
      } catch (error) {
        console.error('WebSocket message error:', error);
      }
    },

    onClose: (event, ws) => {
      // The connection will be automatically removed when disconnected
    },

    onError: (event, ws) => {
      console.error('WebSocket error:', event);
    }
  };
}));

// REST endpoints for WebSocket management
app.post('/make-server-9f7745d8/broadcast/:streamId', async (c) => {
  try {
    const streamId = c.req.param('streamId');
    const message = await c.req.json();

    const sent = wsManager.broadcastToStream(streamId, message);

    return c.json({
      success: true,
      recipients: sent,
      streamId
    });
  } catch (error) {
    return c.json({
      success: false,
      error: error.message
    }, 500);
  }
});

app.get('/make-server-9f7745d8/stream-stats/:streamId', (c) => {
  const streamId = c.req.param('streamId');
  const viewerCount = wsManager.getStreamViewerCount(streamId);

  return c.json({
    streamId,
    viewerCount,
    isActive: viewerCount > 0
  });
});

app.get('/make-server-9f7745d8/websocket-stats', (c) => {
  return c.json({
    totalConnections: wsManager.getTotalConnections(),
    streamStats: wsManager.getAllStreamStats(),
    timestamp: new Date().toISOString()
  });
});

// Send notification to user
app.post('/make-server-9f7745d8/notify-user/:userId', async (c) => {
  try {
    const userId = c.req.param('userId');
    const notification = await c.req.json();

    const sent = wsManager.sendToUser(userId, {
      type: 'notification',
      ...notification
    });

    return c.json({
      success: sent,
      userId
    });
  } catch (error) {
    return c.json({
      success: false,
      error: error.message
    }, 500);
  }
});

export default app;