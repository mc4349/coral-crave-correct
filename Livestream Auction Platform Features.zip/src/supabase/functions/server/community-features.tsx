import { Hono } from 'npm:hono';
import { cors } from 'npm:hono/cors';
import { createClient } from 'npm:@supabase/supabase-js@2';
import * as kv from './kv_store.tsx';

const app = new Hono();

app.use('*', cors({
  origin: '*',
  allowMethods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowHeaders: ['Content-Type', 'Authorization'],
}));

const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
);

// Get forum posts
app.get('/make-server-9f7745d8/forum/posts', async (c) => {
  try {
    const category = c.req.query('category');
    const search = c.req.query('search');
    const sortBy = c.req.query('sortBy') || 'recent';
    const page = parseInt(c.req.query('page') || '1');
    const limit = parseInt(c.req.query('limit') || '20');

    console.log('Getting forum posts:', { category, search, sortBy, page, limit });

    const forumPosts = await kv.getByPrefix('forum_post_');
    let posts = forumPosts.map(post => post.value).filter(post => post && typeof post === 'object');

    // Apply filters
    if (category && category !== 'all') {
      posts = posts.filter(post => post.category === category);
    }

    if (search) {
      const searchTerm = search.toLowerCase();
      posts = posts.filter(post =>
        post.title?.toLowerCase().includes(searchTerm) ||
        post.content?.toLowerCase().includes(searchTerm) ||
        post.tags?.some((tag: string) => tag.toLowerCase().includes(searchTerm))
      );
    }

    // Apply sorting
    switch (sortBy) {
      case 'popular':
        posts.sort((a, b) => (b.likes || 0) - (a.likes || 0));
        break;
      case 'trending':
        posts.sort((a, b) => (b.views || 0) - (a.views || 0));
        break;
      case 'recent':
      default:
        posts.sort((a, b) => new Date(b.timestamp || 0).getTime() - new Date(a.timestamp || 0).getTime());
        break;
    }

    // Paginate
    const startIndex = (page - 1) * limit;
    const paginatedPosts = posts.slice(startIndex, startIndex + limit);

    return c.json({
      posts: paginatedPosts,
      totalCount: posts.length,
      page,
      limit,
      totalPages: Math.ceil(posts.length / limit)
    });

  } catch (error) {
    console.error('Forum posts error:', error);
    return c.json({ error: 'Failed to get forum posts' }, 500);
  }
});

// Create new forum post
app.post('/make-server-9f7745d8/forum/posts', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (!user?.id) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const { title, content, category, tags } = await c.req.json();
    
    console.log('Creating forum post:', { title, category, userId: user.id });

    const postId = `post_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const post = {
      id: postId,
      title,
      content,
      category,
      tags: tags || [],
      author: {
        id: user.id,
        name: user.user_metadata?.name || user.email,
        avatar: user.user_metadata?.avatar_url,
        reputation: 0,
        badge: 'New Member'
      },
      timestamp: new Date().toISOString(),
      replies: 0,
      views: 0,
      likes: 0,
      isPinned: false,
      isAnswered: false
    };

    await kv.set(`forum_post_${postId}`, post);

    return c.json({ success: true, post });

  } catch (error) {
    console.error('Create forum post error:', error);
    return c.json({ error: 'Failed to create post' }, 500);
  }
});

// Get care guides
app.get('/make-server-9f7745d8/care-guides', async (c) => {
  try {
    const category = c.req.query('category');
    const search = c.req.query('search');
    const sortBy = c.req.query('sortBy') || 'recent';
    const difficulty = c.req.query('difficulty');
    const page = parseInt(c.req.query('page') || '1');
    const limit = parseInt(c.req.query('limit') || '20');

    console.log('Getting care guides:', { category, search, sortBy, difficulty, page, limit });

    const careGuides = await kv.getByPrefix('care_guide_');
    let guides = careGuides.map(guide => guide.value).filter(guide => guide && typeof guide === 'object');

    // Apply filters
    if (category && category !== 'all') {
      guides = guides.filter(guide => guide.category === category);
    }

    if (difficulty) {
      guides = guides.filter(guide => guide.difficulty === difficulty);
    }

    if (search) {
      const searchTerm = search.toLowerCase();
      guides = guides.filter(guide =>
        guide.title?.toLowerCase().includes(searchTerm) ||
        guide.description?.toLowerCase().includes(searchTerm) ||
        guide.tags?.some((tag: string) => tag.toLowerCase().includes(searchTerm))
      );
    }

    // Apply sorting
    switch (sortBy) {
      case 'rating':
        guides.sort((a, b) => (b.rating || 0) - (a.rating || 0));
        break;
      case 'popular':
        guides.sort((a, b) => (b.ratingCount || 0) - (a.ratingCount || 0));
        break;
      case 'recent':
      default:
        guides.sort((a, b) => new Date(b.lastUpdated || 0).getTime() - new Date(a.lastUpdated || 0).getTime());
        break;
    }

    // Paginate
    const startIndex = (page - 1) * limit;
    const paginatedGuides = guides.slice(startIndex, startIndex + limit);

    return c.json({
      guides: paginatedGuides,
      totalCount: guides.length,
      page,
      limit,
      totalPages: Math.ceil(guides.length / limit)
    });

  } catch (error) {
    console.error('Care guides error:', error);
    return c.json({ error: 'Failed to get care guides' }, 500);
  }
});

// Create new care guide
app.post('/make-server-9f7745d8/care-guides', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (!user?.id) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const { title, description, content, category, difficulty, tags, coverImage } = await c.req.json();
    
    console.log('Creating care guide:', { title, category, difficulty, userId: user.id });

    const guideId = `guide_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const guide = {
      id: guideId,
      title,
      description,
      content,
      category,
      difficulty,
      tags: tags || [],
      coverImage: coverImage || '',
      author: {
        id: user.id,
        name: user.user_metadata?.name || user.email,
        avatar: user.user_metadata?.avatar_url,
        verified: false
      },
      rating: 0,
      ratingCount: 0,
      readTime: Math.ceil((content?.length || 0) / 200), // Estimate read time
      lastUpdated: new Date().toISOString(),
      createdAt: new Date().toISOString()
    };

    await kv.set(`care_guide_${guideId}`, guide);

    return c.json({ success: true, guide });

  } catch (error) {
    console.error('Create care guide error:', error);
    return c.json({ error: 'Failed to create guide' }, 500);
  }
});

// Get community stats
app.get('/make-server-9f7745d8/community/stats', async (c) => {
  try {
    console.log('Getting community stats');

    // Get counts from KV store
    const forumPosts = await kv.getByPrefix('forum_post_');
    const careGuides = await kv.getByPrefix('care_guide_');
    const users = await kv.getByPrefix('user_profile_');

    const stats = {
      totalMembers: users.length || 12847, // Fallback to mock data
      totalPosts: forumPosts.length || 45692,
      totalGuides: careGuides.length || 234,
      onlineNow: Math.floor(Math.random() * 500) + 200 // Simulate online users
    };

    return c.json(stats);

  } catch (error) {
    console.error('Community stats error:', error);
    return c.json({ error: 'Failed to get community stats' }, 500);
  }
});

// Like/unlike forum post
app.post('/make-server-9f7745d8/forum/posts/:postId/like', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (!user?.id) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const postId = c.req.param('postId');
    const post = await kv.get(`forum_post_${postId}`);
    
    if (!post?.value) {
      return c.json({ error: 'Post not found' }, 404);
    }

    // Check if user already liked this post
    const userLikes = await kv.get(`user_likes_${user.id}`) || { value: [] };
    const hasLiked = userLikes.value.includes(postId);

    if (hasLiked) {
      // Unlike
      userLikes.value = userLikes.value.filter((id: string) => id !== postId);
      post.value.likes = Math.max(0, (post.value.likes || 0) - 1);
    } else {
      // Like
      userLikes.value.push(postId);
      post.value.likes = (post.value.likes || 0) + 1;
    }

    await kv.set(`user_likes_${user.id}`, userLikes.value);
    await kv.set(`forum_post_${postId}`, post.value);

    return c.json({ 
      success: true, 
      liked: !hasLiked, 
      likes: post.value.likes 
    });

  } catch (error) {
    console.error('Like post error:', error);
    return c.json({ error: 'Failed to like post' }, 500);
  }
});

// Rate care guide
app.post('/make-server-9f7745d8/care-guides/:guideId/rate', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (!user?.id) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const guideId = c.req.param('guideId');
    const { rating } = await c.req.json();
    
    if (rating < 1 || rating > 5) {
      return c.json({ error: 'Rating must be between 1 and 5' }, 400);
    }

    const guide = await kv.get(`care_guide_${guideId}`);
    
    if (!guide?.value) {
      return c.json({ error: 'Guide not found' }, 404);
    }

    // Check if user already rated this guide
    const userRatings = await kv.get(`user_ratings_${user.id}`) || { value: {} };
    const previousRating = userRatings.value[guideId];

    if (previousRating) {
      // Update existing rating
      const totalRating = (guide.value.rating || 0) * (guide.value.ratingCount || 0);
      const newTotalRating = totalRating - previousRating + rating;
      guide.value.rating = newTotalRating / guide.value.ratingCount;
    } else {
      // New rating
      const totalRating = (guide.value.rating || 0) * (guide.value.ratingCount || 0);
      const newTotalRating = totalRating + rating;
      guide.value.ratingCount = (guide.value.ratingCount || 0) + 1;
      guide.value.rating = newTotalRating / guide.value.ratingCount;
    }

    userRatings.value[guideId] = rating;

    await kv.set(`user_ratings_${user.id}`, userRatings.value);
    await kv.set(`care_guide_${guideId}`, guide.value);

    return c.json({ 
      success: true, 
      rating: guide.value.rating,
      ratingCount: guide.value.ratingCount 
    });

  } catch (error) {
    console.error('Rate guide error:', error);
    return c.json({ error: 'Failed to rate guide' }, 500);
  }
});

export default app;