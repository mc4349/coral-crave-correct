import { Hono } from 'npm:hono';
import { cors } from 'npm:hono/cors';
import { createClient } from 'npm:@supabase/supabase-js@2';

const app = new Hono();

app.use('*', cors({
  origin: '*',
  allowMethods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowHeaders: ['Content-Type', 'Authorization'],
}));

const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
);

// Initialize production-ready database schema
app.post('/make-server-9f7745d8/init-database', async (c) => {
  try {
    console.log('🚀 Initializing production database schema...');

    // Create tables if they don't exist (using SQL for better performance)
    const tables = [
      // Users table
      `CREATE TABLE IF NOT EXISTS coral_users (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        email VARCHAR(255) UNIQUE NOT NULL,
        name VARCHAR(255) NOT NULL,
        avatar_url TEXT,
        verified BOOLEAN DEFAULT FALSE,
        rating DECIMAL(3,2) DEFAULT 4.0,
        total_sales DECIMAL(10,2) DEFAULT 0,
        total_purchases DECIMAL(10,2) DEFAULT 0,
        follower_count INTEGER DEFAULT 0,
        following_count INTEGER DEFAULT 0,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
      )`,

      // Live streams table
      `CREATE TABLE IF NOT EXISTS live_streams (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        seller_id UUID REFERENCES coral_users(id) ON DELETE CASCADE,
        title VARCHAR(500) NOT NULL,
        description TEXT,
        channel_name VARCHAR(255) UNIQUE NOT NULL,
        thumbnail_url TEXT,
        category VARCHAR(100) NOT NULL,
        is_live BOOLEAN DEFAULT TRUE,
        viewer_count INTEGER DEFAULT 0,
        total_viewers INTEGER DEFAULT 0,
        peak_viewers INTEGER DEFAULT 0,
        started_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        ended_at TIMESTAMP WITH TIME ZONE,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
      )`,

      // Products/Auction items table
      `CREATE TABLE IF NOT EXISTS auction_items (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        stream_id UUID REFERENCES live_streams(id) ON DELETE CASCADE,
        seller_id UUID REFERENCES coral_users(id) ON DELETE CASCADE,
        title VARCHAR(500) NOT NULL,
        description TEXT,
        category VARCHAR(100) NOT NULL,
        starting_bid DECIMAL(10,2) NOT NULL,
        current_bid DECIMAL(10,2) NOT NULL,
        buy_now_price DECIMAL(10,2),
        bid_count INTEGER DEFAULT 0,
        time_left INTEGER DEFAULT 300,
        image_urls TEXT[],
        tags TEXT[],
        status VARCHAR(50) DEFAULT 'active',
        winner_id UUID REFERENCES coral_users(id),
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
      )`,

      // Bids table
      `CREATE TABLE IF NOT EXISTS bids (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        item_id UUID REFERENCES auction_items(id) ON DELETE CASCADE,
        bidder_id UUID REFERENCES coral_users(id) ON DELETE CASCADE,
        amount DECIMAL(10,2) NOT NULL,
        timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        is_winner BOOLEAN DEFAULT FALSE
      )`,

      // Chat messages table
      `CREATE TABLE IF NOT EXISTS chat_messages (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        stream_id UUID REFERENCES live_streams(id) ON DELETE CASCADE,
        user_id UUID REFERENCES coral_users(id) ON DELETE CASCADE,
        message TEXT NOT NULL,
        timestamp TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        message_type VARCHAR(50) DEFAULT 'text'
      )`,

      // Notifications table
      `CREATE TABLE IF NOT EXISTS notifications (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        user_id UUID REFERENCES coral_users(id) ON DELETE CASCADE,
        type VARCHAR(100) NOT NULL,
        title VARCHAR(500) NOT NULL,
        message TEXT NOT NULL,
        read BOOLEAN DEFAULT FALSE,
        action_required BOOLEAN DEFAULT FALSE,
        related_item_id UUID,
        related_item_type VARCHAR(100),
        sender_id UUID REFERENCES coral_users(id),
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
      )`,

      // Follows table
      `CREATE TABLE IF NOT EXISTS follows (
        follower_id UUID REFERENCES coral_users(id) ON DELETE CASCADE,
        following_id UUID REFERENCES coral_users(id) ON DELETE CASCADE,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        PRIMARY KEY (follower_id, following_id)
      )`,

      // Transactions table
      `CREATE TABLE IF NOT EXISTS transactions (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        buyer_id UUID REFERENCES coral_users(id) ON DELETE CASCADE,
        seller_id UUID REFERENCES coral_users(id) ON DELETE CASCADE,
        item_id UUID REFERENCES auction_items(id) ON DELETE CASCADE,
        amount DECIMAL(10,2) NOT NULL,
        platform_fee DECIMAL(10,2) NOT NULL,
        payment_fee DECIMAL(10,2) NOT NULL,
        seller_payout DECIMAL(10,2) NOT NULL,
        payment_method VARCHAR(100) NOT NULL,
        payment_id VARCHAR(255),
        status VARCHAR(50) DEFAULT 'pending',
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        completed_at TIMESTAMP WITH TIME ZONE
      )`
    ];

    // Execute table creation
    for (const tableSQL of tables) {
      const { error } = await supabase.rpc('exec_sql', { sql: tableSQL });
      if (error) {
        console.error('Table creation error:', error);
        // Continue with other tables
      }
    }

    // Create indexes for performance
    const indexes = [
      'CREATE INDEX IF NOT EXISTS idx_live_streams_is_live ON live_streams(is_live)',
      'CREATE INDEX IF NOT EXISTS idx_live_streams_category ON live_streams(category)',
      'CREATE INDEX IF NOT EXISTS idx_live_streams_seller ON live_streams(seller_id)',
      'CREATE INDEX IF NOT EXISTS idx_auction_items_stream ON auction_items(stream_id)',
      'CREATE INDEX IF NOT EXISTS idx_auction_items_status ON auction_items(status)',
      'CREATE INDEX IF NOT EXISTS idx_bids_item ON bids(item_id)',
      'CREATE INDEX IF NOT EXISTS idx_bids_bidder ON bids(bidder_id)',
      'CREATE INDEX IF NOT EXISTS idx_chat_messages_stream ON chat_messages(stream_id)',
      'CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(user_id)',
      'CREATE INDEX IF NOT EXISTS idx_notifications_read ON notifications(read)',
      'CREATE INDEX IF NOT EXISTS idx_follows_follower ON follows(follower_id)',
      'CREATE INDEX IF NOT EXISTS idx_follows_following ON follows(following_id)',
      'CREATE INDEX IF NOT EXISTS idx_transactions_buyer ON transactions(buyer_id)',
      'CREATE INDEX IF NOT EXISTS idx_transactions_seller ON transactions(seller_id)'
    ];

    for (const indexSQL of indexes) {
      const { error } = await supabase.rpc('exec_sql', { sql: indexSQL });
      if (error) {
        console.error('Index creation error:', error);
      }
    }

    console.log('✅ Database schema initialized successfully');

    return c.json({
      success: true,
      message: 'Production database schema initialized',
      timestamp: new Date().toISOString()
    });

  } catch (error) {
    console.error('Database initialization error:', error);
    return c.json({
      success: false,
      error: 'Failed to initialize database',
      details: error.message
    }, 500);
  }
});

// Health check endpoint
app.get('/make-server-9f7745d8/health', async (c) => {
  try {
    // Test database connection
    const { data, error } = await supabase
      .from('coral_users')
      .select('count')
      .limit(1);

    if (error) {
      throw error;
    }

    return c.json({
      status: 'healthy',
      database: 'connected',
      timestamp: new Date().toISOString(),
      uptime: process.uptime ? `${Math.floor(process.uptime())}s` : 'unknown'
    });

  } catch (error) {
    return c.json({
      status: 'unhealthy',
      database: 'disconnected',
      error: error.message,
      timestamp: new Date().toISOString()
    }, 500);
  }
});

// Seed production data
app.post('/make-server-9f7745d8/seed-production-data', async (c) => {
  try {
    console.log('🌱 Seeding production data...');

    // Create demo users
    const demoUsers = [
      {
        id: '550e8400-e29b-41d4-a716-446655440000',
        email: 'demo@coralcrave.com',
        name: 'Demo User',
        verified: true,
        rating: 4.8
      },
      {
        id: '550e8400-e29b-41d4-a716-446655440001',
        email: 'seller1@coralcrave.com',
        name: 'AquaReef Co.',
        verified: true,
        rating: 4.9
      },
      {
        id: '550e8400-e29b-41d4-a716-446655440002',
        email: 'seller2@coralcrave.com',
        name: 'CoralKing_Reef',
        verified: true,
        rating: 4.7
      }
    ];

    // Insert demo users (on conflict do nothing to avoid duplicates)
    for (const user of demoUsers) {
      const { error } = await supabase
        .from('coral_users')
        .upsert(user, { onConflict: 'email' });
      
      if (error) {
        console.warn('User insertion warning:', error);
      }
    }

    console.log('✅ Production data seeded successfully');

    return c.json({
      success: true,
      message: 'Production data seeded',
      users_created: demoUsers.length
    });

  } catch (error) {
    console.error('Data seeding error:', error);
    return c.json({
      success: false,
      error: 'Failed to seed data',
      details: error.message
    }, 500);
  }
});

export default app;