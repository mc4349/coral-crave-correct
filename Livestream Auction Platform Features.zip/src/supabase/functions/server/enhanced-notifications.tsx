import { Hono } from 'npm:hono';
import { cors } from 'npm:hono/cors';
import { createClient } from 'npm:@supabase/supabase-js@2';
import * as kv from './kv_store.tsx';

const app = new Hono();

app.use('*', cors({
  origin: '*',
  allowMethods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowHeaders: ['Content-Type', 'Authorization'],
}));

const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
);

// Get user notifications
app.get('/make-server-9f7745d8/notifications/:userId', async (c) => {
  try {
    const userId = c.req.param('userId');
    const filter = c.req.query('filter') || 'all'; // all, unread, action_required
    const search = c.req.query('search');
    const page = parseInt(c.req.query('page') || '1');
    const limit = parseInt(c.req.query('limit') || '20');

    console.log('Getting notifications for user:', userId, { filter, search, page, limit });

    const userNotifications = await kv.getByPrefix(`notification_${userId}_`);
    let notifications = userNotifications.map(n => n.value).filter(n => n && typeof n === 'object');

    // Apply filters
    if (filter === 'unread') {
      notifications = notifications.filter(n => !n.read);
    } else if (filter === 'action_required') {
      notifications = notifications.filter(n => n.actionRequired);
    }

    // Apply search
    if (search) {
      const searchTerm = search.toLowerCase();
      notifications = notifications.filter(n =>
        n.title?.toLowerCase().includes(searchTerm) ||
        n.message?.toLowerCase().includes(searchTerm)
      );
    }

    // Sort by timestamp (newest first)
    notifications.sort((a, b) => new Date(b.timestamp || 0).getTime() - new Date(a.timestamp || 0).getTime());

    // Paginate
    const startIndex = (page - 1) * limit;
    const paginatedNotifications = notifications.slice(startIndex, startIndex + limit);

    return c.json({
      notifications: paginatedNotifications,
      totalCount: notifications.length,
      unreadCount: notifications.filter(n => !n.read).length,
      actionRequiredCount: notifications.filter(n => n.actionRequired).length,
      page,
      limit,
      totalPages: Math.ceil(notifications.length / limit)
    });

  } catch (error) {
    console.error('Get notifications error:', error);
    return c.json({ error: 'Failed to get notifications' }, 500);
  }
});

// Mark notification as read
app.put('/make-server-9f7745d8/notifications/:userId/:notificationId/read', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (!user?.id) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const userId = c.req.param('userId');
    const notificationId = c.req.param('notificationId');

    if (user.id !== userId) {
      return c.json({ error: 'Forbidden' }, 403);
    }

    const notification = await kv.get(`notification_${userId}_${notificationId}`);
    
    if (!notification?.value) {
      return c.json({ error: 'Notification not found' }, 404);
    }

    notification.value.read = true;
    notification.value.readAt = new Date().toISOString();

    await kv.set(`notification_${userId}_${notificationId}`, notification.value);

    return c.json({ success: true });

  } catch (error) {
    console.error('Mark notification read error:', error);
    return c.json({ error: 'Failed to mark notification as read' }, 500);
  }
});

// Mark all notifications as read
app.put('/make-server-9f7745d8/notifications/:userId/read-all', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (!user?.id) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const userId = c.req.param('userId');

    if (user.id !== userId) {
      return c.json({ error: 'Forbidden' }, 403);
    }

    const userNotifications = await kv.getByPrefix(`notification_${userId}_`);
    const timestamp = new Date().toISOString();

    // Update all notifications to read
    const updatePromises = userNotifications.map(async (item) => {
      if (item.value && !item.value.read) {
        const updated = {
          ...item.value,
          read: true,
          readAt: timestamp
        };
        return kv.set(item.key, updated);
      }
    });

    await Promise.all(updatePromises.filter(Boolean));

    return c.json({ success: true, markedCount: userNotifications.length });

  } catch (error) {
    console.error('Mark all notifications read error:', error);
    return c.json({ error: 'Failed to mark all notifications as read' }, 500);
  }
});

// Create notification
app.post('/make-server-9f7745d8/notifications', async (c) => {
  try {
    const { userId, type, title, message, actionRequired, relatedItem, sender } = await c.req.json();

    if (!userId || !type || !title || !message) {
      return c.json({ error: 'userId, type, title, and message are required' }, 400);
    }

    const notificationId = `notif_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const notification = {
      id: notificationId,
      type,
      title,
      message,
      timestamp: new Date().toISOString(),
      read: false,
      actionRequired: actionRequired || false,
      relatedItem: relatedItem || null,
      sender: sender || null
    };

    await kv.set(`notification_${userId}_${notificationId}`, notification);

    // Get user notification settings to check if they want this type
    const userSettings = await kv.get(`notification_settings_${userId}`);
    const settings = userSettings?.value || {};

    // Send push notification if enabled and supported
    if (settings.pushNotifications && shouldSendNotification(type, settings)) {
      await sendPushNotification(userId, notification);
    }

    // Send email notification if enabled
    if (settings.emailNotifications && shouldSendEmailNotification(type, settings)) {
      await scheduleEmailNotification(userId, notification);
    }

    return c.json({ success: true, notification });

  } catch (error) {
    console.error('Create notification error:', error);
    return c.json({ error: 'Failed to create notification' }, 500);
  }
});

// Get notification settings
app.get('/make-server-9f7745d8/notifications/:userId/settings', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (!user?.id) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const userId = c.req.param('userId');

    if (user.id !== userId) {
      return c.json({ error: 'Forbidden' }, 403);
    }

    const userSettings = await kv.get(`notification_settings_${userId}`);
    
    // Default settings
    const defaultSettings = {
      auctionEnding: true,
      outbid: true,
      auctionWon: true,
      messages: true,
      follows: true,
      priceDrops: true,
      newListings: false,
      reviews: true,
      emailNotifications: true,
      pushNotifications: true,
      endingReminder: 15,
      priceDropThreshold: 10
    };

    const settings = userSettings?.value || defaultSettings;

    return c.json(settings);

  } catch (error) {
    console.error('Get notification settings error:', error);
    return c.json({ error: 'Failed to get notification settings' }, 500);
  }
});

// Update notification settings
app.put('/make-server-9f7745d8/notifications/:userId/settings', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (!user?.id) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const userId = c.req.param('userId');

    if (user.id !== userId) {
      return c.json({ error: 'Forbidden' }, 403);
    }

    const newSettings = await c.req.json();
    
    // Get existing settings
    const existingSettings = await kv.get(`notification_settings_${userId}`);
    const settings = {
      ...(existingSettings?.value || {}),
      ...newSettings,
      updatedAt: new Date().toISOString()
    };

    await kv.set(`notification_settings_${userId}`, settings);

    return c.json({ success: true, settings });

  } catch (error) {
    console.error('Update notification settings error:', error);
    return c.json({ error: 'Failed to update notification settings' }, 500);
  }
});

// Delete notification
app.delete('/make-server-9f7745d8/notifications/:userId/:notificationId', async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (!user?.id) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const userId = c.req.param('userId');
    const notificationId = c.req.param('notificationId');

    if (user.id !== userId) {
      return c.json({ error: 'Forbidden' }, 403);
    }

    await kv.del(`notification_${userId}_${notificationId}`);

    return c.json({ success: true });

  } catch (error) {
    console.error('Delete notification error:', error);
    return c.json({ error: 'Failed to delete notification' }, 500);
  }
});

// Auction ending reminder system
app.post('/make-server-9f7745d8/notifications/auction-reminder', async (c) => {
  try {
    const { auctionId, endTime } = await c.req.json();

    console.log('Setting up auction ending reminders for:', auctionId, endTime);

    // Get all users watching this auction
    const watchers = await kv.get(`auction_watchers_${auctionId}`);
    const watcherIds = watchers?.value || [];

    // Schedule reminders for each watcher
    const reminderPromises = watcherIds.map(async (userId: string) => {
      const userSettings = await kv.get(`notification_settings_${userId}`);
      const settings = userSettings?.value || {};

      if (settings.auctionEnding) {
        const reminderTime = settings.endingReminder || 15; // minutes
        const reminderDate = new Date(new Date(endTime).getTime() - reminderTime * 60 * 1000);

        // Only schedule if reminder time is in the future
        if (reminderDate > new Date()) {
          const reminderId = `reminder_${auctionId}_${userId}_${reminderTime}`;
          const reminder = {
            id: reminderId,
            auctionId,
            userId,
            reminderTime: reminderDate.toISOString(),
            type: 'auction_ending',
            scheduled: true
          };

          await kv.set(`scheduled_reminder_${reminderId}`, reminder);
        }
      }
    });

    await Promise.all(reminderPromises);

    return c.json({ success: true, remindersScheduled: watcherIds.length });

  } catch (error) {
    console.error('Schedule auction reminder error:', error);
    return c.json({ error: 'Failed to schedule auction reminders' }, 500);
  }
});

// Helper functions
function shouldSendNotification(type: string, settings: any): boolean {
  const typeMap: { [key: string]: string } = {
    'auction_ending': 'auctionEnding',
    'outbid': 'outbid',
    'auction_won': 'auctionWon',
    'message': 'messages',
    'follow': 'follows',
    'price_drop': 'priceDrops',
    'new_listing': 'newListings',
    'review': 'reviews'
  };

  const settingKey = typeMap[type];
  return settingKey ? settings[settingKey] !== false : true;
}

function shouldSendEmailNotification(type: string, settings: any): boolean {
  // Only send email for important notifications
  const emailTypes = ['auction_ending', 'outbid', 'auction_won', 'review'];
  return emailTypes.includes(type) && shouldSendNotification(type, settings);
}

async function sendPushNotification(userId: string, notification: any) {
  // In a real implementation, this would send push notifications
  // For now, we'll just log
  console.log('Push notification would be sent to:', userId, notification.title);
}

async function scheduleEmailNotification(userId: string, notification: any) {
  // In a real implementation, this would schedule an email
  // For now, we'll just log
  console.log('Email notification would be sent to:', userId, notification.title);
}

export default app;