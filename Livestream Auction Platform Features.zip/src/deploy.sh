#!/bin/bash

# Coral Crave - Quick Deployment Script
echo "🚀 Starting Coral Crave deployment..."

# Check if environment variables are set
if [ -z "$SUPABASE_URL" ] || [ -z "$SUPABASE_ANON_KEY" ]; then
    echo "❌ Missing Supabase environment variables"
    echo "Please set SUPABASE_URL and SUPABASE_ANON_KEY"
    exit 1
fi

if [ -z "$AGORA_APP_ID" ] || [ -z "$PAYPAL_CLIENT_ID" ]; then
    echo "❌ Missing required API keys"
    echo "Please set AGORA_APP_ID and PAYPAL_CLIENT_ID"
    exit 1
fi

# Install dependencies
echo "📦 Installing dependencies..."
npm install

# Type check
echo "🔍 Running type check..."
npm run type-check

# Build for production
echo "🏗️ Building for production..."
npm run build

# Test the build
echo "🧪 Testing build..."
npm run preview &
PREVIEW_PID=$!
sleep 5

# Check if preview server is running
if curl -f http://localhost:4173 > /dev/null 2>&1; then
    echo "✅ Build test successful"
    kill $PREVIEW_PID
else
    echo "❌ Build test failed"
    kill $PREVIEW_PID
    exit 1
fi

echo "🎉 Build ready for deployment!"
echo ""
echo "Next steps:"
echo "1. Deploy to your platform (Vercel/Netlify/etc.)"
echo "2. Configure environment variables"
echo "3. Set up OAuth redirect URLs"
echo "4. Initialize database with: curl -X POST https://your-domain.com/functions/v1/make-server-9f7745d8/init-database"
echo ""
echo "📖 See DEPLOYMENT_GUIDE.md for detailed instructions"